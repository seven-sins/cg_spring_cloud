package com.infox.tourism.dao;

import org.apache.ibatis.annotations.Mapper;

import com.infox.tourism.entity.DestinationInfoEntity;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 目的地维护表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-06 17:10:28
 */
@Mapper
public interface DestinationInfoDao extends BaseMapper<DestinationInfoEntity> {

    

}
