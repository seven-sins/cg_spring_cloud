package com.infox.tourism.config.resolver;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.core.MethodParameter;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.ModelAndViewContainer;

import com.alibaba.fastjson.JSONObject;
import com.infox.common.exception.CustomException;
import com.infox.common.utils.redis.RedisConstant;
import com.infox.common.utils.redis.RedisDistributedLock;
import com.infox.common.utils.redis.RedisService;
import com.infox.tourism.entity.UserInfoEntity;
import com.infox.tourism.service.UserInfoService;

/**
 * 将当前登录用户信息自动注入
 * @author Tan Ling
 * 2018年12月5日 上午11:01:27
 */
public class UserArgumentResolver implements HandlerMethodArgumentResolver{
	static final String LOCK_KEY_PREFIX = "lock_";
	private RedisService redisService;
	private UserInfoService userInfoService;
    private RedisDistributedLock redisDistributedLock;
	
	@Override
	public boolean supportsParameter(MethodParameter parameter) {
		return parameter.getParameterType().equals(AuthUser.class) || parameter.getParameterType().equals(Guest.class);
	}

	@Override
	public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer,
			NativeWebRequest webRequest, WebDataBinderFactory binderFactory) throws Exception {
		if(redisService == null) {
			redisService = SpringUtil.getBean("redisServiceImpl", RedisService.class);
			if(redisService == null) {
				throw new CustomException("获redisService失败");
			}
		}
		
		if(redisDistributedLock == null) {
			redisDistributedLock = SpringUtil.getBean("redisDistributedLockImpl", RedisDistributedLock.class);
			if(redisDistributedLock == null) {
				throw new CustomException("获取redisDistributedLock失败");
			}
		}
		
		if(userInfoService == null) {
			userInfoService = SpringUtil.getBean("userInfoServiceImpl", UserInfoService.class);
			if(userInfoService == null) {
				throw new CustomException("获取userInfoService失败");
			}
		}
		
		HttpServletRequest request = webRequest.getNativeRequest(HttpServletRequest.class);
		if (parameter.getParameterType().equals(AuthUser.class)) {
			return getAuthUser(request);
		} else if (parameter.getParameterType().equals(Guest.class)) {
			return getGuestUser(request);
		}
		
		return null;
	}
	
	private Guest getGuestUser(HttpServletRequest request) {
		String token = request.getHeader("token");
		if(StringUtils.isBlank(token)) {
			return new Guest();
		}
		
		String openId = (String) redisService.get(RedisConstant.WECHAT_OPENID_PREFIX + token);
		if(StringUtils.isBlank(openId)) {
			return new Guest();
		}
		
		UserInfoEntity userInfo = userInfoService.getByUnionId(openId);
		if(userInfo == null) {
			Guest guest = new Guest();
			guest.setOpenId(openId);
			return guest;
		}
		
		return converObjectToGuest(userInfo);
	}
	
	private AuthUser getAuthUser(HttpServletRequest request) {
		String token = request.getHeader("token");
		if(StringUtils.isBlank(token)) {
			throw new CustomException("token不能为空");
		}
		
		String openId = (String) redisService.get(RedisConstant.WECHAT_OPENID_PREFIX + token);
		if(StringUtils.isBlank(openId)) {
			throw new CustomException("token过期");
		}
		
		/**
		 * 用户登录正常情况下, openId中的值是unionId(下面的接口会把openId替换为unionId)
		 */
		redisDistributedLock.get(LOCK_KEY_PREFIX + token, null);
		UserInfoEntity userInfo;
		try {
			userInfo = userInfoService.findUserInfoByOpenId(token, openId);
		} catch(Exception e) {
			if(e instanceof CustomException) {
				throw e;
			}
			throw new CustomException("获取用户信息出错");
		} finally {
			redisDistributedLock.release(LOCK_KEY_PREFIX + token);
		}
		
		if(userInfo == null) {
			throw new CustomException("使用openId从数据库获取用户信息失败");
		}
		
		return converObjectToAuthUser(userInfo);
	}
	
	public AuthUser converObjectToAuthUser(UserInfoEntity userInfo) {
		String userStr = JSONObject.toJSONString(userInfo);
		return JSONObject.parseObject(userStr, AuthUser.class);
	}
	
	public Guest converObjectToGuest(UserInfoEntity userInfo) {
		String userStr = JSONObject.toJSONString(userInfo);
		return JSONObject.parseObject(userStr, Guest.class);
	}

}
