package com.infox.tourism.service.v2.travel.note.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infox.common.base.impl.BaseServiceImpl;
import com.infox.tourism.entity.travel.note.TravelNoteDetail;
import com.infox.tourism.mapper.travel.note.TravelNoteDetailMapper;
import com.infox.tourism.service.v2.travel.note.TravelNoteDetailService;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 记录明细
 * @author Tan Ling
 * @date 2019年7月5日 下午3:35:34
 */
@Service
public class TravelNoteDetailServiceImpl extends BaseServiceImpl<TravelNoteDetail> implements TravelNoteDetailService {

	@Autowired
	TravelNoteDetailMapper travelNoteDetailMapper;
	
	@Resource
	@Override
	public void setBaseMapper(BaseMapper<TravelNoteDetail> baseMapper) {
		this.baseMapper = baseMapper;
	}

	@Override
	public List<TravelNoteDetail> find(TravelNoteDetail travelNoteDetail) {
		return travelNoteDetailMapper.find(travelNoteDetail);
	}

}
