package com.infox.tourism.dao;

import org.apache.ibatis.annotations.Mapper;

import com.infox.tourism.entity.IntegralPayEntity;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 积分兑换表
 * 
 * @author Tan Ling 2018年12月15日 下午1:31:21
 */
@Mapper
public interface IntegralPayDao extends BaseMapper<IntegralPayEntity> {

}
