package com.infox.tourism.service.v2.activity.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.infox.common.base.impl.BaseServiceImpl;
import com.infox.tourism.entity.activity.LineImages;
import com.infox.tourism.service.v2.activity.LineImagesService;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 产品图片
 * @author Tan Ling
 * @date 2019年7月17日 上午9:57:29
 */
@Service
public class LineImagesServiceImpl extends BaseServiceImpl<LineImages> implements LineImagesService {

	@Resource
	@Override
	public void setBaseMapper(BaseMapper<LineImages> baseMapper) {
		this.baseMapper = baseMapper;
	}

}
