package com.infox.tourism.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.dao.CollectDao;
import com.infox.tourism.entity.CollectEntity;
import com.infox.tourism.entity.vo.UserVO.CollectVO;
import com.infox.tourism.service.CollectService;
import com.infox.tourism.util.DateUtil;
import com.infox.tourism.util.UUIDUtil;

/**
 * 收藏表
 *
 * @author
 * @email @163.com
 * @date 2018-12-10 8:46:05
 */
@Service(" CollectService")
public class CollectServiceImpl implements CollectService {

	/**
	 * collectDao层
	 * 
	 * @param params
	 * @return
	 */
	@Autowired
	private CollectDao collectDao;

	@Override
	public CollectEntity selectById(String travelsActivityId, String userId, String collectType) {
		return collectDao.selectById(travelsActivityId, userId, collectType);
	}

	@Override
	public boolean insert(CollectEntity collectEntity) {
		collectEntity.setCollectUserId(UUIDUtil.create());

		int insert = 0;
		insert = collectDao.insert(collectEntity);

		if (insert > 0) {
			return true;
		}
		return false;
	}

	@Override
	public boolean updateById(CollectEntity collectEntity, AuthUser user) {
		int i = 0;
		boolean r = false;
		CollectEntity collectEntity2 = new CollectEntity();
		// try {
		// System.out.println(collectEntity.getTravelsActivityId());
		collectEntity2 = this.selectById(collectEntity.getTravelsActivityId(), user.getUserId(),
				collectEntity.getCollectType());
		if (collectEntity2 != null) {
			collectEntity.setCollectUserId(collectEntity2.getCollectUserId());
			collectEntity.setUpdateTime(DateUtil.getYYYYMMDDHHMMSS());
			i = collectDao.updateById(collectEntity);
		} else {
			collectEntity.setIsEnable("1");
			collectEntity.setUserId(user.getUserId());
			collectEntity.setCollectUserId(UUIDUtil.create());
			collectEntity.setCreateTime(DateUtil.getYYYYMMDDHHMMSS());
			r = this.insert(collectEntity);
		}
//		} catch (Exception e) {
//			// throw new RRException("收藏模块，updateById方法有异常请联系管理员！");
//		}
		if (i > 0 || r) {
			return true;
		}
		return false;
	}

	/**
	 * 我的收藏 活动 AND 游记
	 * 
	 * @param userId
	 * @param collectType
	 * @return
	 */
	@Override
	public List<CollectVO> selectByUserId(String userId, Integer collectType, int pageNum, int pageSize) {
		PageHelper.startPage(pageNum, pageSize);
		List<CollectVO> list = new ArrayList<>();

		// 活动 类型1活动、2游记
		if (collectType.equals(1)) {
			list = collectDao.selectByActivity(userId, collectType);
		} else if (collectType.equals(2)) {
			list = collectDao.selectTravels(userId, collectType);
		} else {
			return null;
		}

		return list;
	}

	/**
	 * 取消收藏
	 * 
	 * @return
	 */
	@Override
	public boolean updateEnable(CollectEntity collectEntity, AuthUser user) {
		collectEntity.setIsEnable("0");
		collectEntity.setUserId(user.getUserId());
		collectEntity.setUpdateTime(DateUtil.getYYYYMMDDHHMMSS());
		boolean b = collectDao.updateEnable(collectEntity);
		return b;
	}

}
