package com.infox.tourism.controller.userInfoController;

import com.github.pagehelper.PageInfo;
import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.entity.vo.UserVO.AttentionVO;
import com.infox.tourism.service.AttentionService;
import com.infox.tourism.util.R;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

import java.util.HashMap;
import java.util.List;

/**
 * @Author: cenjinxing
 * @Date: Created in 2018/12/12 18:06
 **/
@RestController
@RequestMapping("/myAttention")
@Api(description = "我的关注领队",tags = {"MyAttentionController"})
public class MyAttentionController {

    @Autowired
    private AttentionService attentionService;


    @ApiOperation(value = "我的关注领队", response = AttentionVO.class)
    @GetMapping("/attention")
    public R attention(@ApiIgnore AuthUser authUser, int pageNum , int pageSize) {
        List<AttentionVO> list = attentionService.selectByAttentionPeople(authUser.getUserId(),pageNum,pageSize);

        PageInfo<AttentionVO> pageInfo = new PageInfo<>(list);

        HashMap<Object, Object> map = new HashMap<>();
        map.put("list",list);
        map.put("total",pageInfo.getTotal());


        return R.ok().put("data", map);
    }
}
