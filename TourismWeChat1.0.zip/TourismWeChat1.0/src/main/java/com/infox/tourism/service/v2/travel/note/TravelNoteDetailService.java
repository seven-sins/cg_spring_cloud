package com.infox.tourism.service.v2.travel.note;

import java.util.List;

import com.infox.common.base.BaseService;
import com.infox.tourism.entity.travel.note.TravelNoteDetail;

/**
 * 游记明细
 * @author Tan Ling
 * @date 2019年7月5日 下午3:30:43
 */
public interface TravelNoteDetailService extends BaseService<TravelNoteDetail> {

	/**
	 * 查询游记明细
	 * @author Tan Ling
	 * @date 2019年7月5日 下午3:37:44
	 * @param travelNoteDetail
	 * @return
	 */
	List<TravelNoteDetail> find(TravelNoteDetail travelNoteDetail);
}
