package com.infox.tourism.controller.userInfoController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageInfo;
import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.entity.vo.evaluation.EvaluationVO;
import com.infox.tourism.service.EvaluationService;
import com.infox.tourism.util.R;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

/**
 * @Author: cenjinxing
 * @Date: Created in 2018/12/8 15:39
 **/
@RestController
@RequestMapping("/myevaluation")
@Api(description = "我的_评价接口",tags = {"MyEvaluationController"})
public class MyEvaluationController {

    /**
     * 评价
     */
    @Autowired
    private EvaluationService evaluationService;

    @ApiOperation(value = "根据openid查询未使用的评价列表",response = EvaluationVO.class)
    @GetMapping("/evaluationList")
    public R evaluationList(@ApiIgnore AuthUser authUser, int pageNum, int pageSize){
        List<EvaluationVO> list = evaluationService.selectByUserId(pageNum,pageSize,authUser.getUserId());

        PageInfo<EvaluationVO> pageInfo = new PageInfo<>(list);

        Map<String, Object> map = new HashMap<>();

        map.put("list",list);
        map.put("total",pageInfo.getTotal());

        return R.ok().put("data",map);
    }

}
