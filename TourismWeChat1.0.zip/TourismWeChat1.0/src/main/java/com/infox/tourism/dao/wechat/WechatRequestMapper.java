package com.infox.tourism.dao.wechat;

import org.apache.ibatis.annotations.Mapper;

import com.infox.tourism.entity.wechat.WechatRequest;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 记录微信接口请求次数
 * @author Tan Ling
 * 2019年1月4日 上午11:04:12
 */
@Mapper
public interface WechatRequestMapper extends BaseMapper<WechatRequest> {

	public void updateRequestNum();
}
