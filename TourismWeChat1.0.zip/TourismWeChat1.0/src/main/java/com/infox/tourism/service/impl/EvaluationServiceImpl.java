package com.infox.tourism.service.impl;

import java.util.Date;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.infox.common.exception.CustomException;
import com.infox.common.utils.Assert;
import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.dao.EvaluationDao;
import com.infox.tourism.dao.OrderInfoDao;
import com.infox.tourism.dao.activity.ActivityLeaderMapper;
import com.infox.tourism.entity.ActivityLeaderRelation;
import com.infox.tourism.entity.EvaluationEntity;
import com.infox.tourism.entity.vo.OrderVO.OrderVO;
import com.infox.tourism.entity.vo.activityDetailVO.LineEvaluationVO;
import com.infox.tourism.entity.vo.baseVo.CommentVO;
import com.infox.tourism.entity.vo.evaluation.EvaluationVO;
import com.infox.tourism.service.EvaluationService;
import com.infox.tourism.util.DateUtil;
import com.infox.tourism.util.UUIDUtil;

/**
 * 评价表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-15 11:31:27
 */
@Service("evaluationService")
public class EvaluationServiceImpl implements EvaluationService {
	@Autowired
	private EvaluationDao evaluationDao;
	@Autowired
	private OrderInfoDao orderInfoDao;
	@Autowired
	private ActivityLeaderMapper activityLeaderMapper;

	@Override
	public List<EvaluationVO> selectByUserId(int pageNum, int pageSize, String userId) {
		PageHelper.startPage(pageNum, pageSize);
		List<EvaluationVO> list = evaluationDao.selectByUserId(userId);
		for (EvaluationVO vo : list) {
			// 计算平均分
			Integer sum = (vo.getLeaderSatisfaction() + vo.getLineSatisfaction() + vo.getTrafficSatisfaction()) / 3;
			vo.setSum(sum);
			// 查询领队
			List<ActivityLeaderRelation> leaders = activityLeaderMapper.findActivityLeaderByActivityId(vo.getActivityId());
			vo.setNickName(this.refactorLeaderName(leaders));
		}
		
		return list;
	}

	@Override
	public LineEvaluationVO selectEvaluationByLineId(String lineId) {
		LineEvaluationVO lineEvaluationVO = evaluationDao.selectEvaluationByLineId(lineId);
		return lineEvaluationVO;
	}

	@Override
	public List<CommentVO> selectCommonListByLineId(String lineId) {
		List<CommentVO> list = evaluationDao.selectCommonListByLineId(lineId);
		return list;
	}

	/**
	 * 保存活动评价
	 * 
	 * @param orderVO
	 * @return
	 */
	@Override
	public boolean insertActivityEvaluation(OrderVO orderVO, AuthUser user) {
		EvaluationEntity evaluationEntity = new EvaluationEntity();

		try {
			BeanUtils.copyProperties(evaluationEntity, orderVO);
		} catch (Exception e) {
			throw new CustomException("添加评价时复制属性出错" + e.getMessage());
		} 
		/**
		 * 只给活动主领添加评价
		 */
		Assert.notEmpty(orderVO.getActivityId(), "参数错误, 活动ID不能为空");
		List<ActivityLeaderRelation> leaders = activityLeaderMapper.findActivityLeaderByActivityId(orderVO.getActivityId());
		Assert.isTrue(leaders != null && !leaders.isEmpty(), "数据异常, 活动没有设置领队");

		evaluationEntity.setLeaderId(leaders.get(0).getLeaderId());
		evaluationEntity.setEvaluationId(UUIDUtil.create());
		evaluationEntity.setCreateTime(DateUtil.getYYYYMMDDHHMMSS());
		evaluationEntity.setAuditStatus(0);
		evaluationEntity.setEvaluationTime(new Date());
		evaluationEntity.setBackStatus(0);
		evaluationEntity.setIsDelete(1);
		evaluationEntity.setUserId(user.getUserId());
		evaluationDao.insert(evaluationEntity);
		//
		orderInfoDao.updateEvaluationStatusByOrderId(orderVO.getOrderId());
		orderInfoDao.updateByActivityId(orderVO.getOrderId(), 1);
		
		return true;
	}

	@Override
	public EvaluationEntity selectEvaluationByActivityId(String userId, String activityId) {
		return evaluationDao.selectEvaluationByActivityId(userId, activityId);
	}
	
	private String refactorLeaderName(List<ActivityLeaderRelation> leaders) {
		if(leaders == null || leaders.isEmpty()) {
			return "";
		}
		String name = "";
		for(ActivityLeaderRelation item: leaders) {
			name += item.getLeaderNickName() + ",";
		}
		return name.replaceFirst("\\,$", "");
	}
}
