package com.infox.tourism.service;

import java.util.HashMap;
import java.util.List;

import com.infox.tourism.entity.vo.lineVO.LineDurationCache;
import com.infox.tourism.entity.vo.lineVO.LineVo;

public interface LineService {

    HashMap<String,Object> selectLineCoverImg(String lineId);

    /**查找线路下所有图片的所有图片*/
    @SuppressWarnings("rawtypes")
	List selectImgListByLineId(String lineId);

    /**
     * 查询所有线路的时长, 缓存1分钟
     * @author Tan Ling
     * @date 2019年1月21日 下午5:35:16
     * @return
     */
    List<LineDurationCache> selectAllLineDurationTime();
    
    /**
     * 查询推荐线路
     * @author Tan Ling
     * @date 2019年7月23日 下午5:35:25
     * @return
     */
    List<LineVo> selectRecommendLine(String companyId);
}
