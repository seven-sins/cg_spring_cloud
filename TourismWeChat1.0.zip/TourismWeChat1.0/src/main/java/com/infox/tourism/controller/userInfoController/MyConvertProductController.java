package com.infox.tourism.controller.userInfoController;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.entity.VoucherBaseInformationEntity;
import com.infox.tourism.entity.vo.couponVo.VoucherVo;
import com.infox.tourism.service.VoucherBaseInformationService;
import com.infox.tourism.service.VoucherService;
import com.infox.tourism.util.R;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.util.HashMap;
import java.util.List;

/**
 * @Author: cenjinxing
 * @Date: Created in 2018/12/10 14:50
 **/
@RestController
@RequestMapping("/myConvertProduct")
@Api(description = "我的_积分商城接口",tags = {"MyConvertProductController"})
public class MyConvertProductController {

    /**
     * 优惠券
     */
    @Autowired
    private VoucherBaseInformationService voucherBaseInformationService;

    /**
     * 兑换记录
     */
    @Autowired
    private VoucherService voucherService;

    /**
     * 兑换商品
     * @param
     * @return
     */
    @ApiOperation(value = "兑换商品",response = VoucherVo.class)
    @GetMapping("/convertProductList")
    public R convertProductList(int pageNum, int pageSize){

        List<VoucherVo> list = voucherBaseInformationService.convertProductList(pageNum, pageSize);

        PageInfo<VoucherVo> pageInfo = new PageInfo<>(list);

        HashMap<String, Object> map = new HashMap<>();
        map.put("total",pageInfo.getTotal());
        map.put("list",list);

        return R.ok().put("data",map);
    }

    /**
     * 立即兑换
     * @return
     */
    @ApiOperation(value = "立即兑换",response = VoucherVo.class)
    @PostMapping("/updateIsNeedScord")
    public R updateIsNeedScord(@RequestBody VoucherBaseInformationEntity voucherBaseInformationEntity,@ApiIgnore AuthUser authUser){
        voucherBaseInformationService.updateIsNeedScord(voucherBaseInformationEntity,authUser.getUserId());
        return R.ok();
    }

    @ApiOperation(value = "兑换记录",response = VoucherVo.class)
    @GetMapping("/selectVoucherReceiveByOpenId")
    public R selectVoucherReceiveByOpenId(@ApiIgnore AuthUser authUser,int pageNum, int pageSize){
        PageHelper.startPage(pageNum,pageSize);
        List<VoucherVo> list = voucherService.selectVoucherReceiveByUserId(authUser.getUserId());
        return R.ok().put("data",list).put("total",new PageInfo<>(list).getTotal());
    }
}
