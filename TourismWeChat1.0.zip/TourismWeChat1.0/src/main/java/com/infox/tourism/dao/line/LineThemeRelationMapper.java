package com.infox.tourism.dao.line;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.infox.tourism.entity.LineThemeRelation;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 线路和线路主题关系表
 * @author Tan Ling
 * @date 2019年1月25日 下午1:38:04
 */
@Mapper
public interface LineThemeRelationMapper extends BaseMapper<LineThemeRelation> {
	
	/**
	 * 根据线路删除
	 * @author Tan Ling
	 * @date 2019年1月25日 下午1:40:07
	 * @param lineId
	 */
	void deleteByLineId(@Param("lineId") String lineId);
	
	/**
	 * 根据线路ID查询
	 * @author Tan Ling
	 * @date 2019年1月25日 下午1:42:37
	 * @param lineId
	 * @return
	 */
	List<LineThemeRelation> queryByLineId(@Param("lineId") String lineId);
	
}
