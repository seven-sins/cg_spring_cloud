package com.infox.tourism.service.impl;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.infox.common.base.impl.BaseServiceImpl;
import com.infox.common.exception.CustomException;
import com.infox.common.utils.Assert;
import com.infox.tourism.dao.ActivityInfoDao;
import com.infox.tourism.dao.ActivityRulesDao;
import com.infox.tourism.dao.ActivitySingleRecordDao;
import com.infox.tourism.entity.ActivityInfoEntity;
import com.infox.tourism.entity.ActivityRulesEntity;
import com.infox.tourism.entity.ActivitySingleRecordEntity;
import com.infox.tourism.entity.UserInfoEntity;
import com.infox.tourism.entity.vo.activity.ActivitySingleRecordVo;
import com.infox.tourism.entity.vo.single.ActivitySingleRecordInitiator;
import com.infox.tourism.service.ActivitySingleRecordService;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 拼单活动记录
 * @author Tan Ling
 * 2018年12月8日 下午1:39:55
 */
@Service("activitySingleRecordService")
public class ActivitySingleRecordServiceImpl extends BaseServiceImpl<ActivitySingleRecordEntity> implements ActivitySingleRecordService {
    
	@Autowired
	ActivityInfoDao activityInfoDao;
	@Autowired
	ActivitySingleRecordDao activitySingleRecordDao;
	@Autowired
	ActivityRulesDao activityRulesDao;
	
    @Resource
    public void setBaseMapper(BaseMapper<ActivitySingleRecordEntity> activitySingleRecordDao) {
		this.baseMapper = activitySingleRecordDao;
	}

    /**
        * 查询分页
    * @param pageNum
    * @param pageSize
    * @param search
    * @return
    */
    @Override
    public List<ActivitySingleRecordEntity> queryPage(int pageNum, int pageSize, String search){
        // 使用分页插件实现分页
        PageHelper.startPage(pageNum,pageSize);
        // 调用dao的方法

        return null;
    }

	@Override
	public void insert(UserInfoEntity user, ActivitySingleRecordEntity entity) {
		ActivityInfoEntity activity = activityInfoDao.getByActivityId(entity.getActivityId());
		if(activity == null) {
			throw new CustomException("活动不存在");
		}
		entity.setOriginalPrice(activity.getAdultPrice());
		entity.setUserId(user.getUserId());
		
		activityInfoDao.insert(activity);
	}

	@Override
	public List<ActivitySingleRecordVo> findSingleRecordListByActivityId(int pageNum, int pageSize, String activityId) {
		PageHelper.startPage(pageNum, pageSize);
		List<ActivitySingleRecordVo> list = activitySingleRecordDao.findSingleRecordListByActivityId(activityId);
		for(ActivitySingleRecordVo item: list) {
			item.setUnitTime(String.valueOf(this.getSecond(item.getUnitTime())));
			Assert.notNull(item.getUnitNum(), "数据异常, 拼单人数为空");
			// 判定拼单是否过期
			Assert.notNull(item.getCreateTime(), "数据异常, 拼单创建时间为空");
			if((new Date().getTime() / 1000 - item.getCreateTime().getTime() / 1000) > Long.parseLong(item.getUnitTime())) {
				// 1:拼单正常时间, 2:拼单过期
				item.setAsrStatus(2);
			} else {
				item.setAsrStatus(1);
			}
		}
		
		return list;
	};

	@Override
	public List<ActivitySingleRecordInitiator> findSingleRecordListMoreByActivityId(int pageNum, int pageSize, String activityId) {
		PageHelper.startPage(pageNum, pageSize);
		List<ActivitySingleRecordInitiator> list = activitySingleRecordDao.findSingleRecordListMoreByActivityId(activityId);
		ActivityRulesEntity activityRulesEntity = activityRulesDao.selectByActivityId(activityId);
		if(activityRulesEntity == null) {
			return list;
		}
		if(list == null || list.isEmpty()) {
			return list;
		}
		Assert.isTrue(activityRulesEntity.getUnitNum() != null, "数据异常, 组队所需人数为空");
		if(activityRulesEntity.getMaxUnitNum() == null) {
			activityRulesEntity.setMaxUnitNum(activityRulesEntity.getUnitNum());
		}
		for(ActivitySingleRecordInitiator item: list) {
			// 组队成功
			if(item.getRemainNum() != null && item.getRemainNum() <= 0) {
				item.setIsSuccess(1);
			}
			// 组队满员
			int full = activityRulesEntity.getMaxUnitNum() - (activityRulesEntity.getUnitNum() - item.getRemainNum());
			if(full <= 0) {
				item.setIsFull(1);
			}
		}
		
		return list;
	}
	
	private long getSecond(String unitTime) {
		long time = 0L;
		try {
			Assert.notEmpty(unitTime, "数据异常,  活动拼单时间为空");
			// 数据库存储的 x 为分, 返回时间要求为秒, 所以*60
			time = Long.parseLong(unitTime) * 60;
		}catch(Exception e) {
			if(e instanceof CustomException) {
				throw e;
			}
			e.printStackTrace();
			throw new CustomException("解析拼单时间出错, " + e.getMessage());
		}
		
		return time;
	}


}
