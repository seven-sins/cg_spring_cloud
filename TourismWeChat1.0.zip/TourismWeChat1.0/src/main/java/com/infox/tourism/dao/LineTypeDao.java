package com.infox.tourism.dao;

import com.infox.tourism.entity.LineTypeEntity;
import com.infox.tourism.entity.vo.lineVO.LineTypeVO;
import org.apache.ibatis.annotations.Mapper;
import tk.mybatis.mapper.common.BaseMapper;

import java.util.List;

/**
 * 路线分类表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-06 17:10:28
 */
@Mapper
public interface LineTypeDao extends BaseMapper<LineTypeEntity> {

    /**
    * 查询分页
    * @return
    */
    List<LineTypeEntity> queryPage();
    /**
     * 根据排序查询
     * @return
     */
    LineTypeEntity selectBySorting(Integer ltSorting);

    /**
     * 根据id查询
     * @param lineTypeId
     * @return
     */
    LineTypeEntity selectById(String lineTypeId);

    /**
     * 根据id修改
     */
    int updateById(LineTypeEntity lineTypeEntity);

    /**
     * 删除全部轮播图
     * @param lineTypeEntity
     * @return
     */
    boolean deleteList(LineTypeEntity lineTypeEntity);

    /**
     * 下拉框线路类型
     * @return
     */
    List<LineTypeEntity> lineTypeDropDownBox();


    List<LineTypeVO> selectAllLineType();

    List<LineTypeVO> selectTop3LineType();
}
