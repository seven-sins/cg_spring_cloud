package com.infox.tourism.service.wechat.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infox.tourism.dao.wechat.WechatRequestMapper;
import com.infox.tourism.service.wechat.WechatRequestService;

/**
 * 统计调用微信接口次数
 * @author Tan Ling
 * 2019年1月4日 上午11:08:15
 */
@Service
public class WechatRequestServiceImpl implements WechatRequestService {

	@Autowired
	WechatRequestMapper wechatRequestMapper;
	
	@Override
	public void updateRequestNum() {
		wechatRequestMapper.updateRequestNum();
	}

}
