package com.infox.tourism.config.resolver;

import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.infox.common.exception.CustomException;
import com.infox.common.utils.DateUtils;

/**
 * 拦截输出异常堆栈
 * @author Tan Ling
 * 2018年12月14日 上午9:18:58
 */
@Aspect
@Component
@Order(1)
public class RequestAop {
	static final Logger LOG = LoggerFactory.getLogger(RequestAop.class);
	@Autowired
	private KafkaTemplate<String, String> kafkaTemplate;
	/**
	 * 是否记录到kafka
	 */
	@Value("${kafka.log2kafka:false}")
	private Boolean log2kafka;
	/**
	 * 统计接口耗时
	 */
	@Value("${kafka.topic}")
	private String topic;
	
	@Pointcut("execution(* com.infox..*.*Controller.*(..))")
	public void init() {
		
	}
	
	@Before("init()")
	public void beforeAdvice(JoinPoint joinPoint) {
		// 进入方法前拦截
		// printUrl(false);
	}
	
	@Around("init()")
    public Object around(ProceedingJoinPoint pjp){
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		/**
		 * 输出url
		 */
		String url = request.getRequestURI();
		long startTime = System.currentTimeMillis();
		Object obj = null;
		String bodyArgs = this.bodyArgs2String(pjp.getArgs(), url);
		JSONObject urlArgs = this.urlArgs2String(request, request.getParameterNames(), url);
		try {
			obj = pjp.proceed();
		} catch (Throwable e) {
			long endTime = System.currentTimeMillis();
			if(e instanceof CustomException) {
				/**
				 * 拦截到主动抛出的异常
				 */
				CustomException ex = (CustomException) e;
				this.logInfo2Kafka(request, url, bodyArgs, urlArgs, ex.getMsg(), 400, endTime - startTime, false);
				throw ex;
			} else {
				/**
				 * 拦截到未知异常
				 */
				this.logInfo2Kafka(request, url, bodyArgs, urlArgs, "未捕获异常" + e.getMessage(), 500, endTime - startTime, false);
				throw new CustomException("未捕获异常," + e.getMessage());
			}
		}
		long endTime = System.currentTimeMillis();
		this.logInfo2Kafka(request, url, bodyArgs, urlArgs, "success", 0, endTime - startTime, true);
		
		return obj;
    }
	
	/**
	 * 请录请求耗时
	 * @author Tan Ling
	 * @date 2019年9月12日 上午11:23:35
	 * @param url		请求地址
	 * @param args		requestBody中的参数
	 * @param args2		url中的参数
	 * @param message	消息
	 * @param status	接口调用返回状态
	 * @param executionTime	执行耗时
	 * @param isSuccess	是否调用成功
	 */
	private void logInfo2Kafka(HttpServletRequest request, String url, String bodyArgs, JSONObject urlArgs, String message, Integer status, long executionTime, boolean isSuccess) {
		JSONObject json = new JSONObject();
		json.put("url", url);
		json.put("timestamp", System.currentTimeMillis());
		json.put("visitTime", DateUtils.now2String());
		json.put("message", message);
		json.put("status", status);
		json.put("executionTime", executionTime);
		json.put("channel", request.getHeader("channel"));
		json.put("projectName", "wechat");
		json.put("requestType", request.getMethod());
		/**
		 * 1.requestBody中的参数
		 */
		json.put("bodyArgs", bodyArgs);
		/**
		 * 2.url中的参数
		 */
		json.put("urlArgs", urlArgs);
		/**
		 * 3.如果请求状态不为0, 在控制台输入请求信息
		 */
		if(status != 0) {
			LOG.error("=============请求出错, " + json.toJSONString());
		}
		/**
		 * 4.记录到kafka
		 */
		if(log2kafka) {
			try {
				kafkaTemplate.send(topic, "url_topic", json.toJSONString());
			} catch (Exception e) {
				LOG.error("=============推送消息到kafka出错, " + json.toJSONString());
			}
		}
	}
	
	/**
	 * 读取requestBody中的参数
	 * @author Tan Ling
	 * @date 2019年9月12日 下午2:54:31
	 * @param bodyArgs
	 * @param url
	 * @return
	 */
	private String bodyArgs2String(Object[] bodyArgs, String url) {
		try {
			if(bodyArgs != null && bodyArgs.length > 0) {
				return JSONArray.toJSONString(bodyArgs);
			}
		} catch(Exception e) {
			LOG.error("=============序列化requestBody中的参数出错, " + url);
		}
		return "";
	}
	
	/**
	 * 读取url中的参数
	 * @author Tan Ling
	 * @date 2019年9月12日 下午2:54:40
	 * @param request
	 * @param urlArgs
	 * @param url
	 * @return
	 */
	private JSONObject urlArgs2String(HttpServletRequest request, Enumeration<String> urlArgs, String url) {
		JSONObject urlArgsJson = new JSONObject();
		try {
			if(urlArgs != null) {
				while(urlArgs.hasMoreElements()) {
					try {
						String paraName = (String) urlArgs.nextElement();
						urlArgsJson.put(paraName, request.getParameter(paraName));
					} catch(Exception e) {
						LOG.error("=============记录url中的参数出错", url);
						break;
					}
				}
			}
		}catch(Exception e) {
			LOG.error("=============记录url中的参数出错, " + url);
		}
		return urlArgsJson;
	}
	//	private void printUrl(boolean isError) {
	//		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
	//		/**
	//		 * 输出url
	//		 */
	//		String url = request.getRequestURI();
	//		/**
	//		 * 输出查询参数
	//		 */
	//	    Enumeration<String> enu = request.getParameterNames();
	//	    String params = "";
	//		while(enu.hasMoreElements()) {
	//			try {
	//				String paraName = (String) enu.nextElement();
	//				params += ",  " + paraName + ": " + request.getParameter(paraName);
	//			} catch(Exception e) {
	//				LOG.error("=============输出查询参数出错", e);
	//				break;
	//			}
	//		}
	//		
	//		if (StringUtils.isNotBlank(url) && isError) {
	//			LOG.error("=============request url: " + url);
	//			if(!"".equals(params)) {
	//				params = params.replaceFirst("^\\,", "");
	//				LOG.error("=============请求参数: { " + params + " }");
	//			}
	//		} else {
	//			LOG.info("=============request url: " + url);
	//			if(!"".equals(params)) {
	//				params = params.replaceFirst("^\\,", "");
	//				LOG.info("=============请求参数: {" +  params + " }");
	//			}
	//		}
	//}

}
