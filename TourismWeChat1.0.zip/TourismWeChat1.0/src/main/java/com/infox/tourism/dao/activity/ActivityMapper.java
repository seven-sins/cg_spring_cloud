package com.infox.tourism.dao.activity;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.infox.tourism.entity.ActivityInfoEntity;
import com.infox.tourism.entity.v2.activityInfo.ActivityTripVO;
import com.infox.tourism.entity.v2.activityInfo.SecondKillActivity;
import com.infox.tourism.entity.vo.activity.Activity;
import com.infox.tourism.entity.vo.activity.ActivityBase;
import com.infox.tourism.entity.vo.activity.ActivityBaseParams;
import com.infox.tourism.entity.vo.activity.ActivityOutset;
import com.infox.tourism.entity.vo.activity.ActivityThemeVO;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 活动查询
 * @author Tan Ling
 * @date 2019年1月15日 下午2:49:41
 */
@Mapper
public interface ActivityMapper extends BaseMapper<Activity> {
	
	/**
	 * 查询活动行程
	 * @author Tan Ling
	 * @date 2019年8月5日 上午1:50:13
	 * @param activityId
	 * @return
	 */
	ActivityTripVO getActivityTripById(@Param("activityId") String activityId);
	
	/**
	 * 根据ID查询活动详细信息
	 * @param activityId
	 * @return
	 */
	Activity queryActivityDetail(@Param("activityId") String activityId);
	/**
	 * 查询线路下的活动列表
	 * @author Tan Ling
	 * @date 2019年1月15日 下午5:19:11
	 * @param lineId
	 * @return
	 */
	List<Activity> queryActivityList(@Param("lineId") String lineId);
	/**
	 * 查询活动已报名人数
	 * @author Tan Ling
	 * @date 2019年1月16日 上午9:30:48
	 * @param activityId
	 * @return
	 */
	Integer queryActivityPeopleNum(@Param("activityId") String activityId);
	
	Integer queryPeopleNum(@Param("activityId") String activityId);
	
	/**
	 * 根据城市查询活动
	 * @author Tan Ling
	 * @date 2019年1月17日 下午1:40:30
	 * @param locationId
	 * @return
	 */
	List<Activity> selectSpecialActivityPage(@Param("locationId") String locationId);
	/**
	 * 首页活动搜索
	 * @author Tan Ling
	 * @date 2019年1月21日 上午10:04:28
	 * @param name
	 * @return
	 */
	List<ActivityBase> queryActivityByName(@Param("name") String name, @Param("locationId") String locationId, String companyId);
	/**
	 * 首页活动分类查询
	 * @author Tan Ling
	 * @date 2019年1月21日 上午11:10:41
	 * @param params
	 * @return
	 */
	List<ActivityBase> queryActivityListByType(@Param("params") ActivityBaseParams params);
	/**
	 * 查询线路下的活动出行日期
	 * @author Tan Ling
	 * @date 2019年1月21日 下午3:37:43
	 * @param lineId
	 * @return
	 */
	List<ActivityOutset> queryActivityByLineId(@Param("lineId") String lineId, String companyId);
	/**
	 * 查询活动信息(单记录查询)
	 * @author Tan Ling
	 * @date 2019年1月21日 下午4:11:29
	 * @param activityId
	 * @return
	 */
	ActivityInfoEntity getActivityByActivityId(@Param("activityId") String activityId);
	/**
	 * 查询活动状态
	 * @author Tan Ling
	 * @date 2019年1月22日 下午9:46:43
	 * @param activityId
	 * @return
	 */
	ActivityBase queryActivityStatus(@Param("activityId") String activityId);
	/**
	 * 查询活动基础信息
	 * @author Tan Ling
	 * @date 2019年1月29日 上午11:32:49
	 * @param activityId
	 * @return
	 */
	ActivityBase getActivityBaseByActivityId(@Param("activityId") String activityId);
	/**
	 * 1:=,  2:>,  3:< 活动时长
	 * @author Tan Ling
	 * @date 2019年1月24日 下午3:46:07
	 * @param params
	 * @return
	 */
	List<ActivityBase> queryActivityListByDurationEqAndGtAndLt(@Param("params") ActivityBaseParams params);
	/**
	 * 根据活动主题查询
	 * @author Tan Ling
	 * @date 2019年1月25日 下午4:24:29
	 * @param params
	 * @return
	 */
	List<ActivityBase> queryActivityListByThemeId(@Param("params") ActivityBaseParams params);
	/**
	 * 修改活动状态
	 * @author Tan Ling
	 * @date 2019年1月29日 下午3:21:44
	 * @param activityId
	 * @param activityStatus
	 */
	void updateActivityStatus(@Param("activityId") String activityId, @Param("activityStatus") int activityStatus);
	/**
	 * 查询领队数量
	 * @author Tan Ling
	 * @date 2019年3月5日 上午10:26:23
	 * @param activityId
	 * @return
	 */
	Integer queryLeaderCount(@Param("activityId") String activityId);
	/**
	 * 查询活动目的地
	 * @author Tan Ling
	 * @date 2019年3月27日 上午9:48:38
	 * @param activityId
	 * @return
	 */
	String queryByDestination(@Param("activityId") String activityId);
	/**
	 * 查询所有活动ID
	 * @author Tan Ling
	 * @date 2019年4月8日 下午2:36:11
	 * @return
	 */
	List<String> queryAllActivityId();
	/**
	 * 获取线路下最近一期的活动ID
	 * @author Tan Ling
	 * @date 2019年7月24日 上午9:54:58
	 * @param lineId
	 * @param companyId
	 * @return
	 */
	String getRecentlyActivityId(String lineId, String companyId);
	/**
	 * 查询秒杀活动
	 * @author Tan Ling
	 * @date 2019年7月29日 上午10:06:45
	 * @return
	 */
	List<SecondKillActivity> querySecondKillActivity();

    /**
     * 根据活动id 活动详情出行列表查询
     * @param activityId
     * @return
     */
	ActivityOutset queryExpiredActivityByActivityId(@Param("activityId") String activityId);

	/**
	 * @MethodName: queryPreferentialActivities
	 * @Description: 查询优惠活动列表
	 * @Param: [companyId]
	 * @Return: java.util.List<com.infox.tourism.entity.vo.activity.ActivityBase>
	 * @Author: reco
	 * @Date: 2019/8/26 16:58
	*/
	List<ActivityBase> queryPreferentialActivities(@Param("companyId") String companyId);
	/**
	 * 查询活动主题
	 * @author Tan Ling
	 * @date 2019年9月2日 下午3:32:18
	 * @param activityId
	 * @return
	 */
	List<ActivityThemeVO> queryActivityThemeByActivityId(@Param("activityId") String activityId);
	/**
	 * 减去虚假会员数据
	 * @author Tan Ling
	 * @date 2019年9月18日 下午3:01:15
	 * @param activityId
	 * @param num
	 */
	void updateFalseMemberNum(@Param("activityId") String activityId, @Param("num") Integer num);
}
