package com.infox.tourism.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.infox.tourism.dao.PhotoDao;
import com.infox.tourism.entity.PhotoEntity;
import com.infox.tourism.service.PhotoService;


/**
 * 照片表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-14 14:49:56
 */
@Service("photoService")
public class PhotoServiceImpl implements PhotoService {
    /**
     * photoDao层
     *
     * @param params
     * @return
     */
    @Autowired
    private PhotoDao photoDao;

    /**
     * 根据相册id查询照片
     *
     * @param albumId
     * @return
     */
    @Override
    public List<PhotoEntity> queryByAlbumId(String albumId, int pageNum, int pageSize) {
        // 使用分页插件实现分页
        PageHelper.startPage(pageNum,pageSize);
        List<PhotoEntity> photoEntities = photoDao.queryByAlbumId(albumId);
        return photoEntities;
    }

    /**
     * 添加
     *
     * @param photoEntity
     * @return
     */
    @Override
    public boolean insert(PhotoEntity photoEntity) {

        int insert = photoDao.insert(photoEntity);
        if (insert > 0) {
            return true;
        }
        return false;
    }

    /**
     * 删除照片
     * @param photoId
     * @return
     */
    public boolean deleteByPhotoId( String path ,String photoId){
    	PhotoEntity photoEntity = photoDao.selectByPrimaryKey(photoId);
        photoEntity.setIsDelete(0);
        photoDao.updateByPhotoId(photoEntity);
        
        return true;
    }

    /**
     * 图片的总数
     * @return
     */
    public Integer total(String albumId){
        return photoDao.total(albumId);
    }


}
