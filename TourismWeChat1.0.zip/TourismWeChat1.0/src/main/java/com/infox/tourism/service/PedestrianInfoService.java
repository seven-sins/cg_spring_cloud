package com.infox.tourism.service;

import java.util.List;

import com.infox.common.base.BaseService;
import com.infox.tourism.entity.PedestrianInfoEntity;


/**
 * 出行人
 * @author Tan Ling
 * @date 2019年1月16日 下午3:00:01
 */
public interface PedestrianInfoService extends BaseService<PedestrianInfoEntity> {

	/**
	 * 查询某个订单下的出行人列表
	 * @param activityId
	 * @return
	 */
	List<PedestrianInfoEntity> findByOrderId(String orderId);

	/**
	 * 查询某个订单下的出行人列表           新接口
	 * @param activityId
	 * @return
	 */
	List<PedestrianInfoEntity> findByOrderIdList(String orderId);
	
	/**
	 * 更新出行人状态
	 * (1:正常,2:已改期,3:退款,4:申请退款)
	 * @author Tan Ling
	 * @date 2019年1月16日 下午3:17:21
	 * @param pedestrianId
	 * @param pedestrianStatus
	 */
	void updatePedestrianStatus(String pedestrianId, Integer pedestrianStatus);
	/**
	 * 修改签到
	 */
	void updateIsSignin(String pedestrianId);
	
	/**
	 * 查询信息
	 */
	List<PedestrianInfoEntity> findByActivityId(String activityId);
}
