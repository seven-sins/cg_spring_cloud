package com.infox.tourism.service;

import java.util.List;

import com.infox.common.base.BaseService;
import com.infox.tourism.entity.ActivitySingleRecordEntity;
import com.infox.tourism.entity.UserInfoEntity;
import com.infox.tourism.entity.vo.activity.ActivitySingleRecordVo;
import com.infox.tourism.entity.vo.single.ActivitySingleRecordInitiator;

/**
 * 拼单活动记录
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-15 10:36:29
 */
public interface ActivitySingleRecordService extends BaseService<ActivitySingleRecordEntity> {

	/**
	 * 查询分页
	 * 
	 * @param pageNum  下一页
	 * @param pageSize 显示的长度
	 * @param search   搜索
	 * @return
	 */
	List<ActivitySingleRecordEntity> queryPage(int pageNum, int pageSize, String search);

	/**
	 * 拼单
	 * 
	 * @param user
	 * @param entity
	 */
	void insert(UserInfoEntity user, ActivitySingleRecordEntity entity);

	/**
	 * 查询当前活动拼单发起人列表
	 * 
	 * @param pageNum
	 * @param pageSize
	 * @param activityId
	 * @return
	 */
	List<ActivitySingleRecordVo> findSingleRecordListByActivityId(int pageNum, int pageSize, String activityId);
	
	/**
	 * 查询某个活动下的所有拼单
	 * @param activityId
	 * @return
	 */
	List<ActivitySingleRecordInitiator> findSingleRecordListMoreByActivityId(int pageNum, int pageSize, String activityId);
}
