package com.infox.tourism.service;
import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.entity.EvaluationEntity;
import com.infox.tourism.entity.vo.OrderVO.OrderVO;
import com.infox.tourism.entity.vo.activityDetailVO.LineEvaluationVO;
import com.infox.tourism.entity.vo.baseVo.CommentVO;
import com.infox.tourism.entity.vo.evaluation.EvaluationVO;

import java.util.List;

/**
 * 评价表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-15 11:31:27
 */
public interface EvaluationService {

    /**
    *
    * @param pageNum 下一页
     * @param pageSize 显示的长度
    * @return
    */
    List<EvaluationVO> selectByUserId(int pageNum, int pageSize,String userId);

    /**
     * 线路的评价汇总
     * @param lineId
     * @return
     */
    LineEvaluationVO selectEvaluationByLineId (String lineId);

    /**
     *查出线路的所有评价
     * @param lineId
     * @return
     */
    List<CommentVO> selectCommonListByLineId(String lineId);

    /**
     * 保存活动评价
     * @param orderVO
     * @return
     */
    boolean insertActivityEvaluation(OrderVO orderVO,AuthUser user);

    /**
     * 根据活动id查询评价详情
     * @param activityId
     * @return
     */
    EvaluationEntity selectEvaluationByActivityId(String userId, String activityId);

}

