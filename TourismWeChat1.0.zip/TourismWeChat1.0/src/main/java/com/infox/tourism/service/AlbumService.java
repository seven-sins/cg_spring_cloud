package com.infox.tourism.service;

import com.infox.tourism.entity.PersonalPhotoAlbumEntity;
import com.infox.tourism.entity.vo.albumVO.AlbumVo;

import java.util.List;

/**
 * 相册
 * @Author: cenjinxing
 * @Date: Created in 2018/12/6 10:59
 **/
public interface AlbumService {

    /**
     * 添加相册
     * @param albumVO
     * @return
     */
    boolean addAlbum (String userId,AlbumVo albumVO);

    /**
     * 查询相册id查询
     * @return
     */
    List<AlbumVo> selectByUserId(String userId);

    /**
     * 查询相册列表
     * @return
     */
    List<AlbumVo> queryPage(Integer pageNum, Integer pageSize, String userId);

    /**
     * 删除相册
     */
    boolean deleteByAlbumId(String albumId);

    /**
     * 跟相册id查询信息
     * @param albumId
     * @return
     */
    PersonalPhotoAlbumEntity selectByAlbumId(String albumId);

    /**
     * 更改相册
     * @return
     */
    boolean updateByAlbumId(AlbumVo albumVO);
}
