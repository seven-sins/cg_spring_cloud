package com.infox.tourism.dao;

import org.apache.ibatis.annotations.Mapper;

import com.infox.tourism.entity.MessagePushEntity;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 消息推送表
 * @author Tan Ling
 * 2018年12月26日 下午3:33:44
 */
@Mapper
public interface MessagePushDao extends BaseMapper<MessagePushEntity> {

}
