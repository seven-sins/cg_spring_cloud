package com.infox.tourism.service;

import com.infox.tourism.entity.VipOpenRecordEntity;
import com.infox.tourism.entity.vo.UserVO.VipVO;

/**
 * 会员记录表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-21 15:17:45
 */
public interface VipRecordService {

	/**
	 * 申请会员
	 */
	VipOpenRecordEntity insert(String userId, VipVO  vipVO);
	 
}

