package com.infox.tourism.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.infox.tourism.entity.VoucherBaseInformationEntity;
import com.infox.tourism.entity.vo.couponVo.VoucherVo;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 代金券基础信息表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-21 15:17:44
 */
@Mapper
public interface VoucherBaseInformationDao extends BaseMapper<VoucherBaseInformationEntity> {

    /**
    * 根据userId查询未使用的优惠券 ,0  否   1  是  2,过期
     * 0  否   1  是  2,过期
    * @return
    */
    List<VoucherVo> selectByUserId( @Param("userId")String userId,
                                    @Param("type") Integer type);

    /**
     * 总数
     */
    Integer selectTotel();

    /**
     * 根据主键查询
     * @param voucherBaseId
     * @return
     */
    VoucherBaseInformationEntity selectByPrimaryId(String voucherBaseId);

    /**
     * 立即使用
     * @param
     * @return
     */
    boolean updateVouchersReceiveByStatus(@Param("vrStatus") Integer vrStatus,@Param("vouchersReceiveId") String vouchersReceiveId);

    /**
     * 立即兑换
     * @param
     * @return
     */
    boolean updateIsNeedScord(VoucherBaseInformationEntity voucherBaseInformationEntity);

    /**
     * 删除
     * @param voucherBaseInformationEntity
     * @return
     */
    boolean deleteList(VoucherBaseInformationEntity voucherBaseInformationEntity);

    /**
     * 根据userId查询未使用的优惠券 ,0  否   1  是  2,过期
     * 0  否   1  是  2,过期
     * @return
     */
    List<VoucherVo> convertProductList( @Param("userId")String userId,
                                    @Param("isNeedScord") String isNeedScord);

    /**
     * 兑换商品  所有优惠券
     * @return
     */
    List<VoucherVo> couponList();

}
