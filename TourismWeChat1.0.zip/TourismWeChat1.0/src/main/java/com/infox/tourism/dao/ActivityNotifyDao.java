package com.infox.tourism.dao;

import com.infox.tourism.entity.ActivityNotifyEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.BaseMapper;

/**
 * @Author: cenjinxing
 * @Date: Created in 2019/3/18 10:31
 **/
@Mapper
public interface ActivityNotifyDao extends BaseMapper<ActivityNotifyEntity> {


    /**
     * 添加通知信息
     * @param userId
     * @return
     */
    Integer selectNotifyByUserId(@Param("userId") String userId, @Param("activityId") String activityId, @Param("isNotify") Integer isNotify);
}
