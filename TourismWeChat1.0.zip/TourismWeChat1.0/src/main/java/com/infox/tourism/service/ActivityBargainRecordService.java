package com.infox.tourism.service;

import java.util.List;
import java.util.Map;

import com.infox.common.base.BaseService;
import com.infox.tourism.entity.ActivityBargainRecordEntity;
import com.infox.tourism.entity.UserInfoEntity;

/**
 * 砍价优惠活动记录
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-21 15:17:46
 */
public interface ActivityBargainRecordService extends BaseService<ActivityBargainRecordEntity> {

	/**
	 * 查询分页
	 * 
	 * @param pageNum  下一页
	 * @param pageSize 显示的长度
	 * @param search   搜索
	 * @return
	 */
	List<ActivityBargainRecordEntity> queryPage(int pageNum, int pageSize, String search);

	/**
	 * 砍价
	 * 
	 * @param user
	 * @param entity
	 * @return
	 */
	ActivityBargainRecordEntity assistorBargain(UserInfoEntity user, ActivityBargainRecordEntity entity);

	/**
	 * 获取商品已砍价格和目前价格 
	 * 已砍价格在砍价表中查询 
	 * 目前价格 = 商品原价 - 已砍价格
	 * @param activityId
	 * @return
	 */
	Map<String, Object> queryBargainInfo(UserInfoEntity user, String groupId, String activityId);
}
