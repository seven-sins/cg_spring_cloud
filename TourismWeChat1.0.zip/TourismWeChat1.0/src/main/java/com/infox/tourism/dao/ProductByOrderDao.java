package com.infox.tourism.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.infox.tourism.entity.ProductByOrder;
import com.infox.tourism.entity.vo.OrderVO.ProductByOrderVO;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * @author Tan Ling
 * 2018年12月13日 上午9:12:28
 */
@Mapper
public interface ProductByOrderDao extends BaseMapper<ProductByOrder> {

	/**
	 * 删除订单下的商品
	 * @param orderId
	 */
	void deleteProductByOrderId(@Param("orderId") String orderId);
	/**
	 * 批量修改产品状态
	 * @author Tan Ling
	 * @date 2019年2月14日 下午3:26:17
	 * @param productByOrderIds
	 * @param productByOrderStatus
	 */
	void batchUpdateStatus(@Param("productByOrderIds") String[] productByOrderIds, @Param("productByOrderStatus") Integer productByOrderStatus);
	/**
	 * 使用in查询订单商品
	 * @author Tan Ling
	 * @date 2019年2月14日 下午3:36:26
	 * @param productByOrderIds
	 * @return
	 */
	List<ProductByOrder> selectInProductByOrderId(@Param("productByOrderIds") String[] productByOrderIds);
	/**
	 * 修改退款状态和退款数量
	 * @author Tan Ling
	 * @date 2019年2月18日 上午11:03:51
	 * @param productByOrderId
	 * @param applyRefundNum
	 * @param productByOrderStatus
	 */
	void updateStatusAndApplyRefundNum(@Param("productByOrderId") String productByOrderId, @Param("applyRefundNum") Integer applyRefundNum, @Param("productByOrderStatus") Integer productByOrderStatus);
	/**
	 * 使用订单ID查询订单下的商品列表
	 * @author Tan Ling
	 * @date 2019年2月18日 下午2:25:42
	 * @param orderId
	 * @param status == 1时， 仅查询有效状态下的商品(非改期和非退款状态)   1:正常,2:已改期,3:已退款,4:申请退款
	 * @return
	 */
	List<ProductByOrderVO> queryByOrderId(@Param("orderId") String orderId, @Param("status") Integer status);
}
