package com.infox.tourism.controller.traffic;

import com.infox.tourism.entity.traffic.TrafficMode;
import com.infox.tourism.service.v2.traffic.TrafficModeService;
import com.infox.tourism.util.R;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @Author: Xiao Ming
 * @Date: 2019/7/30 13:34
 * @Version 1.0
 */
@RestController
@RequestMapping("/traffic")
public class TrafficModeController {

    @Autowired
    private TrafficModeService trafficModeService;

    @GetMapping("/list")
    public R getTrafficList(TrafficMode trafficMode){

        List<TrafficMode> trafficModes = trafficModeService.getTrafficList(trafficMode);

        return R.ok("操作成功").put("data", trafficModes);

    }

    @PostMapping("/addTrafficMode")
    public R addTrafficMode(@RequestBody TrafficMode trafficMode){

        trafficModeService.insert(trafficMode);

        return R.ok("操作成功");

    }

    @PostMapping("/updateTrafficMode")
    public R updateTrafficMode(@RequestBody TrafficMode trafficMode){

        trafficModeService.update(trafficMode);

        return R.ok("操作成功");

    }

    @PostMapping("/deleteTrafficMode/{trafficId}")
    public R deleteTrafficMode(@PathVariable("trafficId") String trafficId){

        trafficModeService.deleteById(trafficId);

        return R.ok("操作成功");

    }

}