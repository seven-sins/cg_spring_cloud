package com.infox.tourism.service.v2.impl;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infox.tourism.dao.v2.ExceptionalRecordV2Mapper;
import com.infox.tourism.service.v2.ExceptionalRecordV2Service;

/**
 * 打赏金额总数
 */
/**
 * 
 * @author yuanfang
 * 2019年5月14日 上午10:52:07
 */
@Service
public class ExceptionalRecordV2ServiceImpl implements ExceptionalRecordV2Service {

	@Autowired
	ExceptionalRecordV2Mapper exceptionalRecordV2Mapper;

	@Override
	public BigDecimal queryNumErMoney(String userId) {
		return exceptionalRecordV2Mapper.queryNumErMoney(userId);
	}
}
