package com.infox.tourism.dao;

import java.util.List;

import com.infox.tourism.entity.v2.leader.LeaderScoreVo;
import com.infox.tourism.entity.v2.leaderinfo.vo.LeaderVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.infox.tourism.entity.LeaderInfoEntity;
import com.infox.tourism.entity.LeaderLevelEntity;
import com.infox.tourism.entity.PhotoEntity;
import com.infox.tourism.entity.vo.leaderInfoVO.ActivityUnderLeaderVO;
import com.infox.tourism.entity.vo.leaderInfoVO.LeaderAndActivityVO;
import com.infox.tourism.entity.vo.leaderInfoVO.LeaderPhotoAlbumVO;
import com.infox.tourism.entity.vo.leaderInfoVO.LeaderRecordVO;
import com.infox.tourism.entity.vo.leaderInfoVO.leaderEvaVO;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 领队个人信息表
 *
 * @author yiwei
 * @email @163.com
 * @date 2018-12-10 14:59:35
 */
@Mapper
public interface LeaderInfoDao extends BaseMapper<LeaderInfoEntity> {

	/**
	 * 查询领队等级列表
	 * 
	 * @return
	 */
	List<LeaderLevelEntity> queryLeaderLevelList();

	/**
	 * 根据领队等级查询领队和活动
	 * 
	 * @return
	 */
	List<LeaderAndActivityVO> queryLeaderList(@Param("leaderLevel") String leaderLevel, String companyId);

	/**
	 * 根据领队等级查询领队和活动
	 * 
	 * @return
	 */
	List<ActivityUnderLeaderVO> queryLeaderActivityList(@Param("state") Integer state, @Param("leaderId") String leaderId);

	/**
	 * 根据领队id查询
	 * 
	 * @return
	 */
	LeaderAndActivityVO queryLeaderById(String leaderId);

	/**
	 * 领队相册列表
	 * 
	 * @return
	 */
	List<LeaderPhotoAlbumVO> queryLeaderPhotoList(@Param("leaderId") String leaderId);

	/**
	 * 领队相册详细图片列表
	 * 
	 * @return
	 */
	List<PhotoEntity> queryLeaderPhotoDetailList(@Param("albumId") String albumId);

	/**
	 * 领队评论列表
	 * 
	 * @return
	 */
	List<leaderEvaVO> queryLeaderEvaluationList(@Param("leaderId") String leaderId);

	/**
	 * 领队打赏列表
	 * 
	 * @return
	 */
	List<LeaderRecordVO> queryLeaderExReList(@Param("leaderId") String leaderId);

	/**
	 * 使用userId查询领队信息
	 * 
	 * @param userId
	 * @return
	 */
	LeaderInfoEntity getByUserId(@Param("userId") String userId);
	
	/**
	 * 查询所有领队
	 * @author Tan Ling
	 * @date 2019年1月16日 下午2:13:59
	 * @return
	 */
	List<LeaderInfoEntity> findLeader();

	/**
	 * 根据userId查询
	 * @param userId
	 * @return
	 */
	List<LeaderVo> queryLeaderByUserId(String userId);
	
	/**
	 * 根据userId更新
	 */
	void updateLeaderEnableByUserId(@Param("enable") Integer enable,@Param("userId") String userId);

	/**
	 * 查询打赏金额
	 * @param userId
	 * @return
	 */
    Integer selectExceptionalMoneyByUserId(@Param("userId")String userId);

	/**
	 * 查询分销金额
	 * @param userId
	 * @return
	 */
	Integer selectDistributionAmountByUserId(@Param("userId")String userId);
	
	/**
	 * 更新领队头像
	 * @author Tan Ling
	 * @date 2019年4月26日 下午1:35:40
	 * @param userId
	 * @param headImg
	 */
	void updateLeaderHeadimg(@Param("userId") String userId, @Param("nickName") String nickName, @Param("headImg") String headImg);
	
	/**
	 * 查询领队评分
	 * @author Tan Ling
	 * @date 2019年7月15日 下午2:34:21
	 * @param leaderId
	 * @return
	 */
	LeaderScoreVo queryLeaderScoreByLeaderId(String leaderId);
	/**
	 * 查询领队带队次数
	 * @author Tan Ling
	 * @date 2019年7月15日 下午3:03:51
	 * @param leaderId
	 * @return
	 */
	Integer queryLeaderNumByLeaderId(String leaderId);
	/**
	 * 查询领队被关注数
	 * @author Tan Ling
	 * @date 2019年7月15日 下午3:18:45
	 * @param leaderId
	 * @return
	 */
	Integer queryFollowNumByLeaderId(String leaderId);
}
