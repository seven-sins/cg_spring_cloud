package com.infox.tourism.service.v2.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infox.common.base.impl.BaseServiceImpl;
import com.infox.tourism.entity.v2.econtract.UserEcontract;
import com.infox.tourism.service.v2.UserEcontractService;

import tk.mybatis.mapper.common.BaseMapper;

@Service
public class UserEcontractServicelmpl extends BaseServiceImpl<UserEcontract> implements UserEcontractService {

	@Autowired
	@Override
	public void setBaseMapper(BaseMapper<UserEcontract> baseMapper) {
		this.baseMapper = baseMapper;
	}

}