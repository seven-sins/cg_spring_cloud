package com.infox.tourism.service.wechat;


public interface WechatRequestService {

	public void updateRequestNum();
}
