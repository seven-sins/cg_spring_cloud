package com.infox.tourism.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infox.tourism.dao.JoinCityMapper;
import com.infox.tourism.entity.JoinCity;
import com.infox.tourism.service.JoinCityService;

/**
 * 接入城市
 * @author Tan Ling
 * @date 2019年5月24日 下午4:47:13
 */
@Service
public class JoinCityServiceImpl implements JoinCityService {

	@Autowired
	JoinCityMapper joinCityMapper;
	
	@Override
	public JoinCity getBySbLocationId(String sbLocationId) {
		return joinCityMapper.getBySbLocationId(sbLocationId);
	}

}
