package com.infox.tourism.dao.v2;

import org.apache.ibatis.annotations.Mapper;

import com.infox.tourism.entity.v2.activityactualpayment.ActivityActualPayment;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 实际支出
 * @author Tan Ling
 * 2019年1月7日 下午2:21:10
 */
@Mapper
public interface ActivityActualPaymentMapper extends BaseMapper<ActivityActualPayment> {
    
	/**
	 * 根据主键更新
	 * @param activityActualPayment
	 */
	public void updateByActivityActualPaymentId(ActivityActualPayment activityActualPayment);
}