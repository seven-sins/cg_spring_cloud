package com.infox.tourism.dao;

import com.infox.tourism.entity.MessagePushEntity;
import com.infox.tourism.entity.vo.MessageVO.MessageVO;
import com.infox.tourism.entity.vo.indexVO.MessagePushIndexVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.BaseMapper;

import java.util.List;

/**
 * 消息推送表
 *
 * @author yiwei
 * @email yiwei@163.com
 * @date 2018-11-21 21:01:45
 */
@Mapper
public interface MessageDao extends BaseMapper<MessagePushEntity> {

     /**
     * 首页查找已发布的暴走快讯
     * @return
     */
     List<MessagePushIndexVO> selectListForWeChat();

     /**
      * 我的系统消息
      * @return
      */
     List<MessageVO> selectByUserId(@Param("userId") String userId, @Param("search") String search, @Param("time") String time);
}
