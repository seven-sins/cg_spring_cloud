package com.infox.tourism.controller.signInController;

import java.util.Calendar;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infox.common.utils.Assert;
import com.infox.tourism.entity.signin.SignInEntity;
import com.infox.tourism.service.signIn.SignInService;
import com.infox.tourism.util.R;

/**
 * @Author: Xiao Ming
 * @Date: 2019/7/10 14:25
 * @Version 1.0
 */
@RestController
@RequestMapping("/signIn")
public class SignInController {

    @Autowired
    private SignInService signInService;

    @GetMapping("/addUserSignIn")
    public R addUserSignIn(String userId, Date date){
    	
    	Calendar calendar=Calendar.getInstance();
    	calendar.setTime(date);
    	for(int i = 0; i < 60; i++) {
    		//查询是否已签到过
            SignInEntity signInEntity = signInService.selectUserSignInByDate(userId, calendar.getTime());
            Assert.isNull(signInEntity,"今天已签到过");
            signInService.addUserSignIn(userId, calendar.getTime());
            //
			calendar.add(Calendar.DATE, 1);
//			if(i == 13) {
//				calendar.add(Calendar.DATE, 1);
//			}
    	}

        return R.ok("签到成功");

    }

}