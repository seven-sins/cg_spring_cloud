package com.infox.tourism.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infox.tourism.dao.DestinationDao;
import com.infox.tourism.entity.vo.indexVO.DestinationIndexVO;
import com.infox.tourism.service.DestinationService;


/**
 * 目的地维护表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-06 17:23:31
 */
@Service("destinationInfoService")
public class DestinationServiceImpl implements DestinationService {

    @Autowired
    private DestinationDao destinationInfoDao;

    @Override
    public List<DestinationIndexVO> queryPage(String destinationId) {
    	return destinationInfoDao.queryPage(destinationId);
    }

}
