package com.infox.tourism.service.payment;

import java.util.Map;

import com.infox.tourism.entity.OrderInfoEntity;
import com.infox.tourism.entity.UserInfoEntity;

/**
 * 支付service
 * 
 * @author Tan Ling 2018年12月11日 下午4:28:42
 */
public interface PaymentService {

	/**
	 * 支付
	 * 
	 * @param user
	 * @param orderId
	 * @param orderType
	 * @return
	 */
	public Map<String, ?> pay(UserInfoEntity user, String orderId, String orderType);

	/**
	 * 支付
	 * 
	 * @param user
	 * @param orderId
	 * @param orderType
	 * @return
	 */
	public Map<String, ?> appletPay(UserInfoEntity user, String orderId, String orderType);

	/**
	 * 更新支付状态
	 * 
	 * @param trxid
	 * @param orderType
	 * @param payStatus
	 */
	public void updatePayStatus(String trxid, String orderType, int payStatus);

	/**
	 * 申请退款
	 * 
	 * @param userId
	 * @param orderId
	 * @param orderType
	 * @return
	 */
	public Map<String, ?> refund(String userId, String orderId, String orderType);

	/**
	 * 推送微信消息
	 * 
	 * @param order
	 */
	public void pushWechatMessage(OrderInfoEntity order);
}
