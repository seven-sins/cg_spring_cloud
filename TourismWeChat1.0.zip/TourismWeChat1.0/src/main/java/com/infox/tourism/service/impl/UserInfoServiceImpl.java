package com.infox.tourism.service.impl;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.infox.common.exception.CustomException;
import com.infox.common.utils.Assert;
import com.infox.common.utils.redis.RedisConstant;
import com.infox.common.utils.redis.RedisService;
import com.infox.common.wechat.utils.WechatUtil;
import com.infox.tourism.dao.AttentionDao;
import com.infox.tourism.dao.LeaderInfoDao;
import com.infox.tourism.dao.NumIntegralDao;
import com.infox.tourism.dao.UserInfoDao;
import com.infox.tourism.entity.NumIntegralEntity;
import com.infox.tourism.entity.UserInfoEntity;
import com.infox.tourism.entity.applet.AppletUser;
import com.infox.tourism.entity.vo.UserVO.UserVO;
import com.infox.tourism.entity.vo.albumVO.FootprintVo;
import com.infox.tourism.mapper.travel.note.TravelNoteCollectMapper;
import com.infox.tourism.service.UserInfoService;
import com.infox.tourism.util.UUIDUtil;

/**
  * 用户表
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-22 20:31:29
 */
@Service
public class UserInfoServiceImpl implements UserInfoService {
	static final Logger LOG = LoggerFactory.getLogger(UserInfoServiceImpl.class);
	static final String OPENID_KEY = "openid";
	@Autowired
	private NumIntegralDao numIntegralDao;
	@Autowired
	private AttentionDao attentionDao;
    @Autowired
    private UserInfoDao userInfoDao;
    @Autowired
    private WechatUtil wechatUtil;
    @Autowired
    private RedisService redisService;
    @Autowired
    private LeaderInfoDao leaderInfoDao;
    @Autowired
    private TravelNoteCollectMapper travelNoteCollectMapper;

    /**
    * 查询分页
    * @param pageNum
    * @param pageSize
    * @param search
    * @return
    */
    @Override
    public List<UserInfoEntity> queryPage(int pageNum, int pageSize, String search){
        // 使用分页插件实现分页
        PageHelper.startPage(pageNum,pageSize);
        // 调用dao的方法

        return null;
    }

	@Override
	public void insert(UserInfoEntity userInfo) {
		userInfo.setUserId(UUIDUtil.create());
		userInfo.setCreateTime(new Date());
		userInfoDao.insert(userInfo);
	}

    /**
     * 根据userId查询
     * @param userId
     * @return
     */
    @Override
    public List<FootprintVo> selectByUserId(String userId){
        List<FootprintVo> list = userInfoDao.selectByUserId(userId);

        return list;
    }
	/**
	 * 用户json数据结构
	 * {
	 * 		"country":"中国",
	 *      "province":"广东",
	 *      "city":"广州",
	 * 		"openid":"o4uepwiz1sj9J5hMK6fX4tdDOlz4","sex":1,
	 * 		"nickname":"昵称",
	 * 		"headimgurl":"http://thirdwx.qlogo.cn/mmopen/vi_32/jf8n7hYJq2FGzibISkR0H7wGMd8ic5tGCl2cmHicNf9tcKGDECic56l4dOuEOxRsaL2U7iaHYgJQcJMdYxJ4asP2pvQ/132",
	 * 		"language":"zh_CN","privilege":[]
	 * }
	 */
	@Override
	public UserInfoEntity saveWechatUser(String token, JSONObject user) {
		/**
		 * 1. 查询用户是否已存在
		 * 		先使用unionId查询
		 * 		再使用openId查询
		 */
		UserInfoEntity dbUserInfo;
		if(user.containsKey("unionid")) {
			dbUserInfo = userInfoDao.getByUnionId(user.getString("unionid"));
			if(dbUserInfo != null) {
				redisService.add(RedisConstant.WECHAT_OPENID_PREFIX + token, user.getString("unionid"));
				return dbUserInfo;
			}
		}
		dbUserInfo = userInfoDao.getByOpenId(user.getString("openid"));
		if(dbUserInfo != null) {
			if(user.containsKey("unionid")) {
				userInfoDao.setUnionId(dbUserInfo.getUserId(), user.getString("unionid"));
				redisService.add(RedisConstant.WECHAT_OPENID_PREFIX + token, user.getString("unionid"));
			}
			return dbUserInfo;
		}
		/**
		 * 2. 用户不存在, 添加微信用户信息
		 */
		UserInfoEntity userInfo = new UserInfoEntity();
		userInfo.setUserId(UUIDUtil.create());
		userInfo.setCreateTime(new Date());
		userInfo.setOpenId(user.getString("openid"));
		userInfo.setUnionId(user.getString("unionid"));
		userInfo.setNickName(user.getString("nickname"));
		userInfo.setUProvince(user.getString("province"));
		userInfo.setUCity(user.getString("city"));
		userInfo.setUVip(0);
		String sexKey = "sex";
		if(user.get(sexKey) != null) {
			int sex = "2".equals(user.getString(sexKey)) ? 0: 1;
			userInfo.setUSex(sex);
		}
		userInfo.setHeadImg(user.getString("headimgurl"));
		// 角色(1.普通 2.会员 )
		userInfo.setURole(1);

		// 第一次登陆进来，默认的积分是为0   积分表
		NumIntegralEntity numIntegralEntity = new NumIntegralEntity();
		numIntegralEntity.setNumIntegralId(UUIDUtil.create());
		numIntegralEntity.setUserId(userInfo.getUserId());
		numIntegralEntity.setNumIntegral(0);
		numIntegralEntity.setCreateTime(new Date());
		numIntegralEntity.setCreateBy(userInfo.getNickName());
		try {
			userInfoDao.insert(userInfo);
			numIntegralDao.insert(numIntegralEntity);
		}catch(Exception e) {
			// 某种特定情况下有可能会插入重复数据, 因数据库创建唯一约束, 此处会报错
			LOG.info("=============插入用户信息出错 " + e.getMessage());
			UserInfoEntity existUser = userInfoDao.getByOpenId(user.getString("openid"));
			return existUser;
		}
		LOG.info("=============new user: " + user);
		if(StringUtils.isNotBlank(userInfo.getUnionId())) {
			redisService.add(RedisConstant.WECHAT_OPENID_PREFIX + token, user.getString("unionid"));
		}
		
		return userInfo;
	};
	
	/**
	 * 使用openId获取用户信息
	 */
	@Override
	public UserInfoEntity findUserInfoByOpenId(String token, String openId) {
		// 用户登录成功后会刷新token, token中的openid实际上是unionid
		UserInfoEntity userInfo = userInfoDao.getByUnionId(openId);
		if(userInfo != null) {

			userInfo.setUpdateTime(new Date());
			userInfoDao.updateByUserTime(userInfo);

			return userInfo;
		}
		// unionid查询失败的情况
		// 1. 用户持久化信息中没有unionid
		// 2. 用户点活动商城进入系统的第一个接口调用
		userInfo = userInfoDao.getByOpenId(openId);
		/**
		 * 1. 如果unionid和openid都没找到用户信息, 调用微信接口获取用户信息
		 */
		if(userInfo == null) {
			/**
			 * 数据库中获取失败, 调用微信接口查询用户并持久化
			 */
			JSONObject jsonObj = wechatUtil.getWxUserInfoV2(openId);
			// 48001未关注公众号
			String zero = "0", errCode="48001";
			if(zero.equals(jsonObj.getString("subscribe")) || (jsonObj.containsKey("errcode") && errCode.equals(jsonObj.getString("errcode")))) {
				throw new CustomException(410, "用户未关注公众号");
			}
			if(!jsonObj.containsKey(OPENID_KEY)) {
				throw new CustomException(410, jsonObj.toJSONString());
			}
			return saveWechatUser(token, jsonObj);
		}
		userInfo.setIsLeader(userInfoDao.isLeader(openId));
		// 有openid, 且有unionid， 当前是完整数据, 更新token后返回
		if( StringUtils.isNotBlank(userInfo.getUnionId())) {
			redisService.add(RedisConstant.WECHAT_OPENID_PREFIX + token, userInfo.getUnionId());
		} 
		// 有openid, 但没有unionid, 调用微信接口获取unionid并更新
		else {
			JSONObject jsonObj = wechatUtil.getWxUserInfo(openId);
			if(jsonObj.containsKey("unionid")) {
				userInfoDao.setUnionId(userInfo.getUserId(), jsonObj.getString("unionid"));
				redisService.add(RedisConstant.WECHAT_OPENID_PREFIX + token, jsonObj.getString("unionid"));
			}
		}

		return userInfo;
	}

	/**
	 * 根据userId查询用户页面数据
	 */
	@Override
	public UserVO selectUserInfoByUserId(String userId) {
		if (userId == null || "".equals(userId)){
			return null;
		}
		UserVO userVO = userInfoDao.selectUserInfoByUserId(userId);
		Assert.notNull(userVO, "使用openId查询用户信息失败");
		int i = userInfoDao.selectLeaderByUserId(userId);
		userVO.setlStatus(i);
		Integer numFootprint = userInfoDao.getByNumFootprint(userId);
		userVO.setNumFootprint(numFootprint);
		// 查询收藏游记数量
		Integer numCollect = userInfoDao.getByNumCollect(userId);
		int travelCollectNum = travelNoteCollectMapper.queryCollectCountByUserId(userId);
		numCollect = numCollect == null ? 0 : numCollect;
		numCollect += travelCollectNum;
		
		userVO.setNumCollect(numCollect);
		Integer integer = attentionDao.selectByAttentionNum(userId);
		userVO.setAttentionNum(integer);
		
		return userVO;
	}

	/**
	 * 根据openId 更新用户信息
	 * @param openId
	 * @return
	 */
	@Override
	public boolean updateUserInfoByUserId(UserVO userVO, String userId) {
		boolean b = false;

		/**
		 * 1. 查询用户是否已存在
		 */
		UserVO info = userInfoDao.selectUserInfoByUserId(userId);
		/**
		 * 存在进行更新
		 */
		if (info != null){
			BeanUtils.copyProperties(userVO,info);
			userVO.setUserId(info.getUserId());
			userVO.setUserId(userId);
			userVO.setUpdateTime(new Date());
			// 更新
			b = userInfoDao.updateUserInfoByUserId(userVO);
			// 如果是领队, 同步头像信息
			if(StringUtils.isNotBlank(userVO.getHeadImg())) {
				leaderInfoDao.updateLeaderHeadimg(userId, userVO.getNickName(), userVO.getHeadImg());
			}
		}

		return b;
	}

	@Override
	public Integer updateBackgroundImg(String userId, String url) {
		return userInfoDao.updateBackgroundImg(userId, url);
	}

	@Override
	public UserInfoEntity getByOpenId(String openId) {
		return userInfoDao.getByOpenId(openId);
	}

	/**
     * 根据unionId查询
     * @author Tan Ling
     * @date 2019年6月17日 上午11:50:35
     * @param unionId
     * @return
     */
	@Override
	public UserInfoEntity getByUnionId(String unionId) {
		// 用户登录成功后会刷新token, token中的openid实际上是unionid
		UserInfoEntity userInfo = userInfoDao.getByUnionId(unionId);
		if (userInfo != null) {
			return userInfo;
		}
		// unionid查询失败的情况
		// 1. 用户持久化信息中没有unionid
		// 2. 用户点活动商城进入系统的第一个接口调用
		return userInfoDao.getByOpenId(unionId);
    }

	@Override
	public UserInfoEntity insertAppletUser(AppletUser appletUser) {
		UserInfoEntity dbUser = userInfoDao.getByUnionId(appletUser.getUnionid());
		if(dbUser != null) {
			return dbUser;
		}
		UserInfoEntity userInfo = new UserInfoEntity();
		userInfo.setUserId(UUIDUtil.create());
		userInfo.setCreateTime(new Date());
		userInfo.setOpenId(appletUser.getOpenid());
		userInfo.setUnionId(appletUser.getUnionid());
		userInfo.setNickName(appletUser.getNickName());
		userInfo.setUProvince(appletUser.getProvince());
		userInfo.setUCity(appletUser.getCity());
		userInfo.setUVip(0);
		userInfo.setuSex(appletUser.getGender() != null ? appletUser.getGender() : 0);
		userInfo.setHeadImg(appletUser.getAvatarUrl());
		// 角色(1.普通 2.会员 )
		userInfo.setURole(1);
		// 第一次登陆进来，默认的积分是为0   积分表
		NumIntegralEntity numIntegralEntity = new NumIntegralEntity();
		numIntegralEntity.setNumIntegralId(UUIDUtil.create());
		numIntegralEntity.setUserId(userInfo.getUserId());
		numIntegralEntity.setNumIntegral(0);
		numIntegralEntity.setCreateTime(new Date());
		numIntegralEntity.setCreateBy(userInfo.getNickName());
		userInfoDao.insert(userInfo);
		numIntegralDao.insert(numIntegralEntity);
		
		return userInfo;
	}
}
