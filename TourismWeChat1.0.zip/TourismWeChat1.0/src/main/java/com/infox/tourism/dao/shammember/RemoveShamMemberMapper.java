package com.infox.tourism.dao.shammember;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.infox.tourism.entity.shammember.RemoveShamMember;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 删除虚假会员
 * @author Tan Ling
 * @date 2019年4月22日 下午2:40:42
 */
@Mapper
public interface RemoveShamMemberMapper extends BaseMapper<RemoveShamMember> {
	
	/**
	 * 随机获取指定数量的虚假会员
	 * @author Tan Ling
	 * @date 2019年4月22日 下午2:42:41
	 * @param size
	 * @return
	 */
	List<RemoveShamMember> findByRandom(@Param("size") Integer size);
	/**
	 * 根据ID删除
	 * @author Tan Ling
	 * @date 2019年4月22日 下午2:55:53
	 * @param removeShamId
	 */
	void deleteById(@Param("removeShamId") String removeShamId);
}
