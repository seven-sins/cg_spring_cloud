package com.infox.tourism.dao.v2;

import java.math.BigDecimal;

import org.apache.ibatis.annotations.Mapper;

/**
 * 总分销金额
 * @author yuanfang
 * 2019年5月14日 上午10:55:51
 */
@Mapper
public interface PedestrianInfoV2Mapper {
	
	/**
	 * 总分销金额
	 */
	BigDecimal queryByDistributionUserId(String distributionUserId);
	
	/**
	 * 
	 */
	BigDecimal withdrawByDistributionUserId(String distributionUserId);
}
