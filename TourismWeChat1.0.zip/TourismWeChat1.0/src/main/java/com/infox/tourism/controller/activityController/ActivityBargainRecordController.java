package com.infox.tourism.controller.activityController;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageInfo;
import com.infox.common.utils.Assert;
import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.config.resolver.Guest;
import com.infox.tourism.entity.ActivityBargainRecordEntity;
import com.infox.tourism.service.ActivityBargainRecordService;
import com.infox.tourism.util.R;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import springfox.documentation.annotations.ApiIgnore;

/**
 * 砍价
 * @author Tan Ling
 * 2018年12月8日 下午1:47:12
 */
@Api(description = "砍价")
@RestController
@RequestMapping("/activityBargain")
public class ActivityBargainRecordController {
	
	@Autowired
	private ActivityBargainRecordService activityBargainRecordService;

    @ApiOperation(value = "列表", response = ActivityBargainRecordEntity.class)
    @GetMapping("/list")
    public R list(
    		@RequestParam(value = "pageNum") int pageNum, 
    		@RequestParam(value = "pageSize") int pageSize,
    		@ApiParam ActivityBargainRecordEntity activityBargainRecordEntity){
        List<ActivityBargainRecordEntity> list = activityBargainRecordService.find(pageNum, pageSize, "create_time desc", activityBargainRecordEntity);

        return R.ok().put("data", list).put("total", new PageInfo<ActivityBargainRecordEntity>(list).getTotal());
    }
    
    @ApiOperation("砍价")
    @PostMapping("/assistorBargain")
    public R assistorBargain(@ApiIgnore AuthUser user, @RequestBody ActivityBargainRecordEntity entity) {
    	Assert.notEmpty(entity.getActivityId(), "砍价活动ID不能为空");
    	Assert.notEmpty(entity.getGroupId(), "groupId不能为空");
    	
    	entity = activityBargainRecordService.assistorBargain(user, entity);
    	
    	return R.ok().put("data", entity);
    }
    
    @ApiOperation("活动砍价信息")
    @GetMapping("/assistorBargain/info")
    public R assistorBargainInfo(@ApiIgnore Guest user, String groupId, String activityId) {
    	Assert.notEmpty(activityId, "活动ID不能为空");
    	// 返回已砍价格和目前价格
    	// 已砍价格在砍价表中查询
    	// 目前价格 = 商品原价 - 已砍价格
    	Map<String, Object> map = activityBargainRecordService.queryBargainInfo(user, groupId, activityId);
    	
    	return R.ok().put("data", map);
    }
    
    @ApiOperation("单记录查询")
    @GetMapping("/info/{bargainId}")
    public R info(@PathVariable("bargainId") String bargainId){
    	ActivityBargainRecordEntity activityBargainRecord = activityBargainRecordService.get(bargainId);

        return R.ok().put("data", activityBargainRecord);
    }

    @ApiOperation("保存")
    @PostMapping("/save")
    public R save(@Valid @RequestBody ActivityBargainRecordEntity activityBargainRecord){
    	activityBargainRecordService.insert(activityBargainRecord);

        return R.ok();
    }

    @ApiOperation("修改")
    @PostMapping("/update")
    public R update(@RequestBody ActivityBargainRecordEntity activityBargainRecord){
    	if(activityBargainRecord.getId() == null) {
    		return R.error(400, "ID不能为空");
    	}
    	
    	activityBargainRecordService.update(activityBargainRecord);

        return R.ok();
    }
    
    @ApiOperation("删除")
    @PostMapping("/delete/{activityBargainRecordId}")
    public R delete(@PathVariable("activityBargainRecordId") String activityBargainRecordId){
    	activityBargainRecordService.deleteById(activityBargainRecordId);

        return R.ok();
    }
}
