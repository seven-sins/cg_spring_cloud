package com.infox.tourism.dao;

import com.infox.tourism.entity.VipRecordEntity;
import org.apache.ibatis.annotations.Mapper;
import tk.mybatis.mapper.common.BaseMapper;

/**
 * 会员记录表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-21 15:17:45
 */
@Mapper
public interface VipRecordDao extends BaseMapper<VipRecordEntity> {

    /**
     * 根据用户id 查询
     * @param userId
     * @return
     */
    VipRecordEntity selectByUserId(String userId);

    /**
     * 更新拦截时间
     */
    VipRecordEntity updateByEndTime(VipRecordEntity vipRecordEntity);

    /**
     * 更新vip
     * @param vipRecordEntity
     * @return
     */
    VipRecordEntity updateByVipRecordEntity(VipRecordEntity vipRecordEntity);


}
