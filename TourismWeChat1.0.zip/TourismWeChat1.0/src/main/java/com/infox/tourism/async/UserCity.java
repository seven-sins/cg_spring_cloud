package com.infox.tourism.async;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONObject;
import com.infox.common.utils.redis.RedisConstant;
import com.infox.common.utils.redis.RedisService;
import com.infox.tourism.config.resolver.Guest;
import com.infox.tourism.dao.UserInfoDao;

/**
 * 用户定位城市
 * @author Tan Ling
 * @date 2019年7月25日 上午10:51:28
 */
@Component
public class UserCity {
	@Autowired
	RedisService redisService;
	@Autowired
	UserInfoDao userInfoDao;
	/**
	 * {"result":{"formatted_address":"广东省广州市天河区陶育路160号","business":"石牌,龙口,五山","sematic_description":"暨南大学(广州石牌校区)内,暨南花园-25栋附近29米","cityCode":257,"roads":[],"location":{"lng":113.35107421874999,"lat":23.137365352408894},"poiRegions":[{"uid":"ddc8fe7205e884a7b6f42ffd","distance":"0","name":"暨南大学(广州石牌校区)","tag":"教育培训;高等院校","direction_desc":"内"}],"pois":[],"addressComponent":{"city_level":2,"country":"中国","town":"","distance":"45","city":"广州市","adcode":"440106","country_code_iso":"CHN","country_code_iso2":"CN","country_code":0,"province":"广东省","street":"陶育路","district":"天河区","street_number":"160号","direction":"附近"}},"status":0}
	 * @author Tan Ling
	 * @date 2019年7月25日 上午10:57:18
	 * @param token
	 * @param guest
	 */
	@Async
	public void updateUserCity(String token, Guest guest) {
		if(StringUtils.isBlank(token) || StringUtils.isBlank(guest.getUserId())) {
			return;
		}
		JSONObject position = (JSONObject) redisService.get(RedisConstant.USER_CITY_PREFIX + token);
		if(position == null) {
			return;
		}
		JSONObject result = position.getJSONObject("result");
		if(result == null) {
			return;
		}
		JSONObject addressComponent = result.getJSONObject("addressComponent");
		if(addressComponent == null) {
			return;
		}
		/**
		 * 更新用户国家、省、城市信息
		 */
		// 国家
		guest.setCountry(addressComponent.getString("country"));
		// 省
		guest.setuProvince(addressComponent.getString("province"));
		// 城市
		guest.setuCity(addressComponent.getString("city"));
		// 地区
		guest.setArea(addressComponent.getString("district"));
		// 地址
		guest.setAddress(result.getString("formatted_address"));
		// 更新用户城市
		userInfoDao.updateUserCity(guest);
		redisService.delete(RedisConstant.USER_CITY_PREFIX + token);
	}
	
	@Async
	public void cacheUserPosition(String token, JSONObject position) {
		// 缓存60分钟
		redisService.add(RedisConstant.USER_CITY_PREFIX + token, position, 60);
	}
}
