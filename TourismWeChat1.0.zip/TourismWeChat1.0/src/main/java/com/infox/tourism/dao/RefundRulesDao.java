package com.infox.tourism.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.infox.tourism.entity.RefundRulesEntity;
import com.infox.tourism.entity.vo.activity.RefundRulesVO;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2019-01-15 11:37:54
 */
@Mapper
public interface RefundRulesDao extends BaseMapper<RefundRulesEntity> {

    /**
    * 查询分页
    * @return
    */
    List<RefundRulesEntity> queryPage();

    /**
     * 根据活动id查询退款规则
     * @param activityId
     * @return
     */
    List<RefundRulesVO> selectByActivityId(String activityId);

    /**
     * 根据活动id删除
     * @param activityId
     * @return
     */
    boolean deleteByActivityId(String activityId);
}
