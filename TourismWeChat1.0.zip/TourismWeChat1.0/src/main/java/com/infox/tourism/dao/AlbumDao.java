package com.infox.tourism.dao;

import com.infox.tourism.entity.PersonalPhotoAlbumEntity;
import com.infox.tourism.entity.vo.albumVO.AlbumVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.BaseMapper;

import java.util.List;

/**
 * @Author: cenjinxing
 * @Date: Created in 2018/12/6 10:49
 **/
@Mapper
public interface AlbumDao extends BaseMapper<PersonalPhotoAlbumEntity> {

    /**
     * 查询相册列表
     * @return
     */
    List<AlbumVo> queryPage(@Param(value = "userId") String userId);

    /**
     * 查询相册id查询
     * @return
     */
    List<AlbumVo>  selectByUserId(String userId);

    /**
     * 删除相册
     * @param personalPhotoAlbumEntity
     * @return
     */
    boolean deleteByAlbumId(PersonalPhotoAlbumEntity personalPhotoAlbumEntity);

    /**
     * 跟相册id查询信息
     * @param albumId
     * @return
     */
    PersonalPhotoAlbumEntity selectByAlbumId(String albumId);

    /**
     * 更改相册
     * @return
     */
    boolean updateByAlbumId(PersonalPhotoAlbumEntity personalPhotoAlbumEntity);
}
