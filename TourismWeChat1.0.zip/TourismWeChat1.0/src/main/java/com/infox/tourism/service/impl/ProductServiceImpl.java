package com.infox.tourism.service.impl;

import com.infox.tourism.dao.ProductDao;
import com.infox.tourism.entity.vo.productVO.ProductVO;
import com.infox.tourism.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Author Hale
 * @Date 2018/12/12
 */
@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductDao productDao;


    @Override
    public List<ProductVO> selectProductByActivityId(String activityId) {
        List<ProductVO> list = productDao.selectProductByActivityId(activityId);
        return list;
    }
}
