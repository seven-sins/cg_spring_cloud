package com.infox.tourism.dao;

import org.apache.ibatis.annotations.Mapper;

import com.infox.tourism.entity.IntegralIncomeEntity;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 积分收入表
 * @author Tan Ling
 * 2018年12月15日 下午1:31:08
 */
@Mapper
public interface IntegralIncomeDao extends BaseMapper<IntegralIncomeEntity> {

}
