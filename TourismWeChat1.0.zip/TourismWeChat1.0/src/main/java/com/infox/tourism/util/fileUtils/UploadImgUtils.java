package com.infox.tourism.util.fileUtils;

import java.io.File;
import java.io.IOException;
import java.net.UnknownHostException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.infox.tourism.util.R;

/**
 * @Author: cenjinxing
 * @Date: Created in 2018/12/2 9:14
 **/
public class UploadImgUtils {

	private static final Logger LOG = LoggerFactory.getLogger(UploadImgUtils.class);

//	@Autowired
//	private ThumbnailService thumbnailService;


	private static String UPLOAD_PATH;

	private static String UPLOAD_URL;

	public static void initPath(String uploadPath, String uploadUrl) {
		UploadImgUtils.UPLOAD_PATH = uploadPath;
		UploadImgUtils.UPLOAD_URL = uploadUrl;
	}

	private final ResourceLoader resourceLoader;

	@Autowired
	public UploadImgUtils(ResourceLoader resourceLoader) {
		this.resourceLoader = resourceLoader;
	}

	public ResponseEntity<?> getFile(String filename) {

		try {
			return ResponseEntity.ok(resourceLoader.getResource("file:" + Paths.get(UPLOAD_PATH, filename).toString()));
		} catch (Exception e) {
			return ResponseEntity.notFound().build();
		}

	}

	// 上传方法
//    @RequestMapping(method = RequestMethod.POST, value = "/imgupload")
	public static R handleFileUpload(MultipartFile file, RedirectAttributes redirectAttributes,
			HttpServletRequest request) throws UnknownHostException {
		System.out.println(request.getContextPath());
		System.out.println(request.getPathInfo());
		System.out.println(request.getHeader("WL-Proxy-Client-IP"));

		System.out.println(request.getParameter("member"));

		// 获取IP地址
		// String host = InetAddress.getLocalHost().getHostAddress();

//        System.out.println(InetAddress.getAllByName().);

		// 得到上传时的文件名
		String uploadFileName = file.getOriginalFilename();

		// 获取文件的后缀
		String fileSuffixName = uploadFileName.substring(uploadFileName.lastIndexOf("."));

		// 生成新文件名称
		String newFileName = FileNameUtils.getFileName(uploadFileName);

		String imgPath = UPLOAD_PATH + newFileName;
		
		LOG.info("=============new file: " + newFileName);

		File file1 = new File(imgPath);

		System.out.println(imgPath + "文件名称" + fileSuffixName + "文件后缀");

		// 保存文件
		if (!file.isEmpty()) {
			try {
				file.transferTo(file1);
				redirectAttributes.addFlashAttribute("message",
						"You successfully uploaded" + file.getOriginalFilename() + "!");
			} catch (IOException e) {
				redirectAttributes.addFlashAttribute("message",
						"Failed to upload" + file.getOriginalFilename() + "=>" + e.getMessage());
			}
		} else {
			redirectAttributes.addFlashAttribute("message",
					"Failed to upload" + file.getOriginalFilename() + "because it was empty");
		}

		// String filename = "/"+uploadFileName;

		System.out.println(newFileName);

		return R.ok().put("path", UPLOAD_URL + file1.getName()).put("filename", file1.getName());

	}

	// 删除文件
	public static boolean delFile(String path) {

		// String resultInfo = null;

		if (path == null) {
			return false;
		}

		int lastIndexOf = path.lastIndexOf("/");
		String sb = path.substring(lastIndexOf + 1, path.length());
		sb = UPLOAD_PATH + sb;
		File file = new File(sb);
		if (file.exists()) {
			if (file.delete()) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	public static R filesUpload(MultipartFile[] files, HttpServletRequest request) {

		System.out.println("fileUpload 文件上传 ===== " + files.length);

		List<String> list = new ArrayList<>();
		if (files != null && files.length > 0) {
			for (int i = 0; i < files.length; i++) {
				MultipartFile file = files[i];
				// 保存文件
				list = saveFile(request, file, list);

			}
		}
		// 写着测试，删了就可以
		for (int i = 0; i < list.size(); i++) {
			System.out.println("集合里面的数据" + list.get(i));
		}
		return R.ok().put("data", list);
	}

	private static List<String> saveFile(HttpServletRequest request, MultipartFile file, List<String> list) {
		// 判断文件是否为空
		if (!file.isEmpty()) {
			try {
				// 保存的文件路径(如果用的是Tomcat服务器，文件会上传到\\%TOMCAT_HOME%\\webapps\\YourWebProject\\upload\\文件夹中
				// )

				// 得到上传时的文件名
				String uploadFileName = file.getOriginalFilename();
				// 获取文件的后缀
				// String fileSuffixName =
				// uploadFileName.substring(uploadFileName.lastIndexOf("."));

				// 生成新文件名称
				String newFileName = FileNameUtils.getFileName(uploadFileName);
				LOG.info("=============new file: " + newFileName);
				list.add(UPLOAD_URL + newFileName);
				String fileName = UPLOAD_PATH + newFileName;
				File saveDir = new File(fileName);
				LOG.info("=============save dir: " + saveDir.getPath());
				if (!saveDir.getParentFile().exists()) {
					saveDir.getParentFile().mkdirs();
				}

				// 转存文件
				file.transferTo(saveDir);
				return list;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return list;
	}

}
