package com.infox.tourism.service.v2.impl;


import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infox.tourism.dao.v2.WithdrawalRecordMapper;
import com.infox.tourism.entity.WithdrawalRecordEntity;
import com.infox.tourism.service.v2.WithdrawalRecordService;
import com.infox.tourism.util.UUIDUtil;

/**
 * 
 * @author yuanfang
 * 2019年5月14日 上午10:51:43
 */
@Service
public class WithdrawalRecordServiceImpl implements WithdrawalRecordService{
	
	@Autowired
	WithdrawalRecordMapper withdrawalRecordMapper;

	@Override
	public void insert(WithdrawalRecordEntity withdrawalRecordEntity) {
		withdrawalRecordEntity.setWithdrawalRecordId(UUIDUtil.create());
		// 1:申请提现,2:通过,3:拒绝
		withdrawalRecordEntity.setStatus(1);
		withdrawalRecordEntity.setCreateTime(new Date());
		withdrawalRecordMapper.insert(withdrawalRecordEntity);
	}

	@Override
	public List<WithdrawalRecordEntity> selectByUserId(String userId) {
		List<WithdrawalRecordEntity> list = withdrawalRecordMapper.selectByUserId(userId);
		return list;
	}

	@Override
	public List<WithdrawalRecordEntity> selectAllWithdrawalRecord(WithdrawalRecordEntity withdrawalRecordEntity) {
		List<WithdrawalRecordEntity> list = withdrawalRecordMapper.selectAllWithdrawalRecord(withdrawalRecordEntity);
		return list;
	}

	@Override
	public List<WithdrawalRecordEntity> findByUserId(String userId) {
		/*List<WithdrawalRecordEntity> list= withdrawalRecordMapper.findByUserId(userId);*/
		return withdrawalRecordMapper.findByUserId(userId);
	}

}
