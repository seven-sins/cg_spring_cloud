package com.infox.tourism;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.web.client.RestTemplate;

import com.infox.common.annotation.EnableAppletUtil;
import com.infox.common.annotation.EnableDatabase;
import com.infox.common.annotation.EnableKafkaConfig;
import com.infox.common.annotation.EnablePayment;
import com.infox.common.annotation.EnableRedis;
import com.infox.common.annotation.EnableRedisDistributedLock;
import com.infox.common.annotation.EnableSms;
import com.infox.common.annotation.EnableWechatUtil;

/**
 * @author Tan Ling
 * 2019年1月3日 上午11:48:46
 */
// 启用kafka
@EnableKafkaConfig
// 启用数据库
@EnableDatabase
// 启用redis缓存
@EnableRedis
// 启用分布式锁
@EnableRedisDistributedLock
// 启用收银宝支付功能
@EnablePayment
// 启用微信工具类(消息推送, 信息获取等)
@EnableWechatUtil
// 小程序工具类
@EnableAppletUtil
//启用手机短信发送
@EnableSms
@EnableAsync
@SpringBootApplication
public class TourismApplication {

	public static void main(String[] args) {
		SpringApplication.run(TourismApplication.class, args);
	}

	@Bean
	public RestTemplate restTemplte() {
		return new RestTemplate();
	}
}
