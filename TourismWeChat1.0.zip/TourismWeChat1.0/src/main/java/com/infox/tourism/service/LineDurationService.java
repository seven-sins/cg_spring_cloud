package com.infox.tourism.service;

import java.util.List;

import com.infox.tourism.entity.vo.lineVO.LineDurationVO;

/**
 * 路线时长表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-06 17:14:57
 */
public interface LineDurationService {

    List<LineDurationVO> selectTop6LineDuration();

}

