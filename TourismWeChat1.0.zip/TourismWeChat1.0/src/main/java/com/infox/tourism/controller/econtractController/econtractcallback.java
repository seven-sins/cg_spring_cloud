package com.infox.tourism.controller.econtractController;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.infox.tourism.entity.v2.econtract.Econtract;
import com.infox.tourism.service.v2.EcontractService;
import com.infox.tourism.util.UUIDUtil;

import io.swagger.annotations.Api;

@Api(description = "合同回调")
@RequestMapping("/econtract")
@RestController
public class econtractcallback {
	

	
	@Autowired
	EcontractService econtractService;
    
	@PostMapping("/callback")
	public String callback(@RequestBody JSONObject callbackInfo) {
		System.out.println(callbackInfo.toJSONString());
		
		JSONObject jsonData = callbackInfo.getJSONObject("data");
		String contractNumber = jsonData.getString("contractNumber");  //合同编号
		//int state = jsonData.getIntValue("state");  //状态ID
		
		
		
		Econtract econtract = new Econtract();
		econtract.setEcontractId(UUIDUtil.create());
		econtract.setEcontractContent(callbackInfo.toJSONString());
		econtract.setCreateTime(new Date());
		econtract.setEcontractNumber(contractNumber);
		
		
		
		econtractService.insert(econtract);
		
		return "success";
		
	}
}
