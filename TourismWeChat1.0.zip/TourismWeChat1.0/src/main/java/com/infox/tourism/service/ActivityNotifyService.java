package com.infox.tourism.service;

import com.infox.tourism.config.resolver.AuthUser;

/**
 * @Author: cenjinxing
 * @Date: Created in 2019/3/18 10:22
 **/
public interface ActivityNotifyService{

    /**
     * 添加通知信息
     * @param userId
     * @return
     */
    int insertNotify(AuthUser authUser, String activityId);
}
