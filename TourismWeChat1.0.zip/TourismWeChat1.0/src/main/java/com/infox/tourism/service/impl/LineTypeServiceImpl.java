package com.infox.tourism.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infox.common.base.impl.BaseServiceImpl;
import com.infox.tourism.dao.LineTypeDao;
import com.infox.tourism.entity.LineTypeEntity;
import com.infox.tourism.entity.vo.lineVO.LineTypeVO;
import com.infox.tourism.service.LineTypeService;

import tk.mybatis.mapper.common.BaseMapper;


/**
 * 路线分类表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-06 17:23:31
 */
@Service
public class LineTypeServiceImpl extends BaseServiceImpl<LineTypeEntity> implements LineTypeService {

    @Resource
    public void setBaseMapper(BaseMapper<LineTypeEntity> lineTypeDao) {
		this.baseMapper = lineTypeDao;
	}

	@Autowired
    private LineTypeDao lineTypeDao;

    @Override
    public List<LineTypeVO> selectAllLineType() {
        List<LineTypeVO> list = lineTypeDao.selectAllLineType();
        return list;
    }

    @Override
    public List<LineTypeVO> selectTop3LineType() {
    	return lineTypeDao.selectTop3LineType();
    }
}
