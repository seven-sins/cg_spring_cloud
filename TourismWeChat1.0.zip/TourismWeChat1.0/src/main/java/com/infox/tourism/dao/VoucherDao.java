package com.infox.tourism.dao;

import com.infox.tourism.entity.VouchersPushEntity;
import com.infox.tourism.entity.vo.couponVo.VoucherVo;
import com.infox.tourism.entity.vo.indexVO.VoucherIndexVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.BaseMapper;

import java.util.List;

/**
 * 代金券推送表
 */
@Mapper
public interface VoucherDao extends BaseMapper<VouchersPushEntity> {
	
	/**
	 * 查询按用户推送的优惠券
	 * @author Tan Ling
	 * @date 2019年6月12日 下午5:29:14
	 * @param userId
	 * @return
	 */
    List<VoucherIndexVO> selectUserPushVoucher(@Param("userId") String userId);
    /**
     * 查询按城市推送的优惠券
     * @author Tan Ling
     * @date 2019年6月12日 下午5:26:28
     * @param userId
     * @param locationId
     * @return
     */
    List<VoucherIndexVO> selectCityPushVoucher(@Param("userId") String userId, @Param("locationId") String locationId);

    void insertReceiveVoucher(@Param("userId") String userId, @Param("voucherIds") List<String> voucherIds);

    List<VoucherVo> selectVoucherReceiveByUserId(@Param("userId") String userId);
}
