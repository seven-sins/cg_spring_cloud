package com.infox.tourism.service;

import com.infox.tourism.entity.vo.indexVO.DestinationIndexVO;

import java.util.List;

/**
 * 目的地维护表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-06 17:14:57
 */
public interface DestinationService {
	
	/**
	 * 分页查询所有目的地
	 * @author Tan Ling
	 * @date 2019年1月18日 上午11:10:24
	 * @param destinationId
	 * @return
	 */
	List<DestinationIndexVO> queryPage(String destinationId);
}
