package com.infox.tourism.controller.order;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageInfo;
import com.infox.common.utils.Assert;
import com.infox.common.utils.ValidationUtil;
import com.infox.common.utils.response.Result;
import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.entity.EvaluationEntity;
import com.infox.tourism.entity.OrderInfoEntity;
import com.infox.tourism.entity.order.OrderArgs;
import com.infox.tourism.entity.vo.OrderVO.OrderDetailVO;
import com.infox.tourism.entity.vo.OrderVO.OrderRefund;
import com.infox.tourism.entity.vo.OrderVO.OrderVO;
import com.infox.tourism.service.EvaluationService;
import com.infox.tourism.service.OrderInfoService;
import com.infox.tourism.util.R;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import springfox.documentation.annotations.ApiIgnore;

@RestController
@RequestMapping("/myOrder")
@Api(description = "我的_订单接口", tags = { "MyOrderController" })
public class MyOrderController {
	private static final Logger LOG = Logger.getLogger(MyOrderController.class);
	@Autowired
	private OrderInfoService orderInfoService;

	/**
	 * 创建订单
	 * 
	 * @author Tan Ling
	 * @date 2019年2月15日 上午9:20:30
	 * @param user
	 * @param order
	 * @param groupId
	 * @return
	 */
	@ApiOperation(value = "创建订单", response = OrderInfoEntity.class)
	@PostMapping("/create")
	public R create(@ApiIgnore AuthUser user, @ApiParam @Valid @RequestBody OrderInfoEntity order,
			@RequestParam(value = "groupId", defaultValue = "", required = false) String groupId) {
		if (StringUtils.isNotBlank(groupId)) {
			order.setGroupId(groupId);
		}
		LOG.info("=============create order, shareUserId = " + order.getShareUserId());
		/**
		 * 验证出行人列表
		 */
		ValidationUtil.validList(order.getPedestrianList());
		/**
		 * 验证商品列表
		 */
		if (order.getProductList() != null && !order.getProductList().isEmpty()) {
			ValidationUtil.validList(order.getProductList());
		}
		order = orderInfoService.insert(user, order, order.getBuyType() == null ? 0 : order.getBuyType());

		return R.ok().put("data", order);
	}

	/**
	 * 发起拼单
	 * 
	 * @author Tan Ling
	 * @date 2019年2月15日 上午9:20:38
	 * @param user
	 * @param order
	 * @return
	 */
	@ApiOperation(value = "发起拼单", response = OrderInfoEntity.class)
	@PostMapping("/createGroup")
	public R createGroup(@ApiIgnore AuthUser user, @Valid @RequestBody OrderInfoEntity order) {
		/**
		 * 数据验证
		 */
		this.validGroupData(order);

		order = orderInfoService.createGroup(user, order);

		return R.ok().put("data", order);
	}

	/**
	 * 加入拼单
	 * 
	 * @author Tan Ling
	 * @date 2019年2月15日 上午9:20:44
	 * @param user
	 * @param order
	 * @param groupId
	 * @return
	 */
	@ApiOperation(value = "加入拼单", response = OrderInfoEntity.class)
	@PostMapping("/joinGroup")
	public R joinGroup(@ApiIgnore AuthUser user, @Valid @RequestBody OrderInfoEntity order,
			@RequestParam(value = "groupId", defaultValue = "", required = false) String groupId) {
		/**
		 * 数据验证
		 */
		Assert.notEmpty(groupId, "拼单ID不能为空");

		this.validGroupData(order);

		order = orderInfoService.joinGroup(user, order, groupId);

		return R.ok().put("data", order);
	}

	/**
	 * 评价
	 */
	@Autowired
	private EvaluationService evaluationService;

	/**
	 * 根据openId 根据支付状态查询
	 * 
	 * @return 0，未付款, 1，已付款 -1,退款
	 */
	@ApiOperation(value = "我的订单,0待付款，1已报名，-1已退出", response = OrderVO.class)
	@GetMapping("/selectByOpenIdAndPayStatus")
	public R selectByOpenIdAndPayStatus(@ApiIgnore AuthUser authUser, int pageNum, int pageSize, Integer payStatus) {
		List<OrderVO> list = orderInfoService.selectByUserIdAndPayStatus(pageNum, pageSize, authUser.getUserId(),
				payStatus);

		PageInfo<OrderVO> pageInfo = new PageInfo<>(list);

		HashMap<String, Object> map = new HashMap<>();
		map.put("total", pageInfo.getTotal());
		map.put("list", list);

		return R.ok().put("data", map);
	}

	/**
	 * 根据openId 全部订单
	 */
	@ApiOperation(value = "全部订单", response = OrderVO.class)
	@GetMapping("/getByOrder")
	public R getByOrder(@ApiIgnore AuthUser authUser, int pageNum, int pageSize) {
		List<OrderVO> list = orderInfoService.getByOrder(pageNum, pageSize, authUser.getUserId());

		PageInfo<OrderVO> pageInfo = new PageInfo<>(list);

		HashMap<String, Object> map = new HashMap<>();
		map.put("total", pageInfo.getTotal());
		map.put("list", list);

		return R.ok().put("data", map);
	}

	@ApiOperation(value = "我的订单,4,已结束", response = OrderVO.class)
	@GetMapping("/selectByOpenIdAndActivityStatus")
	public R selectByOpenIdAndActivityStatus(@ApiIgnore AuthUser authUser, int pageNum, int pageSize) {
		List<OrderVO> list = orderInfoService.selectByUserIdAndActivityStatus(pageNum, pageSize, authUser.getUserId());

		PageInfo<OrderVO> pageInfo = new PageInfo<>(list);

		HashMap<String, Object> map = new HashMap<>();
		map.put("total", pageInfo.getTotal());
		map.put("list", list);

		return R.ok().put("data", map);
	}

	@ApiOperation(value = "  0，新订单  1 , 取消订单  2 订单审核  取消订单", response = OrderInfoEntity.class)
	@PostMapping("/updateByOrderIdAndOrderStatus")
	public R updateByOrderIdAndOrderStatus(@RequestBody OrderInfoEntity orderInfoEntity) {
		Assert.notEmpty(orderInfoEntity.getOrderId(), "订单id不能为空");

		boolean b = orderInfoService.updateByOrderIdAndOrderStatus(orderInfoEntity);

		return R.ok().put("data", b);
	}

	@ApiOperation(value = "根据订单id查询", response = OrderVO.class)
	@GetMapping("/selectByOrderId")
	public R selectByOrderId(String orderId) {
		OrderVO orderVO = orderInfoService.selectByOrderId(orderId);

		return R.ok().put("data", orderVO);
	}

	@ApiOperation(value = "活动评价", response = OrderVO.class)
	@PostMapping("/insertActivityEvaluation")
	public R insertActivityEvaluation(@RequestBody OrderVO orderVO, @ApiIgnore AuthUser user) {
		boolean b = evaluationService.insertActivityEvaluation(orderVO, user);

		return R.ok().put("data", b);
	}

	@ApiOperation(value = "根据活动id查询评价详情", response = OrderVO.class)
	@GetMapping("/selectEvaluationByActivityId")
	public R selectEvaluationByActivityId(@ApiIgnore AuthUser user, String activityId) {

		EvaluationEntity evaluationEntity = evaluationService.selectEvaluationByActivityId(user.getUserId(),
				activityId);

		return R.ok().put("data", evaluationEntity);
	}

	/**
	 * 查询订单详情(出行人及增值商品明细) status == 1时，查询正常状态数据(非改期非退款等)
	 * 
	 * @author Tan Ling
	 * @date 2019年2月18日 下午2:10:56
	 * @param orderId
	 * @return
	 */
	@ApiImplicitParams({ @ApiImplicitParam(name = "orderId", value = "订单ID", dataType = "string", paramType = "path"),
			@ApiImplicitParam(name = "status", value = "状态(1查询有效状态下的数据)", dataType = "int", paramType = "query") })
	@ApiOperation(value = "查询订单详情(出行人及增值商品明细)", response = OrderDetailVO.class)
	@GetMapping("/orderDetail/{orderId}")
	public R orderDetail(@PathVariable("orderId") String orderId, Integer status) {
		return R.ok().put("data", orderInfoService.queryOrderDetail(orderId, status));
	}

	/**
	 * 查询订单金额 status == 1时，查询正常状态数据(非改期非退款等)
	 * 
	 * @author Tan Ling
	 * @date 2019年2月19日 上午9:55:51
	 * @param orderId
	 * @param status
	 * @return
	 */
	@ApiOperation(value = "查询订单金额")
	@ApiImplicitParams({ @ApiImplicitParam(name = "orderId", value = "订单ID", dataType = "string", paramType = "path"),
			@ApiImplicitParam(name = "status", value = "状态(1查询有效状态下的数据)", dataType = "int", paramType = "query") })
	@GetMapping("/orderAmount/{orderId}")
	public R amount(@PathVariable("orderId") String orderId, Integer status) {
		return R.ok().put("data", orderInfoService.queryOrderAmount(orderId, status));
	}

	@ApiOperation(value = "申请退团", response = OrderVO.class)
	@PostMapping("/applyRetreat")
	public R applyRetreat(@RequestBody OrderVO orderVO) {

		boolean b = orderInfoService.applyRetreat(orderVO.getOrderId());

		if (b == false) {
			return R.error(6006, "申请退团失败");
		}

		return R.ok().put("data", b);
	}

	/**
	 * 返回订单信息 { data: orderInfo: {}, activityInfo: {} }
	 * 
	 * @author Tan Ling
	 * @date 2019年2月15日 上午9:20:44
	 * @param orderId
	 * @return
	 */
	@ApiOperation("根据订单ID查询活动信息")
	@GetMapping("/orderInfo")
	public R info(String orderId,
			// type=4查退款数据,
			@RequestParam(value = "type", required = false) Integer type) {
		Assert.notEmpty(orderId, "订单ID不能为空");
		Map<String, Object> orderInfo = orderInfoService.getOrderInfo(orderId, type);

		return R.ok().put("data", orderInfo);
	}

	/**
	 * 查询分享列表
	 * 
	 * @author Tan Ling
	 * @date 2019年2月21日 上午11:49:26
	 * @return
	 */
	@ApiOperation("查询待分享信息列表")
	@GetMapping("/shareList")
	public R shareList(@ApiIgnore AuthUser authUser) {
		return R.ok().put("data", orderInfoService.selectShareList(authUser.getUserId()));
	}

	@ApiOperation("查询待分享信息列表")
	@GetMapping("/share/{orderId}")
	public R share(@PathVariable("orderId") String orderId, @ApiIgnore AuthUser authUser) {
		return R.ok().put("data", orderInfoService.selectShare(orderId, authUser.getUserId()));
	}

	@ApiOperation("取消订单")
	@PostMapping("/cancel/{orderId}")
	public R cancel(@PathVariable("orderId") String orderId, @ApiIgnore AuthUser authUser) {
		orderInfoService.cancel(orderId, authUser.getUserId());

		return R.success();
	}

	/**
	 * 申请退款
	 * 
	 * @author Tan Ling
	 * @date 2019年2月18日 上午9:37:21
	 * @param orderRefund
	 * @return
	 */
	@PostMapping("/applyRefund")
	public R applyRefund(@RequestBody OrderRefund orderRefund, @ApiIgnore AuthUser authUser) {
		Assert.notEmpty(orderRefund.getPedestrianId(), "出行人ID不能为空");
		orderInfoService.applyRefund(orderRefund, authUser, true);

		return R.success();
	}

	/**
	 * 计算退款金额
	 * 
	 * @author Tan Ling
	 * @date 2019年5月23日 下午4:29:38
	 * @return
	 */
	@PostMapping("/getRefundAmount")
	public R getRefundAmount(@RequestBody OrderRefund orderRefund, @ApiIgnore AuthUser authUser) {
		Assert.notEmpty(orderRefund.getPedestrianId(), "出行人ID不能为空");
		BigDecimal refundAmount = orderInfoService.applyRefund(orderRefund, authUser, false);

		return R.ok().put("data", refundAmount);
	}

	/**
	 * 查看活动剩余报名人数
	 * 
	 * @author Tan Ling
	 * @date 2019年4月18日 上午9:21:25
	 * @param orderId
	 * @return
	 */
	@GetMapping("/querySurplus/{orderId}")
	public R surplus(@PathVariable("orderId") String orderId) {
		Integer surplusNum = orderInfoService.querySurplus(orderId);

		return R.ok().put("data", surplusNum);
	}
	
	/**
	 * 查询当前活动未支付订单
	 * @author Tan Ling
	 * @date 2019年7月24日 下午3:48:52
	 * @param activityId
	 * @return
	 */
	@GetMapping("/getNonpaymentOrderByActivityId/{activityId}")
	public Result<OrderArgs> getOrderByActivityId(@PathVariable("activityId") String activityId, AuthUser user){
		OrderArgs orderArgs = orderInfoService.getNonpaymentOrderByActivityId(activityId, user.getUserId());
		
		return new Result<>(orderArgs);
	}

	/**
	 * 验证出行人列表(拼单只允许一个出行人)
	 * 
	 * @author Tan Ling
	 * @date 2019年2月15日 上午9:21:51
	 * @param order
	 */
	private void validGroupData(OrderInfoEntity order) {
		/**
		 * 验证出行人列表(拼单只允许一个出行人)
		 */
		ValidationUtil.validList(order.getPedestrianList());
		Assert.isTrue(order.getPedestrianList().size() == 1, "拼单只允许有且仅有一个出行人");
		/**
		 * 验证商品列表
		 */
		if (order.getProductList() != null && !order.getProductList().isEmpty()) {
			ValidationUtil.validList(order.getProductList());
		}
	}

}
