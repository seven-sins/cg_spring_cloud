package com.infox.tourism.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infox.common.utils.Assert;
import com.infox.common.utils.redis.RedisConstant;
import com.infox.common.utils.redis.RedisService;
import com.infox.tourism.dao.InsuranceProductsDao;
import com.infox.tourism.entity.InsuranceProductsEntity;
import com.infox.tourism.service.InsuranceProductService;

/**
 * 保险
 * @author Tan Ling
 * @date 2019年1月29日 下午4:47:59
 */
@Service
public class InsuranceProductServiceImpl implements InsuranceProductService {

	@Autowired
	private InsuranceProductsDao insuranceProductsDao;
	@Autowired
	private RedisService redisService;

	@Override
	public InsuranceProductsEntity getInsuranceProductById(String insuranceProductId) {
		Assert.notEmpty(insuranceProductId, "insuranceProductId不能为空");
		InsuranceProductsEntity insuranceProduct = (InsuranceProductsEntity) redisService.get(RedisConstant.INSURANCE_PRODUCT_PREFIX + insuranceProductId);
		if(insuranceProduct != null) {
			return insuranceProduct;
		}
		insuranceProduct = insuranceProductsDao.selectByPrimaryKey(insuranceProductId);
		if(insuranceProduct != null) {
			redisService.add(RedisConstant.INSURANCE_PRODUCT_PREFIX + insuranceProductId, insuranceProduct, 1000);
			return insuranceProduct;
		}
		
		return null;
	}
}
