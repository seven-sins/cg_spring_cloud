package com.infox.tourism.util.fileUtils;

import java.util.UUID;

/**
 * 生成文件名
 * @Author: cenjinxing
 * @Date: Created in 2018/12/1 18:58
 **/
public class UUIDUtils {

    public static String getUUID(){
        return UUID.randomUUID().toString().replace("-", "");
    }
}
