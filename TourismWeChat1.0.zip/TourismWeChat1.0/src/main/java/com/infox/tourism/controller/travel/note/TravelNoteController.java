package com.infox.tourism.controller.travel.note;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.infox.common.utils.Assert;
import com.infox.common.utils.ValidationUtil;
import com.infox.common.utils.response.Result;
import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.config.resolver.Guest;
import com.infox.tourism.entity.travel.note.TravelNote;
import com.infox.tourism.service.v2.travel.note.TravelNoteService;

/**
 * 游记
 * @author Tan Ling
 * @date 2019年7月5日 下午3:39:32
 */
@RestController
public class TravelNoteController {

	@Autowired
	TravelNoteService travelNoteService;
	/**
	 * 游记列表查询
	 * @author Tan Ling
	 * @date 2019年7月5日 下午3:52:23
	 * @param pageNum
	 * @param pageSize
	 * @param travelNote
	 * @param guest
	 * @return
	 */
	@GetMapping("/travelNote")
	public Result<List<TravelNote>> find(int pageNum, int pageSize, TravelNote travelNote, @RequestParam(value = "mine", required = false) Integer mine, Guest guest){
		PageHelper.startPage(pageNum, pageSize);
		// 如isMine == null, 只查询已发布的游记
		if(mine != null && mine == 1) {
			Assert.notEmpty(guest.getUserId(), "用户信息获取失败");
			travelNote.setUserId(guest.getUserId());
		} else {
			// 1:草稿, 2:提交审核, 3:审核通过
			travelNote.setStatus(3);
		}
		List<TravelNote> list = travelNoteService.find(travelNote, guest);
		
		return new Result<>(list).total(new PageInfo<TravelNote>(list).getTotal());
	}
	
	@PostMapping("/travelNote/insert")
	public Result<?> insert(@Valid @RequestBody TravelNote travelNote, AuthUser user){
		travelNote.setUserId(user.getUserId());
		travelNote.setIsDelete(0);
		ValidationUtil.validList(travelNote.getList());
		// 验证明细记录
		travelNoteService.insert(travelNote);
		
		return Result.SUCCESS;
	}
	
	@PostMapping("/travelNote/update/{travelNoteId}")
	public Result<?> update(@PathVariable("travelNoteId") String travelNoteId, @Valid @RequestBody TravelNote travelNote, AuthUser user){
		travelNote.setTravelNoteId(travelNoteId);
		travelNote.setUserId(user.getUserId());
		// 验证明细记录
		ValidationUtil.validList(travelNote.getList());
		travelNoteService.update(travelNote);
		
		return Result.SUCCESS;
	}
	
	/**
	 * 删除游记
	 * @author Tan Ling
	 * @date 2019年7月5日 下午4:22:32
	 * @param travelNoteId
	 * @param user
	 * @return
	 */
	@PostMapping("/travelNote/delete/{travelNoteId}")
	public Result<?> delete(@PathVariable("travelNoteId") String travelNoteId, AuthUser user){
		/**
		 * 数据验证
		 */
		TravelNote dbData = travelNoteService.get(travelNoteId);
		Assert.notNull(dbData, "参数错误, 游记不存在");
		Assert.isTrue(user.getUserId().equals(dbData.getUserId()), "游记所属用户与当前用户不一致, 拒绝访问");
		travelNoteService.deleteByTravelNoteId(travelNoteId);
		
		return Result.SUCCESS;
	}
	
	/**
	 * 单记录查询
	 * @author Tan Ling
	 * @date 2019年7月5日 下午3:58:38
	 * @param travelNoteId
	 * @return
	 */
	@GetMapping("/travelNote/get/{travelNoteId}")
	public Result<TravelNote> get(@PathVariable("travelNoteId") String travelNoteId, Guest guest){
		return new Result<>(travelNoteService.getByTravelNoteId(travelNoteId, guest));
	}
	
	/**
	 * 点赞+1
	 * @author Tan Ling
	 * @date 2019年7月5日 下午4:17:51
	 * @param travelNoteId
	 * @return
	 */
	@PostMapping("travelNote/addLikeNum/{travelNoteId}")
	public Result<Map<String, Integer>> addLikeNum(@PathVariable("travelNoteId") String travelNoteId, AuthUser user){
		Map<String, Integer> map = new HashMap<>();
		map.put("isLike", travelNoteService.addLikeNum(travelNoteId, user));
		
		return new Result<>(map);
	}
	
	/**
	 * 浏览+1
	 * @author Tan Ling
	 * @date 2019年7月5日 下午4:18:14
	 * @param travelNoteId
	 * @return
	 */
	@PostMapping("travelNote/addViewNum/{travelNoteId}")
	public Result<?> addViewNum(@PathVariable("travelNoteId") String travelNoteId){
		travelNoteService.addViewNum(travelNoteId);
		return Result.SUCCESS;
	}
	
	/**
	 * 分享+1
	 * @author Tan Ling
	 * @date 2019年7月5日 下午4:18:41
	 * @param travelNoteId
	 * @return
	 */
	@PostMapping("travelNote/addShareNum/{travelNoteId}")
	public Result<?> addShareNum(@PathVariable("travelNoteId") String travelNoteId){
		travelNoteService.addShareNum(travelNoteId);
		return Result.SUCCESS;
	}
	
	/**
	 * 收藏数+1
	 * @author Tan Ling
	 * @date 2019年7月5日 下午4:23:48
	 * @param travelNoteId
	 * @param user
	 * @return
	 */
	@PostMapping("travelNote/addCollectNum/{travelNoteId}")
	public Result<Map<String, Integer>> addCollectNum(@PathVariable("travelNoteId") String travelNoteId, AuthUser user){
		Map<String, Integer> map = new HashMap<>();
		map.put("isCollect", travelNoteService.addCollectNum(travelNoteId, user));
		
		return new Result<>(map);
	}
	
	/**
	 * 用户收藏的游记
	 * @author Tan Ling
	 * @date 2019年7月9日 下午3:52:14
	 * @param pageNum
	 * @param pageSize
	 * @param travelNote
	 * @param user
	 * @return
	 */
	@GetMapping("/travelNote/collectList")
	public Result<List<TravelNote>> collectList(int pageNum, int pageSize, TravelNote travelNote, AuthUser user){
		PageHelper.startPage(pageNum, pageSize);
		List<TravelNote> list = travelNoteService.collectList(travelNote, user);
		
		return new Result<>(list).total(new PageInfo<TravelNote>(list).getTotal());
	}
}
