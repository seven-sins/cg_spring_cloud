package com.infox.tourism.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.annotations.Param;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.infox.common.exception.CustomException;
import com.infox.common.utils.Assert;
import com.infox.common.utils.redis.RedisConstant;
import com.infox.common.utils.redis.RedisService;
import com.infox.tourism.dao.ActivityDao;
import com.infox.tourism.dao.ActivityInfoDao;
import com.infox.tourism.dao.ActivityRulesDao;
import com.infox.tourism.dao.ActivitySingleRecordDao;
import com.infox.tourism.dao.DurationScopeMapper;
import com.infox.tourism.dao.EvaluationDao;
import com.infox.tourism.dao.JoinCityMapper;
import com.infox.tourism.dao.LineDao;
import com.infox.tourism.dao.LineDurationDao;
import com.infox.tourism.dao.OrderInfoDao;
import com.infox.tourism.dao.PedestrianInfoDao;
import com.infox.tourism.dao.ProductDao;
import com.infox.tourism.dao.SpikeActivityRuleDao;
import com.infox.tourism.dao.activity.ActivityLeaderMapper;
import com.infox.tourism.dao.activity.ActivityMapper;
import com.infox.tourism.entity.ActivityInfoEntity;
import com.infox.tourism.entity.ActivityLeaderRelation;
import com.infox.tourism.entity.ActivityRulesEntity;
import com.infox.tourism.entity.DurationScope;
import com.infox.tourism.entity.InsuranceProductsEntity;
import com.infox.tourism.entity.JoinCity;
import com.infox.tourism.entity.LineDurationEntity;
import com.infox.tourism.entity.LineEntity;
import com.infox.tourism.entity.PedestrianInfoEntity;
import com.infox.tourism.entity.SpikeActivityRuleEntity;
import com.infox.tourism.entity.v2.activityInfo.ActivityTripVO;
import com.infox.tourism.entity.v2.activityInfo.SecondKillActivity;
import com.infox.tourism.entity.vo.activity.Activity;
import com.infox.tourism.entity.vo.activity.ActivityBase;
import com.infox.tourism.entity.vo.activity.ActivityBaseParams;
import com.infox.tourism.entity.vo.activity.ActivityOutset;
import com.infox.tourism.entity.vo.activityDetailVO.ActivityBriefVO;
import com.infox.tourism.entity.vo.activityDetailVO.LineEvaluationVO;
import com.infox.tourism.entity.vo.activityDetailVO.PayActivityVO;
import com.infox.tourism.entity.vo.activityDetailVO.TripPeopleVO;
import com.infox.tourism.entity.vo.baseVo.ActivityBaseVO;
import com.infox.tourism.entity.vo.lineVO.LineDurationCache;
import com.infox.tourism.entity.vo.single.ActivitySingleRecordInitiator;
import com.infox.tourism.service.ActivityService;
import com.infox.tourism.service.InsuranceProductService;
import com.infox.tourism.service.LineService;
import com.infox.tourism.util.DateUtil;
import com.infox.tourism.util.ImgUtil;

/**
 * 公众号活动查询
 * 
 * @author Tan Ling
 * @date 2019年1月15日 下午2:55:48
 */
@Service
public class ActivityServiceImpl implements ActivityService {
	private static final Logger LOG = LoggerFactory.getLogger(ActivityServiceImpl.class);
	/**
	 * 1已报满 2已成行 3报名中 4已截止 5 即将成行 6已下架
	 */
	// private static final List<Integer> ACTIVITY_STATUS = Arrays.asList(1, 2, 5);
	/**
	 * 活动类型(1:秒杀,2:拼单,3:砍价. 前端对接原因, 此处用string)
	 */
	static final String SINGLE = "2";
	static final String SECKILL = "1";
	static final String BARGAIN = "3";
	private static final Pattern SCOPE = Pattern.compile("-");
	private static final Pattern UP = Pattern.compile("上");
	private static final Pattern DOWN = Pattern.compile("下");
	private static final String NAN = "\\D+";
	private static final String SYMBOL_REGEX = "\\-";
	private static List<BigDecimal> SUB_POINT = new ArrayList<BigDecimal>();
	/**
	 * 活动
	 */
	@Autowired
	private ActivityMapper activityMapper;
	/**
	 * 活动领队
	 */
	@Autowired
	private ActivityLeaderMapper activityLeaderMapper;
	/**
	 * redis
	 */
	@Autowired
	private RedisService redisService;
	@Autowired
	private ActivityDao activityInfoDao;
	@Autowired
	private ActivityRulesDao activityRulesDao;
	@Autowired
	private ActivityInfoDao activityInfo;
	@Autowired
	private ProductDao productDao;
	@Autowired
	private ActivitySingleRecordDao activitySingleRecordDao;
	@Autowired
	private PedestrianInfoDao pedestrianInfoDao;
	@Autowired
	private LineService lineService;
	@Autowired
	private DurationScopeMapper durationScopeMapper;
	@Autowired
	private LineDurationDao lineDurationDao;
	@Autowired
	private InsuranceProductService insuranceProductService;
	@Autowired
	private SpikeActivityRuleDao spikeActivityRuleDao;
	@Autowired
	private LineDao lineDao;
	@Autowired
	private JoinCityMapper joinCityMapper;
	@Autowired
	private OrderInfoDao orderInfoDao;
	@Autowired
	private EvaluationDao evaluationDao;

	public ActivityServiceImpl() {
		for(int i = 0; i<100; i++) {
			if(i < 80) {
				SUB_POINT.add(new BigDecimal("0.0" + new Random().nextInt(9)));
			} else if(i >= 80) {
				SUB_POINT.add(new BigDecimal("0.1" + new Random().nextInt(9)));
			}
		}
	}
	
	// 查询出行人列表
	@Override
	public Activity selectPedestrianInfoByActivityId(String activityId) {
		Activity activity = this.getActivityByActivityId(activityId, true);
		// 查询出行人列表
		activity.setTripList(pedestrianInfoDao.selectPedestrianInfoByActivityId(activityId));
		// 查询活动领队
		activity.setActivityLeader(activityLeaderMapper.findActivityLeaderByActivityId(activityId));
		// 查询活动已报名人数
		activity.setPeopleSum(activityMapper.queryActivityPeopleNum(activity.getActivityId()));
		/**
		 * 判定出行人是否是领队(1:是, 0:否)
		 */
		if (activity.getTripList() != null && !activity.getTripList().isEmpty()) {
			activity.getTripList().forEach(item -> {
				item.setIsLeader(this.isLeader(activity.getActivityLeader(), item.getUserId()));
			});
		}
		return activity;
	}

	@Override
	public Activity queryActivityPedestrin(String activityId) {
		Activity activity = new Activity();
		// 查询出行人列表
		activity.setTripList(pedestrianInfoDao.selectPedestrianInfoByActivityId(activityId));
		// 查询活动领队
		activity.setActivityLeader(activityLeaderMapper.findActivityLeaderByActivityId(activityId));
		/**
		 * 判定出行人是否是领队(1:是, 0:否)
		 */
		if (activity.getTripList() != null && !activity.getTripList().isEmpty()) {
			activity.getTripList().forEach(item -> {
				item.setIsLeader(this.isLeader(activity.getActivityLeader(), item.getUserId()));
			});
		}
		return activity;
	}

	private List<ActivitySingleRecordInitiator> querySingleRecordList(String activityId) {
		List<ActivitySingleRecordInitiator> singleList = activitySingleRecordDao
				.findSingleRecordListMoreByActivityId(activityId);
		if (singleList == null || singleList.isEmpty()) {
			return singleList;
		}
		List<ActivitySingleRecordInitiator> newList = new ArrayList<>();
		for (ActivitySingleRecordInitiator item : singleList) {
			List<PedestrianInfoEntity> pedestrianList = pedestrianInfoDao.findByOrderId(item.getOrderId());
			if (pedestrianList == null || pedestrianList.isEmpty()) {
				continue;
			}
			// 1:正常,2:已改期,3:已退款,4:申请退款,5:退款失败
			Integer pedestrianStatus = pedestrianList.get(0).getPedestrianStatus();
			if (pedestrianStatus != null && pedestrianStatus == 1) {
				newList.add(item);
			}
		}

		return newList;
	}

	/**
	 * 查询活动详情
	 * 
	 * @author Tan Ling
	 * @date 2019年1月15日 下午5:23:27
	 * @param activityId
	 * @return
	 */
	@Override
	public Activity queryActivityDetail(String activityId, Boolean detail) {
		Activity activity = this.getActivityByActivityId(activityId, detail);

		Assert.notNull(activity, "数据异常, 活动未找到");
		if (StringUtils.isNotBlank(activity.getCoverId())) {
			String[] images = activity.getCoverId().split(",");
			if (images.length > 0) {
				activity.setCoverImg(images[0]);
			}
			// 使用缩略图
			activity.setCoverImg(ImgUtil.small(activity.getCoverImg()));
		}
		// 查询活动领队
		activity.setActivityLeader(activityLeaderMapper.findActivityLeaderByActivityId(activityId));
		List<String> leaderIds = new ArrayList<>();
		for (ActivityLeaderRelation item : activity.getActivityLeader()) {
			leaderIds.add(item.getLeaderId());
		}
		// 查询出行人列表
		PageHelper.startPage(1, 8);
		List<TripPeopleVO> tripPeople = pedestrianInfoDao.selectPedestrianInfoByActivityId(activityId);
		if (tripPeople != null && !tripPeople.isEmpty()) {
			// 添加活动时将领队添加到出行人中, 订单中的userId存储的领队ID
			Iterator<TripPeopleVO> it = tripPeople.iterator();
			while (it.hasNext()) {
				TripPeopleVO item = it.next();
				if (leaderIds.contains(item.getUserId())) {
					it.remove();
				}
			}
		}
		activity.setTripList(tripPeople);
		// 查询活动规则
		ActivityRulesEntity activityRulesEntity = activityRulesDao.selectByActivityId(activityId);
		activity.setActivityRulesEntity(activityRulesEntity);
		if (activity.getShelvesTime() != null) {
			long nowTime = System.currentTimeMillis();
			long downTime = activity.getShelvesTime().getTime();
			activity.getActivityRulesEntity().setSecondsKillTime((downTime - nowTime) / 1000);
			System.out.println(nowTime + " ：当前时间 ，" + downTime + " ： 下架时间 , " + (downTime - nowTime) / 1000 + " ：秒杀时间");
		}
		// 查询拼单记录
		if (SINGLE.equals(activity.getActivityType())) {
			activity.setShareList(querySingleRecordList(activityId));
			countSingleStatus(activity, activityRulesEntity);
		}
		// 查询活动已报名人数
		// activity.setPeopleSum(activityMapper.queryActivityPeopleNum(activity.getActivityId()));
		activity.setPeopleSum(this.queryActivityPeopleNum(activity.getActivityId()));
		/**
		 * 判定出行人是否是领队(1:是, 0:否)
		 */
		if (activity.getTripList() != null && !activity.getTripList().isEmpty()) {
			activity.getTripList().forEach(item -> {
				item.setIsLeader(this.isLeader(activity.getActivityLeader(), item.getUserId()));
			});
		}

		// 秒杀活动
		// 判断活动type,
		if (SECKILL.equals(activity.getActivityType())) {
			this.setActivityTyep(activity, activityId);
			// startTime now() endTime
			// 拼单
		} else if (SINGLE.equals(activity.getActivityType())) {
			this.setActivityTyep(activity, activityId);
			// 砍价
		} else if (BARGAIN.equals(activity.getActivityType())) {
			this.setActivityTyep(activity, activityId);
		}

		return activity;
	}

	/**
	 * 计算拼单状态
	 * 
	 * @author Tan Ling
	 * @date 2019年5月10日 下午5:49:50
	 * @param activity
	 * @param activityRulesEntity
	 */
	private void countSingleStatus(Activity activity, ActivityRulesEntity activityRulesEntity) {
		if (activityRulesEntity == null) {
			return;
		}
		if (activity.getShareList() == null || activity.getShareList().isEmpty()) {
			return;
		}
		Assert.isTrue(activityRulesEntity.getUnitNum() != null, "数据异常, 组队所需人数为空");
		if (activityRulesEntity.getMaxUnitNum() == null) {
			activityRulesEntity.setMaxUnitNum(activityRulesEntity.getUnitNum());
		}
		for (ActivitySingleRecordInitiator item : activity.getShareList()) {
			// 组队成功
			if (item.getRemainNum() != null && item.getRemainNum() <= 0) {
				item.setIsSuccess(1);
			}
			// 组队满员
			int full = activityRulesEntity.getMaxUnitNum() - (activityRulesEntity.getUnitNum() - item.getRemainNum());
			if (full <= 0) {
				item.setIsFull(1);
			}
		}
	}

	// 设置活动
	private void setActivityTyep(Activity activity, String activityId) {
		// get rule
		Date date = new Date();
		List<SpikeActivityRuleEntity> spikeActivityRuleEntities = spikeActivityRuleDao.selectSpikeByActivityId(activityId);
		List<SpikeActivityRuleEntity> activityRuleEntities = spikeActivityRuleDao.selectRecentSpikeByActivityId(activityId);
		for (SpikeActivityRuleEntity s : spikeActivityRuleEntities) {
			if (s.getStartTime().getTime() < date.getTime() && date.getTime() < s.getEndTime().getTime()) {
				// 秒杀活动
				activity.setIsMark(0);
				activity.setSpikeStartTime(s.getStartTime());
				activity.setSpikeeEndTime(s.getEndTime());
				activity.setSeckillPrice(s.getSeckillPrice());
				activity.setOriginalPrice(s.getOriginalPrice());
				activity.setCountdown((s.getEndTime().getTime() - System.currentTimeMillis()) / 1000);
				if (activityRuleEntities != null && activityRuleEntities.size() > 0) {
					for (SpikeActivityRuleEntity spikeActivityRuleEntity : activityRuleEntities) {
						activity.setRecentSpikeStartTime(spikeActivityRuleEntity.getStartTime());
						activity.setRecentSpikeEndTTime(spikeActivityRuleEntity.getEndTime());
						break;
					}
				}
				break;
			} else {
				// 普通活动
				activity.setIsMark(1);
				activity.setOriginalPrice(s.getOriginalPrice());
				activity.setCountdown((s.getStartTime().getTime() - System.currentTimeMillis()) / 1000);
				if (s.getStartTime().getTime() > date.getTime() && date.getTime() < s.getEndTime().getTime()) {
					activity.setSpikeStartTime(s.getStartTime());
					activity.setSpikeeEndTime(s.getEndTime());
					break;
				}
			}
		}

	}

	/**
	 * 判断是否领队, 1:是, 0:否
	 * 
	 * @author Tan Ling
	 * @date 2019年1月16日 下午2:32:36
	 * @param leaderList
	 * @param userId
	 * @return
	 */
	private int isLeader(List<ActivityLeaderRelation> leaderList, String userId) {
		if (leaderList != null && !leaderList.isEmpty() && StringUtils.isNotBlank(userId)) {
			for (ActivityLeaderRelation item : leaderList) {
				if (userId.equals(item.getUserId())) {
					return 1;
				}
			}
		}
		return 0;
	}

	/**
	 * 查询活动(单记录)
	 * 
	 * @author Tan Ling
	 * @date 2019年1月15日 下午5:23:48
	 * @param activityId
	 * @return
	 */
	@Override
	public Activity getActivity(String activityId, Boolean detail) {
		Activity activity = this.queryActivityDetail(activityId, detail);
		if (activity != null) {
			List<LineDurationCache> durationList = lineService.selectAllLineDurationTime();
			Integer durationTime = this.getDurationTime(durationList, activity.getLineId());
			activity.setReturnTime(this.refactoryReturnTime(activity.getOutsetTime(), durationTime));
		}

		return activity;
	}

	/**
	 * 查询当前线路下的活动列表
	 * 
	 * @author Tan Ling
	 * @date 2019年1月15日 下午5:23:36
	 * @param lineId
	 * @param activityId
	 * @return
	 */
	@Override
	public List<ActivityOutset> queryActivityList(String lineId, String activityId) {
		ActivityBase activityBase = activityMapper.getActivityBaseByActivityId(activityId);
		Assert.notNull(activityBase, "数据异常, 活动不存在");
		Assert.notEmpty(activityBase.getCompanyId(), "数据异常, 活动companyId不存在");
		List<ActivityOutset> list = activityMapper.queryActivityByLineId(lineId, activityBase.getCompanyId());
		if (list != null && !list.isEmpty()) {
			boolean isGet = false;
			List<LineDurationCache> durationList = lineService.selectAllLineDurationTime();
			Integer durationTime = this.getDurationTime(durationList, lineId);
			for (ActivityOutset item : list) {
				item.setOutsetWeek(DateUtil.dateToWeek(item.getOutsetTime()));
				item.setIsSelect(activityId.equals(item.getActivityId()) ? 1 : 0);
				// item.setPeopleSum(activityMapper.queryActivityPeopleNum(item.getActivityId()));
				item.setPeopleSum(this.queryActivityPeopleNum(item.getActivityId()));
				if (item.getIsSelect() == 1) {
					isGet = true;
					item.setActivityLeader(activityLeaderMapper.findActivityLeaderByActivityId(item.getActivityId()));
				}
				item.setReturnTime(this.refactoryReturnTime(item.getOutsetTime(), durationTime));
			}
			if(!isGet){
				/**
				 * 根据活动id 活动详情出行列表查询(已截止的活动)
				 */
				ActivityOutset expiredActivity = activityMapper.queryExpiredActivityByActivityId(activityId);
				if (expiredActivity != null){
					expiredActivity.setIsSelect(1);
					expiredActivity.setOutsetWeek(DateUtil.dateToWeek(expiredActivity.getOutsetTime()));
					list.add(0, expiredActivity);
				}
			}
		}

		return list;
	}

	/**
	 * 返回时间=出行日期+时长
	 * 
	 * @author Tan Ling
	 * @date 2019年1月21日 下午5:45:44
	 * @param outsetTime
	 * @param durationTime
	 * @return
	 */
	private Date refactoryReturnTime(Date outsetTime, Integer durationTime) {
		if (outsetTime == null || durationTime == null) {
			return outsetTime;
		}
		Calendar returnTime = Calendar.getInstance();
		returnTime.setTime(outsetTime);
		returnTime.add(Calendar.DAY_OF_YEAR, durationTime - 1);// 日期加10天

		return returnTime.getTime();
	}

	/**
	 * 获取线路的时长
	 * 
	 * @author Tan Ling
	 * @date 2019年1月21日 下午5:49:39
	 * @param durationList
	 * @param lineId
	 * @return
	 */
	private Integer getDurationTime(List<LineDurationCache> durationList, String lineId) {
		if (durationList == null || durationList.isEmpty()) {
			return 0;
		}
		for (LineDurationCache item : durationList) {
			if (lineId.equals(item.getLineId())) {
				return item.getDurationTime();
			}
		}

		return 0;
	}

	@Override
	public List<ActivityBaseVO> selectActivityForWeChat(String name) {
		List<ActivityBaseVO> list = activityInfoDao.selectActivityForWeChat(name);
		return list;
	}

	@Override
	public List<ActivityBriefVO> selectActivityBriefByLineId(String lineId, String activityId, String userId) {
		List<ActivityBriefVO> list = activityInfoDao.selectActivityBriefByLineId(lineId, activityId, userId);
		for (ActivityBriefVO activityBriefVO : list) {
			// 计算出发日期是星期几
			activityBriefVO.setOutsetWeek(DateUtil.dateToWeek(activityBriefVO.getOutsetTime()));
		}
		return list;
	}

	@Override
	public PayActivityVO selectPayActivityById(String activityId) {
		PayActivityVO payActivity = activityInfo.getPayActivityByActivityId(activityId);
		Assert.notNull(payActivity, "数据异常, 活动未找到");
		Assert.isTrue(payActivity.getOutsetTime() != null && payActivity.getReturnTime() != null,
				"数据异常, 活动出行日期或返回日期为空");
		payActivity.setDateDiff(DateUtil.differentDays(payActivity.getOutsetTime(), payActivity.getReturnTime()));
		// 查询商品
		payActivity.setProductList(productDao.selectProductByActivityId(activityId));
		// 查询活动规则
		payActivity.setActivityRulesEntity(activityRulesDao.selectByActivityId(activityId));
		// 封面图
		if (StringUtils.isNotBlank(payActivity.getCoverId())) {
			payActivity.setCoverImg(payActivity.getCoverId().split(",")[0]);
			// 使用缩略图
			payActivity.setCoverImg(ImgUtil.small(payActivity.getCoverImg()));
		}
		if (StringUtils.isNotBlank(payActivity.getInsurancesId())) {
			InsuranceProductsEntity insuranceProduct = insuranceProductService
					.getInsuranceProductById(payActivity.getInsurancesId());
			if (insuranceProduct != null) {
				payActivity
						.setInsurancesName(insuranceProduct.getCompanyName() + "  " + insuranceProduct.getProdName());
			}
		}
		/**
		 * 查询年龄限制
		 */
		String ageLimit = lineDao.queryAgeLimitByLineId(payActivity.getLineId());
		Integer minAge = 0, maxAge = 0;
		if (StringUtils.isNotBlank(ageLimit)) {
			String[] arr = ageLimit.split(SYMBOL_REGEX);
			if (arr.length == 2) {
				try {
					minAge = Integer.parseInt(arr[0].replaceAll(NAN, ""));
					maxAge = Integer.parseInt(arr[1].replaceAll(NAN, ""));
					Assert.isTrue(minAge <= maxAge, "年龄段配置错误, " + ageLimit + ", " + maxAge + " 必须>= " + minAge);
				} catch (Exception e) {
					if (e instanceof CustomException) {
						throw e;
					}
					LOG.error("=============解析年龄段限制出错");
					e.printStackTrace();
				}
			}
		}
		payActivity.setMinAge(minAge);
		payActivity.setMaxAge(maxAge);

		return payActivity;
	}

	@Override
	public List<ActivityBase> selectActivityPage(int pageNum, int pageSize, ActivityBaseParams params) {
		// 如果是以时长为条件查询
		if (StringUtils.isNotBlank(params.getDurationScopeId())) {
			DurationScope durationScope = durationScopeMapper.selectByPrimaryKey(params.getDurationScopeId());
			Assert.notNull(durationScope, "数据异常, 时长范围未找到");
			Assert.notEmpty(durationScope.getDurationScope(), "数据异常, 时长范围为空");

			PageHelper.startPage(pageNum, pageSize);
			return checkActivityStatus(
					queryActivityListByDurationEqAndGtAndLt(durationScope.getDurationScope(), params));
		} else if (StringUtils.isNotBlank(params.getLineThemeId())) {
			PageHelper.startPage(pageNum, pageSize);
			return checkActivityStatus(activityMapper.queryActivityListByThemeId(params));
		}
		PageHelper.startPage(pageNum, pageSize);

		return checkActivityStatus(activityMapper.queryActivityListByType(params));
	}
	
	@Override
	public List<ActivityBase> selectActivityPageV2(int pageNum, int pageSize, ActivityBaseParams params) {
		PageHelper.startPage(pageNum, pageSize);
		List<ActivityBase> list = checkActivityStatus(activityMapper.queryActivityListByType(params));
		for(ActivityBase item: list) {
			/**
			 * 1.报名人数
			 */
			item.setBeenPeopleNum(item.getBeenPeopleNum() == null ? 0: item.getBeenPeopleNum());
			item.setJoinNum(orderInfoDao.queryPedestrianNumByLineId(item.getLineId()));
			item.setJoinNum(item.getJoinNum() + item.getBeenPeopleNum());
			// 当前是否优惠时间
			item.setIsDiscountTime(0);
			// 优惠时间倒计时
			item.setCountdown(-1L);
			/**
			 * 2.查询活动主题
			 */
			item.setThemeList(activityMapper.queryActivityThemeByActivityId(item.getActivityId()));
			/**
			 * 3.查询线路评分
			 */
			BigDecimal score = (BigDecimal) redisService.get(RedisConstant.LINE_SCORE_PREFIX + item.getLineId());
			if(score != null) {
				item.setScore(score);
			} else {
				// 
				LineEvaluationVO comment = evaluationDao.selectEvaluationByLineId(item.getLineId());
				if(comment != null) {
					item.setScore(new BigDecimal(comment.getAllSatisfactionAvg()));
					item.setScore(item.getScore().setScale(2, BigDecimal.ROUND_HALF_UP));
				}
				if(new BigDecimal("5").compareTo(item.getScore()) == 0) {
					item.setScore(item.getScore().subtract(SUB_POINT.get(new Random().nextInt(99))));
				}
				redisService.add(RedisConstant.LINE_SCORE_PREFIX + item.getLineId(), item.getScore(), 1440);
			}
			/**
			 * 4.如果是优惠活动, 返回倒计时
			 * 		(1.秒杀活动,2.拼单活动,3.砍价活动)
			 */
			BigDecimal zero = new BigDecimal("0");
			// 2.1秒杀活动
			if("1".equals(item.getActivityType())) {
				// item.setCountdown(this.getCountDown(item.getActivityId()));
				this.getCountDown(item);
				if(item.getIsDiscountTime() == 1) {
					ActivityRulesEntity activityRule = activityRulesDao.selectByActivityId(item.getActivityId());
					BigDecimal price = (activityRule != null && activityRule.getSeckillPrice() != null) ? activityRule.getSeckillPrice() : zero;
					item.setPrice(price);
				}
			} else if("2".equals(item.getActivityType())) {
				// item.setCountdown(this.getCountDown(item.getActivityId()));
				this.getCountDown(item);
				if(item.getIsDiscountTime() == 1) {
					ActivityRulesEntity activityRule = activityRulesDao.selectByActivityId(item.getActivityId());
					BigDecimal price = (activityRule != null && activityRule.getUnitPrice() != null) ? activityRule.getUnitPrice() : zero;
					item.setPrice(price);
				}
			} else if("3".equals(item.getActivityType())) {
				// item.setCountdown(this.getCountDown(item.getActivityId()));
				this.getCountDown(item);
			}
		}
		
		return list;
	}
	
	/**
	 * 查询倒计时
	 * @author Tan Ling
	 * @date 2019年9月6日 上午11:46:17
	 * @param activityId
	 * @return
	 */
	private void getCountDown(ActivityBase activity) {
		List<SpikeActivityRuleEntity> list = spikeActivityRuleDao.selectSpikeByActivityId(activity.getActivityId());
		if(list == null || list.isEmpty()) {
			activity.setCountdown(-1L);
		}
		long countDown = -1L;
		Date start = null, now = new Date();
		for(SpikeActivityRuleEntity item: list) {
			if(item.getStartTime() == null || item.getEndTime() == null) {
				continue;
			}
			// 在优惠时间范围内
			if(item.getStartTime().getTime() < now.getTime() && item.getEndTime().getTime() > now.getTime()) {
				countDown = ((item.getEndTime().getTime() - new Date().getTime()) / 1000);
				activity.setIsDiscountTime(1);
				break;
			} else {
				if(start == null && item.getStartTime().getTime() > now.getTime()) {
					start = item.getStartTime();
				}
			}
		}
		if(countDown < 0 && start != null) {
			countDown = (start.getTime() - now.getTime()) / 1000;
		}
		
		activity.setCountdown(countDown);
	}
//	private Long getCountDown(String activityId) {
//		List<SpikeActivityRuleEntity> list = spikeActivityRuleDao.selectSpikeByActivityId(activityId);
//		if(list == null || list.isEmpty()) {
//			return -1L;
//		}
//		long countDown = -1L;
//		Date start = null, now = new Date();
//		for(SpikeActivityRuleEntity item: list) {
//			if(item.getStartTime() == null || item.getEndTime() == null) {
//				continue;
//			}
//			// 在优惠时间范围内
//			if(item.getStartTime().getTime() < now.getTime() && item.getEndTime().getTime() > now.getTime()) {
//				countDown = ((item.getEndTime().getTime() - new Date().getTime()) / 1000);
//				break;
//			} else {
//				if(start == null && item.getStartTime().getTime() > now.getTime()) {
//					start = item.getStartTime();
//				}
//			}
//		}
//		if(countDown < 0 && start != null) {
//			countDown = (start.getTime() - now.getTime()) / 1000;
//		}
//		
//		return countDown;
//	}

	/**
	 * 检查当前期数活动是否报满, 比如当前线路下有1、2、3期活动, 1期已报满, 显示第2期
	 * 
	 * @author Tan Ling
	 * @date 2019年4月15日 下午2:28:19
	 * @param list
	 * @return
	 */
	private List<ActivityBase> checkActivityStatus(List<ActivityBase> list) {
		if (list == null || list.isEmpty()) {
			return list;
		}
		for (ActivityBase item : list) {
			// 活动状态，1已报满 2已成行 3报名中 4已截止 5 即将成行 6 已下架
			if (item.getActivityStatus() != null && item.getActivityStatus() == 1) {
				List<ActivityOutset> outsetList = activityMapper.queryActivityByLineId(item.getLineId(),
						item.getCompanyId());
				if (outsetList == null || outsetList.isEmpty()) {
					continue;
				}
				for (ActivityOutset outset : outsetList) {
					if (!item.getActivityId().equals(outset.getActivityId())) {
						if (outset.getActivityStatus() != null && outset.getActivityStatus() != 1) {
							item.setOutsetTime(outset.getOutsetTime());
							item.setActivityStatus(outset.getActivityStatus());
							item.setActivityId(outset.getActivityId());
							break;
						}
					}
				}
			}
		}

		return list;
	}

	@Override
	public List<ActivityInfoEntity> selectImageByLineId(String lineId) {
		return activityInfo.selectImageByLineId(lineId);
	}

	/**
	 * 查询热门活动
	 * 
	 * @param popular
	 * @return
	 */
	@Override
	public List<ActivityBase> selectByPopular(Integer popular, int pageNum, int pageSize, String activityId) {
		ActivityBase activityBase = activityMapper.getActivityBaseByActivityId(activityId);
		Assert.notNull(activityBase, "数据异常, 活动不存在");
		PageHelper.startPage(pageNum, pageSize);
		List<ActivityBase> activityBases = activityInfo.selectByPopular(popular, activityId,
				activityBase.getCompanyId());
		for (ActivityBase item : activityBases) {
			item.setCoverImg(ImgUtil.middle(item.getCoverImg()));
		}
		return activityBases;
	}

	/**
	 * 首页活动搜索
	 * 
	 * @author Tan Ling
	 * @date 2019年1月21日 下午2:54:37
	 * @param name
	 * @return
	 */
	@Override
	public List<ActivityBase> queryActivityByName(int pageNum, int pageSize, String name, String locationId) {
		Assert.notEmpty(locationId, "locationId不能为空");
		JoinCity joinCity = joinCityMapper.getBySbLocationId(locationId);
		Assert.notNull(joinCity, "数据异常, 城市信息不存在");

		PageHelper.startPage(pageNum, pageSize);

		return activityMapper.queryActivityByName(name, locationId, joinCity.getCompanyId());
	}

	/**
	 * 查询活动信息(单记录查询,需要缓存)
	 * 
	 * @author Tan Ling
	 * @date 2019年1月21日 下午4:14:31
	 * @param activityId
	 * @return
	 */
	public Activity getActivityByActivityId(@Param("activityId") String activityId, Boolean detail) {
		Activity activity = (Activity) redisService.get(RedisConstant.ACTIVITY_DETAIL_PREFIX + activityId);
		if (activity != null) {
			LOG.info("=============缓存中查询活动详情");
			ActivityBase base = activityMapper.queryActivityStatus(activityId);
			activity.setaStatus(base.getaStatus());
			activity.setActivityStatus(base.getActivityStatus());
			activity.setQrCode(base.getQrCode());
			if (!detail) {
				activity.setActivityCost(null);
				activity.setActivityDetails(null);
				activity.setActivityTrip(null);
			}
			return activity;
		}

		LOG.info("=============从数据库中查询活动详情");

		activity = activityMapper.queryActivityDetail(activityId);
		if (activity != null) {
			ActivityTripVO activityTripVO = activityMapper.getActivityTripById(activityId);
			activity.setActivityTrip(activityTripVO.getActivityTrip());
			activity.setActivityDetails(activityTripVO.getActivityDetails());
			activity.setActivityCost(activityTripVO.getActivityCost());
			redisService.add(RedisConstant.ACTIVITY_DETAIL_PREFIX + activityId, activity, 1440);
		}

		if (!detail) {
			activity.setActivityCost(null);
			activity.setActivityDetails(null);
			activity.setActivityTrip(null);
		}

		return activity;
	}

	private List<ActivityBase> queryActivityListByDurationEqAndGtAndLt(String durationScope,
			ActivityBaseParams params) {
		// type 1:=, 2:>, 3:< 活动时长
		List<String> list = new ArrayList<>();
		// 如果是时间范围
		if (SCOPE.matcher(durationScope).find()) {
			String[] array = durationScope.split("-");
			if (array.length != 2) {
				throw new CustomException("解析活动时长范围错误");
			}
			int start = Integer.parseInt(array[0].replaceAll(NAN, ""));
			int end = Integer.parseInt(array[1].replaceAll(NAN, ""));
			for (int i = start; i <= end; i++) {
				LineDurationEntity duration = lineDurationDao.selectByDuration(i);
				if (duration != null) {
					list.add(duration.getLineDurationId());
				}
			}
			if (list != null && !list.isEmpty()) {
				params.setLineDurationIds(list.toArray(new String[list.size()]));
				params.setType("1");

				return activityMapper.queryActivityListByDurationEqAndGtAndLt(params);
			} else {
				return new ArrayList<>();
			}
		}
		// 如果是xx天以上
		else if (UP.matcher(durationScope).find()) {
			params.setDays(Integer.parseInt(durationScope.replaceAll(NAN, "")));
			params.setType("2");

			return activityMapper.queryActivityListByDurationEqAndGtAndLt(params);
		}
		// 如果是xx天以下
		else if (DOWN.matcher(durationScope).find()) {
			params.setDays(Integer.parseInt(durationScope.replaceAll(NAN, "")));
			params.setType("3");

			return activityMapper.queryActivityListByDurationEqAndGtAndLt(params);
		}
		//
		// 如果是xx天以下
		else {
			params.setDays(Integer.parseInt(durationScope.replaceAll(NAN, "")));
			Assert.notNull(params.getDays(), "参数异常,解析时长出错");
			params.setType("4");

			return activityMapper.queryActivityListByDurationEqAndGtAndLt(params);
		}
	}

	@Override
	public ActivityBase getActivityBaseByActivityId(String activityId) {
		return activityMapper.getActivityBaseByActivityId(activityId);
	}

	/**
	 * 维护活动状态
	 * 
	 * @author Tan Ling
	 * @date 2019年1月29日 下午3:11:00
	 * @param activity
	 */
	@Override
	public void resetActivityStatus(String activityId) {
		ActivityInfoEntity dbData = activityMapper.getActivityByActivityId(activityId);
		Assert.notNull(dbData, "数据异常, 活动不存在");
		/**
		 * 活动状态，1已报满 2已成行 3报名中 4已截止 5 即将成行 6已下架
		 */
		Date now = new Date();
		int activityStatus = dbData.getActivityStatus();
		boolean modify = false;

		Date shelfTime = dbData.getShelfTime();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(shelfTime);
		calendar.add(Calendar.DATE, -1);
		shelfTime = calendar.getTime();

		Date shelvesTime = dbData.getShelvesTime();
		calendar = Calendar.getInstance();
		calendar.setTime(shelvesTime);
		calendar.add(Calendar.DATE, 1);
		shelvesTime = calendar.getTime();

		if (shelfTime.getTime() < now.getTime() && now.getTime() < shelvesTime.getTime()) {
			activityStatus = 3;
			modify = true;
		}

		Integer willNum = dbData.getFormPeople() / 2;
		// 查询领队
		//		List<ActivityLeaderRelation> leaderList = activityLeaderMapper.findActivityLeaderByActivityId(dbData.getActivityId());
		//		Integer leaderNum = leaderList == null ? 0 : leaderList.size();
		// 达到成行人数一半, 即将成行
		Integer joinPeopleNum = activityMapper.queryPeopleNum(dbData.getActivityId());
		joinPeopleNum = joinPeopleNum == null ? 0 : joinPeopleNum;
		// joinPeopleNum = joinPeopleNum + leaderNum;
		//
		if (joinPeopleNum >= willNum) {
			activityStatus = 5;
			modify = true;
		}
		// 参与活动人数 > 成行人数, 状态改为已成行
		if (joinPeopleNum >= dbData.getFormPeople()) {
			activityStatus = 2;
			modify = true;
		}
		// 参与活动人数 == 成行人数, 状态改为已报满
		if (joinPeopleNum >= dbData.getMostPeopleSum()) {
			activityStatus = 1;
			modify = true;
		}
		// 已下架
		if (now.getTime() > shelvesTime.getTime()) {
			activityStatus = 6;
			modify = true;
		}
		// 已截止
		Date endJoinTime = dbData.getEndJoinTime() == null ? dbData.getOutsetTime() : dbData.getEndJoinTime();
		if (endJoinTime.getTime() < now.getTime()) {
			activityStatus = 4;
			modify = true;
		}
		if (modify) {
			activityMapper.updateActivityStatus(activityId, activityStatus);
		}
		/**
		 * 删除报名人数缓存
		 */
		redisService.delete(RedisConstant.PEOPLE_NUM_PREFIX + activityId);
	}

	@Override
	public List<String> queryAllActivityId() {
		return activityMapper.queryAllActivityId();
	}

	@Override
	public Integer queryActivityPeopleNum(String activityId) {
		Integer peopleNum = (Integer) redisService.get(RedisConstant.PEOPLE_NUM_PREFIX + activityId);
		if (peopleNum != null) {
			return peopleNum;
		}
		peopleNum = activityMapper.queryActivityPeopleNum(activityId);
		redisService.add(RedisConstant.PEOPLE_NUM_PREFIX + activityId, peopleNum, 60);

		return peopleNum;
	}

	@Override
	public List<ActivityOutset> queryActivityList(String lineId) {
		LineEntity line = lineDao.getByLineId(lineId);
		Assert.notNull(line, "数据异常, 产品不存在");
		Assert.notEmpty(line.getCompanyId(), "数据异常, 活动companyId不存在");
		List<ActivityOutset> list = activityMapper.queryActivityByLineId(lineId, line.getCompanyId());
		if (list != null && !list.isEmpty()) {
			List<LineDurationCache> durationList = lineService.selectAllLineDurationTime();
			Integer durationTime = this.getDurationTime(durationList, lineId);
			for (ActivityOutset item : list) {
				item.setOutsetWeek(DateUtil.dateToWeek(item.getOutsetTime()));
				item.setIsSelect(0);
				item.setPeopleSum(this.queryActivityPeopleNum(item.getActivityId()));
				if (item.getIsSelect() == 1) {
					item.setActivityLeader(activityLeaderMapper.findActivityLeaderByActivityId(item.getActivityId()));
				}
				item.setReturnTime(this.refactoryReturnTime(item.getOutsetTime(), durationTime));
			}
			// 将第一个活动设置默认
			list.get(0).setIsSelect(1);
		}

		return list;
	}

	@Override
	public List<SecondKillActivity> querySecondKillActivity() {
		return activityMapper.querySecondKillActivity();
	}

	@Override
	public List<ActivityBase> queryPreferentialActivities(String locationId) {
		Assert.notEmpty(locationId, "locationId不能为空");
		JoinCity joinCity = joinCityMapper.getBySbLocationId(locationId);
		Assert.notNull(joinCity, "数据异常, 城市信息不存在");
		return activityMapper.queryPreferentialActivities(joinCity.getCompanyId());
	}
}
