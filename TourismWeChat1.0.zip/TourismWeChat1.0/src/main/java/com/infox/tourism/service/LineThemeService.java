package com.infox.tourism.service;

import com.infox.tourism.entity.vo.lineVO.LineThemeVO;

import java.util.List;

/**
 * @Author Hale
 * @Date 2018/12/13
 */
public interface LineThemeService {

    List<LineThemeVO> selectAllLineTheme();

    List<LineThemeVO> selectIndexTheme();
    
    List<LineThemeVO> selectIndexThemeV2();
}
