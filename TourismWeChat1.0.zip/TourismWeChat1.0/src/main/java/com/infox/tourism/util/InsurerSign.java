package com.infox.tourism.util;

import com.infox.tourism.config.InsuranceConfig;
import org.springframework.util.DigestUtils;

import java.io.UnsupportedEncodingException;

public class InsurerSign {

    public static String getInsurerSign(String JsonStr){

        String sign = InsuranceConfig.devKey+JsonStr;
//        String sign = InsuranceConfig.proKey+JsonStr;

        String repSign = "";

        try {

            repSign = DigestUtils.md5DigestAsHex(sign.getBytes("UTF-8"));

        } catch (UnsupportedEncodingException s) {
            s.printStackTrace();

        }

        return repSign;

    }

}