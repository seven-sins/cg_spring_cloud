package com.infox.tourism.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.infox.tourism.entity.ExceptionalSumInfoEntity;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 打赏总金额
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-21 15:17:45
 */
@Mapper
public interface ExceptionalSumInfoDao extends BaseMapper<ExceptionalSumInfoEntity> {

    /**
    * 查询分页
    * @return
    */
    List<ExceptionalSumInfoEntity> queryPage();
    
    /**
     * 通过 leaderId 查询打赏记录
     * @return
     */
     List<ExceptionalSumInfoEntity> queryExSumInfoByleaderId(@Param("leaderId")String leaderId);

    /**
     * 更新
     */
    int updateById(ExceptionalSumInfoEntity exceptionalSumInfoEntity);
}
