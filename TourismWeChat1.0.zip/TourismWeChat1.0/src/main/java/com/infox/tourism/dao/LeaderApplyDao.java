package com.infox.tourism.dao;

import com.infox.tourism.entity.v2.leaderinfo.vo.LeaderVo;
import org.apache.ibatis.annotations.Mapper;

import com.infox.tourism.entity.LeaderApplyEntity;

import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.BaseMapper;

/**
 * 领队申请表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-12 20:59:36
 */
@Mapper
public interface LeaderApplyDao extends BaseMapper<LeaderApplyEntity> {

    /**
     * 根据userId查询领队申请信息
     */
    LeaderVo selectLeaderApplyByUserId(@Param("userId") String userId);

}
