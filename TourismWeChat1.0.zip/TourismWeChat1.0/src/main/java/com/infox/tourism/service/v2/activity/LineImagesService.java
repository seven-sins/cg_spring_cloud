package com.infox.tourism.service.v2.activity;

import com.infox.common.base.BaseService;
import com.infox.tourism.entity.activity.LineImages;

/**
 * 产品图片
 * @author Tan Ling
 * @date 2019年7月17日 上午9:55:51
 */
public interface LineImagesService extends BaseService<LineImages> {

}
