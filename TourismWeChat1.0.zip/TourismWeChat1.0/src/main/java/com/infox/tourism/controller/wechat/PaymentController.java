package com.infox.tourism.controller.wechat;

import java.io.IOException;
import java.io.PrintStream;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.infox.common.utils.Assert;
import com.infox.common.utils.payment.SybConstants;
import com.infox.common.utils.redis.RedisService;
import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.service.OrderInfoService;
import com.infox.tourism.service.PayHistoryService;
import com.infox.tourism.service.payment.PaymentService;
import com.infox.tourism.util.R;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

/**
 * @author Tan Ling
 * 2018年12月11日 下午9:29:15
 */
@Api(description = "微信支付接口")
@Controller
public class PaymentController {
	private static final Logger LOG = Logger.getLogger(PaymentController.class);
	private static final String REFUND_ORDER_PREFIX = "REFUND_ORDER_PREFIX_";
	private static final String ACTIVITY = "activity";
	@Autowired
	private PaymentService paymentService;
	@Autowired
	private PayHistoryService payHistoryService;
	@Autowired
	private RedisService redisService;
	@Autowired
	private OrderInfoService orderInfoService;
	@Value("{web.domain}")
	private String domain;
	
	@ApiOperation("获取支付信息")
	@GetMapping("/payInfo")
	@ResponseBody
	public R payInfo(@ApiIgnore AuthUser user,
			@RequestParam(value = "orderId") String orderId,
			@RequestParam(value = "orderType") String orderType,
			HttpServletResponse response) throws IOException {
		if(ACTIVITY.equals(orderType)) {
			int surplusNum = orderInfoService.querySurplus(orderId);
			// 在pay.html页面检查是否超过报名人数限制, 如超过则强制跳转到首页
			if(surplusNum < 0) {
				response.sendRedirect(domain);
			}
		}
		Map<String, ?> map;
		//map = sybPayService.pay(1, reqsn, "W02", "标题", "备注", user.getOpenId(), "134541202599004381", "http://bzt.fmcgnet.com/wechat/payment/notify", "", "", "", "");
		map = paymentService.pay(user, orderId, orderType);
		
		LOG.info("=============orderType: " + orderType);
		// LOG.info(JSONObject.toJSONString(map));
		
		return R.ok().put("data", map);
	}
	
	@ApiOperation("获取支付信息")
	@GetMapping("/appletPayInfo")
	@ResponseBody
	public R appletPayInfo(@ApiIgnore AuthUser user,
			@RequestParam(value = "orderId") String orderId,
			@RequestParam(value = "orderType") String orderType,
			@RequestParam(value = "openId", required = false) String openId,
			HttpServletResponse response) throws IOException {
		if(StringUtils.isNotBlank(openId)) {
			user.setOpenId(openId);
		}
		if(ACTIVITY.equals(orderType)) {
			int surplusNum = orderInfoService.querySurplus(orderId);
			// 在pay.html页面检查是否超过报名人数限制, 如超过则强制跳转到首页
			if(surplusNum < 0) {
				response.sendRedirect(domain);
			}
		}
		Map<String, ?> map;
		//map = sybPayService.pay(1, reqsn, "W02", "标题", "备注", user.getOpenId(), "134541202599004381", "http://bzt.fmcgnet.com/wechat/payment/notify", "", "", "", "");
		map = paymentService.appletPay(user, orderId, orderType);
		
		LOG.info("=============orderType: " + orderType);
		// LOG.info(JSONObject.toJSONString(map));
		
		return R.ok().put("data", map);
	}
	
	@ApiOperation("申请退款")
	@PostMapping("/refund")
	@ResponseBody
	public R refund(@RequestBody Map<String, String> params) {
		String orderId = params.get("orderId");
		String orderType = params.get("orderType");
		Assert.notNull(orderId, "orderId不能为空");
		Assert.notNull(orderType, "orderType不能为空");
		
		String userId = (String) redisService.get(REFUND_ORDER_PREFIX + orderId);
		Assert.notNull(userId, "数据异常, 获取用户信息失败");
		
		Map<String, ?> map = paymentService.refund(userId, orderId, orderType);
		
		return R.ok().put("data", map);
	}
	
	/**
	  * 微信支付通知接口
	 * acct=o4uepwiz1sj9J5hMK6fX4tdDOlz4             :openId
	 * appid=00144611                                                               :收付通appid
	 * chnltrxid=4200000204201812118362955511  
	 * cusid=55158104722SF9L                         :收付通商户号
	 * cusorderid=1544515728710  
	 * fee=0  
	 * outtrxid=1544515728710  
	 * paytime=20181211160857  
	 * sign=DBAA1BE004AE66309D93FD3D553DA4BE  
	 * signtype=MD5  
	 * termauthno=CFT  
	 * termrefnum=4200000204201812118362955511  
	 * termtraceno=0  
	 * trxamt=1  
	 * trxcode=VSP501  
	 * trxdate=20181211  
	 * trxid=111867240000451328                                         :交易流水号
	 * trxreserved=备注                                                          :改为记录交易类型
	 * trxstatus=0000
	 * @param request
	 * @return
	 */
	@RequestMapping("/payment/notify")
	public void wechatNotify(HttpServletRequest request, HttpServletResponse response){
		Map<String, Object> map = new HashMap<String, Object>();
		Enumeration<? extends Object> paramNames = request.getParameterNames();
		while (paramNames.hasMoreElements()) {
			String paramName = (String) paramNames.nextElement();
			String[] paramValues = request.getParameterValues(paramName);
			if (paramValues.length > 0) {
				String paramValue = paramValues[0];
				if (paramValue.length() != 0) {
					map.put(paramName, paramValue);
				}
			}
		}
		// 交易流水号
		LOG.info("=============trxid: " + map.get("trxid"));
		// 交易类型
		LOG.info("=============trxreserved: " + map.get("trxreserved"));
		
		Assert.notNull(map.get("trxid"), "数据错误, 交易流水号为空");
		
		paymentService.updatePayStatus((String) map.get("trxid"), (String) map.get("trxreserved"), SybConstants.SYB_PAY);
		try {
			/**
			  * 插入交易记录(插入交易记录不抛出异常)
			 */
			payHistoryService.insert(map);
		}catch(Exception ex) {
			LOG.error("=============插入交易记录出错: " + ex.getMessage());
			ex.printStackTrace();
		}
		
		writeMessageToResponse(response, "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[OK]]></return_msg></xml>");
	}
	
	private void writeMessageToResponse(HttpServletResponse response, String message) {
        try {
            response.setContentType("text/xml");
            PrintStream out = new PrintStream(response.getOutputStream());
            out.print(message);
            out.flush();
        } catch (IOException e) {
            e.printStackTrace();
        } 
    }
}























