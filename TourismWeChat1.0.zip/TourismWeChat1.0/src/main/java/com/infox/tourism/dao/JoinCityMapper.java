package com.infox.tourism.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.infox.tourism.entity.JoinCity;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 接入城市
 * @author Tan Ling
 * @date 2019年5月10日 上午11:31:11
 */
@Mapper
public interface JoinCityMapper extends BaseMapper<JoinCity> {
	
	/**
	 * 查询接入城市列表
	 * @author Tan Ling
	 * @date 2019年5月10日 上午11:35:08
	 * @param joinCity
	 * @return
	 */
	List<JoinCity> find(JoinCity joinCity);
	
	JoinCity getBySbLocationId(String sbLocationId);
}
