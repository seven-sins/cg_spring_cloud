package com.infox.tourism.controller.home;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.entity.vo.activity.ActivityBase;
import com.infox.tourism.service.ActivityNotifyService;
import com.infox.tourism.service.ActivityService;
import com.infox.tourism.util.ImgUtil;
import com.infox.tourism.util.R;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

/**
 * @author Tan Ling
 * @date 2019年1月21日 上午9:39:26
 */
@RestController
@RequestMapping("/home")
@Api(description = "首页接口")
public class HomeController {
	@Value("${web.domain}")
    private String domain;
	@Autowired
	private ActivityService activityService;
	@Autowired
	private ActivityNotifyService activityNotifyService;
	
	@GetMapping("/index")
    public void toDetail(HttpServletResponse response) throws IOException {
    	// http://test.gzbzt.com/#/activedetail?activeId=eb674c5d1fbb49b49fe49a79178210ba&lineId=f623a182e06e4726aaf473da329b42df
    	// String url = domain + "/#/activedetail?activeId=" + activityId + "&lineId=" + lineId;
    	
    	response.sendRedirect(domain);
    }
	
	@ApiOperation("获取活动列表根据名称搜索")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "name", value = "活动名称")
    })
    @GetMapping("/getActivityByNameOrLeader")
    public R getActivityByNameOrLeader(int pageNum, int pageSize, 
    		@RequestParam(value = "name", required = false) String name,
    		@RequestParam(value = "locationId", required = false) String locationId) {
		List<ActivityBase> list = activityService.queryActivityByName(pageNum, pageSize, name, locationId);
		for(ActivityBase item: list) {
			String url = item.getCoverImg();
			// 使用0判断字符串是因为有个坑货给字符串设了个默认值0
			if(StringUtils.isNotBlank(item.getUrl()) && !"0".equals(item.getUrl())) {
				url = item.getUrl();
			}
			
			item.setCoverImg(ImgUtil.hight(url));
		}
        
        return R.ok().put("data", list);
    }

	@PostMapping("/insertNotify")
	public R insertNotify(@ApiIgnore AuthUser authUser, @RequestBody Map<String, String> map) {
		String activityId = map.get("activityId");
		int i = activityNotifyService.insertNotify(authUser, activityId);
		return R.ok().put("data", i);
	}
}
