package com.infox.tourism.service.v2.impl;

import java.util.Date;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infox.common.base.impl.BaseServiceImpl;
import com.infox.common.utils.Assert;
import com.infox.tourism.dao.LeaderInfoDao;
import com.infox.tourism.dao.v2.ActivityActualPaymentMapper;
import com.infox.tourism.entity.LeaderInfoEntity;
import com.infox.tourism.entity.UserInfoEntity;
import com.infox.tourism.entity.v2.activityactualpayment.ActivityActualPayment;
import com.infox.tourism.service.v2.ActivityActualPaymentService;
import com.infox.tourism.util.UUIDUtil;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 实际支出
 * @author Tan Ling
 * 2019年1月7日 下午2:28:30
 */
@Service
public class ActivityActualPaymentServiceImpl extends BaseServiceImpl<ActivityActualPayment> implements ActivityActualPaymentService {

	@Autowired
	private ActivityActualPaymentMapper activityActualPaymentMapper;
	@Autowired
	private LeaderInfoDao leaderInfoDao;
	
	@Resource
	public void setBaseMapper(BaseMapper<ActivityActualPayment> activityActualPaymentMapper) {
		this.baseMapper = activityActualPaymentMapper;
	}

	@Override
	public void updateByActivityAdvancePaymentId(ActivityActualPayment activityActualPayment) {
		activityActualPaymentMapper.updateByActivityActualPaymentId(activityActualPayment);		
	}

	@Override
	public void insert(ActivityActualPayment activityActualPayment, UserInfoEntity user) {
		LeaderInfoEntity leaderInfo = leaderInfoDao.getByUserId(user.getUserId());
		Assert.notNull(leaderInfo, "数据异常, 领队信息不存在");
		
		activityActualPayment.setActivityActualPaymentId(UUIDUtil.create());
		// 状态(1:未审核, 2:已批准, 3:已拒绝, 4:已领取) 
		activityActualPayment.setProjectStatus(1);
		activityActualPayment.setLeaderId(leaderInfo.getLeaderId());
		activityActualPayment.setCreateBy(user.getUserId());
		activityActualPayment.setCreateTime(new Date());
		
		activityActualPaymentMapper.insert(activityActualPayment);
	}
	
	
}
