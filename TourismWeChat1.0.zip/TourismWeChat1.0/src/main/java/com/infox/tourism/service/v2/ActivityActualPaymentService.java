package com.infox.tourism.service.v2;

import com.infox.common.base.BaseService;
import com.infox.tourism.entity.UserInfoEntity;
import com.infox.tourism.entity.v2.activityactualpayment.ActivityActualPayment;

/**
 * 实际支出
 * @author Tan Ling
 * 2019年1月7日 下午2:27:00
 */
public interface ActivityActualPaymentService extends BaseService<ActivityActualPayment> {

	/**
	 * 根据主键更新
	 * @param activityActualPayment
	 */
	public void updateByActivityAdvancePaymentId(ActivityActualPayment activityActualPayment);
	
	/**
	 * 实际支出提交
	 * @param activityActualPayment
	 * @param user
	 */
	public void insert(ActivityActualPayment activityActualPayment, UserInfoEntity user);
	
}
