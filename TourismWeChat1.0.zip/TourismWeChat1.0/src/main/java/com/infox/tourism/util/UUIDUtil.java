package com.infox.tourism.util;

import com.infox.common.utils.IdMaker;

/**
 * @Author: cenjinxing
 * @Date: Created in 2018/9/25 13:50
 **/
public class UUIDUtil {
    public static String create(){
        // return UUID.randomUUID().toString().replace("-","").toString();
    	return IdMaker.getStringKey();
    }
}
