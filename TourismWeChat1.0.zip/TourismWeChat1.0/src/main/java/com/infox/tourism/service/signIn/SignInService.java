package com.infox.tourism.service.signIn;

import com.infox.common.base.BaseService;
import com.infox.tourism.entity.signin.SignInEntity;

import java.util.Date;

/**
 * @Author: Xiao Ming
 * @Date: 2019/7/10 14:33
 * @Version 1.0
 */
public interface SignInService extends BaseService<SignInEntity> {

    void addUserSignIn(String userId, Date date);

    SignInEntity selectUserSignInByDate(String userId, Date signInTime);

}
