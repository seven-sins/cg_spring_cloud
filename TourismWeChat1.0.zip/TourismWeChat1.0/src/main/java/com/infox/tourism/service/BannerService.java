package com.infox.tourism.service;

import com.infox.tourism.entity.vo.indexVO.CarouselMapIndexVO;

import java.util.List;

/**
 * 轮播图表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-06 17:14:57
 */
public interface BannerService {

    /**
     * 微信查询轮播图
     * @return
     */
    List<CarouselMapIndexVO> selectListOfWeChat(String sbLocationId);
}

