package com.infox.tourism.service.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.dao.TravelsDao;
import com.infox.tourism.dao.UserInfoDao;
import com.infox.tourism.entity.TravelsEntity;
import com.infox.tourism.entity.UserInfoEntity;
import com.infox.tourism.entity.vo.travelsVO.TravelsVo;
import com.infox.tourism.service.TravelsService;
import com.infox.tourism.util.DateUtil;
import com.infox.tourism.util.UUIDUtil;

/**
 * 游记表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-21 19:46:05
 */
@Service("travelsService")
public class TravelsServiceImpl implements TravelsService {
	/**
	 * travelsDao层
	 * 
	 * @param params
	 * @return
	 */
	@Autowired
	private TravelsDao travelsDao;
	@Autowired
	private UserInfoDao userInfoDao;

	/**
	 * 查询分页
	 * 
	 * @param pageNum
	 * @param pageSize
	 * @param search
	 * @return
	 */
	@Override
	public List<TravelsVo> queryPage(int pageNum, int pageSize, String userId) {
		// 使用分页插件实现分页
		// PageHelper.startPage(pageNum,pageSize);
		// 调用dao的方法
		List<TravelsVo> list = travelsDao.queryPage(userId);
		return list;
	};

	@Override
	public List<TravelsVo> myTravelsList(int pageNum, int pageSize, String userId) {

		List<TravelsVo> list = travelsDao.myTravelsList(userId);
		return list;
	}

	/**
	 * 根据id查询
	 * 
	 * @param lineTypeId
	 * @return
	 */
	@Override
	public TravelsVo selectById(String userId, String travelsId) {
		TravelsVo travelsEntity = travelsDao.selectById(userId, travelsId);
		if (travelsEntity != null && StringUtils.isNotBlank(userId)) {
			// 如果游记作者和当前登录用户不一致， 不显示未审核通过的游记
			if (!userId.equals(travelsEntity.getAuthorId())) {
				if (travelsEntity.getRequestStatus() != null && travelsEntity.getRequestStatus() != 1) {
					return null;
				}
			}
			// 设置收藏状态
			travelsEntity.setCollectOrNot(travelsDao.isCollect(travelsId, userId));
			UserInfoEntity userInfo = userInfoDao.selectByPrimaryKey(travelsEntity.getAuthorId());
			if (userInfo != null) {
				travelsEntity.setUserName(userInfo.getNickName());
				travelsEntity.setHeadImg(userInfo.getHeadImg());
			}
		}

		return travelsEntity;
	}

	/**
	 * 保存
	 * 
	 * @param travelsEntity
	 * @return
	 */
	@Override
	public boolean insert(TravelsEntity travelsEntity, AuthUser user) {
		travelsEntity.setTravelsId(UUIDUtil.create());
		travelsEntity.setIsDelete(1);
		travelsEntity.setCreateTime(DateUtil.getYYYYMMDDHHMMSS());
		travelsEntity.setReleaseTime(DateUtil.getYYYYMMDDHHMMSS());
		travelsEntity.setPostTime(DateUtil.getYYYYMMDDHHMMSS());
		travelsEntity.setRequestStatus(0);// 待审核
		travelsEntity.setCreateBy(user.getNickName());
		travelsEntity.setAuthorId(user.getUserId());
		travelsEntity.setReleaseBy(user.getUserId());
		travelsEntity.setRelayNum("0");
		travelsEntity.setCollectNum(0);
		int insert = 0;
		insert = travelsDao.insert(travelsEntity);

		return insert > 0;
	}

	/**
	 * 审批
	 */
	@Override
	public boolean approveById(TravelsEntity travelsEntity) {
		return travelsDao.approveById(travelsEntity) > 0;
	}

	/**
	 * 修改
	 */
	@Override
	public boolean updateById(TravelsEntity travelsEntity, AuthUser user) {
		travelsEntity.setUpdateBy(user.getUserId());
		travelsEntity.setUpdateTime(DateUtil.getYYYYMMDDHHMMSS());
		travelsEntity.setRequestStatus(0);
		travelsEntity.setPostTime(DateUtil.getYYYYMMDDHHMMSS());

		return travelsDao.updateById(travelsEntity) > 0;
	}

	/**
	 * 转发
	 */
	@Override
	public boolean updateRelay(TravelsEntity travelsEntity) {
		int num = (Integer.parseInt(travelsEntity.getRelayNum()) + 1);
		travelsEntity.setRelayNum(String.valueOf(num));
		return travelsDao.updateRelay(travelsEntity) > 0;
	}

	/**
	 * 删除全部
	 * 
	 * @param ids
	 * @return
	 */
	@Override
	public boolean deleteList(TravelsEntity travelsEntity) {
		travelsEntity.setIsDelete(0);

		return travelsDao.deleteList(travelsEntity);
	}

}
