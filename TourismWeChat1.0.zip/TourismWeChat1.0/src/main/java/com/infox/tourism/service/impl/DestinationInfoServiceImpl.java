package com.infox.tourism.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.infox.common.base.impl.BaseServiceImpl;
import com.infox.tourism.entity.DestinationInfoEntity;
import com.infox.tourism.service.DestinationInfoService;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 目的地维护表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-06 17:23:31
 */
@Service
public class DestinationInfoServiceImpl extends BaseServiceImpl<DestinationInfoEntity> implements DestinationInfoService {

	@Resource
	public void setBaseMapper(BaseMapper<DestinationInfoEntity> destinationInfoDao) {
		this.baseMapper = destinationInfoDao;
	}
}
