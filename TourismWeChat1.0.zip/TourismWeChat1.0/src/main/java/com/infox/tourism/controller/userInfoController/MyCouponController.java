package com.infox.tourism.controller.userInfoController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageInfo;
import com.infox.common.utils.Assert;
import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.entity.vo.couponVo.VoucherVo;
import com.infox.tourism.service.VoucherBaseInformationService;
import com.infox.tourism.util.R;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

/**
 * @Author: cenjinxing
 * @Date: Created in 2018/12/8 11:06
 **/
@RestController
@RequestMapping("/mycoupon")
@Api(description = "我的_优惠券接口", tags = { "MyCouponController" })
public class MyCouponController {

	@Autowired
	private VoucherBaseInformationService voucherBaseInformationService;

	@ApiOperation(value = "根据userId查询未使用的优惠券列表", response = VoucherVo.class)
	@GetMapping("/couponList")
	public R photoList(@ApiIgnore AuthUser authUser, Integer type, Integer pageNum, Integer pageSize) {
		List<VoucherVo> list = voucherBaseInformationService.selectByUserId(authUser.getUserId(), type, pageNum, pageSize);
		PageInfo<VoucherVo> pageInfo = new PageInfo<>(list);
		Map<Object, Object> map = new HashMap<>();
		map.put("list", list);
		map.put("total", pageInfo.getTotal());

		return R.ok().put("data", map);
	}

	/**
	 * 立即使用
	 * @param
	 * @return
	 */
	@ApiOperation(value = "立即使用", response = VoucherVo.class)
	@PostMapping("/updateByVoucherBaseId")
	public R updateByVoucherBaseId(@RequestBody JSONObject jsonObject) {
		String id = jsonObject.get("vouchersReceiveId").toString();

		Assert.notNull(id, "优惠券领取id不能为空");

		boolean b = voucherBaseInformationService.updateUse(id);

		return R.ok().put("data", b);
	}

}
