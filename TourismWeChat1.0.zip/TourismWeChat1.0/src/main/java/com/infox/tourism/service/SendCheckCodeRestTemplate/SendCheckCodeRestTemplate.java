package com.infox.tourism.service.SendCheckCodeRestTemplate;

import com.alibaba.fastjson.JSONObject;
import com.infox.tourism.util.XmlTool;
import org.dom4j.DocumentException;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.util.Calendar;

public class SendCheckCodeRestTemplate {

    public static JSONObject requestSendCheckCode(String mobile, String code){

        RestTemplate restTemplate = new RestTemplate();

        HttpHeaders httpHeaders = new HttpHeaders();

        httpHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        MultiValueMap<String, String> params = new LinkedMultiValueMap<>();

        Calendar calendar = Calendar.getInstance();

        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH) + 1;
        int day = calendar.get(Calendar.DAY_OF_MONTH);


        String messgeContent = "【暴走团】您于"+ year +"年"+ month +"月"+ day +"日申请了帐号激活，校验码是"+code;

        String sendMessgeUrl = "http://139.196.236.35:8888/sms.aspx";

        params.add("action", "send");
        params.add("userid", "39");
        params.add("account", "sr-huilin");
        params.add("password", "huilin@sr4320");
        params.add("mobile", mobile);
        params.add("content", messgeContent);

        HttpEntity<MultiValueMap<String, String>> httpEntity = new HttpEntity<>(params, httpHeaders);

        ResponseEntity<String> responseEntity = restTemplate.postForEntity(sendMessgeUrl, httpEntity, String.class);

        JSONObject responseJSONObject = null;

        try {

            responseJSONObject = XmlTool.documentToJSONObject(responseEntity.getBody());

            return responseJSONObject;

        } catch (DocumentException e) {
            e.printStackTrace();
            return responseJSONObject;
        }

    }

}