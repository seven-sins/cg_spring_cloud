package com.infox.tourism.service;

import com.infox.tourism.entity.ExceptionalRecordEntity;
import com.infox.tourism.entity.LeaderInfoEntity;
import com.infox.tourism.entity.vo.UserVO.ExceptionalVO;

import java.util.List;

/**
 * 打赏记录表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-21 15:17:45
 */
public interface ExceptionalRecordService {
    /**
    * 查询分页
    * @param pageNum 下一页
     * @param pageSize 显示的长度
     * @param userId 搜索
    * @return
    */
    List<ExceptionalVO> selectByExceptionalPeople(int pageNum, int pageSize, String userId);

    /**
     * 我的总金额
     * @param userId
     * @return
     */
    Integer getTotalAmount(String userId);

    /**
     * 打赏领队
     * @param pageNum
     * @param pageSize
     * @param activityId
     * @return
     */
    List<LeaderInfoEntity> rewardLeader(String activityId);
    /**
     * 打赏明细
     * @param pageNum
     * @param pageSize
     * @param activityId
     * @return
     */
    List<ExceptionalRecordEntity> rewardRecord(int pageNum, int pageSize,String activityId,String leaderId);

}

