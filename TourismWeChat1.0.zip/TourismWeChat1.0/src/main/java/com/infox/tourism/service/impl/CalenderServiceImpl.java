package com.infox.tourism.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infox.tourism.dao.CalenderDao;
import com.infox.tourism.entity.vo.CalenderVO.CalenderCountVO;
import com.infox.tourism.entity.vo.CalenderVO.CalenderVO;
import com.infox.tourism.service.CalenderService;

@Service("calenderService")
@Transactional
public class CalenderServiceImpl implements CalenderService {

	@Autowired
	private CalenderDao calenderDao;

	@Override
	public List<CalenderCountVO> selectCalenderCount(String startTime, String endTime, String companyId) {
		// 调用dao的方法
		List<CalenderCountVO> calenderCountList = calenderDao.selectCalenderCount(startTime, endTime, companyId);
		return calenderCountList;
	}

	@Override
	public List<CalenderVO> selectCalenderListByDay(int pageNum, int pageSize, String dayTime, String companyId) {
		List<CalenderVO> calenderList = calenderDao.selectCalenderListByDay(dayTime, companyId);

		return calenderList;
	}

}
