package com.infox.tourism.controller.userInfoController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.infox.tourism.entity.vo.MessageVO.MessageVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageInfo;
import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.entity.MessagePushEntity;
import com.infox.tourism.service.MessageService;
import com.infox.tourism.util.R;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

/**
 * @Author: cenjinxing
 * @Date: Created in 2018/12/12 19:16
 **/
@RestController
@RequestMapping("/mySysMessage")
@Api(description = "我的系统消息",tags = {"MySysMessageController"})
public class MySysMessageController {

    @Autowired
    private MessageService messageService;

    /**
     * 我的系统消息提醒
     */
    @ApiOperation(value = "我的系统消息提醒",response = MessagePushEntity.class)
    @GetMapping("/sysMessage")
    public R sysMessage(@ApiIgnore AuthUser authUser, int pageNum , int pageSize,String search,String time){
        List<MessageVO> list = messageService.selectByUserId(authUser.getUserId(), pageNum, pageSize,search,time);

        PageInfo<MessageVO> pageInfo = new PageInfo<>(list);

        Map<Object, Object> map = new HashMap<>();
        map.put("list",list);
        map.put("total",pageInfo.getTotal());

        return R.ok().put("data",map);
    }
}
