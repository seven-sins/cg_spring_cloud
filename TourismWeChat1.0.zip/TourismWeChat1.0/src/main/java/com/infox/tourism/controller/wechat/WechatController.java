package com.infox.tourism.controller.wechat;

import java.io.IOException;
import java.util.Map;
import java.util.Random;
import java.util.SortedMap;
import java.util.TreeMap;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.infox.common.utils.Assert;
import com.infox.common.utils.redis.RedisConstant;
import com.infox.common.utils.redis.RedisService;
import com.infox.common.wechat.utils.WechatProperties;
import com.infox.common.wechat.utils.WechatUtil;
import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.util.R;
import com.infox.tourism.util.SHA1;
import com.infox.tourism.util.UUIDUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

/**
 * 微信登录
 * @author Tan Ling
 * 2018年12月7日 上午10:47:59
 */
@Api(description = "微信登录接口")
@RestController
public class WechatController {
	private static final Logger LOG = LoggerFactory.getLogger(WechatController.class);
	@Autowired
	private WechatUtil wechatUtil;
	@Autowired
	private RedisService redisService;
	@Autowired
	private WechatProperties wechatProperties;
	
	@ApiOperation("微信回调接口")
	@RequestMapping("/wechatCallback")
	public void wechatCallback(HttpServletResponse response, String code) throws IOException {
		LOG.info("=============code: " + code);
		/**
		 * 获取openId
		 */
		JSONObject accessToken = wechatUtil.getWxOpenId(code);
		LOG.info("=============accessToken: " + accessToken);
		/**
		 * 生成缓存token(缓存有效时间6小时)  6小时 = 240分
		 */
		String token = UUIDUtil.create();
		redisService.add(RedisConstant.WECHAT_OPENID_PREFIX + token, accessToken.getString("openid"));
		
		response.sendRedirect(wechatProperties.getRedirectUrl() + token);
	}
	
	@ApiOperation("获取用户信息")
	@GetMapping("/wechatUser")
	public R wechatUser(@ApiIgnore AuthUser authUser) {
		return R.ok().put("data", authUser);
	}
	
	@ApiOperation("获取签名")
	@PostMapping(value="/signature")
    public R getSignature(@RequestBody Map<String, String> map){
		String url = map.get("url");
		Assert.notEmpty(url, "获取签名url不能为空");
		LOG.info("=============before url: " + url);
		url = url.trim();
		String timestamp = (System.currentTimeMillis() / 1000) + "";
		String accessToken = wechatUtil.getWxAccessToken().getString("access_token");  
		JSONObject jsapiTicketJson = wechatUtil.getJsApiTicket(accessToken);

        LOG.info("=============jsapiTicket: " + jsapiTicketJson);
        LOG.info("=============access_token: " + accessToken);
        
        String jsapiTicket = jsapiTicketJson.getString("ticket");
        
        SortedMap<String, String> params = new TreeMap<>();
        params.put("jsapi_ticket", jsapiTicket);
		params.put("noncestr", createNoncestr());
		params.put("timestamp", timestamp);
		
		params.put("url", url);
        params.put("signature", SHA1.encode(params));
        params.put("appid", wechatProperties.getAppId());
        
        LOG.info("=============signature: " + params);
 
        return R.ok().put("data", params);
    }
	
	private String createNoncestr() {
		String chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		StringBuffer buf = new StringBuffer();
		int length = 16;
		for (int i = 0; i < length; i++) {
			Random rd = new Random();
			buf.append(chars.charAt(rd.nextInt(chars.length() - 1)));
		}
		return buf.toString();
	}
	
	//	@GetMapping("/test01")
	//	public Object test() {
	//		JSONObject json = new JSONObject();
	//		json.put("startDate", "2018-12-19");
	//		json.put("endDate", "2018-12-23");
	//		json.put("insurancesId", "fc95dc5e5b654c5caad77975aa603082");
	//		json.put("orderId", "123456789");
	//		json.put("destination", "中国香港");
	//		JSONArray array = new JSONArray();
	//		
	//		JSONObject people = new JSONObject();
	//		people.put("insureName", "郝海龙");
	//		people.put("cardCode", "350502198412211776");
	//		people.put("mobile", "15377728913");
	//		array.add(people);
	//		
	//		JSONObject people1 = new JSONObject();
	//		people1.put("insureName", "鞠霖一");
	//		people1.put("cardCode", "450921199306278933");
	//		people1.put("mobile", "15377728913");
	//		array.add(people1);
	//		
	//		JSONObject people2 = new JSONObject();
	//		people2.put("insureName", "习敏");
	//		people2.put("cardCode", "653130199106219608");
	//		people2.put("mobile", "15377728913");
	//		array.add(people2);
	//		
	//		json.put("insurants", array);
	//		
	//		String url = "http://bzt.fmcgnet.com/api/tourism/insuranceinfo/sendsimpleinsure";
	//		ResponseEntity<String> result = new RestTemplate().postForEntity(url, json, String.class);
	//		
	//		System.out.println(result.toString());
	//	
	//		return 1;
	//	}
	
	//	@GetMapping("/test02")
	//	public Object test02() {
	//		messageUtil.pushOrderWechatMessage("orderId11111", "productId111", "productName111", "remark111");
	//		return 1;
	//	}
	
}
