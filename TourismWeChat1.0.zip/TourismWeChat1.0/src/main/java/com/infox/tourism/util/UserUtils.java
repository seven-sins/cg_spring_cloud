package com.infox.tourism.util;

/**
 * 获取当前用户身份信息
 *
 * @Author: cenjinxing
 * @Date: Created in 2018/10/19 16:12
 **/
public class UserUtils {
//    public static void setUserCache(UserCacheVO userCache){
//        if(userCache == null){
//            ShiroUtils.removeSessionAttribute("UserCache");
//        }
//        else{
//            ShiroUtils.setSessionAttribute("UserCache", userCache);
//        }
//    }
//
//    /**
//     * @return 获取当前用户缓存
//     */
//    public static UserCacheVO getUserCache(){
//        return (UserCacheVO) ShiroUtils.getSessionAttribute("UserCache");
//    }
}
