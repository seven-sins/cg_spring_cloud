package com.infox.tourism.controller.teamController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.infox.common.utils.response.Result;
import com.infox.tourism.entity.team.TeamActivity;
import com.infox.tourism.entity.team.TeamLine;
import com.infox.tourism.entity.team.TeamLineDetail;
import com.infox.tourism.service.team.TeamService;

/**
 * 团队定制活动
 * @author Tan Ling
 * @date 2019年6月26日 下午1:36:37
 */
@RestController
public class TeamController {

	@Autowired
	private TeamService teamService;
	
	@GetMapping("/team/line/detail/{lineId}")
	public Result<TeamLineDetail> lineDetail(@PathVariable("lineId") String lineId){
		return new Result<>(teamService.queryLineDetail(lineId));
	}
	
	/**
	 * 查询线路列表
	 * @author Tan Ling
	 * @date 2019年6月26日 下午2:26:57
	 * @param pageNum
	 * @param pageSize
	 * @return
	 */
	@GetMapping("/team/line/list")
	public Result<List<TeamLine>> queryTeamLine(int pageNum, int pageSize){
		PageHelper.startPage(pageNum, pageSize);
		List<TeamLine> list = teamService.find();
		
		return new Result<>(list).total(new PageInfo<TeamLine>(list).getTotal());
	}
	
	/**
	 * 查询活动列表
	 * @author Tan Ling
	 * @date 2019年6月26日 下午2:27:04
	 * @param pageNum
	 * @param pageSize
	 * @param lineId
	 * @return
	 */
	@GetMapping("/team/{lineId}/activity")
	public Result<List<TeamActivity>> queryTeamActivity(int pageNum, int pageSize, @PathVariable("lineId") String lineId){
		PageHelper.startPage(pageNum, pageSize);
		List<TeamActivity> list = teamService.queryActivityList(lineId);
		
		return new Result<>(list).total(new PageInfo<TeamActivity>(list).getTotal());
	}
}
