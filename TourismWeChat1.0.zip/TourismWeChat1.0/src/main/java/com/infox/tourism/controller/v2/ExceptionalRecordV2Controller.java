package com.infox.tourism.controller.v2;

import java.math.BigDecimal;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.service.v2.ExceptionalRecordV2Service;
import com.infox.tourism.util.R;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

/**
 * 
 * @author yuanfang
 * 2019年5月14日 上午10:56:47
 */
@RestController
@RequestMapping("/exceptionalRecord/V2")
public class ExceptionalRecordV2Controller {

	@Autowired
	ExceptionalRecordV2Service exceptionalRecordV2Service;

	@ApiOperation("打赏金额总数")
	@GetMapping("/queryNumErMoney")
	public R queryNumErMoney(@ApiIgnore AuthUser user) {
		BigDecimal queryNumErMoney = exceptionalRecordV2Service.queryNumErMoney(user.getUserId());
		return R.ok().put("data", queryNumErMoney);
	}
}
