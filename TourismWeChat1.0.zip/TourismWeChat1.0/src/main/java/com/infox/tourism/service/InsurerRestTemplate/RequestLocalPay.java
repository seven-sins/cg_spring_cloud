package com.infox.tourism.service.InsurerRestTemplate;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.infox.tourism.util.InsurerApi;
import com.infox.tourism.util.InsurerSign;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class RequestLocalPay {

    public static JSONObject sendRequestLocalPay(JSONObject localPayJSON){

        RestTemplate restTemplate = new RestTemplate();

        System.out.println("------------------发送的请求参数：" + localPayJSON.toJSONString());

        String localPaySign = InsurerSign.getInsurerSign(localPayJSON.toJSONString());
        String localApiUrl = InsurerApi.getLocalPayAPI(localPaySign);

        HttpEntity<JSONObject> httpEntity = new HttpEntity<>(localPayJSON);

        ResponseEntity<String> responseEntity = restTemplate.postForEntity(localApiUrl, httpEntity, String.class);

        return JSON.parseObject(responseEntity.getBody());

    }

}