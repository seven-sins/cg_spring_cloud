package com.infox.tourism.service;

import java.util.List;

import com.infox.tourism.entity.ActivityInfoEntity;
import com.infox.tourism.entity.v2.activityInfo.SecondKillActivity;
import com.infox.tourism.entity.vo.activity.Activity;
import com.infox.tourism.entity.vo.activity.ActivityBase;
import com.infox.tourism.entity.vo.activity.ActivityBaseParams;
import com.infox.tourism.entity.vo.activity.ActivityOutset;
import com.infox.tourism.entity.vo.activityDetailVO.ActivityBriefVO;
import com.infox.tourism.entity.vo.activityDetailVO.PayActivityVO;
import com.infox.tourism.entity.vo.baseVo.ActivityBaseVO;

/**
 * 活动表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-15 10:36:29
 */
public interface ActivityService {
	// 查询出行人列表
	Activity selectPedestrianInfoByActivityId(String activityId);
	/**
	 * 查询活动详细信息
	 * @param activityId
	 * @return
	 */
	Activity queryActivityDetail(String activityId, Boolean detail);
	/**
	 * 查询活动
	 * @param activityId
	 * @return
	 */
	Activity getActivity(String activityId, Boolean detail);
    /**
     * 查询活动通过活动名称和领队名称模糊查询
     * 要查询的内容
     * @return
     */
    List<ActivityBaseVO> selectActivityForWeChat(String name);

    /**
     * 根据线路Id查询活动简介列表
     */
    List<ActivityBriefVO> selectActivityBriefByLineId(String lineId,String activityId,String userId);

    PayActivityVO selectPayActivityById(String activityId);
    
    /**
     * 首页活动列表分类查询
     * @author Tan Ling
     * @date 2019年1月21日 上午11:14:03
     * @param pageNum
     * @param pageSize
     * @param params
     * @return
     */
    List<ActivityBase> selectActivityPage(int pageNum,int pageSize, ActivityBaseParams params);
    /**
     * 新活动列表查询(2019-09-03)
     * @author Tan Ling
     * @date 2019年9月2日 下午2:33:24
     * @param pageNum
     * @param pageSize
     * @param params
     * @return
     */
    List<ActivityBase> selectActivityPageV2(int pageNum,int pageSize, ActivityBaseParams params);

    List<ActivityInfoEntity> selectImageByLineId(String lineId);
    /**
     * 查询当前线路下的活动列表
     * @author Tan Ling
     * @date 2019年1月15日 下午5:21:34
     * @param lineId
     * @param activityId
     * @return
     */
	List<ActivityOutset> queryActivityList(String lineId, String activityId);
	
	/**
	 * 查询线路下的活动出行日期列表
	 * @author Tan Ling
	 * @date 2019年7月24日 上午9:32:41
	 * @param lineId
	 * @return
	 */
	List<ActivityOutset> queryActivityList(String lineId);
	
	// List<Activity> selectSpecialActivityPage(int pageNum,int pageSize, String locationId);

	/**
	 * 查询热门活动
	 * @param popular
	 * @return
	 */
	List<ActivityBase> selectByPopular(Integer popular,int pageNum,int pageSize,String activityId);
	/**
	 * 首页活动搜索
	 * @author Tan Ling
	 * @date 2019年1月21日 上午10:04:28
	 * @param name
	 * @return
	 */
	List<ActivityBase> queryActivityByName(int pageNum, int pageSize, String name, String locationId);
	/**
	 * 查询活动信息(单记录查询,需要缓存)
	 * @author Tan Ling
	 * @date 2019年1月21日 下午4:14:31
	 * @param activityId
	 * @return
	 */
	Activity getActivityByActivityId(String activityId, Boolean detail);
	/**
	 * 查询活动基础信息
	 * @author Tan Ling
	 * @date 2019年1月29日 上午11:32:49
	 * @param activityId
	 * @return
	 */
	ActivityBase getActivityBaseByActivityId(String activityId);
	/**
	 * 维护活动状态
	 * @author Tan Ling
	 * @date 2019年1月29日 下午3:29:46
	 * @param activityId
	 */
	void resetActivityStatus(String activityId);
	/**
	 * 查询活动所有出行人信息
	 * @author Tan Ling
	 * @date 2019年3月22日 上午9:34:47
	 * @param activityId
	 * @return
	 */
	Activity queryActivityPedestrin(String activityId);
	/**
	 * 查询所有活动ID
	 * @author Tan Ling
	 * @date 2019年4月8日 下午2:35:21
	 * @return
	 */
	List<String> queryAllActivityId();
	/**
	 * 查询活动已报名人数
	 * @author Tan Ling
	 * @date 2019年1月16日 上午9:30:48
	 * @param activityId
	 * @return
	 */
	Integer queryActivityPeopleNum(String activityId);
	/**
	 * 查询秒杀活动
	 * @author Tan Ling
	 * @date 2019年7月29日 上午10:06:06
	 * @return
	 */
	List<SecondKillActivity> querySecondKillActivity();

	/**
	 * @MethodName: queryPreferentialActivities
	 * @Description: 查询优惠活动列表
	 * @Param: [locationId]
	 * @Return: java.util.List<com.infox.tourism.entity.vo.activity.ActivityBase>
	 * @Author: reco
	 * @Date: 2019/8/26 16:56
	*/
	List<ActivityBase> queryPreferentialActivities(String locationId);
}

