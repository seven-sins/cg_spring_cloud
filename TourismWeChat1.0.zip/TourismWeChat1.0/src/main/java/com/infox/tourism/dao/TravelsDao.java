package com.infox.tourism.dao;

import com.infox.tourism.entity.TravelsEntity;
import com.infox.tourism.entity.vo.travelsVO.TravelsVo;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import tk.mybatis.mapper.common.BaseMapper;

import java.util.List;

/**
 * 游记表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-21 19:46:05
 */
@Mapper
public interface TravelsDao extends BaseMapper<TravelsEntity> {

    /**
    * 查询游记分页
    * @return
    */
    List<TravelsVo> queryPage(@Param("userId") String userId);
    
    /**
     * 查询我的游记分页
     * @return
     */
     List<TravelsVo> myTravelsList(@Param("userId") String userId);

     /**
      * 根据id查询
      * @param travelsId
      * @param userId
      * @return
      */
     TravelsVo selectById(@Param("userId") String userId,@Param("travelsId")String travelsId);

     /**
      * 审批
      */
     int approveById(TravelsEntity travelsEntity);
     
     /**
      * 根据id修改
      */
     int updateById(TravelsEntity travelsEntity);

     /**
      * 转发
      */
     int updateRelay(TravelsEntity travelsEntity);
     
     /**
      * 删除全部
      * @param travelsEntity
      * @return
      */
     boolean deleteList(TravelsEntity travelsEntity);
     /**
      * 检查当前用户是否关注游记
      * @author Tan Ling
      * @date 2019年2月18日 下午3:28:20
      * @param travelsId
      * @param userId
      * @return
      */
     Integer isCollect(String travelsId, String userId);
}
