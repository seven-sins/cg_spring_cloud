package com.infox.tourism.service;

import com.infox.tourism.entity.PersonalSettingsEntity;

/**
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-12-11 18:52:59
 */
public interface PersonalSettingsService {

    /**
    * 查询分页
    * @return
    */
    PersonalSettingsEntity queryPage(String userId);

    /**
     * 领队动态提醒      1 开启   2  关闭
     */
    boolean updatePersonalSettings(PersonalSettingsEntity personalSettingsEntity);

}

