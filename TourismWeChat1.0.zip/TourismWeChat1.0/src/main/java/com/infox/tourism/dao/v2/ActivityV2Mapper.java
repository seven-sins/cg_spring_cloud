package com.infox.tourism.dao.v2;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.infox.tourism.entity.ActivityInfoEntity;

/**
 * 
 * @author yuanfang
 * 2019年5月14日 上午10:55:32
 */
@Mapper
public interface ActivityV2Mapper {
	/**
	 * 
	 */
	List<ActivityInfoEntity> queryByLeaderId(String leaderId );
	
	/**
	 * 
	 */
	 int queryCountByUserId(String userId);
}


