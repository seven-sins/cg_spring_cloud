package com.infox.tourism.service;

import java.util.List;

import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.entity.CollectEntity;
import com.infox.tourism.entity.vo.UserVO.CollectVO;

/**
 * 收藏表
 *
 * @author yiwei
 * @email @163.com
 * @date 2018-12-10 8:46:05
 */
public interface CollectService {

	/**
     * 根据id查询
     * @param collectUserId
     * @return
     */
	CollectEntity selectById(String travelsActivityId, String userId, String collectType);

    /**
     * 保存
     * @param CollectEntity
     * @return
     */
    boolean insert(CollectEntity collectEntity);
    /**
     * 根据id修改
     */
    boolean updateById(CollectEntity collectEntity,AuthUser use);

    /**
     * 我的收藏  活动 AND 游记
     * @param userId
     * @param collectType
     * @return
     */
    List<CollectVO> selectByUserId(String userId, Integer collectType, int pageNum, int pageSize);

    /**
     * 取消收藏
     * @return
     */
    boolean updateEnable(CollectEntity collectEntity,AuthUser user);

}
