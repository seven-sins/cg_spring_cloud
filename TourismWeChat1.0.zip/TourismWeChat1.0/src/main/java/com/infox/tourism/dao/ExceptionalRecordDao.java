package com.infox.tourism.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.infox.tourism.entity.ExceptionalRecordEntity;
import com.infox.tourism.entity.vo.UserVO.ExceptionalVO;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 打赏记录表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-21 15:17:45
 */
@Mapper
public interface ExceptionalRecordDao extends BaseMapper<ExceptionalRecordEntity> {

    /**
    * 查询分页
    * @return
    */
    List<ExceptionalRecordEntity> queryPage();

    /**
     * 根据exceptional_people查询
     * @return
     */
    List<ExceptionalVO> selectByExceptionalPeople(String userId);

    /**
     * 我的总金额
     * @param userId
     * @return
     */
    Integer getTotalAmount(String userId);
  
    /**
     * 更新
     */
    int updateById(ExceptionalRecordEntity exceptionalRecordEntity);
    
    /*
     * 根据id查找
     *      
     */
    ExceptionalRecordEntity queryById(@Param("exceptionalRecordId")String exceptionalRecordId);
    
    /*
     * 根据trxid查找
     *      
     */
    ExceptionalRecordEntity queryByTrxid(@Param("trxid")String trxid);

    /**
     * 根据活动id跟领队id查询数据
     * @return
     */
    List<ExceptionalRecordEntity> selectExceptionalRecordByActivityIdAndLeaderId(@Param("activityId")String activityId,@Param("leaderId") String[] leaderId);
    
    void updateStatusById(@Param("exceptionalRecordId") String exceptionalRecordId, @Param("trxid") String trxid, @Param("state") Integer state);

    Integer selectCountByLeaderId(@Param("leaderId") String leaderId);
}
