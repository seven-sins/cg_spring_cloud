package com.infox.tourism.controller.userInfoController;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infox.common.utils.Assert;
import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.entity.vo.UserVO.UserVO;
import com.infox.tourism.service.UserInfoService;
import com.infox.tourism.util.R;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

/**
 * @Author: cenjinxing
 * @Date: Created in 2018/12/11 15:51
 **/
@RestController
@RequestMapping("/userInfo")
@Api(description = "我的", tags = { "userInfoController" })
public class UserInfoController {

	/**
	 * 用户
	 */
	@Autowired
	private UserInfoService userInfoService;

	/**
	 * 根据openid查询用户页面数据
	 */
	@ApiOperation(value = "我的", response = UserVO.class)
	@GetMapping("/selectByOpenId")
	public R selectByOpenId(@ApiIgnore AuthUser authUser) {
		UserVO userVO = userInfoService.selectUserInfoByUserId(authUser.getUserId());
		if (userVO == null) {
			return R.error(400, "个人信息为空");
		}

		return R.ok().put("data", userVO);
	}

	/**
	 * 根据openid更新我的信息
	 */
	@ApiOperation(value = "更新--我的", response = UserVO.class)
	@PostMapping("/updateByOpenId")
	public R updateByOpenId(@ApiIgnore AuthUser authUser, @RequestBody UserVO userVO) {
		boolean b = userInfoService.updateUserInfoByUserId(userVO, authUser.getUserId());
		return R.ok().put("data", b);
	}

	/**
	 * 更改背景圖片
	 */
	@ApiOperation(value = "更新--我的背景圖", response = UserVO.class)
	@PostMapping("/updateBackgroundImg")
	public R updateBackgroundImg(@ApiIgnore AuthUser authUser, @RequestBody Map<String, Object> map) {
		Assert.notNull(map.get("url"), "圖片連接不能爲空");
		userInfoService.updateBackgroundImg(authUser.getUserId(), map.get("url").toString());
		return R.success();
	}

}
