package com.infox.tourism.controller.activityController;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.infox.common.utils.Assert;
import com.infox.common.utils.DateUtils;
import com.infox.common.utils.redis.RedisService;
import com.infox.common.utils.response.Result;
import com.infox.common.wechat.qrcode.QRCodeUtil;
import com.infox.common.wechat.utils.WechatUtil;
import com.infox.tourism.async.UserCity;
import com.infox.tourism.config.resolver.Guest;
import com.infox.tourism.entity.JoinCity;
import com.infox.tourism.entity.activity.LineImages;
import com.infox.tourism.entity.v2.activityInfo.SecondKillActivity;
import com.infox.tourism.entity.vo.activity.Activity;
import com.infox.tourism.entity.vo.activity.ActivityBase;
import com.infox.tourism.entity.vo.activity.ActivityBaseParams;
import com.infox.tourism.entity.vo.activity.ActivityOutset;
import com.infox.tourism.entity.vo.activityDetailVO.LineEvaluationVO;
import com.infox.tourism.entity.vo.baseVo.CommentVO;
import com.infox.tourism.entity.vo.lineVO.LineVo;
import com.infox.tourism.service.ActivityService;
import com.infox.tourism.service.EvaluationService;
import com.infox.tourism.service.JoinCityService;
import com.infox.tourism.service.LineService;
import com.infox.tourism.service.v2.ViewRecordService;
import com.infox.tourism.service.v2.activity.LineImagesService;
import com.infox.tourism.util.ImgUtil;
import com.infox.tourism.util.R;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * @author Tan Ling
 * @date 2019年1月30日 下午2:24:49
 */
@Api(description = "活动",tags = {"ActivityController"})
@RestController
@RequestMapping("/activity")
public class ActivityController {
	private static final Logger LOG = LoggerFactory.getLogger(ActivityController.class);
	static final String ACTIVITY_DETAIL_URL = "/#/activedetail?activeId=%s&lineId=%s";
	static final String SHARE_DETAIL_URL = "%s/redirect.html?app3Redirect=%s";
    @Autowired
    private ActivityService activityService;
    @Autowired
    private LineService lineService;
    @Autowired
    private EvaluationService evaluationService;
    @Autowired
    private WechatUtil wechatUtil;
    @Autowired
    private ViewRecordService viewRecordService;
    @Autowired
    private LineImagesService lineImagesService;
    @Autowired
    private JoinCityService joinCityService;
    @Autowired
    private RedisService redisService;
    
    @Value("${upload.path}")
    String uploadPath;
    @Value("${upload.url}")
    String uploadUrl;
    @Value("${web.domain}")
    String domain;
    
    @Autowired
    UserCity userCity;
    
    /**
     * 暴走精选
     * @author Tan Ling
     * @date 2019年7月23日 下午5:44:14
     * @param pageNum
     * @param pageSize
     * @return
     */
    @SuppressWarnings("unchecked")
	@GetMapping("/selectRecommendLine")
    public Result<List<LineVo>> selectRecommendLine(int pageNum, int pageSize, String locationId){
    	Assert.notEmpty(locationId, "locationId不能为空");
		JoinCity joinCity = joinCityService.getBySbLocationId(locationId);
		Assert.notNull(joinCity, "数据异常, 城市信息不存在");
		
		String key = locationId + pageNum + "" + pageSize + "recommendLine";
		List<LineVo> list = (List<LineVo>) redisService.get(key);
		if(list == null || list.isEmpty()) {
			PageHelper.startPage(pageNum, pageSize);
			list = lineService.selectRecommendLine(joinCity.getCompanyId());
			if(list != null && !list.isEmpty()) {
				redisService.add(key, list, 1);
			}
		}
    	
    	return new Result<>(list).total(new PageInfo<LineVo>(list).getTotal());
    }

    @ApiOperation("获取活动所有出行人")
    @GetMapping("/queryActivityList")
    public R queryActivityList(String activityId) {
        Assert.notEmpty(activityId, "活动ID不能为空");
        Activity activity = activityService.selectPedestrianInfoByActivityId(activityId);
        return R.ok().put("data",activity);
    }
    
    @ApiOperation("获取活动所有出行人")
    @GetMapping("/queryActivityPedestrin")
    public R queryActivityPedestrin(String activityId) {
    	Assert.notEmpty(activityId, "活动ID不能为空");
    	Activity activity = activityService.queryActivityPedestrin(activityId);
    	return R.ok().put("data",activity);
    }

    @ApiOperation("获取活动")
    @GetMapping("/getActivityByLineId")
    public R getLineByLineId(Guest guest, String lineId, String activityId, HttpServletRequest request){
    	Assert.notEmpty(activityId, "活动ID不能为空");
    	// 修复有些页面没有lineId的问题, lineId改由后端获取
    	ActivityBase activityBase = activityService.getActivityBaseByActivityId(activityId);
    	Assert.notNull(activityBase, "数据异常, 查询活动基础信息返回null");
    	lineId = activityBase.getLineId();
    	Assert.notEmpty(lineId, "数据异常, 活动lineId为空");
    	
        HashMap<String,Object> map = new HashMap<>();
        /**
         * 查询出行活动列表
         */
        List<ActivityOutset> list = activityService.queryActivityList(lineId, activityId);
        
        HashMap<String, Object> coverMap = lineService.selectLineCoverImg(lineId);
        LineEvaluationVO comment = evaluationService.selectEvaluationByLineId(lineId);
        if(comment == null){
            comment = new LineEvaluationVO(activityId);
        }
        List<CommentVO> commonList = evaluationService.selectCommonListByLineId(lineId);
		map.put("list", list);
		map.put("cover", coverMap);
		map.put("overall", comment);
		map.put("commentList", commonList);
		map.put("images", this.getImage(lineId));
		map.put("outsetGroup", this.getOutsetGroup(list));
		
		/**
		 * 添加访问记录
		 */
		viewRecordService.addViewRecord(guest, lineId, null);
		/**
		 * 更新用户位置信息
		 */
    	userCity.updateUserCity(request.getHeader("token"), guest);
		
        return R.ok().put("data",map);
    }
    
    private List<Map<String, Object>> getOutsetGroup(List<ActivityOutset> list){
    	if(list == null || list.isEmpty()) {
    		return null;
    	}
    	Map<String, Integer> map = new HashMap<>();
    	for(ActivityOutset item: list) {
    		String key = DateUtils.format(item.getOutsetTime(), "yyyy-MM");
    		if(!map.containsKey(key)) {
    			map.put(key, 1);
    		} else {
    			Integer oldValue = map.get(key);
    			map.put(key, oldValue + 1);
    		}
    	}
    	
    	List<Map<String, Object>> result = new ArrayList<>();
    	for (Map.Entry<String, Integer> item : map.entrySet()) {
    		Map<String, Object> m = new HashMap<>();
    		m.put("month", item.getKey());
    		m.put("num", item.getValue());
    		m.put("sorting", item.getKey().replaceAll("\\W+", ""));
    		result.add(m);
        }
    	Collections.sort(result, new Comparator<Map<String, Object>>() {
			@Override
			public int compare(Map<String, Object> o1, Map<String, Object> o2) {
				long diff = Integer.parseInt(o1.get("sorting").toString()) - Integer.parseInt(o2.get("sorting").toString());
				if(diff > 0) {
					return 1;
				} else if(diff < 0) {
					return -1;
				}
				return 0;
			}
    	});
    	
    	return result;
    }
    
    @ApiOperation("获取活动")
    @GetMapping("/getActivityByLineIdV2")
    public R getLineByLineIdV2(Guest guest, String lineId){
        HashMap<String,Object> map = new HashMap<>();
        /**
         * 查询出行活动列表
         */
        List<ActivityOutset> list = activityService.queryActivityList(lineId);
        
        HashMap<String, Object> coverMap = lineService.selectLineCoverImg(lineId);
        LineEvaluationVO comment = evaluationService.selectEvaluationByLineId(lineId);
        List<CommentVO> commonList = evaluationService.selectCommonListByLineId(lineId);
        if(list != null && !list.isEmpty()) {
        	map.put("activityId", list.get(0).getActivityId());
        }
		map.put("list", list);
		map.put("cover", coverMap);
		map.put("overall", comment);
		map.put("commentList", commonList);
		map.put("images", this.getImage(lineId));
		
		/**
		 * 添加访问记录
		 */
		viewRecordService.addViewRecord(guest, lineId, null);
		
        return R.ok().put("data",map);
    }
    
    private List<String> getImage(String lineId){
    	LineImages lineImages = new LineImages();
    	lineImages.setLineId(lineId);
    	List<LineImages> list = lineImagesService.find(1, Integer.MAX_VALUE, "create_time DESC", lineImages);
    	List<String> images = new ArrayList<>();
    	for(LineImages item: list) {
    		images.add(ImgUtil.hight(item.getImageUrl()));
    	}
    	return images;
    }
    
    @GetMapping("/detail")
    public void toDetail(HttpServletResponse response, String activityId, String lineId) throws IOException {
    	// http://test.gzbzt.com/#/activedetail?activeId=eb674c5d1fbb49b49fe49a79178210ba&lineId=f623a182e06e4726aaf473da329b42df
    	String url = domain + "/#/activedetail?activeId=" + activityId + "&lineId=" + lineId;
    	
    	response.sendRedirect(url);
    }
    
    @GetMapping("/shareDetail")
    public void shareDetail(HttpServletResponse response, @RequestParam("activityId") String activityId, @RequestParam(value = "userId", required = false, defaultValue = "") String userId) throws IOException {
    	String url = domain + "/#/activedetail?activeId=" + activityId + "&userId=" + userId;
    	
    	response.sendRedirect(url);
    }

    /**
     * 获取活动详情
     * @author Tan Ling
     * @date 2019年1月15日 下午3:16:32
     * @param activityId
     * @return
     */
    @ApiOperation("获取活动详情")
    @GetMapping("/getActivityDetail")
    public R queryActivityDetail(Guest guest, String activityId, @RequestParam(value = "detail", required = false, defaultValue = "false") Boolean detail ){
    	Assert.notEmpty(activityId, "参数错误, activityId不能为空");
    	Date start = new Date();
        Activity activity = activityService.queryActivityDetail(activityId, detail);
        /**
		 * 添加访问记录
		 */
		viewRecordService.addViewRecord(guest, null, activityId);
		
        Date end = new Date();
        LOG.info("=============控制器耗时: " + (end.getTime() - start.getTime()) / 1000);
        
        return R.ok().put("data", activity);
    }

    @ApiOperation("查询线路下所有活动的图片")
    @GetMapping("/getActivityPicByLineId")
    public R getActivityPicByLineId (String lineId){
        List<?> list =  this.getImage(lineId);
        return R.ok().put("coverList",list);
    }

    @ApiOperation("查询预付款活动详情")
    @GetMapping("/getPayActivityById")
    public R getPayActivityById(String activityId){
    	Assert.notEmpty(activityId, "参数错误, activityId不能为空");
        return R.ok().put("data", activityService.selectPayActivityById(activityId));
    }

    /**
     * 首页活动列表分类查询
     * @author Tan Ling
     * @date 2019年1月21日 上午11:27:21
     * @param pageNum
     * @param pageSize
     * @param map
     * @return
     */
	@ApiOperation("首页活动列表分类查询")
	@GetMapping("/selectActivityPage")
	public R selectActivityPage(int pageNum, int pageSize, ActivityBaseParams params) {
		List<ActivityBase> list = activityService.selectActivityPage(pageNum, pageSize, params);
		if(list != null && !list.isEmpty()) {
			list.forEach(item -> {
				// item.setCoverImg(item.getCoverId().split(",")[0]);
				// 使用缩略图
				if("reducedPrice".equals(params.getType())) {
					String url = item.getCoverImg();
					// 使用0判断字符串是因为有个坑货给字符串设了个默认值0
					if(StringUtils.isNotBlank(item.getDisplayUrl()) && !"0".equals(item.getDisplayUrl())) {
						url = item.getDisplayUrl();
					}
					item.setCoverImg(ImgUtil.hight(url));
				} 
				else if ("hot".equals(params.getType())){
					String url = item.getCoverImg();
					// 使用0判断字符串是因为有个坑货给字符串设了个默认值0
					if(StringUtils.isNotBlank(item.getDisplayUrl()) && !"0".equals(item.getDisplayUrl())) {
						url = item.getDisplayUrl();
					}
					item.setCoverImg(ImgUtil.hight(url));
				}
				else {
					String url = item.getCoverImg();
					// 使用0判断字符串是因为有个坑货给字符串设了个默认值0
					if(StringUtils.isNotBlank(item.getUrl()) && !"0".equals(item.getUrl())) {
						url = item.getUrl();
					}
					item.setCoverImg(ImgUtil.small(url));
				}
			});
		}
		return R.ok().put("data", list).put("total", new PageInfo<ActivityBase>(list).getTotal());
	}
	
	/**
	 * 新版活动列表查询(2019-09-02修改)
	 * @author Tan Ling
	 * @date 2019年9月2日 下午3:18:46
	 * @param pageNum
	 * @param pageSize
	 * @param params
	 * @return
	 */
	@ApiOperation("首页活动列表分类查询")
	@GetMapping("/selectActivityPageV2")
	public R selectActivityPageV2(int pageNum, int pageSize, ActivityBaseParams params) {
		List<ActivityBase> list = activityService.selectActivityPageV2(pageNum, pageSize, params);
		if(list != null && !list.isEmpty()) {
			list.forEach(item -> {
				/**
				 * 1.设置封面图
				 */
				String url = item.getCoverImg();
				// 使用0判断字符串是因为有个坑货给字符串设了个默认值0
				if(StringUtils.isNotBlank(item.getUrl()) && !"0".equals(item.getUrl())) {
					url = item.getUrl();
				}
				item.setCoverImg(ImgUtil.middle(url));
			});
		}
		return R.ok().put("data", list).put("total", new PageInfo<ActivityBase>(list).getTotal());
	}
    
	/**
	 * 首页优惠活动查询
	 * @author Tan Ling
	 * @date 2019年1月21日 上午11:40:57
	 * @param pageNum
	 * @param pageSize
	 * @param
	 * @return
	 */
	@ApiOperation("分页查询优惠活动")
	@GetMapping("/selectSpecialActivityPage")
	public R selectSpecialActivityPage(int pageNum, int pageSize, ActivityBaseParams params) {
		List<ActivityBase> list = activityService.selectActivityPage(pageNum, pageSize, params);

		return R.ok().put("data", list).put("total", new PageInfo<ActivityBase>().getTotal());
	}

    /**
     * 查询所有的热门路线
     */
    @ApiOperation("查询所有的热门路线")
    @GetMapping("/selectByPopular")
    public R selectByPopular(int pageNum,int pageSize,String activityId ){
        List<ActivityBase> payActivityVOS = activityService.selectByPopular(1,pageNum,pageSize,activityId);
		PageInfo<ActivityBase> payActivityVOPageInfo = new PageInfo<>(payActivityVOS);
        return R.ok().put("data",payActivityVOS).put("total",payActivityVOPageInfo.getTotal());
    }
    
	@GetMapping("/qrCode")
    public R qrCode(String activityId, String userId) {
    	Assert.notEmpty(activityId, "activityId不能为空");
    	String fileName = activityId + ".jpg";
    	if(StringUtils.isNotBlank(userId)) {
    		fileName = userId + fileName;
    	}
        this.createQrCode(activityId, fileName, userId);
        
        return R.ok().put("data", uploadUrl + fileName);
    }
    
	/**
	 * 生成所有活动的二维码, 测试使用
	 * @author Tan Ling
	 * @date 2019年4月8日 下午2:34:28
	 * @return
	 */
	@GetMapping("/createAllQRCode")
	public R createAllQRCode() {
		List<String> activityIdList = activityService.queryAllActivityId();
		if(activityIdList != null && !activityIdList.isEmpty()) {
			for(String activityId: activityIdList) {
				this.createQrCode(activityId, activityId + ".jpg", null);
			}
		}
		
		return R.success();
	}
	
	/**
	 * 生成二维码
	 * @author Tan Ling
	 * @date 2019年4月8日 下午2:33:20
	 * @param activityId
	 * @param fileName
	 */
    @SuppressWarnings("deprecation")
	private void createQrCode(String activityId, String fileName, String userId) {
    	String targetUrl = String.format(ACTIVITY_DETAIL_URL, activityId, "empty");
    	if(StringUtils.isNotBlank(userId)) {
    		targetUrl += "&userId=" + userId;
    	}
    	targetUrl = domain + targetUrl;
    	targetUrl = String.format(SHARE_DETAIL_URL, domain, URLEncoder.encode(targetUrl));
        try {
			QRCodeUtil.encode(targetUrl, fileName, uploadPath + "logo.png", uploadPath, true);
		} catch (Exception e) {
			e.printStackTrace();
		}
    }

    /**
     * 获取分享短链接
     * @author Tan Ling
     * @date 2019年5月15日 下午4:36:21
     * @param activityId
     * @param userId
     * @return
     */
    @GetMapping("/getShortUrl")
    public R getShortUrl(@RequestParam(value = "activityId") String activityId, @RequestParam(value = "userId", defaultValue = "") String userId) {
    	Assert.notEmpty(activityId, "活动ID不能为空");
    	
    	String targetUrl = domain + "/wechat/activity/shareDetail?activityId=" + activityId + "&userId=" + userId;
    	
    	JSONObject josn = wechatUtil.long2Short(targetUrl);
    	
    	return R.ok().put("data", josn);
    }
    
    /**
     * 查询秒杀活动
     * @author Tan Ling
     * @date 2019年7月29日 上午10:09:35
     * @param pageNum
     * @param pageSize
     * @return
     */
    @GetMapping("/querySecondKillActivity")
    public Result<List<SecondKillActivity>> querySecondKillActivity(int pageNum, int pageSize, @RequestParam(value = "locationId", required = false) String locationId) {
    	PageHelper.startPage(pageNum, pageSize);
    	List<SecondKillActivity> list = activityService.querySecondKillActivity();
    	if(list != null && !list.isEmpty()) {
    		for(SecondKillActivity item: list) {
    			if(item.getStartTime() == null) {
    				continue;
    			}
    			// 当前在秒杀时间内的活动
    			if(item.getStartTime().getTime() < new Date().getTime()) {
    				if(item.getEndTime() != null) {
        				item.setCountdown((item.getEndTime().getTime() - new Date().getTime()) / 1000);
        			} else {
        				item.setCountdown(-1L);
        			}
        			// 封面图 
        			String[] images = item.getCoverId().split(",");
        			if(images.length > 0) {
        				item.setCoverImg(images.length > 0 ? images[0]: "");
        			}
    			} else {
    				// 当前不在秒杀时间内的活动
    				if(item.getStartTime() != null) {
    					item.setCountdown((item.getStartTime().getTime() - new Date().getTime()) / 1000);
        			} else {
        				item.setCountdown(-1L);
        			}
        			// 封面图 
        			String[] images = item.getCoverId().split(",");
        			if(images.length > 0) {
        				item.setCoverImg(images.length > 0 ? images[0]: "");
        			}
    			}
    		}
    	}
    	
    	return new Result<>(list).total(new PageInfo<SecondKillActivity>(list).getTotal());
    }

    /**
     * @MethodName: queryPreferentialActivities
     * @Description: 查询优惠活动列表
     * @Param: [locationId]
     * @Return: com.infox.common.utils.response.Result<java.util.List<com.infox.tourism.entity.vo.activity.ActivityBase>>
     * @Author: reco
     * @Date: 2019/8/26 17:19
    */
    @GetMapping("/queryPreferentialActivities")
    public Result<List<ActivityBase>> queryPreferentialActivities(@RequestParam(value = "locationId", required = false) String locationId){
		List<ActivityBase> list = activityService.queryPreferentialActivities(locationId);
    	return new Result<>(list);
	}

}
