package com.infox.tourism.service;

import com.infox.tourism.entity.VipOpenRecordEntity;

import java.util.List;

/**
 * 
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-12-13 14:28:51
 */
public interface VipOpenRecordService {

    /**
    * 查询分页
    * @param pageNum 下一页
     * @param pageSize 显示的长度
     * @param search 搜索
    * @return
    */
    List<VipOpenRecordEntity> queryPage(int pageNum, int pageSize, String search);
}

