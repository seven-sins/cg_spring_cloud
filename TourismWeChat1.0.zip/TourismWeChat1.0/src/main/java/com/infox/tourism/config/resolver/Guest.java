package com.infox.tourism.config.resolver;

import com.infox.tourism.entity.UserInfoEntity;

public class Guest extends UserInfoEntity {

	private static final long serialVersionUID = 1L;

}
