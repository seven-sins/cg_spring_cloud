package com.infox.tourism.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infox.tourism.dao.LineDurationDao;
import com.infox.tourism.entity.vo.lineVO.LineDurationVO;
import com.infox.tourism.service.LineDurationService;

/**
 * 路线时长表
 * @author Tan Ling
 * @date 2019年1月18日 上午11:11:08
 */
@Service
public class LineDurationServiceImpl implements LineDurationService {

    @Autowired
    private LineDurationDao lineDurationDao;

    @Override
    public List<LineDurationVO> selectTop6LineDuration() {
    	return lineDurationDao.selectTop6LineDuration();
    }
    
}
