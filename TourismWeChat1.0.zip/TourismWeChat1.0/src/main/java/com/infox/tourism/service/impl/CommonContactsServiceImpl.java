package com.infox.tourism.service.impl;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infox.common.base.impl.BaseServiceImpl;
import com.infox.common.exception.CustomException;
import com.infox.common.utils.Assert;
import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.dao.CommonContactsDao;
import com.infox.tourism.entity.CommonContacts;
import com.infox.tourism.service.CommonContactsService;
import com.infox.tourism.util.UUIDUtil;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 常用联系人
 * @author Tan Ling
 * 2018年12月5日 下午3:53:47
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class CommonContactsServiceImpl extends BaseServiceImpl<CommonContacts> implements CommonContactsService {

	@Autowired
	CommonContactsDao commonContactsDao;
	
	@Resource
	public void setBaseMapper(BaseMapper<CommonContacts> commonContactsDao) {
		this.baseMapper = commonContactsDao;
	}
	
	@Override
	public void insert(CommonContacts commonContacts) {
		commonContacts.setCommonContactsId(UUIDUtil.create());
		commonContacts.setCreateTime(new Date());
		commonContactsDao.insert(commonContacts);
	}

	@Override
	public void insert(AuthUser user, List<CommonContacts> list) {
		commonContactsDao.deleteByUserId(user.getUserId());
		for(CommonContacts item: list) {
			item.setUserId(user.getUserId());
			item.setCommonContactsId(UUIDUtil.create());
			item.setCreateTime(new Date());
			commonContactsDao.insert(item);
		}
	}

	@Override
	public void deleteByContactsId(String commonContactsId) {
		commonContactsDao.deleteByContactsId(commonContactsId);		
	}

	@Override
	public List<CommonContacts> findInId(String userId, String[] ids) {
		return commonContactsDao.findInId(userId, ids);
	}

	@Override
	public void updateByContactId(CommonContacts commonContacts) {
		commonContactsDao.updateByContactId(commonContacts);
	}

	@Override
	public CommonContacts getByIdCard(String userId, String idCard) {
		return commonContactsDao.getByIdCard(userId, idCard);
	}

	@Override
	public void checkIdCard(String userId, String idCard, String contactId, Integer certificateType) {
		if(StringUtils.isBlank(idCard)) {
			return;
		}
		String errorMsg = certificateType != null && certificateType == 1? "身份证号已存在": "护照已存在";
		CommonContacts commonContacts = commonContactsDao.getByIdCard(userId, idCard);
		// contactId不为空时, 当前是修改操作
		if(StringUtils.isNotBlank(contactId)) {
			if(commonContacts == null) {
				return;
			}
			Assert.isTrue(contactId.equals(commonContacts.getCommonContactsId()), errorMsg);
		} else {
			if(commonContacts != null) {
				throw new CustomException(errorMsg);
			}
		}
	}
}
