package com.infox.tourism.util;

import org.springframework.web.multipart.MultipartFile;

public class FileUtil {

    public static boolean checkFile(String fileName) {
        //设置允许上传文件类型
        String suffixList = ".doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.gif,.jpg,.rar,.zip,.png";

        if (suffixList.contains(fileName.trim().toLowerCase())) {
            return true;
        }
        return false;
    }


    public static boolean checkImage(String fileName) {
        //设置允许上传图片类型
        String suffixList = " .gif,.jpg,.jpg,.png";

        if (suffixList.contains(fileName.trim().toLowerCase())) {
            return true;
        }
        return false;
    }

    /**
     * 获取文件格式
     */
    public static String getFileSuffixName(String fileName){
        return fileName.substring(fileName.indexOf("."));
    }

    /**
     * 获取文件名称
     * @param file  文件对象
     * @return
     */
    public static String getFileName(MultipartFile file){
        return   file.getOriginalFilename().replace(" ","");
    }



}
