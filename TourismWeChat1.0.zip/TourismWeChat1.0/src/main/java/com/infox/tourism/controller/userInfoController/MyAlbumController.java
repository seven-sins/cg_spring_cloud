package com.infox.tourism.controller.userInfoController;

import java.io.File;
import java.io.IOException;
import java.net.UnknownHostException;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageInfo;
import com.infox.common.qiniu.QiniuYunUtil;
import com.infox.common.utils.Assert;
import com.infox.common.utils.response.Result;
import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.entity.PersonalPhotoAlbumEntity;
import com.infox.tourism.entity.PhotoEntity;
import com.infox.tourism.entity.vo.albumVO.AlbumVo;
import com.infox.tourism.service.AlbumService;
import com.infox.tourism.service.PhotoService;
import com.infox.tourism.util.DateUtil;
import com.infox.tourism.util.R;
import com.infox.tourism.util.UUIDUtil;
import com.infox.tourism.util.fileUtils.FileNameUtils;
import com.infox.tourism.util.fileUtils.ThumbnailService;
import com.infox.tourism.util.fileUtils.UploadImgUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

/**
 * @Author: cenjinxing
 * @Date: Created in 2018/12/6 10:47
 **/
@RestController
@RequestMapping("/album")
@Api(description = "我的_增加相册接口", tags = {"albumController"})
public class MyAlbumController {

    /**
     * 相册
     */
    @Autowired
    private AlbumService albumService;

    /**
     * 照片
     */
    @Autowired
    private PhotoService photoService;

    @Autowired
    private ThumbnailService thumbnailService;

//
//    private static String UPLOAD_PATH;
//
//    private static String UPLOAD_URL;

    // 读取图片的路径
//    public static final String ROOT = "F://temp//";
//    public static final String ROOT = "/data/wwwroot/btzservice/temp/";
    @Value("${website.domain}")
    private String domain;
    @Value("${upload.path}")
    private String uploadPath;
    @Value("${upload.url}")
    private String uploadUrl;
    private final ResourceLoader resourceLoader;

    public MyAlbumController(ResourceLoader resourceLoader) {
        this.resourceLoader = resourceLoader;
    }

    @ApiOperation(value = "相册列表", notes = "相册列表(用于数据同步)", response = AlbumVo.class)
    @GetMapping("/albumList")
    public Result<?> albumList(@ApiIgnore AuthUser authUser, int pageNum, int pageSize) {
		// 图片总数
		List<AlbumVo> list = albumService.queryPage(pageNum, pageSize, authUser.getUserId());
		if (list != null && !list.isEmpty()) {
			for (AlbumVo albumVo : list) {
				// 图片总数
				albumVo.setPhotoTotal(photoService.total(albumVo.getAlbumId()));
			}
		}

		return new Result<>(list).total(new PageInfo<AlbumVo>(list).getTotal());
	}

    @ApiOperation(value = "添加相册", response = AlbumVo.class)
    @PostMapping("/addAlbum")
    public R addAlbum(@ApiIgnore AuthUser authUser, @RequestBody AlbumVo albumVO) {
        if (albumVO == null){
            return R.error(400, "albumVO不能为空!");
        }
        boolean b = albumService.addAlbum(authUser.getUserId(), albumVO);
        if (b == false) {
            return R.error(6006, "相册名称已存在!");
        }

        return R.ok().put("data", b);
    }

    @ApiOperation(value = "根据相册id查询相册信息", response = PersonalPhotoAlbumEntity.class)
    @GetMapping("/selectByAlbumId")
    public R selectByAlbumId(String albumId) {

        if (albumId == null){
            return R.error(400,"相册id不能为空");
        }

        PersonalPhotoAlbumEntity entity = albumService.selectByAlbumId(albumId);

        return R.ok().put("data", entity);
    }


    @ApiOperation("修改")
    @PostMapping("/update")
    public R update(@RequestBody AlbumVo albumVO) {

        if (albumVO == null){
            return R.error(400, "albumVO不能为空!");
        }

        boolean b = albumService.updateByAlbumId(albumVO);

        return R.ok().put("data", b);
    }


    @ApiOperation(value = "照片列表", response = PhotoEntity.class)
    @PostMapping("/photoList")
    public R photoList(@RequestBody JSONObject jsonObject) {

        int pageNum = Integer.parseInt(jsonObject.get("pageNum").toString());
        int pageSize = Integer.parseInt(jsonObject.get("pageSize").toString());
        String albumId = jsonObject.get("albumId").toString();


        List<PhotoEntity> list = photoService.queryByAlbumId(albumId, pageNum, pageSize);

        PageInfo<PhotoEntity> pageInfo = new PageInfo<>(list);

        PersonalPhotoAlbumEntity personalPhotoAlbumEntity = albumService.selectByAlbumId(albumId);

        Map<Object, Object> map = new HashMap<>();

        map.put("title", personalPhotoAlbumEntity.getPpaName());
        map.put("list", list);
        map.put("total", pageInfo.getTotal());

        return R.ok().put("data", map);
    }

    @ApiOperation(value = "添加照片", response = PhotoEntity.class)
    @PostMapping("/addPhoto")
    public Result<PhotoEntity> addPhoto(@Valid @RequestBody PhotoEntity photoEntity) {
        photoEntity.setIsDelete(1);
        photoEntity.setPhotoId(UUIDUtil.create());
        photoEntity.setCreateTime(DateUtil.getYYYYMMDDHHMMSS());
        photoEntity.setUserId("admin");
        photoService.insert(photoEntity);

        return new Result<>(photoEntity);
    }


    @ApiOperation(value = "上传相册封面图", response = PersonalPhotoAlbumEntity.class)
    @PostMapping("/uploadAlbumImage")
    public R uploadAlbumImage(@RequestParam("file") MultipartFile file, RedirectAttributes redirectAttributes, HttpServletRequest request) throws UnknownHostException {
        UploadImgUtils.initPath(uploadPath, uploadUrl);
        System.out.println(request.getContextPath());
        System.out.println(request.getPathInfo());
        System.out.println(request.getHeader("WL-Proxy-Client-IP"));

        System.out.println(request.getParameter("member"));

        // 获取IP地址
        // String host = InetAddress.getLocalHost().getHostAddress();

//        System.out.println(InetAddress.getAllByName().);

        // 得到上传时的文件名
        String uploadFileName = file.getOriginalFilename();

        // 获取文件的后缀
        String fileSuffixName = uploadFileName.substring(uploadFileName.lastIndexOf("."));

        // 生成新文件名称
        String newFileName = FileNameUtils.getFileName(uploadFileName);

        String imgPath = uploadPath + newFileName;

        thumbnailService.thumbnail(file,uploadPath,uploadPath,newFileName,fileSuffixName);

        File file1 = new File(imgPath);

        System.out.println(imgPath + "文件名称" + fileSuffixName + "文件后缀");

        // 保存文件
        if (!file.isEmpty()) {
            try {
                file.transferTo(file1);
                redirectAttributes.addFlashAttribute("message",
                        "You successfully uploaded" + file.getOriginalFilename() + "!");
            } catch (IOException e) {
                redirectAttributes.addFlashAttribute("message",
                        "Failed to upload" + file.getOriginalFilename() + "=>" + e.getMessage());
            }
        } else {
            redirectAttributes.addFlashAttribute("message",
                    "Failed to upload" + file.getOriginalFilename() + "because it was empty");
        }

        System.out.println(newFileName);
        
        /**
     	 * 同步到七牛云
         */
        QiniuYunUtil.uploadToQiniu(imgPath, file1.getName());
        // http://common.gzbzt.com
        // http://ppu5dov7s.bkt.clouddn.com
        String imageUrl = "http://common.gzbzt.com/common/" + file1.getName();

        return R.ok().put("path", imageUrl).put("filename", file1.getName());
    }

    @ApiOperation("读取图片")
    @RequestMapping(method = RequestMethod.GET, value = "/{filename:.+}", produces = "image/jpg")
    @ResponseBody
    public ResponseEntity<?> getFile(@PathVariable String filename) {

        try {
            return ResponseEntity.ok(resourceLoader.getResource("file:" + Paths.get(uploadUrl, filename).toString()));
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @ApiOperation(value = "删除相册封面图", response = PersonalPhotoAlbumEntity.class)
    @PostMapping("/deleteAlbumImage")
    public R deleteAlbumImage(@PathVariable String path) {

        return R.ok().put("data", true);
    }

    @ApiOperation(value = "删除相册", response = PersonalPhotoAlbumEntity.class)
    @PostMapping("/deleteAlbum")
    public R deleteAlbum(@RequestBody Map<String, String> map) {
        String albumId = map.get("albumId");

        if (albumId == null){
            return R.error(400,"相册id不能为空");
        }

        boolean b = albumService.deleteByAlbumId(albumId);

        if (b == false) {
            return R.error(400, "删除相册有误");
        }

        return R.ok().put("data", b);
    }


    @ApiOperation(value = "删除照片", response = PhotoEntity.class)
    @PostMapping("/deletePhotoImage")
    public R deletePhotoImage(@RequestBody Map<String, Object> map) {
        Assert.notNull(map.get("photoId"), "不能为空");

        String photoId = map.get("photoId").toString();

        boolean b = photoService.deleteByPhotoId(null, photoId);

        return R.ok().put("data", b);
    }

    @ApiOperation(value = "上传多张图片")
    @PostMapping("/uploadPhotoImage")
    //requestParam要写才知道是前台的那个数组
    public R uploadPhotoImage(MultipartFile[] file, HttpServletRequest request) {
    	UploadImgUtils.initPath(uploadPath, uploadUrl);
        List<MultipartFile> files = ((MultipartHttpServletRequest) request).getFiles("file");

        System.out.println("多少个文件------" + file.length);

        System.out.println("多少个文件------" + files.size());
        R r = UploadImgUtils.filesUpload(file, request);

        return R.ok().put("data", r);
    }


}
