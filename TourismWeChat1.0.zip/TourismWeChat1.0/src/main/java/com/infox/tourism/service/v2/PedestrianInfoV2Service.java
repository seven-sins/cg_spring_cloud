package com.infox.tourism.service.v2;

import java.math.BigDecimal;
/**
 * 
 * @author yuanfang
 * 2019年5月14日 上午10:50:50
 */
public interface PedestrianInfoV2Service {
	
	/**
	 *总分销金额 
	 */
	BigDecimal queryByDistributionUserId(String distributionUserId);
	
	/**
	 * 
	 */
	BigDecimal withdrawByDistributionUserId(String distributionUserId);
}
