package com.infox.tourism.service.v2;

import java.util.List;

import com.infox.tourism.entity.ActivityInfoEntity;
/**
 * 
 * @author yuanfang
 * 2019年5月14日 上午10:50:39
 */
public interface ActivityV2Service {
	/**
	 * 领队带领的活动
	 */
	List<ActivityInfoEntity> queryByLeaderId(String leaderId);
	
	/**
	 * 领队活动总数
	 */
	int queryCountByUserId(String userId);
}
