package com.infox.tourism.service.v2;

import java.math.BigDecimal;
/**
 * 
 * @author yuanfang
 * 2019年5月14日 上午10:50:45
 */
public interface ExceptionalRecordV2Service {

	/**
	 * 打赏金额总数
	 */
	BigDecimal queryNumErMoney(String userId);
}
