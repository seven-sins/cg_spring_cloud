package com.infox.tourism.controller.userInfoController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.entity.VipOpenRecordEntity;
import com.infox.tourism.entity.vo.UserVO.VipVO;
import com.infox.tourism.service.VipRecordService;
import com.infox.tourism.util.R;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

/**
 * 开通超级vip
 * @Author: cenjinxing
 * @Date: Created in 2018/12/13 11:47
 **/
@RestController
@RequestMapping("/superVip")
@Api(description = "开通超级vip",tags = {"OpenSuperVipController"})
public class OpenSuperVipController {

    @Autowired
    private VipRecordService vipRecordService;

    /**
     * 开通超级vip
     */
    @ApiOperation(value = "开通超级vip",response = VipVO.class)
    @PostMapping("/addSuuperVip")
    public R addSuuperVip(@ApiIgnore AuthUser authUser, @RequestBody VipVO vipVO){
        VipOpenRecordEntity insert = vipRecordService.insert(authUser.getUserId(), vipVO);

        if (insert == null){
            return R.error(400,"开通会员失败，请联系管理员");
        }

        return R.ok().put("data",insert);
    }

}
