package com.infox.tourism.service;

import com.infox.common.base.BaseService;
import com.infox.tourism.entity.DurationScope;

/**
 * 活动时长范围
 * @author Tan Ling
 * @date 2019年1月24日 上午9:38:31
 */
public interface DurationScopeService extends BaseService<DurationScope> {

}
