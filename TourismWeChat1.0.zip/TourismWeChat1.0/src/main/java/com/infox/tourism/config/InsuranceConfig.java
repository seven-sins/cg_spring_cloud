package com.infox.tourism.config;

public class InsuranceConfig {

    public static String partnerId = "1003525";

    public static String devKey = "TNZWQ2YzVkNGNiOTl1003525";

    public static String devUrl = "http://tuneapi.qixin18.com";

    public static String proKey = "ONYjc4M2M5YmQzYzI1003525";

    public static String proUrl = "http://api.qixin18.com";

    public static String ProductListAPI = "/border/productList";

    public static String SimpleInsureAPI = "/api/simpleInsure";

    public static String SimpleTrialAPI = "/api/simpleTrial";

    public static String LocalPayAPI = "/api/localPay";

    public static String ProductDestinationAPI = "/border/productDestination";

    public static String SurrenderPolicyAPI = "/api/surrenderPolicy";
}