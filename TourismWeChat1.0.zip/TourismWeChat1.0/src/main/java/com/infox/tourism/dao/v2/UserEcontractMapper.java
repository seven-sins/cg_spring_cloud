package com.infox.tourism.dao.v2;

import org.apache.ibatis.annotations.Mapper;

import com.infox.tourism.entity.v2.econtract.UserEcontract;

import tk.mybatis.mapper.common.BaseMapper;

@Mapper
public interface UserEcontractMapper extends BaseMapper<UserEcontract> {

}
