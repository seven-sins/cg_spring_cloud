package com.infox.tourism.dao;

import java.math.BigDecimal;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.infox.tourism.entity.ActivityBargainRecordEntity;
import com.infox.tourism.entity.vo.bargain.ActivityBargainRecordVo;
import com.infox.tourism.entity.vo.share.ToShareVO;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 砍价优惠活动记录
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-21 15:17:46
 */
@Mapper
public interface ActivityBargainRecordDao extends BaseMapper<ActivityBargainRecordEntity> {

	/**
	 * 查询分页
	 * 
	 * @return
	 */
	List<ActivityBargainRecordEntity> queryPage();

	/**
	 * 获取用户当前活动已砍掉的价格
	 * 
	 * @param groupId
	 * @param activityId
	 * @return
	 */
	BigDecimal getActivityTotalBargainPrice(@Param("groupId") String groupId, @Param("activityId") String activityId);

	/**
	 * 查询用户当前活动帮砍价格的用户列表
	 * 
	 * @param groupId
	 * @param activityId
	 * @return
	 */
	List<ActivityBargainRecordVo> findActivityBargainUserList(@Param("groupId") String groupId,
			@Param("activityId") String activityId);

	/**
	 * 查询当前用户针对当前活动帮xx用户的砍价信息
	 * 
	 * @param groupId
	 * @param activityId
	 * @param assistorUserId
	 * @return
	 */
	List<ActivityBargainRecordEntity> findCurrentUserAndActivityBargainPrice(@Param("groupId") String groupId,
			@Param("activityId") String activityId, @Param("assistorUserId") String assistorUserId);

	/**
	 * 查询当前帮砍价用户数量
	 * 
	 * @param groupId
	 * @param activityId
	 * @return
	 */
	Integer getActivityBargainUserCount(@Param("groupId") String groupId, @Param("activityId") String activityId);

	/**
	 * 查询当前用户针对当前活动发起的砍价信息
	 * 
	 * @param userId
	 * @param activityId
	 * @return
	 */
	ActivityBargainRecordEntity getCurrentUserBargainInfo(@Param("userId") String userId,
			@Param("activityId") String activityId);

	ActivityBargainRecordEntity getBargainInfoByGroupId(@Param("activityId") String activityId,
			@Param("groupId") String groupId);

	/**
	 * 根据主键更新
	 * 
	 * @param activityBargainRecordEntity
	 */
	void updateByBargainId(ActivityBargainRecordEntity activityBargainRecordEntity);

	/**
	 * 查询待分享的砍价信息
	 * 
	 * @author Tan Ling
	 * @date 2019年2月21日 上午11:30:42
	 * @param userId
	 * @return
	 */
	List<ToShareVO> selectShareList(@Param("userId") String userId);
}
