package com.infox.tourism.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infox.tourism.dao.LineLevelDao;
import com.infox.tourism.entity.vo.lineVO.LineLevelVO;
import com.infox.tourism.service.LineLevelService;


/**
 * 路线等级表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-06 17:23:31
 */
@Service("lineLevelService")
public class LineLevelServiceImpl implements LineLevelService {


    @Autowired
    private LineLevelDao lineLevelDao;

    @Override
    public List<LineLevelVO> selectTop5LineLevel() {
        List<LineLevelVO> list = lineLevelDao.selectTop5LineLevel();
        return list;
    }
}
