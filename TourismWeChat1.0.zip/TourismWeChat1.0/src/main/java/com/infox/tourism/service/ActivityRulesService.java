package com.infox.tourism.service;

import java.util.List;

import com.infox.common.base.BaseService;
import com.infox.tourism.entity.ActivityRulesEntity;

/**
 * 活动规则表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-15 10:36:29
 */
public interface ActivityRulesService extends BaseService<ActivityRulesEntity> {

	/**
	 * 查询分页
	 * 
	 * @param pageNum  下一页
	 * @param pageSize 显示的长度
	 * @param search   搜索
	 * @return
	 */
	List<ActivityRulesEntity> queryPage(int pageNum, int pageSize, String search);

	/**
	 * 根据活动ID获取活动规则
	 * 
	 * @param activityId
	 * @return
	 */
	ActivityRulesEntity selectByActivityId(String activityId);
}
