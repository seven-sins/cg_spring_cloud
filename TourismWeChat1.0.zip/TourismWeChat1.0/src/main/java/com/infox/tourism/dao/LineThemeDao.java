package com.infox.tourism.dao;

import com.infox.tourism.entity.LineThemeEntity;
import com.infox.tourism.entity.vo.lineVO.LineThemeVO;
import org.apache.ibatis.annotations.Mapper;
import tk.mybatis.mapper.common.BaseMapper;

import java.util.List;

/**
 * 路线主题表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-06 17:10:28
 */
@Mapper
public interface LineThemeDao extends BaseMapper<LineThemeEntity> {

    List<LineThemeVO> selectAllLineTheme();

    LineThemeVO selectTopOne();
    /**
     * 查询前3个活动主题
     * @author Tan Ling
     * @date 2019年1月30日 下午4:52:39
     * @return
     */
    List<LineThemeVO> selectTop3();
    /**
     * 只查询非特定主题(类似本周活动、下周活动）
     * @author Tan Ling
     * @date 2019年7月26日 下午3:06:59
     * @return
     */
    List<LineThemeVO> selectTop8();
}
