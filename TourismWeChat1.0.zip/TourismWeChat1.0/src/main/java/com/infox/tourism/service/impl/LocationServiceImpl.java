package com.infox.tourism.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infox.tourism.dao.LocationDao;
import com.infox.tourism.entity.SbLocationEntity;
import com.infox.tourism.entity.vo.locationVO.SBLocationVO;
import com.infox.tourism.service.LocationService;


/**
 * 全球地区表
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-06 17:23:31
 */
@Service
public class LocationServiceImpl implements LocationService {
    /**
    * sbLocationDao层
    * @param params
    * @return
    */
    @Autowired
    private LocationDao sbLocationDao;

    @Override
    public SbLocationEntity selectByValueForWeChat(String adcode) {
        SbLocationEntity location = sbLocationDao.selectByValueForWeChat(adcode);
        if(location.getSerial().split("\\.").length>4){
            location = sbLocationDao.selectById(location.getParentId());
        }
        
        return location;
    }

    @Override
    public List<SBLocationVO> selectCoverCity(String locationId) {
    	return sbLocationDao.selectCoverCity(locationId);
    }


}
