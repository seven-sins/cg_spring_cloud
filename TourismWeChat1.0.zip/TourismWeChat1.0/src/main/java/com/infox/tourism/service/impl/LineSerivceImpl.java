package com.infox.tourism.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infox.common.utils.redis.RedisConstant;
import com.infox.common.utils.redis.RedisService;
import com.infox.tourism.dao.LineDao;
import com.infox.tourism.dao.OrderInfoDao;
import com.infox.tourism.dao.activity.ActivityMapper;
import com.infox.tourism.dao.activity.ViewRecordMapper;
import com.infox.tourism.entity.vo.lineVO.LineDurationCache;
import com.infox.tourism.entity.vo.lineVO.LineVo;
import com.infox.tourism.service.LineService;
import com.infox.tourism.util.ImgUtil;

/**
 * @Description TODO
 * @Author Hale
 * @Date 2018/12/6
 */
@Service
public class LineSerivceImpl implements LineService {

    @Autowired
    private LineDao lineDao;
    @Autowired
    private RedisService redisService;
    @Autowired
    OrderInfoDao orderInfoDao;
    @Autowired
    ViewRecordMapper viewRecordMapper;
    @Autowired
    ActivityMapper activityMapper;

    @Override
    public HashMap<String, Object> selectLineCoverImg(String lineId) {
        HashMap<String,Object> result= new HashMap<>();
        Map<String, String> map = lineDao.selectCoverImgByLineId(lineId);
        String[] imgList = map.get("l_url").split(",");
        Integer count = lineDao.selectImgCountByLineId(lineId);
        result.put("coverList",imgList);
        result.put("count",count);
        return result;
    }

    @SuppressWarnings("rawtypes")
	@Override
    public List selectImgListByLineId(String lineId) {
        List list = lineDao.selectImgListByLineId(lineId);
        return list;
    }

    @SuppressWarnings("unchecked")
	@Override
	public List<LineDurationCache> selectAllLineDurationTime() {
		List<LineDurationCache> list = (List<LineDurationCache>) redisService.get(RedisConstant.LINE_DURATION_TIME_CACHE_PREFIX);
		if(list != null) {
			return list;
		}
		list = lineDao.selectAllLineDurationTime();
		if(list != null) {
			/**
			 * 只缓存1分钟
			 */
			redisService.add(RedisConstant.LINE_DURATION_TIME_CACHE_PREFIX, list, 1);
		}
		
		return list;
	}

	@Override
	public List<LineVo> selectRecommendLine(String companyId) {
		List<LineVo> list = lineDao.selectRecommendLine(companyId);
		if(list == null || list.isEmpty()) {
			return list;
		}
		for(LineVo item: list) {
			// 访问次数
			item.setViewNum(viewRecordMapper.queryCountByLineId(item.getLineId()));
			// 报名人数
			item.setBeenPeopleNum(item.getBeenPeopleNum() == null ? 0: item.getBeenPeopleNum());
			item.setJoinNum(orderInfoDao.queryPedestrianNumByLineId(item.getLineId()));
			item.setJoinNum(item.getJoinNum() + item.getBeenPeopleNum());
			// 当前线路最新一期的活动ID
			item.setActivityId(activityMapper.getRecentlyActivityId(item.getLineId(), item.getCompanyId()));
			if(StringUtils.isNotBlank(item.getDisplayUrl())) {
				item.setConverImg(ImgUtil.hight(item.getDisplayUrl()));
			} else {
				String[] imgs = item.getLUrl().split(",");
				if(imgs != null && imgs.length > 0) {
					item.setConverImg(ImgUtil.hight(imgs[0]));
				}
			}
		}
		
		return list;
	}
}
