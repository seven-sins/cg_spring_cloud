package com.infox.tourism.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.infox.tourism.dao.AlbumDao;
import com.infox.tourism.dao.PhotoDao;
import com.infox.tourism.entity.PersonalPhotoAlbumEntity;
import com.infox.tourism.entity.PhotoEntity;
import com.infox.tourism.entity.vo.albumVO.AlbumVo;
import com.infox.tourism.service.AlbumService;
import com.infox.tourism.util.DateUtil;
import com.infox.tourism.util.UUIDUtil;

/**
 * 相册
 * @Author: cenjinxing
 * @Date: Created in 2018/12/6 11:01
 **/
@Service("albumService")
public class AlbumServiceImpl implements AlbumService{
   @Autowired
   private AlbumDao albumDao;
    @Autowired
   private PhotoDao photoDao;
    /**
     * 添加相册
     * @param albumVO
     * @return
     */
    @Override
    public boolean addAlbum(String userId,AlbumVo albumVO) {
        List<AlbumVo> list = albumDao.queryPage(userId);
        for (AlbumVo albumVo : list) {
            if (albumVo.getPpaName().equals(albumVO.getPpaName())){
                return false;
            }
        }

        PersonalPhotoAlbumEntity personalPhotoAlbumEntity = new PersonalPhotoAlbumEntity();
        BeanUtils.copyProperties(albumVO,personalPhotoAlbumEntity);
        personalPhotoAlbumEntity.setUserId(userId);
        personalPhotoAlbumEntity.setAlbumId(UUIDUtil.create());
        personalPhotoAlbumEntity.setIsDelete("1");
        personalPhotoAlbumEntity.setCreateTime(new Date());
        personalPhotoAlbumEntity.setCreateBy(userId);
        int insert = albumDao.insert(personalPhotoAlbumEntity);

        //保存相册成功
        if (insert > 0){
            if (albumVO.getpUrl() != null && albumVO.getpUrl() != ""){
                String[] split = albumVO.getpUrl().split(",");
                for (int i = 0; i < split.length; i++) {
                    PhotoEntity photoEntity = new PhotoEntity();
                    photoEntity.setPUrl(split[i]);
                    photoEntity.setPhotoId(UUIDUtil.create());
                    photoEntity.setIsDelete(1);
                    photoEntity.setAlbumId(personalPhotoAlbumEntity.getAlbumId());
                    photoEntity.setCreateTime(DateUtil.getYYYYMMDDHHMMSS());
                    photoDao.insert(photoEntity);
                }
            }
        }

        return insert > 0;
    }

    /**
     * 查询相册id查询
     * @return
     */
    @Override
    public List<AlbumVo>  selectByUserId(String userId) {
        return albumDao.selectByUserId(userId);
    }

    /**
     * 查询相册列表
     * @return
     */
    @Override
    public List<AlbumVo> queryPage(Integer pageNum, Integer pageSize,String userId) {
    	// 分页
        PageHelper.startPage(pageNum, pageSize);
        return albumDao.queryPage(userId);
    }

    /**
     * 删除相册
     */
    @Override
    public boolean deleteByAlbumId(String albumId){

        List<PhotoEntity> list = photoDao.queryByAlbumId(albumId);

        for (PhotoEntity p : list) {
            p.setIsDelete(0);
            photoDao.updateByPhotoId(p);
        }

        PersonalPhotoAlbumEntity personalPhotoAlbumEntity = albumDao.selectByAlbumId(albumId);

        if (personalPhotoAlbumEntity == null){
            return false;
        }

        personalPhotoAlbumEntity.setIsDelete("0");

        boolean b = albumDao.deleteByAlbumId(personalPhotoAlbumEntity);

        return b;
    }

    /**
     * 跟相册id查询信息
     * @param albumId
     * @return
     */
    @Override
    public PersonalPhotoAlbumEntity selectByAlbumId(String albumId){
        return albumDao.selectByAlbumId(albumId);
    }

    /**
     * 更新
     * @param albumVO
     * @return
     */
    @Override
    public boolean updateByAlbumId(AlbumVo albumVO) {
        boolean b;

        PersonalPhotoAlbumEntity personalPhotoAlbumEntity = new PersonalPhotoAlbumEntity();
        BeanUtils.copyProperties(albumVO,personalPhotoAlbumEntity);
        personalPhotoAlbumEntity.setUpdateBy("");
        personalPhotoAlbumEntity.setUpdateTime(new Date());
        b = albumDao.updateByAlbumId(personalPhotoAlbumEntity);

        //保存相册成功
        if (b == true){

            if (albumVO.getpUrl() != null && albumVO.getpUrl() != ""){
                String[] split = albumVO.getpUrl().split(",");
                for (int i = 0; i < split.length; i++) {
                    PhotoEntity photoEntity = new PhotoEntity();
                    photoEntity.setPUrl(split[i]);
                    photoEntity.setPhotoId(UUIDUtil.create());
                    photoEntity.setIsDelete(1);
                    photoEntity.setAlbumId(personalPhotoAlbumEntity.getAlbumId());
                    photoEntity.setCreateTime(DateUtil.getYYYYMMDDHHMMSS());
                    photoDao.insert(photoEntity);
                }
                return b;
            }
            return b;
        }

        return b;
    }

}
