package com.infox.tourism.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.infox.tourism.entity.ActivityCoverEntity;

import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.BaseMapper;

/**
  * 活动的封面图表
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-15 10:36:29
 */
@Mapper
public interface ActivityCoverDao extends BaseMapper<ActivityCoverEntity> {

	/**
	* 查询分页
	* @return
	*/
	List<ActivityCoverEntity> queryPage();

	List<ActivityCoverEntity> queryByCoverList(@Param("activityId") String activityId);

}
