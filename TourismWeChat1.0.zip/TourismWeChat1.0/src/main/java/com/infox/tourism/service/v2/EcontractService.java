package com.infox.tourism.service.v2;

import com.infox.common.base.BaseService;
import com.infox.tourism.entity.v2.econtract.Econtract;


public interface EcontractService extends BaseService<Econtract> {
    
}



