package com.infox.tourism.controller.travelsController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.config.resolver.Guest;
import com.infox.tourism.entity.TravelsEntity;
import com.infox.tourism.entity.vo.travelsVO.TravelsVo;
import com.infox.tourism.service.TravelsService;
import com.infox.tourism.util.R;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

/**
 * 游记表
 *
 * @author yiwei
 * @param <PageUtils>
 * @email 996358199@qq.com
 * @date 2018-11-21 19:46:05
 */
@Api(description = "游记", tags = { "TravelsController" })
@RestController
@RequestMapping("/travels")
public class TravelsController<PageUtils> {
	@Autowired
	private TravelsService travelsService;

	/**
	 * 游记 列表
	 */
	@ApiOperation(value = "游记列表", notes = "游记列表", response = TravelsVo.class)
	@GetMapping("/travelsList")
	public R list(int pageNum, int pageSize, @ApiIgnore AuthUser user) {
		PageHelper.startPage(pageNum, pageSize);
		List<TravelsVo> travelsList = travelsService.queryPage(pageNum, pageSize, user.getUserId());
		PageInfo<TravelsVo> pageInfo = new PageInfo<>(travelsList);
		return R.ok().put("data", travelsList).put("total", pageInfo.getTotal());
	}

	/**
	 * 我的游记列表
	 */
	@ApiOperation(value = "我的游记列表", notes = "我的游记列表", response = TravelsVo.class)
	@GetMapping("/myTravelsList")
	public R myTravelsList(int pageNum, int pageSize, @ApiIgnore AuthUser user) {
		PageHelper.startPage(pageNum, pageSize);
		List<TravelsVo> travelsList = travelsService.myTravelsList(pageNum, pageSize, user.getUserId());
		PageInfo<TravelsVo> pageInfo = new PageInfo<>(travelsList);
		return R.ok().put("data", travelsList).put("total", pageInfo.getTotal());
	}

	/**
	 * 游记详情
	 */
	@ApiOperation(value = "游记详情", notes = "游记详情", response = TravelsVo.class)
	@GetMapping("/getTravelsById")
	public R getTravelsById(Guest user, String travelsId) {
		TravelsVo travels = travelsService.selectById(user.getUserId(), travelsId);

		return R.ok().put("data", travels);
	}

	/**
	 * 保存
	 */
	@ApiOperation(value = "保存游记", notes = "保存游记", response = TravelsEntity.class)
	@PostMapping("/save")
	public R save(@RequestBody TravelsEntity travels, @ApiIgnore AuthUser user) {
		boolean insert = travelsService.insert(travels, user);

		return R.ok().put("data", insert);
	}

	/**
	 * 修改
	 */
	@ApiOperation(value = "修改游记", notes = "修改游记", response = TravelsEntity.class)
	@PostMapping("/update")
	public R update(@RequestBody TravelsEntity travels, @ApiIgnore AuthUser user) {
		boolean b = travelsService.updateById(travels, user);

		return R.ok().put("data", b);
	}

	/**
	 * 转发
	 */
	@ApiOperation(value = "游记转发", notes = "游记转发", response = TravelsEntity.class)
	@PostMapping("/updateRelay")
	public R updateRelay(@RequestBody TravelsEntity travels) {
		boolean b = travelsService.updateRelay(travels);

		return R.ok().put("data", b);
	}

	/**
	 * 删除
	 */
	@ApiOperation(value = "游记删除", notes = "游记删除", response = TravelsEntity.class)
	@PostMapping("/delete")
	public R delete(@RequestBody TravelsEntity travels) {
		boolean b = travelsService.deleteList(travels);

		return R.ok().put("data", b);
	}

}
