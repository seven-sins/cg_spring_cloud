package com.infox.tourism.controller.v2;

import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageInfo;
import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.entity.v2.activityadvancepayment.ActivityAdvancePayment;
import com.infox.tourism.service.v2.ActivityAdvancePaymentService;
import com.infox.tourism.util.R;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

/**
 * @author Tan Ling
 * 2019年1月7日 下午2:32:20
 */
@RestController
@Api(description = "预付款接口")
@RequestMapping("/activityAdvancePayment")
public class ActivityAdvancePaymentController {

	@Autowired
	private ActivityAdvancePaymentService ActivityAdvancePaymentService;
	
	@ApiOperation(value = "列表",response = ActivityAdvancePayment.class)
	@GetMapping("/list")
	public R list(@RequestParam("pageNum") Integer pageNum, @RequestParam("pageSize") Integer pageSize,
			ActivityAdvancePayment activityAdvancePayment) {
		List<ActivityAdvancePayment> list = ActivityAdvancePaymentService.find(pageNum, pageSize, null, activityAdvancePayment);
		
		return R.ok().put("data", list).put("total", new PageInfo<ActivityAdvancePayment>(list).getTotal());
	}
	
	@ApiOperation(value = "预付款申请")
	@PostMapping("/create")
	public R create(@Valid @RequestBody ActivityAdvancePayment activityAdvancePayment, @ApiIgnore AuthUser user) {
		ActivityAdvancePaymentService.insert(activityAdvancePayment, user);
		
		return R.success();
	}
	
	@ApiOperation(value = "修改")
	@PostMapping("/update/{activityAdvancePaymentId}")
	public R update(@PathVariable("activityAdvancePaymentId") String activityAdvancePaymentId, 
					@RequestBody ActivityAdvancePayment activityAdvancePayment, @ApiIgnore AuthUser user) {
		activityAdvancePayment.setActivityAdvancePaymentId(activityAdvancePaymentId);
		activityAdvancePayment.setUpdateBy(user.getUserId());
		activityAdvancePayment.setUpdateTime(new Date());
		
		ActivityAdvancePaymentService.updateByActivityAdvancePaymentId(activityAdvancePayment);
		
		return R.success();
	}
	
	@ApiOperation(value = "预付款详情")
	@GetMapping("/info/{activityAdvancePaymentId}")
	public R get(@PathVariable("activityAdvancePaymentId") String activityAdvancePaymentId) {
		ActivityAdvancePayment activityAdvancePayment = ActivityAdvancePaymentService.get(activityAdvancePaymentId);
		
		return R.ok().put("data", activityAdvancePayment);
	}
	
}
