package com.infox.tourism.controller.userInfoController;

import com.github.pagehelper.PageInfo;
import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.entity.CollectEntity;
import com.infox.tourism.entity.vo.UserVO.CollectVO;
import com.infox.tourism.service.CollectService;
import com.infox.tourism.util.R;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.util.HashMap;
import java.util.List;

/**
 * 我的收藏
 * 
 * @Author: cenjinxing
 * @Date: Created in 2018/12/11 21:00
 **/
@RestController
@RequestMapping("/myCollection")
@Api(description = "我的收藏", tags = { "MyCollectionController" })
public class MyCollectionController {

	/**
	 * 收藏
	 */
	@Autowired
	private CollectService collectService;

	/**
	 * 我的收藏 活动 AND 游记
	 * 
	 * @param
	 * @return
	 */
	@ApiOperation(value = "我的收藏  活动 AND 游记", response = CollectVO.class)
	@GetMapping("/selectByOpenId")
	public R selectByOpenId(@ApiIgnore AuthUser authUser, Integer collectType, int pageNum, int pageSize) {
		List<CollectVO> list = collectService.selectByUserId(authUser.getUserId(), collectType, pageNum, pageSize);

		PageInfo<CollectVO> pageInfo = new PageInfo<>(list);

		HashMap<String, Object> map = new HashMap<>();
		map.put("list", list);
		map.put("total", pageInfo.getTotal());

		return R.ok().put("data", map);
	}

	/**
	 * 取消收藏
	 * 
	 * @param
	 * @return yiwei 修改：2018.12.27
	 */
	@ApiOperation(value = "取消收藏", response = CollectEntity.class)
	@PostMapping("/updateEnable")
	public R updateEnable(@RequestBody CollectEntity collectEntity, @ApiIgnore AuthUser user) {

		boolean b = collectService.updateEnable(collectEntity, user);

		return R.ok().put("data", b);
	}

}
