//package com.infox.tourism.util;
//
//public class RedisConstant {
//	/**
//	 * 缓存openid前缀
//	 */
//	public static final String WECHAT_OPENID_PREFIX = "wechat_openid_prefix__";
//	/**
//	 * 缓存微信用户前缀
//	 */
//	public static final String WECHAT_USER_PREFIX = "wechat_user_prefix__";
//	/**
//	 * 微信wechat_access_token
//	 */
//	public static final String WECHAT_ACCESS_TOKEN = "wechat_access_token__";
//	/**
//	 * jsapi_ticket缓存前缀
//	 */
//	public static final String JSAPI_TICKET_PREFIX = "jsapi_ticket_prefix__";
//	/**
//	 * 跟微信用户一对一
//	 */
//	public static final String WECHAT_USER_ACCESS_TOKEN = "wechat_user_access_token__";
//}
