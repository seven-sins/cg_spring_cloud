package com.infox.tourism.controller.activityController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageInfo;
import com.infox.tourism.entity.DestinationInfoEntity;
import com.infox.tourism.service.DestinationInfoService;
import com.infox.tourism.util.R;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * 目的地
 * @author Tan Ling
 * 2018年12月10日 下午7:46:18
 */
@Api(description = "目的地")
@RequestMapping("/destinationInfo")
@RestController
public class DestinationInfoController {

	@Autowired
	DestinationInfoService destinationInfoService;
	
	@ApiOperation(value = "列表", response = DestinationInfoEntity.class)
	@GetMapping("/list")
	public R list(@RequestParam("pageNum") int pageNum, @RequestParam("pageSize") int pageSize, @ApiParam DestinationInfoEntity destinationInfoEntity) {
		List<DestinationInfoEntity> list = destinationInfoService.find(pageNum, pageSize, "create_time desc", destinationInfoEntity);
		
		return R.ok().put("data", list).put("total", new PageInfo<DestinationInfoEntity>(list).getTotal());
	}
}
