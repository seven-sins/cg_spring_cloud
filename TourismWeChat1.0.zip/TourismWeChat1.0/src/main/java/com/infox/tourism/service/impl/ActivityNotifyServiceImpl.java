package com.infox.tourism.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infox.common.base.impl.BaseServiceImpl;
import com.infox.common.utils.Assert;
import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.dao.ActivityInfoDao;
import com.infox.tourism.dao.ActivityNotifyDao;
import com.infox.tourism.entity.ActivityInfoEntity;
import com.infox.tourism.entity.ActivityNotifyEntity;
import com.infox.tourism.service.ActivityNotifyService;
import com.infox.tourism.util.UUIDUtil;

import tk.mybatis.mapper.common.BaseMapper;
/**
 * @Author: cenjinxing
 * @Date: Created in 2019/3/18 10:25
 **/
@Service
public class ActivityNotifyServiceImpl extends BaseServiceImpl<ActivityNotifyEntity> implements ActivityNotifyService {

    // 信息通知
    @Autowired
    private ActivityNotifyDao activityNotifyDao;

    // 活动
    @Autowired
    private ActivityInfoDao activityInfoDao;

    /**
     * 添加通知信息
     * @param userId
     * @return
     */
    @Override
    public int insertNotify(AuthUser authUser, String activityId) {
        int insert = 0;
        ActivityInfoEntity activityInfoEntity = activityInfoDao.selectByPrimaryKey(activityId);
        // 判断活动满人的状态
        if (activityInfoEntity.getActivityStatus() == 1){
            Assert.notEmpty(authUser.getUserId(),"用户id不能为空");
            Assert.notEmpty(activityId,"活动id不能为空");
            Integer id = activityNotifyDao.selectNotifyByUserId(authUser.getUserId(),activityId,0);
            if (id == 0){
                ActivityNotifyEntity activityNotifyEntity = new ActivityNotifyEntity();
                activityNotifyEntity.setActivityId(activityId);
                activityNotifyEntity.setIsNotify(0);
                activityNotifyEntity.setNotifyId(UUIDUtil.create());
                activityNotifyEntity.setUserId(authUser.getUserId());
                activityNotifyEntity.setOpenId(authUser.getOpenId());
                insert = activityNotifyDao.insert(activityNotifyEntity);
            }
        }
        return insert;
    }

	@Override
	public void setBaseMapper(BaseMapper<ActivityNotifyEntity> baseMapper) {
		this.baseMapper = baseMapper;
	}
}

