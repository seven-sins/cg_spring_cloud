package com.infox.tourism.service.InsurerRestTemplate;

import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.infox.tourism.config.InsuranceConfig;
import com.infox.tourism.util.GenerateTransNo;
import com.infox.tourism.util.InsurerApi;
import com.infox.tourism.util.InsurerSign;

public class ObtainInsurerProducts {

    //请求流水号
    private static String transNo;
//    private String InsurNum;

    public static JSONObject getInsurerProducts(){

        RestTemplate restTemplate = new RestTemplate();

        transNo = GenerateTransNo.getTransNo();

        System.out.println("----------------------------保险订单流水号：" + transNo + "----长度:" + transNo.length());

        JSONObject jsonObject = new JSONObject();

        jsonObject.put("transNo",transNo);
        jsonObject.put("partnerId", InsuranceConfig.partnerId);

        String jsonStr = jsonObject.toJSONString();

        System.out.println("----------------------------请求参数JSON：" + jsonStr);

//        String sign = InsuranceConfig.devKey+jsonStr;

//        System.out.println("----------------------------请求参数sign：" + sign);

        //向保险接口发送请求的签名
//        try {
//            repSign = DigestUtils.md5DigestAsHex(sign.getBytes("UTF-8"));
//        } catch (UnsupportedEncodingException s) {
//            s.printStackTrace();
//        }
        String repSign = InsurerSign.getInsurerSign(jsonStr);

        System.out.println("----------------------------请求参数MD5sign：" + repSign);

//        String repUrl = InsuranceConfig.devUrl + InsuranceConfig.ProductListAPI + "?sign=" + repSign;

//        System.out.println("----------------------------请求地址：" + repUrl);
        System.out.println("----------------------------请求地址：" + InsurerApi.getProductListAPI(repSign));

        HttpEntity<JSONObject> httpEntity = new HttpEntity<>(jsonObject);

        ResponseEntity<String> responseEntity = restTemplate.postForEntity(InsurerApi.getProductListAPI(repSign), httpEntity, String.class);

        System.out.println("----------------------------请求状态码：" + responseEntity.getStatusCode());

        System.out.println("ProductListJson----------------------------请求回来的数据：" + responseEntity.getBody());

        JSONObject ProductListJson = JSON.parseObject(responseEntity.getBody());

        return ProductListJson;

    }

    public String getTransNo() {
        return transNo;
    }

}