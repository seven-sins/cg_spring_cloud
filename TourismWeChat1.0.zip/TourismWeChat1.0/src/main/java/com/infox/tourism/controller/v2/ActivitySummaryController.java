package com.infox.tourism.controller.v2;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.infox.tourism.entity.v2.activitysummary.ActivitySummary;
import com.infox.tourism.service.v2.ActivitySummaryService;
import com.infox.tourism.util.R;

import io.swagger.annotations.ApiOperation;

/**
 * 
 * @author yuanfang
 * 2019年5月14日 上午10:57:39
 */
@RestController
@RequestMapping("/summary")
public class ActivitySummaryController {
	@Autowired
	ActivitySummaryService activitySummaryService;
	
	@ApiOperation("添加总结")
	@PostMapping("/insert")
	public R insert(@Valid @RequestBody ActivitySummary activitSummary) {
		activitySummaryService.insert(activitSummary);
		return R.success();
	}
	
	@ApiOperation("修改总结")
	@PostMapping("/update/{activitySummaryId}")
	public R update(@PathVariable ("activitySummaryId") String activitySummaryId, @Valid @RequestBody ActivitySummary activitSummary) {
		activitSummary.setActivitySummaryId(activitySummaryId);
		activitySummaryService.update(activitSummary);
		
		return R.success();
	}
	
	@ApiOperation("删除总结")
	@PostMapping("/delect/{activitySummaryId}")
	public R update(@PathVariable ("activitySummaryId") String activitySummaryId ) {
		activitySummaryService.deleteByActivitySummaryId(activitySummaryId);
		return R.success();
	}
	
	@ApiOperation("查询总结")
	@GetMapping("/select/{activitySummaryId}")
	public R selectByActivitySummaryId(@PathVariable ("activitySummaryId") String activitySummaryId) {
		ActivitySummary activitySummary = activitySummaryService.selectByActivitySummaryId(activitySummaryId);
		return R.ok().put("data", activitySummary);
	}
	
	@ApiOperation("查询所有总结")
	@GetMapping("/select")
	public R selectAllActivitySummary(int pageNum, int pageSize,ActivitySummary activitySummary) {
		PageHelper.startPage(pageNum, pageSize);
		List<ActivitySummary> list = activitySummaryService.selectAllActivitySummary(activitySummary);
		return R.ok().put("data", list).put("total", new PageInfo<ActivitySummary>(list).getTotal());
	}
	
	@ApiOperation("查询活动人ID")
	@GetMapping("/find/{activityId}")
	public R findByActivityId(@PathVariable ("activityId") String activityId) {
		ActivitySummary activitySummary =activitySummaryService.findByActivityId(activityId);
		return R.ok().put("data", activitySummary);
		
	}
	
	

}
