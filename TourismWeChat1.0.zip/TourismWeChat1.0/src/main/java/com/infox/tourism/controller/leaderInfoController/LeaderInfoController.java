package com.infox.tourism.controller.leaderInfoController;

import static jdk.nashorn.internal.objects.NativeDebug.map;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageInfo;
import com.infox.common.utils.Assert;
import com.infox.common.utils.response.Result;
import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.config.resolver.Guest;
import com.infox.tourism.entity.AttentionEntity;
import com.infox.tourism.entity.ExceptionalRecordEntity;
import com.infox.tourism.entity.JoinCity;
import com.infox.tourism.entity.LeaderInfoEntity;
import com.infox.tourism.entity.LeaderLevelEntity;
import com.infox.tourism.entity.PhotoEntity;
import com.infox.tourism.entity.v2.leader.LeaderScoreVo;
import com.infox.tourism.entity.vo.albumVO.AlbumVo;
import com.infox.tourism.entity.vo.leaderInfoVO.ActivityUnderLeaderVO;
import com.infox.tourism.entity.vo.leaderInfoVO.LeaderAndActivityVO;
import com.infox.tourism.entity.vo.leaderInfoVO.LeaderPhotoAlbumVO;
import com.infox.tourism.entity.vo.leaderInfoVO.LeaderRecordVO;
import com.infox.tourism.entity.vo.leaderInfoVO.leaderEvaVO;
import com.infox.tourism.service.AlbumService;
import com.infox.tourism.service.JoinCityService;
import com.infox.tourism.service.LeaderApplyService;
import com.infox.tourism.service.LeaderInfoService;
import com.infox.tourism.service.PhotoService;
import com.infox.tourism.util.R;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

/**
 * 领队个人信息表
 *
 * @author yiwei
 * @email @163.com
 * @date 2018-12-10 10:59:35
 */
@Api(description = "领队个人信息",tags = {"LeaderInfoController"})
@RestController
@RequestMapping("/leaderInfo")
public class LeaderInfoController {
    @Autowired
    private LeaderInfoService leaderInfoService;
    @Autowired
    private LeaderApplyService leaderApplyService;
    @Autowired
    private JoinCityService joinCityService;
    @Autowired
    private AlbumService albumService;
    @Autowired
    private PhotoService photoService;

    /**
     * 领队等级列表
     */
    @ApiOperation(value ="领队等级列表", notes = "领队等级列表", response = LeaderLevelEntity.class)
    @GetMapping("/queryLeaderLevelList")
    public R queryLeaderLevelList(@RequestParam(value = "locationId", required = false) String locationId) {
        List<LeaderLevelEntity> exList = leaderInfoService.queryLeaderLevelList();      
        return R.ok().put("data", exList);
    }
    
    /**
     * 领队列表
     */
    @ApiOperation(value ="领队列表", notes = "领队列表", response = LeaderAndActivityVO.class)
    @GetMapping("/leaderList")
    public Result<List<LeaderAndActivityVO>> list(int pageNum, int pageSize, String leaderLevel, @RequestParam(value = "locationId", defaultValue = "1b03e554006211e9922700163e0ec1a2") String locationId) {
    	Assert.notEmpty(locationId, "locationId不能为空");
		JoinCity joinCity = joinCityService.getBySbLocationId(locationId);
		Assert.notNull(joinCity, "数据异常, 城市信息不存在");
		
        List<LeaderAndActivityVO> voList = leaderInfoService.queryLeaderList(pageNum, pageSize, leaderLevel, joinCity.getCompanyId());
        PageInfo<LeaderAndActivityVO> pageInfo = new PageInfo<>(voList);

		for (int i = 0; i < voList.size(); i++) {
        	String leaderId = voList.get(i).getLeaderId();
        	LeaderScoreVo leaderScoreVo = leaderInfoService.queryLeaderScoreByLeaderId(leaderId);
        	BigDecimal overallScore = leaderScoreVo.getTrafficSatisfaction().add(leaderScoreVo.getLeaderSatisfaction()).add(leaderScoreVo.getLineSatisfaction());
    		// 领队综合评分
        	voList.get(i).setOverallScore(overallScore.divide(new BigDecimal("3"), 2, BigDecimal.ROUND_HALF_UP));
        	List<ActivityUnderLeaderVO> activityList = leaderInfoService.queryLeaderActivityList(pageNum, 5, 3, leaderId);
        	voList.get(i).setActivityList(activityList);
        	//
        	voList.get(i).setTrafficSatisfaction(leaderScoreVo.getTrafficSatisfaction());
        	voList.get(i).setLeaderSatisfaction(leaderScoreVo.getLeaderSatisfaction());
        	voList.get(i).setLineSatisfaction(leaderScoreVo.getLineSatisfaction());
        }
        
		return new Result<>(voList).total(pageInfo.getTotal());
    }

    /**
     * 领队活动列表
     */
    @ApiOperation(value ="领队活动列表", notes = "领队活动列表", response = LeaderAndActivityVO.class)
    @GetMapping("/queryLeaderActivityList")
    public R queryLeaderActivityList(int pageNum, int pageSize,int state, String leaderId) {
        List<ActivityUnderLeaderVO> voList = leaderInfoService.queryLeaderActivityList(pageNum, pageSize, state,leaderId);
        PageInfo<ActivityUnderLeaderVO> pageInfo = new PageInfo<>(voList);
        return R.ok().put("data", voList).put("total", pageInfo.getTotal());
    }
    
    /**
     * 领队个人信息
     */
    @ApiOperation(value ="领队个人信息", notes ="领队个人信息", response = LeaderAndActivityVO.class)
    @GetMapping("/queryLeaderById")
    public R queryLeaderById(String leaderId,  @ApiIgnore Guest user) {
    	LeaderAndActivityVO leaderAndActivityVO = leaderInfoService.queryLeaderById(leaderId, user);
    	
        return R.ok().put("data", leaderAndActivityVO);
    }
    
    /**
     * 领队相册列表
     */
    @ApiOperation(value =" 领队相册列表", notes = " 领队相册列表", response = LeaderPhotoAlbumVO.class)
    @GetMapping("/queryLeaderPhotoList")
    public Result<?> queryLeaderPhotoList(int pageNum, int pageSize, String leaderId) {
    	Assert.notEmpty(leaderId, "领队ID不能为空");
    	LeaderInfoEntity leader = leaderInfoService.get(leaderId);
    	Assert.notNull(leader, "参数错误, 领队不存在");
    	Assert.notEmpty(leader.getUserId(), "数据异常, 领队关联的用户ID不存在");
    	// 图片总数
		List<AlbumVo> list = albumService.queryPage(pageNum, pageSize, leader.getUserId());
		if (list != null && !list.isEmpty()) {
			for (AlbumVo albumVo : list) {
				// 图片总数
				albumVo.setPhotoTotal(photoService.total(albumVo.getAlbumId()));
			}
		}
		
		return new Result<>(list).total(new PageInfo<AlbumVo>(list).getTotal());
    }
    
    /**
     * 领队相册详细列表
     */
    @ApiOperation(value ="领队相册详细列表", notes = "领队相册详细列表", response = PhotoEntity.class)
    @GetMapping("/queryLeaderPhotoDetailList")
    public R queryLeaderPhotoDetailList(int pageNum, int pageSize, String albumId) {
        List<PhotoEntity> photoList = leaderInfoService.queryLeaderPhotoDetailList(pageNum, pageSize, albumId);
        PageInfo<PhotoEntity> pageInfo = new PageInfo<>(photoList);
        return R.ok().put("data", photoList).put("total", pageInfo.getTotal());
    }
    
    /**
     * 领队评论列表
     */
    @ApiOperation(value ="领队评论列表", notes = "领队评论列表", response = leaderEvaVO.class)
    @GetMapping("/queryLeaderEvaluationList")
    public R queryLeaderEvaluationList(int pageNum, int pageSize, String leaderId) {
        List<leaderEvaVO> evaluationList = leaderInfoService.queryLeaderEvaluationList(pageNum, pageSize, leaderId);
        PageInfo<leaderEvaVO> pageInfo = new PageInfo<>(evaluationList);
        return R.ok().put("data", evaluationList).put("total", pageInfo.getTotal());
    }
    
    /**
     * 领队打赏列表
     */
    @ApiOperation(value ="领队打赏列表", notes = "领队打赏列表", response = LeaderRecordVO.class)
    @GetMapping("/queryLeaderExReList")
    public R queryLeaderExReList(int pageNum, int pageSize, String leaderId) {
        List<LeaderRecordVO> exList = leaderInfoService.queryLeaderExReList(pageNum, pageSize, leaderId);
        PageInfo<LeaderRecordVO> pageInfo = new PageInfo<>(exList);
        return R.ok().put("data", exList).put("total", pageInfo.getTotal());
    }

    /**
     * 领队打赏
     */
    @ApiOperation(value ="领队打赏", notes = "领队打赏", response = ExceptionalRecordEntity.class)
    @PostMapping("/exceptionalRecordsave")
    public R save(@Valid @RequestBody ExceptionalRecordEntity exceptionalRecordEntity, @ApiIgnore  AuthUser user){
    	ExceptionalRecordEntity exceptionalRecord = leaderInfoService.insert(exceptionalRecordEntity, user);
        return R.ok().put("data",exceptionalRecord);
    }

    /**
     * 根据打赏id查询
     */
    @ApiOperation(value ="根据打赏id查询", notes = "根据打赏id查询", response = ExceptionalRecordEntity.class)
    @GetMapping("/selectExceptionalRecordById")
    public R selectExceptionalRecordById(String orderId){
        ExceptionalRecordEntity exceptionalRecord = leaderInfoService.selectExceptionalRecordById(orderId);
        return R.ok().put("data",exceptionalRecord);
    }
    
    /**
     * 关注领队
     */
    @ApiOperation(value =" 领队关注", notes = "领队关注", response = AttentionEntity.class)
    @PostMapping("/insertAttention")
    public R insertAttention(@RequestBody AttentionEntity attentionEntity,@ApiIgnore  AuthUser user){
        boolean insert = leaderInfoService.insertAttention(attentionEntity,user);
        return R.ok().put("data",insert);
    }
    
	/**
	 * 申请领队
	 * @param leaderInfo
	 * @return
	 */
	@ApiOperation("申请领队")
	@PostMapping("/insert")
	public R insert(@Valid @RequestBody LeaderInfoEntity leaderInfo, @ApiIgnore AuthUser user) {
		leaderInfo.setUserId(user.getUserId());
		leaderInfo.setNickName(user.getNickName());
		leaderInfo = leaderInfoService.insert(user, leaderInfo);
		
		return R.ok().put("data", leaderInfo);
	}

    @ApiOperation("根据openid查询领队申请的信息")
    @PostMapping("/selectLeaderApplyByOpenId")
    public R selectLeaderApplyByUserId(@ApiIgnore AuthUser user) {
        return R.ok().put("data", leaderApplyService.selectLeaderApplyByUserId(user.getUserId()));
    }

    /**
     * 领队账户-查询可提现金额
     */
	@SuppressWarnings("restriction")
	@ApiOperation("领队账户-查询可提现金额")
    @GetMapping("/selectCanWithdrawalsMoneyByOpenId")
    public R selectCanWithdrawalsMoneyByUserId(@ApiIgnore AuthUser user) {
        Integer id = leaderInfoService.selectCanWithdrawalsMoneyByUserId(user.getUserId());
        Map<String, Object> map = new HashMap<>();
        map("money",id);
        return R.ok().put("data", map);
    }

}
