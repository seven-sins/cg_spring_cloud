package com.infox.tourism.dao.v2;


import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.infox.tourism.entity.WithdrawalRecordEntity;

import tk.mybatis.mapper.common.BaseMapper;


/**
 *  提现
 * @author yuanfang
 * 2019年5月14日 上午10:56:00
 */
@Mapper
public interface WithdrawalRecordMapper extends BaseMapper<WithdrawalRecordEntity> {
//	
//	/**
//	 * 提现记录
//	 */
//	 public void insert(WithdrawalRecordEntity withdrawalRecordEntity);
	 
	 /**
	  * 查询提现数据
	  */
	 List<WithdrawalRecordEntity> selectByUserId(String userId);
	
	 /**
	  * 查询提现账户
	  */
	 List<WithdrawalRecordEntity> findByUserId(String userId);
	 
	 /**
	  * 查看所有提现
	  */
	 List<WithdrawalRecordEntity> selectAllWithdrawalRecord(WithdrawalRecordEntity withdrawalRecordEntity);
}
