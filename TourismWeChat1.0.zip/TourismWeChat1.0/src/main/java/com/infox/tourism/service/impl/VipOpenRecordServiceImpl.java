package com.infox.tourism.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.infox.tourism.entity.VipOpenRecordEntity;
import com.infox.tourism.service.VipOpenRecordService;


/**
 * 
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-12-13 14:28:51
 */
@Service("vipOpenRecordService")
public class VipOpenRecordServiceImpl implements VipOpenRecordService {
	//    /**
	//    * vipOpenRecordDao层
	//    * @param params
	//    * @return
	//    */
	//    @Autowired
	//    private VipOpenRecordDao vipOpenRecordDao;

    /**
    * 查询分页
    * @param pageNum
    * @param pageSize
    * @param search
    * @return
    */
    @Override
    public List<VipOpenRecordEntity> queryPage(int pageNum, int pageSize, String search){
        // 使用分页插件实现分页
        PageHelper.startPage(pageNum,pageSize);
        // 调用dao的方法

        return null;
    };

}
