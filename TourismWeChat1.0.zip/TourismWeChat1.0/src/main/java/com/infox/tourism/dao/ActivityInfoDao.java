package com.infox.tourism.dao;

import java.util.List;

import com.infox.tourism.entity.vo.activity.ActivityBase;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.infox.tourism.entity.ActivityInfoEntity;
import com.infox.tourism.entity.vo.activityDetailVO.PayActivityVO;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 活动表
 * @author Tan Ling
 * 2018年12月12日 上午11:59:02
 */
@Mapper
public interface ActivityInfoDao extends BaseMapper<ActivityInfoEntity> {

	ActivityInfoEntity getByActivityId(@Param("activityId") String activityId);
	
	/**
	 * 根据主键更新
	 * @param activityInfoEntity
	 */
	void updateByActivityId(ActivityInfoEntity activityInfoEntity);
	
	/**
	 * 查询当前线路下所有活动的图片
	 * @param lineId
	 * @return
	 */
	List<ActivityInfoEntity> selectImageByLineId(@Param("lineId") String lineId);
	
	/**
	 * 查询支付的活动详情
	 * @param activityId
	 * @return
	 */
	PayActivityVO getPayActivityByActivityId(@Param("activityId") String activityId);

	/**
	 * 查询热门活动
	 * @param popular
	 * @return
	 */
	List<ActivityBase> selectByPopular(@Param("popular") Integer popular,
									   @Param("activityId") String activityId,
									   String companyId);

	/**
	 * 根据路线id查询有多少条活动
	 */
	List<ActivityBase> selectActivityByLineId(@Param("lineId")String lineId);
}
