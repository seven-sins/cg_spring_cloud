package com.infox.tourism.dao;

import com.infox.tourism.entity.ActivityLeaderRelation;
import com.infox.tourism.entity.OrderInfoEntity;
import com.infox.tourism.entity.vo.OrderVO.OrderVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.BaseMapper;

import java.util.List;

/**
 * 订单表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-21 15:17:45
 */
@Mapper
public interface OrderInfoDao extends BaseMapper<OrderInfoEntity> {

	/**
	 * 根据userId 根据支付状态查询
	 * 
	 * @param userId
	 * @param payStatus
	 * @return
	 */
	List<OrderVO> selectByUserIdAndPayStatus(@Param("userId") String userId, @Param("payStatus") Integer payStatus);
	
	List<OrderVO> selectByUserIdOrPayStatus(@Param("userId") String userId);

	List<OrderVO> getByOrder(@Param("userId") String userId);

	/**
	 * 根据活动id查询领队
	 */
	List<ActivityLeaderRelation> selectByActivityId(@Param("activityId")String activityId);

	/**
	  * 根据userId 根据活动状态查询
	 * 
	 * @param userId
	 * @return
	 */
	List<OrderVO> selectByUserIdAndActivityStatus(@Param("userId") String userId);

	/**
	  * 取消订单 0，新订单 1 取消订单 2 订单审核
	 * 
	 * @return
	 */
	boolean updateByOrderIdAndOrderStatus(OrderInfoEntity orderInfoEntity);

	/**
	  * 根据id查询订单
	 * 
	 * @param orderId
	 * @return
	 */
	OrderVO selectByOrderId(String orderId);

	/**
	  * 设置订单交易流水号
	 * 
	 * @param orderInfoEntity
	 */
	void updateOrderTrxid(OrderInfoEntity orderInfoEntity);

	/**
	  * 更新支付状态
	 * 
	 * @param trxid
	 * @param payStatus
	 */
	void updatePayStatus(@Param("trxid") String trxid, @Param("payStatus") int payStatus);

	/**
	  * 使用orderId获取订单
	 * 
	 * @param orderId
	 * @return
	 */
	OrderInfoEntity getByOrderId(@Param("orderId") String orderId);

	/**
	  * 使用trxid查询订单
	 * 
	 * @param trxid
	 * @return
	 */
	OrderInfoEntity getByTrxid(@Param("trxid") String trxid);

	/**
	  * 申请退团 根据订单id
	 * 
	 * @param orderId
	 * @return
	 */
	OrderVO applyRetreat(String orderId);

	/**
	  * 退单
	 * 
	 * @return
	 */
	boolean updateByOrderIdAndPayStatus(OrderInfoEntity orderInfoEntity);
	
	/**
	  * 使用用户ID和活动ID查询订单
	 * @param userId
	 * @param activityId
	 * @return
	 */
	List<OrderInfoEntity> findByUserAndActivityId(@Param("userId") String userId, @Param("activityId") String activityId);
	/**
	 * 修改订单状态
	 * @param orderId
	 * @param deleteStatus
	 */
	void updateOrderStatusByOrderId(@Param("orderId") String orderId, @Param("deleteStatus") Integer deleteStatus);
	/**
	 * 根据活动id更新订单评价状态
	 * @return
	 */
	boolean updateByActivityId(@Param("orderId") String orderId,@Param("evaluateState")Integer evaluateState);
	/**
	 * 根据订单号查询
	 * @author Tan Ling
	 * @date 2019年1月17日 下午2:52:01
	 * @param orderNumber
	 * @return
	 */
	OrderInfoEntity getByOrderNumber(@Param("orderNumber") String orderNumber);
	/**
	 * 修改拼单状态(1:拼单中,2:拼单成功,3:拼单失败)
	 * @author Tan Ling
	 * @date 2019年1月26日 上午10:33:56
	 * @param orderId
	 * @param singleStatus
	 */
	void updateSingleStatus(@Param("orderId") String orderId, @Param("singleStatus") Integer singleStatus);
	/**
	 * 查询有申请退款的订单ID
	 * @author Tan Ling
	 * @date 2019年2月20日 下午6:47:56
	 * @return
	 */
	List<String> queryOrderIdOfHasRefund();
	/**
	 * 查询订单信息
	 * @author Tan Ling
	 * @date 2019年2月20日 下午6:49:58
	 * @param orderIds
	 * @return
	 */
	List<OrderVO> selectInOrderId(@Param("orderIds") String[] orderIds);

	/**
	 * 根据订单id更新评价状态
	 * @param orderId
	 * @return
	 */
	Integer updateEvaluationStatusByOrderId(@Param("orderId")String orderId);
	
	/**
	 * 更新订单修改时间
	 * @author Tan Ling
	 * @date 2019年4月18日 上午11:40:07
	 * @param orderId
	 */
	void setUpdateTime(@Param("orderId") String orderId);
	
	/**
	 * 统计线路下已报名人数
	 * @author Tan Ling
	 * @date 2019年7月23日 下午4:57:31
	 * @param lineId
	 * @return
	 */
	Integer queryPedestrianNumByLineId(String lineId);
	
	/**
	 * 查询当前活动未支付订单
	 * @author Tan Ling
	 * @date 2019年7月24日 下午3:53:23
	 * @param activityId
	 * @param userId
	 * @return
	 */
	OrderInfoEntity getNonpaymentOrderByActivityId(String activityId, String userId);
	
	/**
	 * 删除当前活动未支付订单
	 * @author Tan Ling
	 * @date 2019年7月24日 下午3:54:15
	 * @param activityId
	 * @param userId
	 */
	void deleteNonpaymentOrderByActivityId(String activityId, String userId);

	/**
	 * 删除当前活动未支付订单过滤指定订单ID
	 * @param activityId
	 * @param userId
	 * @param orderId
	 */
	void deleteNonpaymentOrderByActivityIdAndOrderId(@Param("activityId") String activityId,@Param("userId") String userId,@Param("orderId") String orderId);

}
