package com.infox.tourism.service.v2;

import com.infox.common.base.BaseService;
import com.infox.tourism.entity.v2.econtract.UserEcontract;

public interface UserEcontractService  extends BaseService<UserEcontract>{

}
