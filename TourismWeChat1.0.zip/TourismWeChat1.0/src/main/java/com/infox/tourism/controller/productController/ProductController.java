package com.infox.tourism.controller.productController;

import io.swagger.annotations.Api;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Description TODO
 * @Author Hale
 * @Date 2018/12/12
 */
@Api(description = "产品Controller",tags = {"ProductController"})
@RestController
@RequestMapping("/product")
public class ProductController {


}
