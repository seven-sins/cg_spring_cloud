package com.infox.tourism.service;

import com.infox.tourism.entity.InsuranceProductsEntity;

/**
 * 保险
 * @author Tan Ling
 * @date 2019年1月29日 下午4:47:26
 */
public interface InsuranceProductService {
	/**
	 * 使用ID查询保险
	 * @author Tan Ling
	 * @date 2019年1月29日 下午4:48:59
	 * @param insuranceProductId
	 * @return
	 */
	InsuranceProductsEntity getInsuranceProductById(String insuranceProductId);
}
