package com.infox.tourism.service.team.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infox.tourism.dao.team.TeamMapper;
import com.infox.tourism.entity.team.TeamActivity;
import com.infox.tourism.entity.team.TeamLine;
import com.infox.tourism.entity.team.TeamLineDetail;
import com.infox.tourism.service.EvaluationService;
import com.infox.tourism.service.team.TeamService;

/**
 * 团队定制活动
 * @author Tan Ling
 * @date 2019年6月26日 下午1:41:07
 */
@Service
public class TeamServiceImpl implements TeamService {
	@Autowired
	private TeamMapper teamMapper;
	@Autowired
	private EvaluationService evaluationService;
	
	@Override
	public List<TeamLine> find() {
		List<TeamLine> list = teamMapper.find();
		if(list != null && !list.isEmpty()) {
			for(TeamLine item: list) {
				item.setActivityList(teamMapper.queryActivityByLineId(item.getLineId(), 3));
				String destination = "";
				if(StringUtils.isNotBlank(item.getdProvince())) {
					destination += item.getdProvince();
				} else {
					destination += item.getdCountry();
				}
				if(item.getActivityList() != null && !item.getActivityList().isEmpty() && StringUtils.isNotBlank(item.getActivityList().get(0).getDestination())) {
					destination += " " + item.getActivityList().get(0).getDestination();
					/**
					 * 如果活动没设置副标题, 将线路名称作为副标题
					 */
					for(TeamActivity activity: item.getActivityList()) {
						if(StringUtils.isBlank(activity.getSubtitle())) {
							activity.setSubtitle(item.getLineName());
						}
					}
				}
				item.setDestination(destination);
			}
		}
		
		return list;
	}

	@Override
	public List<TeamActivity> queryActivityList(String lineId) {
		return teamMapper.queryActivityList(lineId);
	}

	@Override
	public TeamLineDetail queryLineDetail(String lineId) {
		TeamLineDetail detail = teamMapper.queryLineDetail(lineId);
		if(detail != null) {
			detail.setCommentList(evaluationService.selectCommonListByLineId(lineId));
			String destination = "";
			if(StringUtils.isNotBlank(detail.getdProvince())) {
				destination += detail.getdProvince();
			} else {
				destination += detail.getdCountry();
			}
			List<TeamActivity> activityList = teamMapper.queryActivityByLineId(detail.getLineId(), 1);
			if(activityList != null && !activityList.isEmpty() && StringUtils.isNotBlank(activityList.get(0).getDestination())) {
				destination += " " + activityList.get(0).getDestination();
			}
			detail.setDestination(destination);
		}
		
		return detail;
	}
}
