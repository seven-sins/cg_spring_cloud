package com.infox.tourism.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.infox.tourism.entity.UserInfoEntity;
import com.infox.tourism.entity.vo.UserVO.UserVO;
import com.infox.tourism.entity.vo.albumVO.FootprintVo;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 用户表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-22 20:31:29
 */
@Mapper
public interface UserInfoDao extends BaseMapper<UserInfoEntity> {

    /**
    * 查询分页
    * @return
    */
    List<UserInfoEntity> queryPage();

    /**
     * 根据userId查询
     * @param userId
     * @return
     */
    List<FootprintVo> selectByUserId(String userId);
    
    /**
     * 使用openid获取用户对象
     * @param openId
     * @return
     */
    UserInfoEntity getByOpenId(String openId);

    /**
     * 根据userId查询用户页面数据
     */
    UserVO selectUserInfoByUserId(String userId);

    /**
     * 根据userId查询是否申请领队
     */
    int selectLeaderByUserId(String userId);

    /**
     * 根据用户信息
     * @param userVO
     * @return
     */
    boolean updateUserInfoByUserId(UserVO userVO);

    /**
     * 开通会员信息
     * @param userInfoEntity
     * @return
     */
    boolean updateUserInfoVip(UserInfoEntity userInfoEntity);

    /**
     * 开通会员信息
     * @param userInfoEntity
     * @return
     */
    boolean updateUserInfoVipByUserId(UserInfoEntity userInfoEntity);

    /**
     * 更新vip截至时间
     * @param userInfoEntity
     * @return
     */
    boolean updateUserInfoEndTime(UserInfoEntity userInfoEntity);
    
    /**
     * 查询用户是否是领队
     * @author Tan Ling
     * @date 2019年1月18日 下午5:22:19
     * @param userId
     * @return
     */
    Integer isLeader(@Param("userId") String userId);

    /**
     * 更新--我的背景圖
     * @param userId
     * @param url
     * @return
     */
    Integer updateBackgroundImg(String userId, String url);

    /**
     * 我的足迹总数
     * @param userId
     * @return
     */
    Integer getByNumFootprint(String userId);

    /**
     * 我的收藏总数
     * @param userId
     * @return
     */
    Integer getByNumCollect(String userId);
    
    /**
     * 设置用户的unionId
     * @author Tan Ling
     * @date 2019年6月14日 下午4:08:30
     * @param userId
     * @param unionId
     */
    void setUnionId(String userId, String unionId);
    
    /**
     * 根据unionid查询用户
     * @author Tan Ling
     * @date 2019年6月14日 下午4:49:26
     * @param unionId
     * @return
     */
    UserInfoEntity getByUnionId(String unionId);
    
    /**
     * 更新用户城市信息
     * @author Tan Ling
     * @date 2019年7月25日 上午11:19:05
     * @param guest
     */
	void updateUserCity(UserInfoEntity user);

    /**
     * 更新用户登录时间
     * @param user
     */
	void updateByUserTime(UserInfoEntity user);
    
}
