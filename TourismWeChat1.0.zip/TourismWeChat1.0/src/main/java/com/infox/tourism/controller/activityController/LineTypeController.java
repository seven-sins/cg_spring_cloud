package com.infox.tourism.controller.activityController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageInfo;
import com.infox.tourism.entity.LineTypeEntity;
import com.infox.tourism.service.LineTypeService;
import com.infox.tourism.util.R;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * 线路分类列表查询
 * @author Tan Ling
 * 2018年12月10日 下午7:14:37
 */
@Api(description = "线路类型")
@RequestMapping("/lineType")
@RestController
public class LineTypeController {

	@Autowired
	LineTypeService lineTypeService;
	
	@ApiOperation(value = "列表", response = LineTypeEntity.class)
	@GetMapping("/list")
	public R list(@RequestParam("pageNum") int pageNum, @RequestParam("pageSize") int pageSize, @ApiParam LineTypeEntity lineTypeEntity) {
		List<LineTypeEntity> list = lineTypeService.find(pageNum, pageSize, "create_time asc", lineTypeEntity);
		return R.ok().put("data", list).put("total", new PageInfo<LineTypeEntity>(list).getTotal());
	}


}
