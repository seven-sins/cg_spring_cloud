package com.infox.tourism.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.infox.tourism.entity.CommonContacts;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 常用联系人
 * @author Tan Ling
 * 2018年12月5日 下午3:51:25
 */
@Mapper
public interface CommonContactsDao extends BaseMapper<CommonContacts> {

	/**
	 * 删除当前用户所有联系人
	 * @param userId
	 */
	void deleteByUserId(@Param("userId") String userId);
	
	/**
	 * 根据联系人ID删除
	 * @param commonContactsId
	 */
	void deleteByContactsId(@Param("commonContactsId") String commonContactsId);

	/**
	 * 根据id查询
	 * @param userId
	 * @param ids
	 * @return
	 */
	List<CommonContacts> findInId(@Param("userId") String userId, @Param("ids") String[] ids);
	
	/**
	 * 更新
	 * @param commonContacts
	 */
	void updateByContactId(CommonContacts commonContacts);
	
	/**
	 * 根据身份证号查询
	 * @param userId
	 * @param idCard
	 * @return
	 */
	CommonContacts getByIdCard(@Param("userId") String userId, @Param("idCard") String idCard);
	
}
