package com.infox.tourism.dao.team;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.infox.tourism.entity.team.TeamActivity;
import com.infox.tourism.entity.team.TeamLine;
import com.infox.tourism.entity.team.TeamLineDetail;

/**
 * 团队定制活动
 * @author Tan Ling
 * @date 2019年6月26日 下午1:41:55
 */
@Mapper
public interface TeamMapper {
	
	/**
	 * 查询线路列表
	 * @author Tan Ling
	 * @date 2019年6月26日 下午2:16:03
	 * @return
	 */
	List<TeamLine> find();
	/**
	 * 查询线路下的活动列表
	 * @author Tan Ling
	 * @date 2019年6月26日 下午2:16:09
	 * @param lineId
	 * @return
	 */
	List<TeamActivity> queryActivityByLineId(String lineId, Integer size);
	/**
	 * 查询线路下的活动列表
	 * @author Tan Ling
	 * @date 2019年6月26日 下午2:17:47
	 * @param lineId
	 * @return
	 */
	List<TeamActivity> queryActivityList(String lineId);
	
	/**
	 * 查询线路详情
	 * @author Tan Ling
	 * @date 2019年6月26日 下午4:28:56
	 * @param lineId
	 * @return
	 */
	TeamLineDetail queryLineDetail(String lineId);
	
}
