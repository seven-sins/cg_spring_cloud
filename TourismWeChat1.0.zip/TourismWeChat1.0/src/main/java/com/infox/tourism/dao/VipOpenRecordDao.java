package com.infox.tourism.dao;

import com.infox.tourism.entity.VipOpenRecordEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.BaseMapper;

import java.util.List;

/**
 * 
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-12-13 14:28:51
 */
@Mapper
public interface VipOpenRecordDao extends BaseMapper<VipOpenRecordEntity> {

    /**
    * 查询分页
    * @return
    */
    List<VipOpenRecordEntity> queryPage();

    /**
     * 根据VIPid查询
     * @param vipId
     * @return
     */
    VipOpenRecordEntity selectByVipId(String vipId);

    /**
     * 设置订单交易流水号
     * @param vipOpenRecordEntity
     * @return
     */
    boolean updateVipOpenRecordTrxid(VipOpenRecordEntity vipOpenRecordEntity);

    /**
     * 更新支付状态
     * @param trxid
     * @param payStatus
     * @return
     */
    boolean updatePayStatus(@Param("trxid") String trxid, @Param("payStatus") int payStatus);

    /**
     * 根据订单流水号查询
     * @param trxid
     * @return
     */
    VipOpenRecordEntity selectByTrxid(String trxid);

}
