package com.infox.tourism.service.v2;

import com.infox.common.base.BaseService;
import com.infox.tourism.entity.UserInfoEntity;
import com.infox.tourism.entity.v2.activityadvancepayment.ActivityAdvancePayment;

/**
 * 预付款service
 * @author Tan Ling
 * 2019年1月7日 下午2:27:00
 */
public interface ActivityAdvancePaymentService extends BaseService<ActivityAdvancePayment> {

	/**
	 * 根据主键更新
	 * @param activityAdvancePayment
	 */
	public void updateByActivityAdvancePaymentId(ActivityAdvancePayment activityAdvancePayment);
	
	/**
	 * 预付款申请
	 * @param activityAdvancePayment
	 * @param user
	 */
	public void insert(ActivityAdvancePayment activityAdvancePayment, UserInfoEntity user);
	
}
