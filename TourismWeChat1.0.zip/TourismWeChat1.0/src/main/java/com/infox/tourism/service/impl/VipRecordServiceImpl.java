package com.infox.tourism.service.impl;

import java.util.Calendar;
import java.util.Date;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infox.tourism.dao.UserInfoDao;
import com.infox.tourism.dao.VipOpenRecordDao;
import com.infox.tourism.dao.VipRecordDao;
import com.infox.tourism.entity.UserInfoEntity;
import com.infox.tourism.entity.VipOpenRecordEntity;
import com.infox.tourism.entity.VipRecordEntity;
import com.infox.tourism.entity.vo.UserVO.VipVO;
import com.infox.tourism.service.VipRecordService;
import com.infox.tourism.util.UUIDUtil;

/**
 * 会员记录表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-21 15:17:45
 */
@Service("vipRecordService")
public class VipRecordServiceImpl implements VipRecordService {
	@Autowired
	private VipRecordDao vipRecordDao;
	@Autowired
	private VipOpenRecordDao vipOpenRecordDao;
	@Autowired
	private UserInfoDao userInfoDao;

	/**
	 * 申请会员
	 *
	 * @param userId
	 * @param vipVO
	 * @return
	 */
	@Override
	public VipOpenRecordEntity insert(String userId, VipVO vipVO) {
		UserInfoEntity entity = new UserInfoEntity();
		VipRecordEntity vipRecordEntity = new VipRecordEntity();

		VipOpenRecordEntity vipOpenRecordEntity = new VipOpenRecordEntity();

		// 获取当前时间
		Calendar calendarEndDate = Calendar.getInstance();

		// 查询用户是否开通会员
		UserInfoEntity userInfoEntity = userInfoDao.selectByPrimaryKey(userId);

		// 没有开通会员
		// 更新用户信息
		BeanUtils.copyProperties(vipVO, entity);
		entity.setUserId(userId);

		// 判断会员是否过期 根据现在时间跟截至时间判断，现在时间大于截至时间，过期 现在时间小于截至时间，没有过期
		if (userInfoEntity.getEndTime() != null
				&& calendarEndDate.getTime().getTime() > userInfoEntity.getEndTime().getTime()) {
			vipOpenRecordEntity = openVip(vipRecordEntity, vipOpenRecordEntity, vipVO, userInfoEntity);
			// 获取12个月的时间，开通会员截至时间
			calendarEndDate.add(Calendar.MONTH, 12);
			entity.setEndTime(calendarEndDate.getTime());

			userInfoDao.updateUserInfoVipByUserId(entity);
			// 插入会员记录表
		} else {
			vipOpenRecordEntity = openVip(vipRecordEntity, vipOpenRecordEntity, vipVO, userInfoEntity);

			// 获取12个月的时间，开通会员截至时间
			calendarEndDate.add(Calendar.MONTH, 12);
			entity.setEndTime(calendarEndDate.getTime());

			userInfoDao.updateUserInfoVipByUserId(entity);
		}

		return vipOpenRecordEntity;
	}

	VipOpenRecordEntity openVip(VipRecordEntity vipRecordEntity, VipOpenRecordEntity vipOpenRecordEntity, VipVO vipVO,
			UserInfoEntity userInfoEntity) {
		// 获取当前时间
		Calendar calendarEndDate = Calendar.getInstance();

		// 获取12个月的时间，开通会员截至时间
		calendarEndDate.add(Calendar.MONTH, 12);
		BeanUtils.copyProperties(vipVO, vipRecordEntity);
		vipRecordEntity.setVipId(UUIDUtil.create());
		vipRecordEntity.setUserId(userInfoEntity.getUserId());
		vipRecordEntity.setStartTime(new Date());
		vipRecordEntity.setEndTime(calendarEndDate.getTime());

		vipRecordDao.insert(vipRecordEntity);

		// 插入会员开通记录表

		BeanUtils.copyProperties(vipVO, vipOpenRecordEntity);
		vipOpenRecordEntity.setVipOpenId(UUIDUtil.create());
		vipOpenRecordEntity.setVipId(vipRecordEntity.getVipId());
		vipOpenRecordEntity.setPayType(1);
		vipOpenRecordEntity.setPayStatus(0);
		vipOpenRecordDao.insert(vipOpenRecordEntity);

		return vipOpenRecordEntity;

	}

}
