package com.infox.tourism.controller.userInfoController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageInfo;
import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.entity.vo.albumVO.FootprintVo;
import com.infox.tourism.service.UserInfoService;
import com.infox.tourism.util.R;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

/**
 *
 * @Author: cenjinxing
 * @Date: Created in 2018/12/7 11:59
 **/
@RestController
@RequestMapping("/footprint")
@Api(description = "我的_足迹接口",tags = {"FootprintController"})
public class MyFootprintController {

    /**
     * 微信用户
     */
    @Autowired
    private UserInfoService userInfoService;

    @ApiOperation(value = "足迹列表",response = FootprintVo.class)
    @PostMapping("/footprintList")
    public R photoList(@ApiIgnore AuthUser authUser){
//        服务器上 放开注解
        List<FootprintVo> list = userInfoService.selectByUserId(authUser.getUserId());

        PageInfo<FootprintVo> pageInfo = new PageInfo<>(list);

        Map<Object, Object> map = new HashMap<>();
        map.put("list",list);
        map.put("total",pageInfo.getTotal());

        return R.ok().put("data",map);
    }


}
