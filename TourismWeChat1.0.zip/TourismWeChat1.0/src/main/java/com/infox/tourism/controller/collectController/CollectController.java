package com.infox.tourism.controller.collectController;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.config.resolver.Guest;
import com.infox.tourism.entity.CollectEntity;
import com.infox.tourism.service.CollectService;
import com.infox.tourism.util.R;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

/**
 * 收藏表
 *
 * @author yiwei
 * @param <PageUtils>
 * @email 996358199@qq.com
 * @date 2018-12-10 9:46:05
 */
@Api(description = "收藏", tags = { "CollectController" })
@RestController
@RequestMapping("/collect")
public class CollectController<PageUtils> {
	@Autowired
	private CollectService collectService;

	/**
	 * 收藏和取消收藏
	 */
	@ApiOperation(value = "收藏和取消收藏", notes = "收藏和取消收藏", response = CollectEntity.class)
	@PostMapping("/update")
	public R update(@RequestBody CollectEntity collectEntity, @ApiIgnore AuthUser user) {
		boolean b = collectService.updateById(collectEntity, user);

		return R.ok().put("data", b);
	}

	/**
	 * 根据活动或游记id查询用户是否收藏
	 */
	@ApiOperation(value = "根据活动或游记id查询用户是否收藏", notes = "根据活动或游记id查询用户是否收藏", response = CollectEntity.class)
	@GetMapping("/judeConllect")
	public R judeConllect(String travelsActivityId, String collectType, @ApiIgnore Guest user) {
		boolean i = false;
		if(user == null || StringUtils.isBlank(user.getUserId())) {
			return R.ok().put("data", i);
		}
		CollectEntity collectEntity = collectService.selectById(travelsActivityId, user.getUserId(), collectType);
		if (collectEntity != null && collectEntity.getIsEnable().equals("1")) {
			i = true;
		}
		return R.ok().put("data", i);
	}
}
