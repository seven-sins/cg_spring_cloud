package com.infox.tourism.config.filter.request.wrapper;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;

import javax.servlet.ReadListener;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

/**
 * @author rex.tan
 * @date 2019年9月12日 上午9:37:10
 */
public class WebHttpServletRequestWrapper extends HttpServletRequestWrapper {
    private final byte[] body;
    private String parameters;
 
    public WebHttpServletRequestWrapper(HttpServletRequest request) throws IOException {
        super(request);
        parameters = HttpRequestUtil.getBodyContent(request);
        body = parameters.getBytes(Charset.forName("UTF-8"));
    }
 
    /**
     * 获取requestBody中读取的参数
     * @author Tan Ling
     * @date 2019年9月12日 上午9:54:35
     * @return
     */
    public String getRequestParams() {
    	return this.parameters;
    }
    
    @Override
    public BufferedReader getReader() throws IOException {
        return new BufferedReader(new InputStreamReader(getInputStream()));
    }
 
    @Override
    public ServletInputStream getInputStream() throws IOException {
        final ByteArrayInputStream bais = new ByteArrayInputStream(body);
        return new ServletInputStream() {
            @Override
            public int read() throws IOException {
                return bais.read();
            }
 
            @Override
            public boolean isFinished() {
                return false;
            }
 
            @Override
            public boolean isReady() {
                return false;
            }
 
            @Override
            public void setReadListener(ReadListener readListener) {
 
            }
        };
    }
}
