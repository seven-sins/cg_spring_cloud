package com.infox.tourism.service.v2.traffic.impl;

import com.infox.tourism.entity.traffic.TrafficMode;
import com.infox.tourism.mapper.traffic.TrafficModeMapper;
import com.infox.tourism.service.v2.traffic.TrafficModeService;
import com.infox.tourism.util.UUIDUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

/**
 * @Author: Xiao Ming
 * @Date: 2019/7/30 11:44
 * @Version 1.0
 */
@Service
public class TrafficModeServiceImpl implements TrafficModeService {

    @Autowired
    private TrafficModeMapper trafficModeMapper;

    @Override
    public List<TrafficMode> find(int pageNum, int pageSize, String orderBy, TrafficMode entity) {
        return null;
    }

    @Override
    public TrafficMode get(String id) {
        return null;
    }

    @Override
    public void insert(TrafficMode entity) {

        entity.setTrafficId(UUIDUtil.create());
        entity.setCreateTime(new Date());

        trafficModeMapper.insert(entity);
    }

    @Override
    public void update(TrafficMode entity) {

        entity.setUpdateTime(new Date());

        trafficModeMapper.updateTrafficMode(entity);

    }

    @Override
    public void deleteById(String id) {
        trafficModeMapper.deleteTrafficMode(id);
    }

    /**
     * 查询交通方式下拉列表
     * @param trafficMode
     * @return
     */
    @Override
    public List<TrafficMode> getTrafficList(TrafficMode trafficMode) {
        return trafficModeMapper.selectTrafficList(trafficMode);
    }

    @Override
    public void addTrafficListByActivityOrLine(TrafficMode trafficMode, String id, int type) {

        trafficMode.setTrafficId(UUIDUtil.create());
        trafficMode.setCreateTime(new Date());
        trafficMode.setTrafflicModeType(type);

        if (type == 1){

            trafficMode.setLineId(id);

        } else if (type == 2){

            trafficMode.setActivityId(id);

        }

        trafficModeMapper.insert(trafficMode);

    }

    @Override
    public void deleteTrafficModeByActivityOrLine(String id, int type) {

        if (type == 1){

            trafficModeMapper.deleteTrafficModeByLineId(id);

        } else if (type == 2){

            trafficModeMapper.deleteTrafficModeByActivityId(id);

        }

    }

    @Override
    public List<TrafficMode> selectTrafficListByLineId(String id) {
        return trafficModeMapper.selectTrafficListByLineId(id);
    }

}