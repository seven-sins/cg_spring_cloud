package com.infox.tourism.service;

import java.util.List;

import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.entity.TravelsEntity;
import com.infox.tourism.entity.vo.travelsVO.TravelsVo;

/**
 * 游记表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-21 19:46:05
 */
public interface TravelsService {

	/**
	 * 查询分页
	 * 
	 * @param pageNum  下一页
	 * @param pageSize 显示的长度
	 * @param search   搜索
	 * @return
	 */
	List<TravelsVo> queryPage(int pageNum, int pageSize, String userId);

	/**
	 * 查询我的游记分页
	 * 
	 * @return
	 */
	List<TravelsVo> myTravelsList(int pageNum, int pageSize, String userId);

	/**
	 * 根据id查询
	 * 
	 * @param travelsId
	 * @return
	 */
	TravelsVo selectById(String userId, String travelsId);

	/**
	 * 保存
	 * 
	 * @param TravelsEntity
	 * @return
	 */
	boolean insert(TravelsEntity TravelsEntity, AuthUser user);

	/**
	 * 审批
	 */
	boolean approveById(TravelsEntity TravelsEntity);

	/**
	 * 根据id修改
	 */
	boolean updateById(TravelsEntity TravelsEntity, AuthUser user);

	/**
	 * 转发
	 */
	boolean updateRelay(TravelsEntity TravelsEntity);

	/**
	 * 删除全部
	 * 
	 * @param ids
	 * @return
	 */
	boolean deleteList(TravelsEntity TravelsEntity);
}
