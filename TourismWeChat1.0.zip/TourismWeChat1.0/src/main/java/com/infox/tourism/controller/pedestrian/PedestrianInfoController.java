package com.infox.tourism.controller.pedestrian;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infox.common.utils.Assert;
import com.infox.tourism.entity.PedestrianInfoEntity;
import com.infox.tourism.service.PedestrianInfoService;
import com.infox.tourism.util.R;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 出行人控制器
 * @author Tan Ling
 * @date 2019年1月16日 下午2:58:42
 */
@Api(description = "出行人")
@RestController
@RequestMapping("/pedestrian")
public class PedestrianInfoController {

	@Autowired
	private PedestrianInfoService pedestrianInfoService;
	
	@ApiOperation(value = "列表", response = PedestrianInfoEntity.class)
	@GetMapping("/list/{orderId}")
	public R list(@PathVariable("orderId") String orderId) {
		return R.ok().put("data", pedestrianInfoService.findByOrderId(orderId));
	}

	@ApiOperation(value = "出行人列表", response = PedestrianInfoEntity.class)
	@GetMapping("/pedestrianList/{orderId}")
	public R pedestrianList(@PathVariable("orderId") String orderId) {
		return R.ok().put("data", pedestrianInfoService.findByOrderIdList(orderId));
	}
	
	@ApiOperation(value = "申请退款")
	@PostMapping("/apply/{pedestrianId}")
	public R apply(@PathVariable("pedestrianId") String pedestrianId) {
		PedestrianInfoEntity pedestrianInfo = pedestrianInfoService.get(pedestrianId);
		Assert.notNull(pedestrianInfo, "数据异常, 出行人不存在");
		/**
		 * (1:正常,2:已改期,3:退款,4:申请退款)
		 */
		Assert.isTrue(pedestrianInfo.getPedestrianStatus() != null && pedestrianInfo.getPedestrianStatus() != 2, "操作失败, 出行人已改期");
		Assert.isTrue(pedestrianInfo.getPedestrianStatus() != null && pedestrianInfo.getPedestrianStatus() != 3, "操作失败, 出行人已退款");
		Assert.isTrue(pedestrianInfo.getPedestrianStatus() != null && pedestrianInfo.getPedestrianStatus() != 4, "操作失败, 出行人已经申请过退款");
		//
		pedestrianInfoService.updatePedestrianStatus(pedestrianId, 4);
		
		return R.success();
	}
	
	@ApiOperation(value = "取消申请")
	@PostMapping("/cancelApply/{pedestrianId}")
	public R cancelApply(@PathVariable("pedestrianId") String pedestrianId) {
		PedestrianInfoEntity pedestrianInfo = pedestrianInfoService.get(pedestrianId);
		Assert.notNull(pedestrianInfo, "数据异常, 出行人不存在");
		/**
		 * (1:正常,2:已改期,3:退款,4:申请退款)
		 */
		Assert.isTrue(pedestrianInfo.getPedestrianStatus() != null && pedestrianInfo.getPedestrianStatus() == 4, "操作失败, 出行人未申请过退款");
		pedestrianInfoService.updatePedestrianStatus(pedestrianId, 1);
		
		return R.success();
	}
	
	@ApiOperation(value="修改签到")
	@PostMapping("/signin/{pedestrianId}")
	public R updateIsSignin(@PathVariable("pedestrianId") String pedestrianId) {
		pedestrianInfoService.updateIsSignin(pedestrianId);
		return R.success();
	}
	
	@ApiOperation(value="查询用户签到")
	@GetMapping("/queryUsers/{activityId}")
	public R findByActivityId(@PathVariable("activityId") String activityId) {
		List<PedestrianInfoEntity> list=pedestrianInfoService.findByActivityId(activityId);
		return R.ok().put("data", list);
		}
}
	
