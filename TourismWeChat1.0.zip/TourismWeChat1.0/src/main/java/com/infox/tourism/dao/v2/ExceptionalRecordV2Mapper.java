package com.infox.tourism.dao.v2;

import java.math.BigDecimal;
import org.apache.ibatis.annotations.Mapper;

/**
 * 打赏金额总数
 * @author yuanfang
 * 2019年5月14日 上午10:55:42
 */
@Mapper
public interface ExceptionalRecordV2Mapper {

	/**
	 * 打赏金额总数
	 */
	BigDecimal queryNumErMoney(String userId);
}
