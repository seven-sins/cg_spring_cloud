package com.infox.tourism.service;

import java.util.List;

import com.infox.common.base.BaseService;
import com.infox.tourism.entity.LineTypeEntity;
import com.infox.tourism.entity.vo.lineVO.LineTypeVO;

/**
 * 路线分类表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-06 17:14:57
 */
public interface LineTypeService extends BaseService<LineTypeEntity> {

    List<LineTypeVO> selectAllLineType();

    List<LineTypeVO> selectTop3LineType();
}

