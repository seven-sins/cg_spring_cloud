package com.infox.tourism.service.impl;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infox.common.base.impl.BaseServiceImpl;
import com.infox.common.utils.Assert;
import com.infox.tourism.dao.DurationScopeMapper;
import com.infox.tourism.entity.DurationScope;
import com.infox.tourism.service.DurationScopeService;
import com.infox.tourism.util.UUIDUtil;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 活动时长范围
 * @author Tan Ling
 * @date 2019年1月24日 上午9:39:24
 */
@Service
public class DurationScopeServiceImpl extends BaseServiceImpl<DurationScope> implements DurationScopeService {
	
	@Autowired
	private DurationScopeMapper durationScopeMapper;
	
	@Resource
	public void setBaseMapper(BaseMapper<DurationScope> durationScopeMapper) {
		this.baseMapper = durationScopeMapper;
	}

	@Override
	public void deleteById(String id) {
		Integer count = durationScopeMapper.checkUsed(id);
		Assert.isTrue(count == null || count == 0, "数据被使用不能删除");
		
		durationScopeMapper.deleteByDurationScopeId(id);
	}
	
	@Override
	public void insert(DurationScope entity) {
		Assert.isTrue(durationScopeMapper.getByDurationScope(entity.getDurationScope()) == null, "时长范围已存在");
		entity.setDurationScopeId(UUIDUtil.create());
		entity.setIsDelete(0);
		
		baseMapper.insert(entity);
	}
	
	@Override
	public void update(DurationScope entity) {
		DurationScope dbData = durationScopeMapper.getByDurationScope(entity.getDurationScope());
		Assert.isTrue(dbData.getDurationScopeId().equals(entity.getDurationScopeId()), "时长范围已存在");
		
		baseMapper.updateByPrimaryKeySelective(entity);
	}
	
}
