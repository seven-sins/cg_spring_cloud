package com.infox.tourism.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.infox.tourism.entity.DestinationInfoEntity;
import com.infox.tourism.entity.vo.indexVO.DestinationIndexVO;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 目的地维护表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-06 17:10:28
 */
@Mapper
public interface DestinationDao extends BaseMapper<DestinationInfoEntity> {

    /**
     * 分页查询目的地
     * @return
     */
    List<DestinationIndexVO> queryPage(@Param("destinationId") String destinationId);

}
