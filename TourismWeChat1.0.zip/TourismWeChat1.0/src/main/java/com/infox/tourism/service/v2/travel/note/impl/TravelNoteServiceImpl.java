package com.infox.tourism.service.v2.travel.note.impl;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infox.common.base.impl.BaseServiceImpl;
import com.infox.common.utils.Assert;
import com.infox.common.utils.redis.RedisService;
import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.config.resolver.Guest;
import com.infox.tourism.entity.UserInfoEntity;
import com.infox.tourism.entity.travel.note.TravelNote;
import com.infox.tourism.entity.travel.note.TravelNoteCollect;
import com.infox.tourism.entity.travel.note.TravelNoteDetail;
import com.infox.tourism.entity.travel.note.TravelNoteLike;
import com.infox.tourism.mapper.travel.note.TravelNoteCollectMapper;
import com.infox.tourism.mapper.travel.note.TravelNoteDetailMapper;
import com.infox.tourism.mapper.travel.note.TravelNoteLikeMapper;
import com.infox.tourism.mapper.travel.note.TravelNoteMapper;
import com.infox.tourism.service.v2.travel.note.TravelNoteService;
import com.infox.tourism.util.UUIDUtil;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 游记
 * @author Tan Ling
 * @date 2019年7月5日 下午3:32:03
 */
@Service
public class TravelNoteServiceImpl extends BaseServiceImpl<TravelNote> implements TravelNoteService {
	static final String USER_LIKE_PREFIX = "user_like_";
	static final String USER_COLLECT_PREFIX = "user_collect_";
	@Autowired
	TravelNoteMapper travelNoteMapper;
	@Autowired
	TravelNoteDetailMapper travelNoteDetailMapper;
	@Autowired
	TravelNoteCollectMapper travelNoteCollectMapper;
	@Autowired
	TravelNoteLikeMapper travelNoteLikeMapper;
	@Autowired
	RedisService redisService;
	
	@Resource
	@Override
	public void setBaseMapper(BaseMapper<TravelNote> baseMapper) {
		this.baseMapper = baseMapper;
	}
	
	@Override
	public void insert(TravelNote travelNote) {
		travelNote.setCommentNum(0);
		travelNote.setShareNum(0);
		travelNote.setLikeNum(0);
		travelNote.setViewNum(0);
		travelNote.setCollectNum(0);
		// 状态, 1:草稿, 2:提交审核, 3:审核通过
		travelNote.setStatus(travelNote.getStatus() == null ? 1 : travelNote.getStatus() == 1 ? 1 : 2);
		travelNote.setTravelNoteId(UUIDUtil.create());
		travelNote.setCreateTime(new Date());
		travelNoteMapper.insert(travelNote);
		// 
		for(TravelNoteDetail item: travelNote.getList()) {
			Assert.isTrue(StringUtils.isNotBlank(item.getTravelImg()) || StringUtils.isNotBlank(item.getTravelText()), "图片和文字不能同时为空");
			item.setSorting(System.currentTimeMillis());
			item.setTravelNoteDetailId(UUIDUtil.create());
			item.setTravelNoteId(travelNote.getTravelNoteId());
			travelNoteDetailMapper.insert(item);
		}
	}
	
	@Override
	public void update(TravelNote travelNote) {
		/**
		 * 数据验证
		 */
		TravelNote dbData = travelNoteMapper.selectByPrimaryKey(travelNote.getTravelNoteId());
		Assert.notNull(dbData, "参数错误, 游记不存在");
		Assert.isTrue(dbData.getStatus() != 2, "游记已提交审核不能修改");
		Assert.isTrue(dbData.getStatus() != 3, "游记已发布不能修改");
		Assert.isTrue(travelNote.getUserId().equals(dbData.getUserId()), "游记所属用户与当前用户不一致, 拒绝访问");
		//
		travelNote.setUserId(travelNote.getUserId());
		// 状态, 1:草稿, 2:提交审核, 3:审核通过
		travelNote.setStatus(travelNote.getStatus() == null ? 1 : travelNote.getStatus() == 1 ? 1 : 2);
		/**
		 * 清空不需要修改的字段
		 */
		travelNote.setCommentNum(null);
		travelNote.setShareNum(null);
		travelNote.setLikeNum(null);
		travelNote.setViewNum(null);
		travelNote.setCollectNum(null);
		travelNote.setCreateTime(null);
		travelNote.setIsDelete(null);
		travelNote.setRejectReason("");
		travelNoteMapper.updateByPrimaryKeySelective(travelNote);
		// 先删除明细重新添加
		travelNoteDetailMapper.deleteByTravelNoteId(travelNote.getTravelNoteId());
		// 
		for(TravelNoteDetail item: travelNote.getList()) {
			item.setSorting(System.currentTimeMillis());
			item.setTravelNoteDetailId(UUIDUtil.create());
			item.setTravelNoteId(travelNote.getTravelNoteId());
			travelNoteDetailMapper.insert(item);
		}
	}

	@Override
	public List<TravelNote> find(TravelNote travelNote, Guest guest) {
		List<TravelNote> list = travelNoteMapper.find(travelNote);
		if(list != null && !list.isEmpty() && StringUtils.isNotBlank(guest.getUserId())) {
			List<TravelNoteLike> likeList = this.findUserLike(guest.getUserId());
			List<TravelNoteCollect> collectList = this.findUserCollect(guest.getUserId());
			for(TravelNote item: list) {
				this.markStatus(item, collectList, likeList);
			}
		}
		
		return list;
	}

	/**
	 * 标记收藏和点赞状态
	 * @author Tan Ling
	 * @date 2019年7月8日 上午9:19:38
	 * @param travelNote
	 * @param collectList
	 * @param likeList
	 */
	private void markStatus(TravelNote travelNote, List<TravelNoteCollect> collectList, List<TravelNoteLike> likeList) {
		// 标记收藏状态
		if(collectList != null && !collectList.isEmpty()) {
			for(TravelNoteCollect item: collectList) {
				if(travelNote.getUserId().equals(item.getUserId()) && travelNote.getTravelNoteId().equals(item.getTravelNoteId())) {
					travelNote.setIsCollect(1);
					break;
				}
			}
		}
		// 标记点赞状态
		if(likeList != null && !likeList.isEmpty()) {
			for(TravelNoteLike item: likeList) {
				if(travelNote.getUserId().equals(item.getUserId()) && travelNote.getTravelNoteId().equals(item.getTravelNoteId())) {
					travelNote.setIsLike(1);
					break;
				}
			}
		}
	}

	@Override
	public void addViewNum(String travelNoteId) {
		checkDbData(travelNoteId);
		travelNoteMapper.addViewNum(travelNoteId, 1);		
	}

	@Override
	public int addLikeNum(String travelNoteId, UserInfoEntity user) {
		int isLike = 0;
		TravelNote dbData = checkDbData(travelNoteId);
		if(travelNoteLikeMapper.get(travelNoteId, user.getUserId()) != null) {
			// 如已收藏, 取消
			if(dbData.getLikeNum() >= 1) {
				travelNoteMapper.addLikeNum(travelNoteId, -1);	
			}
			travelNoteLikeMapper.deleteRecord(travelNoteId, user.getUserId());
			isLike = 0;
		} else {
			// 没收藏, 添加记录
			travelNoteMapper.addLikeNum(travelNoteId, 1);	
			travelNoteLikeMapper.insert(new TravelNoteLike(travelNoteId, user.getUserId()));
			isLike = 1;
		}	
		// 清除当前用户点赞列表缓存
		redisService.delete(USER_LIKE_PREFIX + user.getUserId());
		
		return isLike;
	}

	@Override
	public void addShareNum(String travelNoteId) {
		checkDbData(travelNoteId);
		travelNoteMapper.addShareNum(travelNoteId, 1);		
	}

	@Override
	public void addCommentNum(String travelNoteId) {
		checkDbData(travelNoteId);
		travelNoteMapper.addCommentNum(travelNoteId, 1);		
	}

	@Override
	public void deleteById(String travelNoteId) {
		travelNoteMapper.deleteByPrimaryKey(travelNoteId);
		travelNoteDetailMapper.deleteByTravelNoteId(travelNoteId);
	}

	@Override
	public int addCollectNum(String travelNoteId, UserInfoEntity user) {
		int isCollect = 0;
		TravelNote dbData = checkDbData(travelNoteId);
		if(travelNoteCollectMapper.get(travelNoteId, user.getUserId()) != null) {
			// 如已收藏, 取消
			if(dbData.getCollectNum() >= 1) {
				travelNoteMapper.addCollectNum(travelNoteId, -1);	
			}
			travelNoteCollectMapper.deleteRecord(travelNoteId, user.getUserId());
			isCollect = 0;
		} else {
			// 没收藏, 添加记录
			travelNoteMapper.addCollectNum(travelNoteId, 1);	
			travelNoteCollectMapper.insert(new TravelNoteCollect(travelNoteId, user.getUserId()));
			isCollect = 1;
		}
		// 清除当前用户收藏列表缓存
		redisService.delete(USER_COLLECT_PREFIX + user.getUserId());
		
		return isCollect;
	}
	
	private TravelNote checkDbData(String travelNoteId) {
		TravelNote dbData = travelNoteMapper.selectByPrimaryKey(travelNoteId);
		Assert.notNull(dbData, "参数错误, 游记不存在");
		
		return dbData;
	}

	@Override
	public TravelNote getByTravelNoteId(String travelNoteId, Guest guest) {
		// 查询主体信息
		TravelNote query = new TravelNote();
		query.setTravelNoteId(travelNoteId);
		List<TravelNote> list = travelNoteMapper.find(query);
		if(list == null || list.isEmpty()) {
			return null;
		}
		// 返回主体信息
		TravelNote travelNote = list.get(0);
		
		TravelNoteDetail travelNoteDetail = new TravelNoteDetail();
		travelNoteDetail.setTravelNoteId(travelNote.getTravelNoteId());
		travelNote.setList(travelNoteDetailMapper.find(travelNoteDetail));
		// 标记收藏和点赞状态
		List<TravelNoteLike> likeList = this.findUserLike(guest.getUserId());
		List<TravelNoteCollect> collectList = this.findUserCollect(guest.getUserId());
		this.markStatus(travelNote, collectList, likeList);
		
		return travelNote;
	}
	
	@SuppressWarnings("unchecked")
	private List<TravelNoteLike> findUserLike(String userId){
		List<TravelNoteLike> list = (List<TravelNoteLike>) redisService.get(USER_LIKE_PREFIX + userId);
		if(list != null) {
			return list;
		}
		list = travelNoteLikeMapper.find(userId);
		if(list == null || list.isEmpty()) {
			return null;
		}
		redisService.add(USER_LIKE_PREFIX + userId, list, 600);
		
		return list;
	}
	
	@SuppressWarnings("unchecked")
	private List<TravelNoteCollect> findUserCollect(String userId){
		List<TravelNoteCollect> list = (List<TravelNoteCollect>) redisService.get(USER_COLLECT_PREFIX + userId);
		if(list != null) {
			return list;
		}
		list = travelNoteCollectMapper.find(userId);
		if(list == null || list.isEmpty()) {
			return null;
		}
		redisService.add(USER_COLLECT_PREFIX + userId, list, 600);
		
		return list;
	}

	@Override
	public void deleteByTravelNoteId(String travelNoteId) {
		travelNoteMapper.deleteByTravelNoteId(travelNoteId);
	}

	@Override
	public List<TravelNote> collectList(TravelNote travelNote, AuthUser user) {
		travelNote.setUserId(user.getUserId());
		List<TravelNote> list = travelNoteMapper.collectList(travelNote);
		if(list != null && !list.isEmpty() && StringUtils.isNotBlank(user.getUserId())) {
			List<TravelNoteLike> likeList = this.findUserLike(user.getUserId());
			List<TravelNoteCollect> collectList = this.findUserCollect(user.getUserId());
			for(TravelNote item: list) {
				this.markStatus(item, collectList, likeList);
			}
		}
		
		return list;
	}
}
