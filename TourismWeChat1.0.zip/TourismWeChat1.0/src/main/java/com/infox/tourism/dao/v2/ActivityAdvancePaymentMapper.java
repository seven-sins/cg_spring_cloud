package com.infox.tourism.dao.v2;

import org.apache.ibatis.annotations.Mapper;

import com.infox.tourism.entity.v2.activityadvancepayment.ActivityAdvancePayment;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 预付款
 * @author Tan Ling
 * 2019年1月7日 下午2:21:10
 */
@Mapper
public interface ActivityAdvancePaymentMapper extends BaseMapper<ActivityAdvancePayment> {
    
	/**
	 * 根据主键更新
	 * @param activityAdvancePayment
	 */
	public void updateByActivityAdvancePaymentId(ActivityAdvancePayment activityAdvancePayment);
}