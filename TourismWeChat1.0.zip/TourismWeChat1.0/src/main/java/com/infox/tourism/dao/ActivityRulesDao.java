package com.infox.tourism.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.infox.tourism.entity.ActivityRulesEntity;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 活动规则表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-15 10:36:29
 */
@Mapper
public interface ActivityRulesDao extends BaseMapper<ActivityRulesEntity> {

    /**
    * 查询分页
    * @return
    */
    List<ActivityRulesEntity> queryPage(String search);

    /**
     * 更新活动规则
     * @param activityRulesEntity
     * @return
     */
    Integer updateActivityRules(ActivityRulesEntity activityRulesEntity);

    /**
     * 根据活动id查询是否有这个活动存在
     * @param activityId
     * @return
     */
    ActivityRulesEntity selectByActivityId(String activityId);


    /**
     * 删除全部
     * @param activityRulesEntity
     * @return
     */
    boolean deleteList(ActivityRulesEntity activityRulesEntity);

}
