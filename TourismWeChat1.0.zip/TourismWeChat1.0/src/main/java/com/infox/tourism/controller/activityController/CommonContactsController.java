package com.infox.tourism.controller.activityController;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageInfo;
import com.infox.common.utils.Assert;
import com.infox.common.utils.IdcardUtil;
import com.infox.common.utils.ValidationUtil;
import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.entity.CommonContacts;
import com.infox.tourism.entity.PedestrianInfoEntity;
import com.infox.tourism.service.CommonContactsService;
import com.infox.tourism.util.R;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import springfox.documentation.annotations.ApiIgnore;

/**
 * 常用联系人控制器
 * @author Tan Ling
 * 2018年12月5日 下午3:59:57
 */
@RestController
@Api(description = "常用联系人")
@RequestMapping("/commonContacts")
public class CommonContactsController {

	@Autowired
	CommonContactsService commonContactsService;
	
	@ApiOperation(value = "列表", response = CommonContacts.class)
	@GetMapping("/list")
	public R list(
				@RequestParam(value = "pageNum") int pageNum, 
				@RequestParam(value = "pageSize") int pageSize, 
				@ApiParam CommonContacts commonContacts, 
				@ApiIgnore AuthUser user) {
		// 设置查询条件userId, 用户只能获取自己的常用联系人
		commonContacts.setUserId(user.getUserId());
		List<CommonContacts> list = commonContactsService.find(pageNum, pageSize, "create_time desc", commonContacts);
		
		return R.ok().put("data", list).put("total", new PageInfo<CommonContacts>(list).getTotal());
	}
	
	@ApiOperation(value = "列表", response = CommonContacts.class)
	@PostMapping("/findInId")
	public R list(@ApiIgnore AuthUser user, @RequestBody Map<String, ?> map) {
		String ids = (String) map.get("ids");
		if(StringUtils.isBlank(ids)) {
			return R.ok().put("data", new ArrayList<>()).put("total", 0);
		}
		// 设置查询条件userId, 用户只能获取自己的常用联系人
		List<CommonContacts> list = commonContactsService.findInId(user.getUserId(), ids.split(","));
		
		return R.ok().put("data", list).put("total", new PageInfo<CommonContacts>(list).getTotal());
	}
	
	@ApiOperation("新增")
	@PostMapping("/insert")
	public R insert(@Valid @RequestBody CommonContacts commonContacts, @ApiIgnore AuthUser user) { 
		commonContacts.setUserId(user.getUserId());
		// 检查身份证号码是否重复
		commonContactsService.checkIdCard(user.getUserId(), commonContacts.getIdCard(), null, commonContacts.getCertificateType());
		
		// 如果证件类型是身份证, 从身份证中解析年龄
		if(commonContacts.getCertificateType() == PedestrianInfoEntity.IDCATD) {
			commonContacts.setAge(IdcardUtil.getAgeFromIdCard(commonContacts.getIdCard()));
			commonContacts.setSex(IdcardUtil.getSexFromIdCard(commonContacts.getIdCard()));
			commonContacts.setBirthday(IdcardUtil.getBirthdayFromIdCard(commonContacts.getIdCard()));
		} else {
			Assert.notNull(commonContacts.getSex(), commonContacts.getContactsName() + "性别不能为空");
			Assert.notNull(commonContacts.getBirthday(), commonContacts.getContactsName() + "出生日期不能为空");
			commonContacts.setAge(IdcardUtil.getAgeFromBirthday(commonContacts.getBirthday()));
		}
		
		commonContactsService.insert(commonContacts);
		
		return R.ok();
	}
	
	@ApiOperation("修改")
	@PostMapping("/update/{commonContactsId}")
	public R update(@PathVariable("commonContactsId") String commonContactsId, @Valid @RequestBody CommonContacts commonContacts, @ApiIgnore AuthUser user) { 
		// 检查身份证号码是否重复
		commonContactsService.checkIdCard(user.getUserId(), commonContacts.getIdCard(), commonContactsId, commonContacts.getCertificateType());
		
		commonContacts.setUserId(user.getUserId());
		commonContacts.setCommonContactsId(commonContactsId);
		commonContacts.setUpdateTime(new Date());
		commonContacts.setUpdateBy(user.getUserId());
		commonContactsService.updateByContactId(commonContacts);
		
		return R.ok();
	}
	
	@ApiOperation("批量新增")
	@PostMapping("/batchInsert")
	public R insert(@RequestBody List<CommonContacts> list, @ApiIgnore AuthUser user) { 
		ValidationUtil.validList(list);
		commonContactsService.insert(user, list);
		
		return R.ok();
	}
	
	@ApiOperation("删除")
	@PostMapping("/delete/{commonContactsId}")
	public R delete(@PathVariable("commonContactsId") String commonContactsId) {
		commonContactsService.deleteByContactsId(commonContactsId);
		
		return R.ok();
	}
}
