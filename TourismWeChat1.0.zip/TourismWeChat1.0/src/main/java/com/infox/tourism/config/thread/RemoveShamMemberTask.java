package com.infox.tourism.config.thread;

import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;

import com.infox.tourism.service.OrderInfoService;

/**
 * (后台线程)修改活动状态
 * @author Tan Ling
 * @date 2019年1月14日 下午1:40:32
 */
@Component
public class RemoveShamMemberTask implements ApplicationListener<ApplicationReadyEvent>, Ordered {
	private static final Logger LOG = LoggerFactory.getLogger(RemoveShamMemberTask.class);
	@Autowired
	private OrderInfoService orderInfoService;
	
	@Override
	public int getOrder() {
		return 999;
	}

	@Override
	public void onApplicationEvent(ApplicationReadyEvent event) {
		new RemoveShamMemberThread(orderInfoService).start();
	}
	
	public class RemoveShamMemberThread extends Thread {
		private Integer intervalTime = 30;
		private OrderInfoService orderInfoService;
		
		@Override
		public void run() {
			while(true) {
				try {
					intervalTime = new Random().nextInt(100) + 70;
					Thread.sleep(intervalTime * 60 * 1000);
					LOG.info("=============删除虚假会员");
					orderInfoService.removeShamMember();
				}catch(Exception e) {
					LOG.error("=============删除虚假会员后台线程出错");
					e.printStackTrace();
				}
			}
		}
		
		public RemoveShamMemberThread() {
			
		}
		
		public RemoveShamMemberThread(OrderInfoService orderInfoService) {
			this.orderInfoService = orderInfoService;
		}
	}
}

