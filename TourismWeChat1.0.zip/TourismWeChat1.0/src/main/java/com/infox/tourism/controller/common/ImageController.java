package com.infox.tourism.controller.common;

import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.infox.common.utils.Assert;
import com.infox.common.utils.IdMaker;
import com.infox.common.utils.response.Result;
import com.infox.common.wechat.utils.ImageDownload;

/**
 * 图片下载
 * @author rex.tan
 * @date 2019年9月16日 下午4:39:17
 */
@RestController
public class ImageController {
	/**
	 * 上传存储图片地址
	 */
	@Value("${upload.path}")
	private String uploadPath;
	/**
	 * 上传后图片访问地址
	 */
	@Value("${upload.url2}")
	private String uploadUrl;
	
	@PostMapping("/downloadImage")
	public Result<String> downloadImage(@RequestBody Map<String, String> map){
		Assert.notEmpty(map.get("url"), "url不能为空");
		String fileName = IdMaker.getStringKey() + ".jpg";
		ImageDownload.download(map.get("url"), uploadPath + fileName);
		
		return new Result<>(uploadUrl + fileName);
	}
}
