package com.infox.tourism.service.signIn.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.infox.tourism.entity.integral.IntegralLog;
import com.infox.tourism.entity.signin.SignInEntity;
import com.infox.tourism.mapper.integral.IntegralLogMapper;
import com.infox.tourism.mapper.signin.SignInMapper;
import com.infox.tourism.service.signIn.SignInService;
import com.infox.tourism.util.UUIDUtil;

/**
 * @Author: Xiao Ming
 * @Date: 2019/7/10 14:34
 * @Version 1.0
 */
@Service
@Component
public class SignInServiceImpl implements SignInService {
    @Autowired
    private SignInMapper signInMapper;
    @Autowired
    private IntegralLogMapper integralLogMapper;

    @Value("${sign-in.integral}")
    private int integral;

    @Value("${sign-in.daysintegral1}")
    private int daysIntegral1;

    @Value("${sign-in.daysintegral2}")
    private int daysIntegral2;

    @Value("${sign-in.daysintegral3}")
    private int daysIntegral3;

    @Override
    public List<SignInEntity> find(int pageNum, int pageSize, String orderBy, SignInEntity entity) {
        return null;
    }

    @Override
    public SignInEntity get(String id) {
        return null;
    }

    @Override
    public void insert(SignInEntity entity) {
        signInMapper.insert(entity);
    }

    @Override
    public void update(SignInEntity entity) {

    }

    @Override
    public void deleteById(String id) {

    }

    /**
     * 用户签到
     * @param userId
     */
    @Override
    public void addUserSignIn(String userId, Date date) {
        SignInEntity signInEntity = new SignInEntity();
        IntegralLog integralLog = new IntegralLog();
        Date nowDate = date;
        signInEntity.setSignInId(UUIDUtil.create());
        signInEntity.setSignInTime(nowDate);
        signInEntity.setUserId(userId);
        signInEntity.setIsReset(0);

        integralLog.setIntegralLogId(UUIDUtil.create());
        integralLog.setIntegralType(1);
        integralLog.setUserId(userId);
        integralLog.setCreateTime(date);

        int max = 30;
        List<Integer> newList = new ArrayList<>();
        newList.add(7);
        newList.add(15);
        newList.add(max);
        List<SignInEntity> list = signInMapper.selectUserSignInByDay(userId, max, date);
        /**
         * 获取连续签到天数
         */
        int signInDay = this.getContinuousSignInDay(list, date);
        
        //
        int current = 0;
        for (Integer days: newList){
			if(days - 1 == signInDay) {
				current = days;
			}
        }

        signInEntity.setSignInDays(current);
        //插入签到用户
        signInMapper.insert(signInEntity);
        integralLogMapper.insert(integralLog);
        /**
         * 连续签到达到最大天数时重置
         */
        if(current == max) {
        	signInMapper.reset(userId);
        }
    }
    /**
     * 判断日期是否连续
     * @author Tan Ling
     * @date 2019年7月22日 上午11:24:46
     * @param signInEntities
     * @return
     */
    private int getContinuousSignInDay(List<SignInEntity> list, Date currentDate) {
    	int signInDays = 0;
    	if(list == null || list.isEmpty()) {
    		return signInDays++;
    	}
    	
    	Calendar preDate = Calendar.getInstance();
    	preDate.setTime(currentDate);
    	for(SignInEntity item: list) {
    		preDate.add(Calendar.DATE, -1);
			if(!(preDate.getTime().getTime() == item.getSignInTime().getTime())) {
				return signInDays++;
			} else {
				signInDays++;
			}
    	}
    	
    	return signInDays;
    }

    @Override
    public SignInEntity selectUserSignInByDate(String userId, Date signInTime) {
        return signInMapper.selectUserSignInByDate(userId, signInTime);
    }

}