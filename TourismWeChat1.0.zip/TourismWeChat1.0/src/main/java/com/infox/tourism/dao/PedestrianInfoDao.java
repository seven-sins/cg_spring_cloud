package com.infox.tourism.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.infox.tourism.entity.PedestrianInfoEntity;
import com.infox.tourism.entity.vo.activityDetailVO.TripPeopleVO;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 出行人表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-19 16:02:59
 */
@Mapper
public interface PedestrianInfoDao extends BaseMapper<PedestrianInfoEntity> {

	/**
	  * 查询活动参与人数
	 * @param activityId
	 * @return
	 */
	Integer getCountByActivityId(@Param("activityId") String activityId);
	
	/**
	  * 查询订单下的出行人数量
	 * @param orderId
	 * @return
	 */
	Integer getCountByOrderId(@Param("orderId") String orderId);
	
	/**
	 * 查询订单下出行人数量
	 * @author Tan Ling
	 * @date 2019年4月18日 上午9:30:45
	 * @param orderId
	 * @return
	 */
	Integer getTotalCountByOrderId(@Param("orderId") String orderId);
	
	/**
	  * 查询虚假会员数量
	 * @param activityId
	 * @return
	 */
	Integer getShamCountByActivityId(@Param("activityId") String activityId);
	
	/**
	  * 查询指定活动指定数量的虚假会员
	 * @param activityId
	 * @param size
	 * @return
	 */
	List<PedestrianInfoEntity> findShamList(@Param("activityId") String activityId, @Param("size") Integer size);
	
	/**
	  * 查询某个订单下的出行人列表
	 * @param activityId
	 * @return
	 */
	List<PedestrianInfoEntity> findByOrderId(@Param("orderId") String orderId);
	/**
	 * 修改出行人状态
	 * @param pedestrianId
	 * @param deleteStatus
	 */
	void updatePedestrianInfoStatus(@Param("pedestrianId") String pedestrianId, @Param("deleteStatus") Integer deleteStatus);

	/**
	 * 根据订单id删除出行人
	 * @param pedestrianInfoEntity
	 * @return
	 */
	boolean deleteByOrderId(PedestrianInfoEntity pedestrianInfoEntity);
	/**
	 * 使用身份证号和活动ID查询
	 * @param activityId
	 * @param idCard
	 * @return
	 */
	int selectPedestrianCountByActivityIdAndIdCard(@Param("activityId") String activityId, @Param("idCard") String idCard);
	/**
	 * 查询出行人(报名人及出行人总的数量)
	 * @param activityId
	 * @return
	 */
	List<TripPeopleVO> selectPedestrianInfoByActivityId(@Param("activityId") String activityId);
	/**
	 * 更新出行人状态
	 * (1:正常,2:已改期,3:退款,4:申请退款)
	 * @author Tan Ling
	 * @date 2019年1月16日 下午3:17:21
	 * @param pedestrianId
	 * @param pedestrianStatus
	 */
	void updatePedestrianStatus(@Param("pedestrianId") String pedestrianId, @Param("pedestrianStatus") Integer pedestrianStatus);
	/**
	 * 查询某个订单下的出行人列表           新接口
	 * @param orderId
	 * @return
	 */
	List<PedestrianInfoEntity> findByOrderIdList(String orderId);
	/**
	 * 查询订单下正常状态的出行人
	 * @author Tan Ling
	 * @date 2019年1月26日 下午5:52:46
	 * @param orderId
	 * @return
	 */
	List<PedestrianInfoEntity> queryPedestrianOfOrderByOrderId(@Param("orderId") String orderId,@Param("status") Integer status);
	/**
	 * 查退出的订单出行人
	 * @author Tan Ling
	 * @date 2019年1月26日 下午6:31:18
	 * @param orderId
	 * @return
	 */
	List<PedestrianInfoEntity> queryExitPedestrianOfOrderByOrderId(@Param("orderId") String orderId);
	
	/**
     * 查询出行人
     * @author Tan Ling
     * @date 2019年2月14日 下午12:02:58
     * @param pedestrianIds
     * @return
     */
    List<PedestrianInfoEntity> selectInPedestrianId(@Param("pedestrianIds") String[] pedestrianIds);
    /**
     * 批量修改状态
     * @author Tan Ling
     * @date 2019年2月14日 下午2:38:26
     * @param pedestrianIds
     * @param pedestrianStatus
     */
    void updateStatusInPedestrianIds(@Param("pedestrianIds") String[] pedestrianIds, @Param("pedestrianStatus") Integer pedestrianStatus);
    /**
     * 修改签到
     * (1：签到,0：未签到)
     */
    void updateIsSignin(@Param("pedestrianId") String pedestrianId);
    
    /**
     * 查询信息
     */
    List<PedestrianInfoEntity> findByActivityId(@Param("activityId") String activityId);
}
