package com.infox.tourism.dao;

import com.infox.tourism.entity.SpikeActivityRuleEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.BaseMapper;

import java.util.List;

/**
 * 
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2019-03-13 17:45:15
 */
@Mapper
public interface SpikeActivityRuleDao extends BaseMapper<SpikeActivityRuleEntity> {


    int deleteSpikeByActivityId(@Param("activityId") String activityId);

    /**
     * 根据活动id查询秒杀规则
     * @param activityId
     * @return
     */
    List<SpikeActivityRuleEntity> selectSpikeByActivityId(@Param("activityId") String activityId);

    List<SpikeActivityRuleEntity> selectRecentSpikeByActivityId(@Param("activityId") String activityId);
}
