package com.infox.tourism.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infox.tourism.dao.LineThemeDao;
import com.infox.tourism.entity.vo.lineVO.LineThemeVO;
import com.infox.tourism.service.LineThemeService;

/**
 * @Author Hale
 * @Date 2018/12/13
 */
@Service
public class LineThemeServiceImpl implements LineThemeService {

    @Autowired
    private LineThemeDao lineThemeDao;

    @Override
    public List<LineThemeVO> selectAllLineTheme() {
        List<LineThemeVO> list = lineThemeDao.selectAllLineTheme();
        return list;
    }

    @Override
    public List<LineThemeVO> selectIndexTheme() {
    	List<LineThemeVO> lineThemeList = lineThemeDao.selectTop3();
    	if(lineThemeList != null && !lineThemeList.isEmpty()) {
    		lineThemeList.get(0).setIsSelect(1);
    	}
    	
    	return lineThemeList;
    }
    
    @Override
    public List<LineThemeVO> selectIndexThemeV2() {
    	return lineThemeDao.selectTop8();
    }
}
