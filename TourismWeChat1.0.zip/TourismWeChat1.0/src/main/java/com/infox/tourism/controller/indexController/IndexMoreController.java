package com.infox.tourism.controller.indexController;

import com.github.pagehelper.PageHelper;
import com.infox.tourism.entity.vo.indexVO.DestinationIndexVO;
import com.infox.tourism.entity.vo.lineVO.LineDurationVO;
import com.infox.tourism.entity.vo.lineVO.LineLevelVO;
import com.infox.tourism.entity.vo.lineVO.LineThemeVO;
import com.infox.tourism.entity.vo.lineVO.LineTypeVO;
import com.infox.tourism.service.*;
import com.infox.tourism.util.ImgUtil;
import com.infox.tourism.util.R;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;

/**
 * @Author Hale
 * @Date 2018/12/13
 */
@RestController
@RequestMapping("/indexMore")
public class IndexMoreController {

    @Autowired
    private DestinationService destinationService;
    @Autowired
    private LineTypeService lineTypeService;
    @Autowired
    private LineThemeService lineThemeService;
    @Autowired
    private LineLevelService lineLevelService;
    @Autowired
    private LineDurationService lineDurationService;

    @GetMapping("/getDestinationPage")
    public R selectDestinationPage(int pageNum, int pageSize, String destination){
        // 使用分页插件实现分页
        PageHelper.startPage(pageNum, pageSize);
        List<DestinationIndexVO> list = destinationService.queryPage(destination);
        if(list != null && !list.isEmpty()) {
        	for(DestinationIndexVO item: list) {
        		item.setDUrl(ImgUtil.small(item.getDUrl()));
        	}
        }
        
        return R.ok().put("data",list);
    }

    @GetMapping("/getIndexMoreData")
    public R selectLineType(){
        HashMap<String,Object> result = new HashMap<>();
        List<LineTypeVO> type = lineTypeService.selectAllLineType();
        if(type != null && !type.isEmpty()) {
        	for(LineTypeVO item: type) {
        		item.setTypeIcon(ImgUtil.small(item.getTypeIcon()));
        	}
        }
        List<LineThemeVO> theme = lineThemeService.selectAllLineTheme();
        if(theme != null && !theme.isEmpty()) {
        	for(LineThemeVO item: theme) {
        		item.setLineThemeIcon(ImgUtil.small(item.getLineThemeIcon()));
        	}
        }
        List<LineLevelVO> level = lineLevelService.selectTop5LineLevel();
        if(level != null && !level.isEmpty()) {
        	for(LineLevelVO item: level) {
        		item.setLlIcon(ImgUtil.small(item.getLlIcon()));
        	}
        }
        List<LineDurationVO> duration = lineDurationService.selectTop6LineDuration();
        if(duration != null && !duration.isEmpty()) {
        	for(LineDurationVO item: duration) {
        		item.setUrl(ImgUtil.small(item.getUrl()));
        	}
        }
        result.put("lineType",type);
        result.put("lineTheme",theme);
        result.put("lineLevel",level);
        result.put("lineDuration",duration);
        return R.ok().put("data",result);
    }

}
