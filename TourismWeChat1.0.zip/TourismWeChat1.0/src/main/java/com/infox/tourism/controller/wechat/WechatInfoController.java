package com.infox.tourism.controller.wechat;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSONObject;
import com.infox.common.utils.Assert;
import com.infox.common.utils.redis.RedisConstant;
import com.infox.common.utils.redis.RedisService;
import com.infox.common.wechat.utils.WechatProperties;
import com.infox.tourism.util.UUIDUtil;

/**
 * 网页授权方式
 * @author Tan Ling
 * @date 2019年1月14日 下午12:59:31
 */
@RestController
public class WechatInfoController {
	private static final String OPENID_KEY = "openid";
	private static final String ACCESS_TOKEN = "access_token";
	private static final Logger LOG = Logger.getLogger(WechatInfoController.class);
	@Autowired
	private WechatProperties wechatProperties;
	@Autowired
	private RestTemplate restTemplate;
	@Autowired
	private RedisService redisService;
	//	@Autowired
	//	private AppletUtil appletUtil;
	
	@GetMapping("/getWechatUserInfo")
	public Object getWechatUserInfo() {
		String url = String.format(wechatProperties.getGetUserAccessTokenUrl(), wechatProperties.getAppId());
		LOG.info("=============url: " + url);
		return restTemplate.postForEntity(url, null, String.class);
	}
	
	@RequestMapping("/getWechatUserInfoCallback")
	public void getWechatUserInfoCallback(HttpServletResponse response, String code) throws IOException {
		LOG.info("=============code: " + code);
		String openIdUrl = String.format(wechatProperties.getGetWechatUserOpenIdUrl(), wechatProperties.getAppId(), wechatProperties.getAppSecret(), code);
		ResponseEntity<String> result = restTemplate.postForEntity(openIdUrl, null, String.class);
		Assert.notNull(result, "=============获取access_token失败...");
		
		JSONObject json = JSONObject.parseObject(result.getBody());
		LOG.info("==========获取openId: " + json);
		Assert.isTrue(json.containsKey("openid"), "=============获取openId失败, openId为空...");
		/**
		 * 生成缓存token(缓存有效时间6小时)  6小时 = 240分
		 */
		String token = UUIDUtil.create();
		// 缓存openId
		redisService.add(RedisConstant.WECHAT_OPENID_PREFIX + token, json.getString(OPENID_KEY));
		// 以openId作为key缓存access_token
		redisService.add(RedisConstant.WECHAT_USER_ACCESS_TOKEN + json.getString(OPENID_KEY), json.getString(ACCESS_TOKEN));
		
		LOG.info("=============json: " + json);
		
		response.sendRedirect(wechatProperties.getRedirectUrl() + token);
	}

	
}
