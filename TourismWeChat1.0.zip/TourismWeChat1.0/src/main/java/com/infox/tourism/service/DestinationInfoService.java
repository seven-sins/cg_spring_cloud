package com.infox.tourism.service;

import com.infox.common.base.BaseService;
import com.infox.tourism.entity.DestinationInfoEntity;

/**
 * 目的地维护表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-06 17:14:57
 */
public interface DestinationInfoService extends BaseService<DestinationInfoEntity> {
    


}

