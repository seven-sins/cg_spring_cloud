package com.infox.tourism.service;

import java.util.List;

import com.infox.common.base.BaseService;
import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.entity.CommonContacts;

public interface CommonContactsService extends BaseService<CommonContacts> {

	/**
	 * 批量新增
	 * @param user
	 * @param list
	 */
	void insert(AuthUser user, List<CommonContacts> list);
	
	/**
	 * 根据联系人ID删除
	 * @param commonContactsId
	 */
	void deleteByContactsId(String commonContactsId);

	/**
	 * 根据id查询
	 * @param userId
	 * @param ids
	 * @return
	 */
	List<CommonContacts> findInId(String userId, String[] ids);
	
	/**
	 * 更新
	 * @param commonContacts
	 */
	void updateByContactId(CommonContacts commonContacts);
	
	/**
	 * 根据身份证号查询
	 * @param userId
	 * @param idCard
	 * @return
	 */
	CommonContacts getByIdCard(String userId, String idCard);
	
	/**
	 * 检查身份证号是否重复
	 * @param userId
	 * @param idCard
	 * @param contactId
	 */
	void checkIdCard(String userId, String idCard, String contactId, Integer certificateType);
}
