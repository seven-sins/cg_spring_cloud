package com.infox.tourism.util.insurance;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.infox.common.exception.CustomException;
import com.infox.common.utils.Assert;
import com.infox.tourism.dao.ActivityInfoDao;
import com.infox.tourism.dao.InsureOrderDao;
import com.infox.tourism.dao.OrderInfoDao;
import com.infox.tourism.dao.PedestrianInfoDao;
import com.infox.tourism.entity.ActivityInfoEntity;
import com.infox.tourism.entity.InsureOrderEntity;
import com.infox.tourism.entity.OrderInfoEntity;
import com.infox.tourism.entity.PedestrianInfoEntity;

/**
  * 活动投保工具类
 * @author Tan Ling
 * 2018年12月17日 下午5:09:57
 */
@Component
public class InsuranceUtil {
	private static final Logger LOG = LoggerFactory.getLogger(InsuranceUtil.class);
	@Value("${insurance.buy}")
	private String insuranceBuy;
	@Value("${insurance.refund}")
	private String insuranceRefund;
	private RestTemplate restTemplate = new RestTemplate();
	@Autowired
	private OrderInfoDao orderInfoDao;
	@Autowired
	private ActivityInfoDao activityInfoDao;
	@Autowired
    private PedestrianInfoDao pedestrianInfoDao;
	@Autowired
	private InsureOrderDao insureOrderDao;
	/**
	  *  购买保险
	 * @param orderId
	 */
	public void buyInsurance(String orderId) {
		/**
		  * 当前方法微信支付成功，推送支付状态时调用， 不能抛异常， 加try catch
		 */
		try {
			// 查询订单信息
			OrderInfoEntity orderInfo = orderInfoDao.selectByPrimaryKey(orderId);
			Assert.notNull(orderInfo, "数据异常, 订单不存在");
			Assert.notEmpty(orderInfo.getActivityId(), "数据异常, 订单活动ID不能为空");
			// 查询订单活动信息
			ActivityInfoEntity activityInfo = activityInfoDao.selectByPrimaryKey(orderInfo.getActivityId());
			Assert.notNull(activityInfo, "数据异常, 订单不存在");
			Assert.notNull(activityInfo.getOutsetTime(), "数据异常, 活动出行日期为空");
			Assert.notNull(activityInfo.getReturnTime(), "数据异常, 活动结束日期为空");
			Assert.notEmpty(activityInfo.getInsurancesId(), "数据异常, 活动保单ID为空");
			// 查询订单出行人列表
			List<PedestrianInfoEntity> list = pedestrianInfoDao.findByOrderId(orderId);
			Assert.isTrue(list != null && !list.isEmpty(), "数据异常, 订单出行人为空");
			/**
			  * 构建投保数据
			  * 数据结构:
			 * {
				  "startDate":"2018-12-16",
				  "endDate":"2018-12-17",
				  "insurancesId":"fc95dc5e5b654c5caad77975aa603082",
				  "orderId":"123456789",
				  "destination":"中国香港",
				  "insurants":[{
				    "insureName":"郝海龙",
				    "cardCode":"350502198412211776",
				    "mobile":"15377728913"
				  },{
				    "insureName":"鞠霖一",
				    "cardCode":"450921199306278933",
				    "mobile":"15377728913"
				  },{
				    "insureName":"习敏",
				    "cardCode":"653130199106219608",
				    "mobile":"15377728913"
				  }]
				}
			*/
			// 主体信息
			JSONObject json = new JSONObject();
			json.put("startDate", this.getYearMonthDay(activityInfo.getOutsetTime()));
			json.put("endDate", this.getYearMonthDay(activityInfo.getReturnTime()));
			json.put("insurancesId", activityInfo.getInsurancesId());
			json.put("orderId", orderId);
			json.put("destination", activityInfo.getActivityName());
			// 出行人
			JSONArray array = new JSONArray();
			for(PedestrianInfoEntity item: list) {
				JSONObject people = new JSONObject();
				people.put("insureName", item.getContactPeople());
				people.put("cardCode", item.getpIdentity());
				people.put("mobile", item.getContactPhone());
				array.add(people);
			}
			// 提交
			json.put("insurants", array);
			this.buy(json);
		} catch(Exception e) {
			if(e instanceof CustomException) {
				LOG.error("============投保出错: " + ((CustomException) e).getMsg());
			}
			e.printStackTrace();
		}
	}
	
	/**
	  * 退保
	 * @param orderId
	 */
	public JSONObject refundInsurance(String orderId) {
		InsureOrderEntity insureOrder = insureOrderDao.getByOrderId(orderId);
		Assert.notNull(insureOrder, "数据异常,  保单数据为空");
		Assert.notEmpty(insureOrder.getInsureNum(), "数据异常,  投保单号为空");
		// 退保
		return this.refund(insureOrder.getInsureNum());
	}
	
	/**
	 * admin模块会处理结果, 此处只简单调用不做其他任何处理
	 * @param jsonObject
	 */
	public void buy(JSONObject jsonObject) {
		try {
			ResponseEntity<String> response = restTemplate.postForEntity(insuranceBuy, jsonObject, String.class);
			LOG.info("=============投保返回结果: " + response.getBody());
		} catch(Exception e) {
			LOG.error("=============投保出错");
			e.printStackTrace();
		}
	}
	
	public JSONObject refund(String insuranceId) {
		ResponseEntity<String> response = restTemplate.getForEntity(insuranceRefund + "?ins=" + insuranceId, null, String.class);
		LOG.info("=============退保返回结果: " + response.getBody());
		return JSONObject.parseObject(response.getBody());
	}
	
	private String getYearMonthDay(Date date) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        return sdf.format(date);
	}
	
}
