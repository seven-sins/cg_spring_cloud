package com.infox.tourism.service;

import java.util.List;

import com.infox.tourism.entity.UserInfoEntity;
import com.infox.tourism.entity.vo.couponVo.VoucherVo;
import com.infox.tourism.entity.vo.indexVO.VoucherIndexVO;

/**
 * @Description TODO
 * @Author Hale
 * @Date 2018/12/5
 */
public interface VoucherService {

	/** 查询推送的优惠券 */
	List<VoucherIndexVO> selectPushVoucher(String userId, String locationId);

	/** 一键领取优惠券 */
	void insertReceiveVoucher(UserInfoEntity user, List<String> voucherIds);

	/**
	 * 查询兑换优惠券记录
	 * 
	 * @param openId
	 * @return
	 */
	List<VoucherVo> selectVoucherReceiveByUserId(String userId);

}
