package com.infox.tourism.service;

import java.util.List;

import com.alibaba.fastjson.JSONObject;
import com.infox.tourism.entity.UserInfoEntity;
import com.infox.tourism.entity.applet.AppletUser;
import com.infox.tourism.entity.vo.UserVO.UserVO;
import com.infox.tourism.entity.vo.albumVO.FootprintVo;

/**
 * 用户表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-22 20:31:29
 */
public interface UserInfoService {

    /**
    * 查询分页
    * @param pageNum 下一页
     * @param pageSize 显示的长度
     * @param search 搜索
    * @return
    */
    List<UserInfoEntity> queryPage(int pageNum, int pageSize, String search);
    
    /**
     * 新增用户
     * @param userInfo
     */
    void insert(UserInfoEntity userInfo);

    /**
     * 根据userId查询
     * @param userId
     * @return
     */
    List<FootprintVo> selectByUserId(String userId);
    
    /**
     * 保存微信用户信息
     * json数据结构
     * {
	 * 		"country":"中国",
	 *      "province":"广东",
	 *      "city":"广州",
	 * 		"openid":"o4uepwiz1sj9J5hMK6fX4tdDOlz4","sex":1,
	 * 		"nickname":"昵称",
	 * 		"headimgurl":"http://thirdwx.qlogo.cn/mmopen/vi_32/jf8n7hYJq2FGzibISkR0H7wGMd8ic5tGCl2cmHicNf9tcKGDECic56l4dOuEOxRsaL2U7iaHYgJQcJMdYxJ4asP2pvQ/132",
	 * 		"language":"zh_CN","privilege":[]
	 * }
     * @param jsonObject
     * @return
     */
    UserInfoEntity saveWechatUser(String token, JSONObject jsonObject);
    
    /**
     * 使用openId从数据库获取用户信息, 查询失败继续调用微信接口获取
     * @param openId
     * @return
     */
    UserInfoEntity findUserInfoByOpenId(String token, String openId);
    
    /**
     * 使用openId从数据库获取用户信息
     * @param openId
     * @return
     */
    UserInfoEntity getByOpenId(String openId);

    /**
     * 根据openid查询用户页面数据
     */
    UserVO selectUserInfoByUserId(String userId);

    /**
     * 根据openId 更新用户信息
     * @param openId
     * @return
     */
    boolean updateUserInfoByUserId(UserVO userVO,String userId);

    /**
     * 更新--我的背景圖
     * @param userId
     * @param url
     * @return
     */
    Integer updateBackgroundImg(String userId, String url);
    
    /**
     * 根据unionId查询
     * @author Tan Ling
     * @date 2019年6月17日 上午11:50:35
     * @param unionId
     * @return
     */
    UserInfoEntity getByUnionId(String unionId);
    
    /**
     * 添加小程序用户
     * @author Tan Ling
     * @date 2019年6月18日 下午1:46:25
     * @param appletUser
     */
    UserInfoEntity insertAppletUser(AppletUser appletUser);

}

