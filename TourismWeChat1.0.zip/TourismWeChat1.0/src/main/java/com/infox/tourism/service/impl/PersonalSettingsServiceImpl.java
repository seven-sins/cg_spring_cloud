package com.infox.tourism.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infox.tourism.dao.PersonalSettingsDao;
import com.infox.tourism.entity.PersonalSettingsEntity;
import com.infox.tourism.service.PersonalSettingsService;
import com.infox.tourism.util.UUIDUtil;

/**
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-12-11 18:52:59
 */
@Service("personalSettingsService")
public class PersonalSettingsServiceImpl implements PersonalSettingsService {
    /**
    * personalSettingsDao层
    * @param params
    * @return
    */
    @Autowired
    private PersonalSettingsDao personalSettingsDao;

    /**
    * 查询分页
    * @return
    */
    @Override
    public PersonalSettingsEntity queryPage(String userId){
        // 查询是否有数据，如果没有，默认添加
        PersonalSettingsEntity selectByOpenId = personalSettingsDao.selectByUserId(userId);

        if (selectByOpenId == null){
            /**
             * 判断是否有设置  1 开启   2  关闭',
             */
            PersonalSettingsEntity personalSettingsEntity = new PersonalSettingsEntity();
            personalSettingsEntity.setSettingId(UUIDUtil.create());
            personalSettingsEntity.setEnrollName(2);
            personalSettingsEntity.setHideTravels(2);
            personalSettingsEntity.setLineTips(2);
            personalSettingsEntity.setLeaderMovingTips(2);
            personalSettingsEntity.setUserId(userId);
            personalSettingsDao.insert(personalSettingsEntity);
        }

        return selectByOpenId;
    }

    /**
     *  1 领队动态提醒   2  全新线路时提醒   3   报名名额提醒    4   隐藏游记
     */
    @Override
    public boolean updatePersonalSettings(PersonalSettingsEntity personalSettingsEntity) {

        boolean b = false;

        /**
         * 1 领队动态提醒
         */
        if(personalSettingsEntity.getType().equals(1)){
            b = personalSettingsDao.updateLeaderMovingTips(personalSettingsEntity.getLeaderMovingTips(),personalSettingsEntity.getSettingId());

            /**
             * 2  全新线路时提醒
             */
        } else if (personalSettingsEntity.getType().equals(2)){
            b = personalSettingsDao.updateLineTips(personalSettingsEntity.getLineTips(),personalSettingsEntity.getSettingId());

            /**
             * 3   报名名额提醒
             */
        } else if (personalSettingsEntity.getType().equals(3)){
            b = personalSettingsDao.updateEnrollName(personalSettingsEntity.getEnrollName(),personalSettingsEntity.getSettingId());

            /**
             * 4   隐藏游记
             */
        } else  {
            b = personalSettingsDao.updateHideTravels(personalSettingsEntity.getHideTravels(),personalSettingsEntity.getSettingId());
        }

        return b;
    }


}
