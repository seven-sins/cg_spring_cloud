package com.infox.tourism.service.impl;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.infox.common.base.impl.BaseServiceImpl;
import com.infox.common.exception.CustomException;
import com.infox.common.utils.Assert;
import com.infox.tourism.dao.ActivityBargainRecordDao;
import com.infox.tourism.dao.ActivityRulesDao;
import com.infox.tourism.dao.UserInfoDao;
import com.infox.tourism.dao.activity.ActivityMapper;
import com.infox.tourism.entity.ActivityBargainRecordEntity;
import com.infox.tourism.entity.ActivityInfoEntity;
import com.infox.tourism.entity.ActivityRulesEntity;
import com.infox.tourism.entity.UserInfoEntity;
import com.infox.tourism.entity.vo.bargain.ActivityBargainRecordVo;
import com.infox.tourism.service.ActivityBargainRecordService;
import com.infox.tourism.util.ImgUtil;
import com.infox.tourism.util.UUIDUtil;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 砍价优惠活动记录
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-21 15:17:46
 */
@Service
public class ActivityBargainRecordServiceImpl extends BaseServiceImpl<ActivityBargainRecordEntity> implements ActivityBargainRecordService {
	@Autowired
	private ActivityBargainRecordDao activityBargainRecordDao;
	@Autowired
	private ActivityRulesDao activityRulesDao;
	@Autowired
	private ActivityMapper activityMapper;
	@Autowired
	private UserInfoDao userInfoDao;
	
	@Resource
    public void setBaseMapper(BaseMapper<ActivityBargainRecordEntity> activityBargainRecordDao) {
		this.baseMapper = activityBargainRecordDao;
	}

    /**
        * 查询分页
    * @param pageNum
    * @param pageSize
    * @param search
    * @return
    */
    @Override
    public List<ActivityBargainRecordEntity> queryPage(int pageNum, int pageSize, String search){
        // 使用分页插件实现分页
        PageHelper.startPage(pageNum,pageSize);
        // 调用dao的方法

        return null;
    }

	@Override
	public ActivityBargainRecordEntity assistorBargain(UserInfoEntity user, ActivityBargainRecordEntity entity) {
		List<ActivityBargainRecordEntity> dbList = activityBargainRecordDao.findCurrentUserAndActivityBargainPrice(entity.getGroupId(), entity.getActivityId(), user.getUserId());
		if(dbList != null && !dbList.isEmpty()) {
			throw new CustomException("不能重复砍价");
		}
		ActivityBargainRecordEntity activityBargain = activityBargainRecordDao.getBargainInfoByGroupId(entity.getActivityId(), entity.getGroupId());
		Assert.isTrue(!user.getUserId().equals(activityBargain.getUserId()), "不能帮自己砍价");
		Assert.isTrue(activityBargain.getIsEnd() != null && activityBargain.getIsEnd() != 1, "砍价已结束");
		
		UserInfoEntity userInfo = userInfoDao.selectByPrimaryKey(activityBargain.getUserId());
		Assert.notNull(userInfo, "数据异常, 帮砍价用户不存在");
		ActivityInfoEntity activityInfo = activityMapper.getActivityByActivityId(entity.getActivityId());
		Assert.notNull(activityInfo, "数据异常, 砍价活动不存在");
		ActivityRulesEntity activityRules = activityRulesDao.selectByActivityId(entity.getActivityId());
		Assert.notNull(activityRules, "数据异常, 砍价活动规则不存在");
		Assert.notNull(activityRules.getBargainingTime(), "数据异常, 砍价结束时间为空");
		// 判断是否超出砍价截止时间
		Assert.isTrue(this.getEndTime(activityBargain.getCreateTime(), activityRules.getBargainingTime()) > 0, "砍价已结束");
		// 判断砍价用户数量是否达到上限
		Assert.notNull(activityRules.getBargainNum(), "数据异常, 砍价用户数量为空");
		Integer bargainNum = activityBargainRecordDao.getActivityBargainUserCount(entity.getGroupId(), entity.getActivityId());
		bargainNum = bargainNum == null ? 0 : bargainNum;
		Assert.isTrue(activityRules.getBargainNum() > bargainNum, "砍价用户数量超出限制");
		//
		Assert.notNull(activityInfo.getAdultPrice(), "数据异常,  活动规则原价为空");
		Assert.notNull(activityRules.getBargainPrice(), "数据异常,  活动规则砍价价格为空");
		// 已砍掉的金额
		BigDecimal amount = activityBargainRecordDao.getActivityTotalBargainPrice(entity.getGroupId(), entity.getActivityId());
		amount = amount == null ? new BigDecimal(0) : amount;
		// 砍价最大金额
		// 商品原价-商品砍价
		//BigDecimal bargainPrice = activityInfo.getAdultPrice().subtract(activityRules.getBargainPrice());
		BigDecimal bargainPrice = activityRules.getBargainPrice();
		Assert.notNull(bargainPrice, "数据异常, 砍价金额为空");
		if(bargainPrice.compareTo(amount) == -1) {
			throw new CustomException("数据异常,  砍价金额超出最大值");
		}
		// 当前砍掉的价格
		Assert.notNull(activityRules.getBargainNum(), "砍价人数不能为空");
		BigDecimal currentBargainPrice = activityRules.getBargainPrice().divide(new BigDecimal(activityRules.getBargainNum()), BigDecimal.ROUND_HALF_UP);
		currentBargainPrice = this.getRandom(new BigDecimal(0.01), currentBargainPrice);
		if(bargainPrice.compareTo(amount.add(currentBargainPrice)) == -1) {
			currentBargainPrice = bargainPrice.subtract(amount.add(currentBargainPrice));
		}
		/**
		 * 插入砍价记录
		 */
		entity.setActivityRulesId(activityRules.getActivityRulesId());
		// 主键
		entity.setBargainId(UUIDUtil.create());
		entity.setUserId(activityBargain.getUserId());
		entity.setBargainPrice(currentBargainPrice);
		// 帮忙砍价的用户
		entity.setAssistorUserId(user.getUserId());
		entity.setCreateTime(new Date());
		entity.setCraterBy(user.getUserId());
		entity.setGroupId(entity.getGroupId());
		entity.setIsInitiator(0);
		activityBargainRecordDao.insert(entity);
		
		return entity;
	};
	
	private BigDecimal getRandom(BigDecimal min, BigDecimal max) {
		double dMin = min.doubleValue();
		double dMax = max.doubleValue();
		double boundedDouble = dMin + new Random().nextDouble() * (dMax - dMin);
		BigDecimal decimal = new BigDecimal(boundedDouble);
		
		return decimal.setScale(2, BigDecimal.ROUND_HALF_UP);
	}

	/**
	 * 获取商品已砍价格和目前价格 
	 * 已砍价格在砍价表中查询 
	 * 目前价格 = 商品原价 - 已砍价格
	 */
	@Override
	public Map<String, Object> queryBargainInfo(UserInfoEntity user, String groupId, String activityId) {
		/**
		 * groupId如为空, 当前用户作为发起人生成一条砍价记录
		 */
		ActivityBargainRecordEntity bargainInfo = null;
		if(user != null && StringUtils.isNotBlank(user.getUserId()) && StringUtils.isBlank(groupId)) {
			bargainInfo = this.getInitiatorBargainInfo(user, activityId);
			groupId = bargainInfo.getGroupId();
		} else {
			bargainInfo = activityBargainRecordDao.getBargainInfoByGroupId(activityId, groupId);
			Assert.notNull(bargainInfo, "参数错误, 砍价记录不存在");
		}
		
		ActivityInfoEntity activityInfo = activityMapper.getActivityByActivityId(activityId);
		Assert.notNull(activityInfo, "数据异常, 活动不存在");
		Assert.notNull(activityInfo.getAdultPrice(), "数据异常, 活动原价为空");
		Assert.notEmpty(activityInfo.getCoverId(), "数据异常, 活动图片为空");
		String[] images = activityInfo.getCoverId().split(",");
		Assert.isTrue(images.length > 0, "数据异常, 活动图片为空");
		activityInfo.setCoverId(ImgUtil.middle(images[0]));
		
		// 活动当前已砍掉的价格总额
		BigDecimal amount = activityBargainRecordDao.getActivityTotalBargainPrice(groupId, activityId);
		amount = amount == null ? new BigDecimal(0) : amount;
		// 参与当前活动的砍价用户
		List<ActivityBargainRecordVo> list = activityBargainRecordDao.findActivityBargainUserList(groupId, activityId);
		// 查询活动规则表数据
		ActivityRulesEntity activityRules = activityRulesDao.selectByActivityId(activityInfo.getActivityId());
		Assert.notNull(activityRules, "数据异常, 活动规则不存在");
		
		Map<String, Object> map = new HashMap<>();
		map.put("originalPrice", activityInfo.getAdultPrice());
		map.put("currentPrice", activityInfo.getAdultPrice().subtract(amount));
		map.put("bargainPrice", activityInfo.getAdultPrice().subtract(activityInfo.getAdultPrice().subtract(amount)));
		map.put("activityInfo", activityInfo);
		map.put("list", list);
		map.put("endTime", this.getEndTime(bargainInfo.getCreateTime(), activityRules.getBargainingTime()));
		map.put("groupId", groupId);
		map.put("isInitiator", bargainInfo.getUserId().equals(user.getUserId()) ? 1 : 0);
		// 砍价活动是否已下单
		map.put("isEnd", bargainInfo.getIsEnd());
		
		return map;
	}
	
	private ActivityBargainRecordEntity getInitiatorBargainInfo(UserInfoEntity user, String activityId) {
		ActivityBargainRecordEntity bargainInfo = activityBargainRecordDao.getCurrentUserBargainInfo(user.getUserId(), activityId);
		// 如不存在创建一条砍价记录
		if(bargainInfo == null) {
			bargainInfo = new ActivityBargainRecordEntity();
			bargainInfo.setUserId(user.getUserId());
			bargainInfo.setActivityId(activityId);
			bargainInfo.setGroupId(UUIDUtil.create());
			bargainInfo.setBargainId(UUIDUtil.create());
			// 当前为发起人
			bargainInfo.setIsInitiator(1);
			bargainInfo.setCreateTime(new Date());
			bargainInfo.setBargainPrice(new BigDecimal(0));
			bargainInfo.setAfterPrice(new BigDecimal(0));
			bargainInfo.setAssistorUserId(user.getUserId());
			// 是否结束
			bargainInfo.setIsEnd(0);
			activityBargainRecordDao.insert(bargainInfo);
		}
		
		return bargainInfo;
	}
	
	private long getEndTime(Date createTime, Integer minute) {
		Assert.notNull(createTime, "数据异常, 创建时间为空");
		Assert.notNull(minute, "数据异常, 砍价时间为空");
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(createTime);
		calendar.add(Calendar.MINUTE, minute);
		
		return (calendar.getTimeInMillis() - Calendar.getInstance().getTimeInMillis()) / 1000;
	}
	
}
