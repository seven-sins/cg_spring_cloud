package com.infox.tourism.controller.activityController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageInfo;
import com.infox.tourism.entity.DurationScope;
import com.infox.tourism.service.DurationScopeService;
import com.infox.tourism.util.R;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * 时长范围接口管理
 * @author Tan Ling
 * @date 2019年1月24日 上午9:56:58
 */
@RestController
@Api("时长范围")
@RequestMapping("/durationScope")
public class DurationScopeController {

	@Autowired
	private DurationScopeService durationScopeService;
	
	@ApiOperation(value = "列表",response = DurationScope.class)
	@GetMapping("/list")
	public R list(@RequestParam(value = "pageNum") int pageNum, @RequestParam(value = "pageSize") int pageSize, @ApiParam DurationScope durationScope) {
		// 过滤掉删除的数据
		durationScope.setIsDelete(0);
		List<DurationScope> list = durationScopeService.find(pageNum, pageSize, "sort asc", durationScope);
		
		return R.ok().put("data", list).put("total", new PageInfo<DurationScope>(list).getTotal());
	}
	
//	@ApiOperation("保存")
//	@PostMapping("/insert")
//	public R insert(@Valid @RequestBody DurationScope durationScope, @ApiIgnore AuthUser user) {
//		durationScope.setCreateBy(user.getUserId());
//		durationScope.setCreateTime(new Date());
//		durationScopeService.insert(durationScope);
//		
//		return R.success();
//	}
	
//	@ApiOperation("修改")
//	@PostMapping("/update/{durationScopeId}")
//	public R update(@PathVariable("durationScopeId") String durationScopeId, @RequestBody DurationScope durationScope, @ApiIgnore AuthUser user) {
//		durationScope.setUpdateBy(user.getUserId());
//		durationScope.setUpdateTime(new Date());
//		durationScope.setDurationScopeId(durationScopeId);
//		durationScopeService.update(durationScope);
//		
//		return R.success();
//	}
	
//	@ApiOperation("删除")
//	@PostMapping("/delete/{durationScopeId}")
//	public R delete(@PathVariable("durationScopeId") String durationScopeId, @ApiIgnore AuthUser user) {
//		durationScopeService.deleteById(durationScopeId);
//		
//		return R.success();
//	}
}
