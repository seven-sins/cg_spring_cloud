package com.infox.tourism.service.InsurerRestTemplate;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.infox.tourism.util.InsurerApi;
import com.infox.tourism.util.InsurerSign;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class RequestSimpleInsure {

    public static JSONObject sendRequestSimpleInsure(JSONObject simpleInsureFristJSON){

        RestTemplate restTemplate = new RestTemplate();

        String repSign = InsurerSign.getInsurerSign(simpleInsureFristJSON.toJSONString());

        String repSUrl = InsurerApi.getSimpleInsureAPI(repSign);

        System.out.println("--------------发送的请求参数：" + simpleInsureFristJSON.toJSONString());

        HttpEntity<JSONObject> httpEntity = new HttpEntity<>(simpleInsureFristJSON);

        ResponseEntity<String> responseEntity = restTemplate.postForEntity(repSUrl, httpEntity, String.class);

        System.out.println("SimpleInsureJson--------------请求回来的参数：" + responseEntity.getBody());

        JSONObject SimpleInsureJson = JSON.parseObject(responseEntity.getBody());

        return SimpleInsureJson;

    }

}