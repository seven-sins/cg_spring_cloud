package com.infox.tourism.service.v2;

import java.util.List;

import com.infox.tourism.entity.WithdrawalRecordEntity;

/**
 * 
 * @author yuanfang
 * 2019年5月14日 上午10:50:54
 */

public interface WithdrawalRecordService {
	
	/**
	 * 提现记录
	 */
	void insert(WithdrawalRecordEntity withdrawalRecordEntity);
	
	/**
	 * 查询提现记录
	 */
	List<WithdrawalRecordEntity> selectByUserId(String userId);
	
	/**
	 * 查询提现账户
	 */
	List<WithdrawalRecordEntity> findByUserId(String userId);
	
	/**
	 * 所有提现
	 */
	List<WithdrawalRecordEntity> selectAllWithdrawalRecord(WithdrawalRecordEntity withdrawalRecordEntity);
}
