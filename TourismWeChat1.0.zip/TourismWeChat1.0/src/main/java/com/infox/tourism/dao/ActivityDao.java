package com.infox.tourism.dao;

import com.infox.tourism.entity.ActivityInfoEntity;
import com.infox.tourism.entity.vo.activityDetailVO.ActivityBriefVO;
import com.infox.tourism.entity.vo.activityDetailVO.ActivityDetailVO;
import com.infox.tourism.entity.vo.activityDetailVO.ActivityQuery;
import com.infox.tourism.entity.vo.activityDetailVO.PayActivityVO;
import com.infox.tourism.entity.vo.baseVo.ActivityBaseVO;
import com.infox.tourism.entity.vo.indexVO.LabelIndexVO;
import com.infox.tourism.entity.vo.lineVO.ThemeIndexVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.BaseMapper;

import java.util.List;

/**
 * 活动表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-15 10:36:29
 */
@Mapper
public interface ActivityDao extends BaseMapper<ActivityInfoEntity> {

	/**
	 * 公众号按活动主题查出活动
	 * 
	 * @return
	 */
	List<ThemeIndexVO> selectActivityGroupByThemeByDestinationId(@Param("destinationId") String destinationId,
			@Param("themeId") String themeId);

	/**
	 * 公众号查询活动
	 * 
	 * @param activityName 活动名称
	 * @param leaderName   领队名称
	 * @return
	 */
	List<ActivityBaseVO> selectActivityForWeChat(@Param("name") String name);

	List<LabelIndexVO> selectActivityGroupByLabelByDestinationId(@Param("destinationId") String destinationId);
	/**
	 * 查询活动详情
	 * 
	 * @param activityId
	 * @return
	 */
	List<ActivityDetailVO> selectActivityDetailById(@Param("activityId") String activityId);

	List<ActivityBriefVO> selectActivityBriefByLineId(@Param("lineId") String lineId,
			@Param("activityId") String activityId, @Param("userId") String userId);

	PayActivityVO selectPayActivityById(@Param("activityId") String activityId);

	List<ActivityBaseVO> selectActivityPage(int pageNum, int pageSize,
			@Param("activityQuery") ActivityQuery activityQuery);

	List<ActivityBaseVO> selectSpecialActivityPage(int pageNum, int pageSize, @Param("locationId") String locationId);

	List<ActivityBaseVO> selectWeekEndActivityPage(int pageNum, int pageSize,
			@Param("activityQuery") ActivityQuery activityQuery);

	List<ActivityBaseVO> selectNextWeekActivityPage(int pageNum, int pageSize,
			@Param("activityQuery") ActivityQuery activityQuery);
}
