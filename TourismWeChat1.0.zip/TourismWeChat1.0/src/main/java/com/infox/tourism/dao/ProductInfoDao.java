package com.infox.tourism.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.infox.tourism.entity.ProductInfoEntity;
import com.infox.tourism.entity.vo.productVO.ProductInfoVO;

import tk.mybatis.mapper.common.BaseMapper;

/**
  * 商品表
 * 
 * @author Tan Ling 2018年12月13日 上午9:24:18
 */
@Mapper
public interface ProductInfoDao extends BaseMapper<ProductInfoEntity> {
	/**
	 * 根据订单ID查询商品
	 * @param orderId
	 * @return
	 */
	List<ProductInfoVO> findProductByOrderId(@Param("orderId") String orderId);
	
	List<ProductInfoVO> findExitProductByOrderId(@Param("orderId") String orderId);
}
