package com.infox.tourism.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.infox.common.base.BaseService;
import com.infox.tourism.entity.OrderInfoEntity;
import com.infox.tourism.entity.UserInfoEntity;
import com.infox.tourism.entity.order.OrderArgs;
import com.infox.tourism.entity.vo.OrderVO.OrderDetailVO;
import com.infox.tourism.entity.vo.OrderVO.OrderRefund;
import com.infox.tourism.entity.vo.OrderVO.OrderVO;
import com.infox.tourism.entity.vo.share.ToShareVO;

/**
 * 订单表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-21 15:17:45
 */
public interface OrderInfoService extends BaseService<OrderInfoEntity> {

	/**
	 * 创建订单(普通)
	 * @param user
	 * @param order
	 * @return
	 */
	public OrderInfoEntity insert(UserInfoEntity user, OrderInfoEntity order, Integer type);

	/**
	 * 根据userId 根据支付状态查询
	 * 
	 * @param pageNum
	 * @param pageSize
	 * @param userId
	 * @param payStatus
	 * @return
	 */
	List<OrderVO> selectByUserIdAndPayStatus(int pageNum, int pageSize, String userId, Integer payStatus);
	List<OrderVO> getByOrder(int pageNum, int pageSize, String userId);

	/**
	 * 根据userId 根据活动状态查询
	 * 
	 * @param pageNum
	 * @param pageSize
	 * @param userId
	 * @return
	 */
	List<OrderVO> selectByUserIdAndActivityStatus(int pageNum, int pageSize, String userId);

	/**
	 * 取消订单
	 * 
	 * @return
	 */
	boolean updateByOrderIdAndOrderStatus(OrderInfoEntity orderInfoEntity);

	/**
	 * 根据id查询订单
	 * @param orderId
	 * @return
	 */
	OrderVO selectByOrderId(String orderId);

	/**
	 * 申请退团
	 */
	boolean applyRetreat(String orderId);

	/**
	 * 获取订单信息
	 * @author Tan Ling
	 * @date 2019年2月18日 上午9:38:43
	 * @param orderId
	 * @param type
	 * @return
	 */
	public Map<String, Object> getOrderInfo(String orderId, Integer type);

	/**
	 * 发起拼单
	 * @author Tan Ling
	 * @date 2019年2月18日 上午9:38:38
	 * @param user
	 * @param order
	 * @return
	 */
	public OrderInfoEntity createGroup(UserInfoEntity user, OrderInfoEntity order);

	/**
	 * 加入拼单
	 * @author Tan Ling
	 * @date 2019年2月18日 上午9:38:32
	 * @param user
	 * @param order
	 * @param groupId
	 * @return
	 */
	public OrderInfoEntity joinGroup(UserInfoEntity user, OrderInfoEntity order, String groupId);

	/**
	 * 申请退款
	 * @author Tan Ling
	 * @date 2019年2月18日 上午9:38:23
	 * @param orderRefund
	 * @param authUser
	 * @param isRefund (为false时, 返回退款金额, 为true时触发退款操作)
	 */
	public BigDecimal applyRefund(OrderRefund orderRefund, UserInfoEntity authUser, boolean isRefund);

	/**
	 * 查询订单明细(出行人和商品列表)
	 * @author Tan Ling
	 * @date 2019年2月18日 下午2:40:14
	 * @param orderId
	 * @param status(默认查所有, status == 1时查询正常状态下的出行人和商品)
	 * @return
	 */
	public OrderDetailVO queryOrderDetail(String orderId, Integer status);
	
	/**
	 * 查询订单金额    status == 1时，查询正常状态数据(非改期非退款等)
	 * @author Tan Ling
	 * @date 2019年2月19日 上午9:58:06
	 * @param orderId
	 * @param status
	 * @return
	 */
	Map<String, ?> queryOrderAmount(String orderId, Integer status);

	/**
	 * 查询分享信息列表
	 * @author Tan Ling
	 * @date 2019年2月21日 上午11:52:27
	 * @param userId
	 * @return
	 */
	List<ToShareVO> selectShareList(String userId);

	/**
	 * 查询分享信息
	 * @author Tan Ling
	 * @date 2019年2月21日 下午4:14:21
	 * @param orderId
	 * @param userId
	 * @return
	 */
	public ToShareVO selectShare(String orderId, String userId);

	/**
	 * 取消订单
	 * @author Tan Ling
	 * @date 2019年2月22日 下午4:18:17
	 * @param orderId
	 * @param userId
	 */
	public void cancel(String orderId, String userId);

	/**
	 * 查看活动剩余报名人数
	 * @author Tan Ling
	 * @date 2019年4月18日 上午9:21:02
	 * @param orderId
	 * @return
	 */
	public Integer querySurplus(String orderId);
	
	/**
	 * 删除虚假会员(定时任务)
	 * @author Tan Ling
	 * @date 2019年4月22日 下午2:17:34
	 */
	public void removeShamMember();
	
	/**
	 * 查询当前活动未支付订单
	 * @author Tan Ling
	 * @date 2019年7月24日 下午3:51:47
	 * @param activityId
	 * @param userId
	 * @return
	 */
	public OrderArgs getNonpaymentOrderByActivityId(String activityId, String userId);
	
}
