package com.infox.tourism.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.infox.tourism.entity.LineEntity;
import com.infox.tourism.entity.vo.lineVO.LineDetailVO;
import com.infox.tourism.entity.vo.lineVO.LineDurationCache;
import com.infox.tourism.entity.vo.lineVO.LineVo;

import tk.mybatis.mapper.common.BaseMapper;

@Mapper
public interface LineDao extends BaseMapper<LineEntity> {
    LineDetailVO selectLineActivityByLineId(@Param("lineId") String lineId);

    /**查找线路的封面图*/
    Map<String,String> selectCoverImgByLineId(@Param("lineId") String lineId);

    /**查找线路下所有图片的总图片数量*/
    Integer selectImgCountByLineId(@Param("lineId") String lineId);

    /**查找线路下所有图片的所有图片*/
    @SuppressWarnings("rawtypes")
	List selectImgListByLineId(@Param("lineId") String lineId);

    /**
     * 查询所有线路的时长, 缓存1分钟
     * @author Tan Ling
     * @date 2019年1月21日 下午5:35:16
     * @return
     */
    List<LineDurationCache> selectAllLineDurationTime();
    /**
     * 查询活动年龄限制
     * @author Tan Ling
     * @date 2019年1月30日 上午11:18:56
     * @param lineId
     * @return
     */
    String queryAgeLimitByLineId(@Param("lineId") String lineId);
    /**
     * 查询推荐线路
     * @author Tan Ling
     * @date 2019年7月23日 下午5:34:33
     * @return
     */
    List<LineVo> selectRecommendLine(String companyId);
    /**
     * 根据主键查询线路
     * @author Tan Ling
     * @date 2019年7月24日 上午9:35:06
     * @param lineId
     * @return
     */
    LineEntity getByLineId(String lineId);
}
