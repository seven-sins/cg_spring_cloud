package com.infox.tourism.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.infox.tourism.entity.AttentionEntity;
import com.infox.tourism.entity.vo.UserVO.AttentionVO;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 关注记录表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-21 15:17:45
 */
@Mapper
public interface AttentionDao extends BaseMapper<AttentionEntity> {

    /**
    * 查询分页
    * @return
    */
    List<AttentionEntity> queryPage();

    /**
     * 通过 leaderId，userId 查询关注
     * @return
     */
     List<AttentionEntity> queryAttByUserId(@Param("leaderId")String leaderId, @Param("userId")String userId);

    /**
     * 更新
     */
    int updateById(AttentionEntity attentionEntity);

    /**
     *我的关注领队
     * @param userId
     * @return
     */
    List<AttentionVO> selectByAttentionPeople(String userId);

    /**
     *我的关注领队
     * @param userId
     * @return
     */
    Integer selectByAttentionNum(String userId);
}
