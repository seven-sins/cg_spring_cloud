package com.infox.tourism.service.v2.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infox.common.exception.CustomException;
import com.infox.tourism.dao.v2.ActivitySummaryMapper;
import com.infox.tourism.entity.v2.activitysummary.ActivitySummary;
import com.infox.tourism.service.v2.ActivitySummaryService;
import com.infox.tourism.util.UUIDUtil;

/**
 * 
 * @author yuanfang
 * 2019年5月14日 上午10:51:22
 */
@Service
public class ActivitySummaryServiceImpl implements ActivitySummaryService {
	@Autowired
	ActivitySummaryMapper activitySummaryMapper;

	@Override
	public void insert(ActivitySummary activitySummary) {
		if(activitySummaryMapper.findByActivityId(activitySummary.getActivityId()) != null){
			throw new CustomException("summary exist");
		}
		activitySummary.setActivitySummaryId(UUIDUtil.create());
		activitySummary.setCreateTime(new Date());
		activitySummaryMapper.insert(activitySummary);
		
	}

	@Override
	public void update(ActivitySummary activitySummary) {
		activitySummaryMapper.updateByPrimaryKey(activitySummary);
		
	}

	@Override
	public void deleteByActivitySummaryId(String activitySummaryId) {
		activitySummaryMapper.deleteByActivitySummaryId(activitySummaryId);
		
	}

	@Override
	public ActivitySummary selectByActivitySummaryId(String activitySummaryId) {
		return activitySummaryMapper.selectByPrimaryKey(activitySummaryId);
	}

	@Override
	public List<ActivitySummary> selectAllActivitySummary(ActivitySummary activitySummary) {
		List<ActivitySummary> list=activitySummaryMapper.selectAllActivitySummary(activitySummary);
		return list;
	}

	@Override
	public ActivitySummary findByActivityId(String activityId) {
		
		return activitySummaryMapper.findByActivityId(activityId);
	}
	
}
