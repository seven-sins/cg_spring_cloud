package com.infox.tourism.service;

import java.util.List;

import com.infox.common.base.BaseService;
import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.config.resolver.Guest;
import com.infox.tourism.entity.AttentionEntity;
import com.infox.tourism.entity.ExceptionalRecordEntity;
import com.infox.tourism.entity.LeaderInfoEntity;
import com.infox.tourism.entity.LeaderLevelEntity;
import com.infox.tourism.entity.PhotoEntity;
import com.infox.tourism.entity.UserInfoEntity;
import com.infox.tourism.entity.v2.leader.LeaderScoreVo;
import com.infox.tourism.entity.v2.leaderinfo.vo.LeaderVo;
import com.infox.tourism.entity.vo.leaderInfoVO.ActivityUnderLeaderVO;
import com.infox.tourism.entity.vo.leaderInfoVO.LeaderAndActivityVO;
import com.infox.tourism.entity.vo.leaderInfoVO.LeaderPhotoAlbumVO;
import com.infox.tourism.entity.vo.leaderInfoVO.LeaderRecordVO;
import com.infox.tourism.entity.vo.leaderInfoVO.leaderEvaVO;

/**
 * 领队个人信息表
 *
 * @author yiwei
 * @email @163.com
 * @date 2018-12-10 10:59:35
 */
public interface LeaderInfoService extends BaseService<LeaderInfoEntity> {

	/**
	 * 查询领队等级列表
	 * 
	 * @return
	 */
	List<LeaderLevelEntity> queryLeaderLevelList();

	/**
	 * 查询领队分页
	 * 
	 * @param pageNum     下一页
	 * @param pageSize    显示的长度
	 * @param leaderLevel 领队等级
	 * @return
	 */
	List<LeaderAndActivityVO> queryLeaderList(int pageNum, int pageSize, String leaderLevel, String companyId);

	/**
	 * 根据领队活动分页
	 * 
	 * @param leaderId
	 * @return
	 */
	List<ActivityUnderLeaderVO> queryLeaderActivityList(int pageNum, int pageSize, int state, String leaderId);

	/**
	 * 根据领队id查询
	 * 
	 * @return
	 */
	LeaderAndActivityVO queryLeaderById(String leaderId, Guest user);

	/**
	 * 根据领队相册列表
	 * 
	 * @return
	 */
	List<LeaderPhotoAlbumVO> queryLeaderPhotoList(int pageNum, int pageSize, String leaderId);

	/**
	 * 领队相册详细图片列表
	 * 
	 * @return
	 */
	List<PhotoEntity> queryLeaderPhotoDetailList(int pageNum, int pageSize, String albumId);

	/**
	 * 领队评论列表
	 * 
	 * @return
	 */
	List<leaderEvaVO> queryLeaderEvaluationList(int pageNum, int pageSize, String leaderId);

	/**
	 * 领队打赏列表
	 * 
	 * @return
	 */
	List<LeaderRecordVO> queryLeaderExReList(int pageNum, int pageSize, String leaderId);

	/**
	 * 打赏领队
	 * 
	 * @return
	 */
	ExceptionalRecordEntity insert(ExceptionalRecordEntity leaderRecordVO, AuthUser user);

	/**
	 * 根据id查询打赏记录表
	 * @param exceptionalRecordId
	 * @return
	 */
	ExceptionalRecordEntity selectExceptionalRecordById(String exceptionalRecordId);

	/**
	 * 关注领队
	 * 
	 * @return
	 */
	boolean insertAttention(AttentionEntity attentionEntity, AuthUser user);

	/**
	 * 申请领队
	 * 
	 * @param user
	 * @param leaderInfoEntity
	 */
	LeaderInfoEntity insert(UserInfoEntity user, LeaderInfoEntity leaderInfoEntity);
	/**
	 * 查询所有领队
	 * @author Tan Ling
	 * @date 2019年1月16日 下午2:16:03
	 * @return
	 */
	List<LeaderInfoEntity> findLeader();

	/**
	 * 根据userId查询
	 * @param userId
	 * @return
	 */
	List<LeaderVo> queryLeaderByUserId(String userId,int pageNum,int pageSize);

	/**
	 * 领队账户-查询可提现金额
	 * @param userId
	 * @return
	 */
	Integer selectCanWithdrawalsMoneyByUserId(String userId);
	
	/**
	 * 查询领队评分
	 * @author Tan Ling
	 * @date 2019年7月15日 下午2:34:21
	 * @param leaderId
	 * @return
	 */
	LeaderScoreVo queryLeaderScoreByLeaderId(String leaderId);
}
