package com.infox.tourism.service;

import com.infox.tourism.entity.VoucherBaseInformationEntity;
import com.infox.tourism.entity.vo.couponVo.VoucherVo;

import java.util.List;

/**
 * @Author: cenjinxing
 * @Date: Created in 2018/12/8 12:16
 **/
public interface VoucherBaseInformationService {

	/**
	 * 根据userId查询未使用的优惠券
	 * 
	 * @return
	 */
	List<VoucherVo> selectByUserId(String userId, Integer type, Integer pageNum, Integer pageSize);

	/**
	 * 立即使用
	 * 
	 * @param
	 * @return
	 */
	boolean updateUse(String voucherBaseId);

	/**
	 * 积分商城
	 * 
	 * @param
	 * @return
	 */
	List<VoucherVo> convertProductList(Integer pageNum, Integer pageSize);

	/**
	 * 立即兑换
	 * 
	 * @param
	 * @return
	 */
	void updateIsNeedScord(VoucherBaseInformationEntity voucherBaseInformationEntity, String userId);

}
