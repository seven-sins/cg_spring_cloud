package com.infox.tourism.service;

import com.infox.tourism.entity.vo.productVO.ProductVO;

import java.util.List;

/**
 * @Author Hale
 * @Date 2018/12/12
 */
public interface ProductService {

    List<ProductVO> selectProductByActivityId(String activityId);
}
