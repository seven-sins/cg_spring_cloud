package com.infox.tourism.controller.v2;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.service.v2.ExceptionalRecordV2Service;
import com.infox.tourism.service.v2.PedestrianInfoV2Service;
import com.infox.tourism.util.R;

import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

/**
 * 
 * @author yuanfang
 * 2019年5月14日 上午10:56:38
 */
@RestController
@RequestMapping("/pedestrianinfo/v2")
public class PedestrianInfroV2Controller {

	@Autowired
	PedestrianInfoV2Service pedestrianInfoV2Service;
	@Autowired
	ExceptionalRecordV2Service exceptionalRecordV2Service;
	
	@ApiOperation(value="总分销金额")
	@GetMapping("/queryByDistributionUserId")
	public R  queryByDistributionUserId(@ApiIgnore AuthUser user) {
		BigDecimal queryByDistributionUserId =pedestrianInfoV2Service.queryByDistributionUserId(user.getUserId());
		return R.ok().put("data",queryByDistributionUserId);
	}
	
	@ApiOperation(value="总提现金额")
	@GetMapping("/withdrawByDistributionUserId")
	public R withdrawByDistributionUserId(@ApiIgnore AuthUser user) {
		BigDecimal withdrawByDistributionUserId =pedestrianInfoV2Service.withdrawByDistributionUserId(user.getUserId());
		BigDecimal queryNumErMoney = exceptionalRecordV2Service.queryNumErMoney(user.getUserId());
		BigDecimal add = withdrawByDistributionUserId.add(queryNumErMoney);
		System.out.println(add);
		return R.ok().put("data",withdrawByDistributionUserId);
	}
}
