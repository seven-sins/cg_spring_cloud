package com.infox.tourism.config.resolver;

import com.infox.tourism.entity.UserInfoEntity;

/**
  * 当前登录用户
 * @author Tan Ling
 * 2018年12月5日 上午11:07:58
 */
public class AuthUser extends UserInfoEntity {

	private static final long serialVersionUID = 1L;

}
