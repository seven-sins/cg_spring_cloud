package com.infox.tourism.service.v2.traffic;

import com.infox.common.base.BaseService;
import com.infox.tourism.entity.traffic.TrafficMode;

import java.util.List;

/**
 * @Author: Xiao Ming
 * @Date: 2019/7/30 11:44
 * @Version 1.0
 */
public interface TrafficModeService extends BaseService<TrafficMode> {

    List<TrafficMode> getTrafficList(TrafficMode trafficMode);

    void addTrafficListByActivityOrLine(TrafficMode trafficMode, String id, int type);

    void deleteTrafficModeByActivityOrLine(String id, int type);

    List<TrafficMode> selectTrafficListByLineId(String id);

}
