//package com.infox.tourism.util;
//
//import com.infox.tourism.util.exception.CustomException;
//
///**
// * 断言
// * 
// * @author Tan Ling 2018年12月13日 上午11:06:41
// */
//public class Assert {
//
//	private Assert() {
//
//	}
//
//	/**
//	 * 断言表达式结果为是，否则抛出异常
//	 * 
//	 * @param expression boolean表达式
//	 * @param message    异常消息
//	 * @throws CustomException
//	 */
//	public static void isTrue(boolean expression, String message) throws CustomException {
//		if (!expression) {
//			throw new CustomException(message);
//		}
//	}
//
//	/**
//	 * 断言对象不空，否则抛出异常
//	 * 
//	 * @param object  目标对象
//	 * @param message 异常消息
//	 * @throws CustomException
//	 */
//	public static void notNull(Object object, String message) throws CustomException {
//		if (object == null) {
//			throw new CustomException(message);
//		}
//	}
//
//	/**
//	 * 断言对象为空，否则抛出异常
//	 * 
//	 * @param object  目标对象
//	 * @param message 异常消息
//	 * @throws CustomException
//	 */
//	public static void isNull(Object object, String message) throws CustomException {
//		if (object != null) {
//			throw new CustomException(message);
//		}
//	}
//
//	/**
//	 * 断言字符串对象和内容不为空，否则抛出异常
//	 * 
//	 * @param str     字符串对象
//	 * @param message 异常消息
//	 * @throws CustomException
//	 */
//	public static void notEmpty(String str, String message) throws CustomException {
//		if (str == null || "".equals(str.trim())) {
//			throw new CustomException(message);
//		}
//	}
//}
