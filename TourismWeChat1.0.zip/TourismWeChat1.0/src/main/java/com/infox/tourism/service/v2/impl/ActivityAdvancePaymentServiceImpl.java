package com.infox.tourism.service.v2.impl;

import java.util.Date;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infox.common.base.impl.BaseServiceImpl;
import com.infox.common.utils.Assert;
import com.infox.tourism.dao.LeaderInfoDao;
import com.infox.tourism.dao.v2.ActivityAdvancePaymentMapper;
import com.infox.tourism.entity.LeaderInfoEntity;
import com.infox.tourism.entity.UserInfoEntity;
import com.infox.tourism.entity.v2.activityadvancepayment.ActivityAdvancePayment;
import com.infox.tourism.service.v2.ActivityAdvancePaymentService;
import com.infox.tourism.util.UUIDUtil;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 预付款Service
 * @author Tan Ling
 * 2019年1月7日 下午2:28:30
 */
@Service
public class ActivityAdvancePaymentServiceImpl extends BaseServiceImpl<ActivityAdvancePayment> implements ActivityAdvancePaymentService {

	@Autowired
	private ActivityAdvancePaymentMapper activityAdvancePaymentMapper;
	@Autowired
	private LeaderInfoDao leaderInfoDao;
	
	@Resource
	public void setBaseMapper(BaseMapper<ActivityAdvancePayment> activityAdvancePaymentMapper) {
		this.baseMapper = activityAdvancePaymentMapper;
	}

	@Override
	public void updateByActivityAdvancePaymentId(ActivityAdvancePayment activityAdvancePayment) {
		activityAdvancePaymentMapper.updateByActivityAdvancePaymentId(activityAdvancePayment);		
	}

	@Override
	public void insert(ActivityAdvancePayment activityAdvancePayment, UserInfoEntity user) {
		LeaderInfoEntity leaderInfo = leaderInfoDao.getByUserId(user.getUserId());
		Assert.notNull(leaderInfo, "数据异常, 领队信息不存在");
		
		activityAdvancePayment.setActivityAdvancePaymentId(UUIDUtil.create());
		// 状态(1:未审核, 2:已批准, 3:已拒绝, 4:已领取) 
		activityAdvancePayment.setProjectStatus(1);
		activityAdvancePayment.setLeaderId(leaderInfo.getLeaderId());
		activityAdvancePayment.setCreateBy(user.getUserId());
		activityAdvancePayment.setCreateTime(new Date());
		
		activityAdvancePaymentMapper.insert(activityAdvancePayment);
	}
	
}
