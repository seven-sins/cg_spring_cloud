package com.infox.tourism.controller.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.infox.tourism.entity.vo.activity.ActivityBase;
import com.infox.tourism.service.ActivityService;
import com.infox.tourism.util.R;

/**
 * @Author: Xiao Ming
 * @Date: 2019/8/2 14:48
 * @Version 1.0
 */
@RestController
@RequestMapping("/testFlink")
public class TestFlinkController {

    @Autowired
    ActivityService activityService;

    @Autowired
    KafkaTemplate<String, String> kafkaTemplate;
    @Value("${kafka.log2kafka:false}")
    Boolean log2kafka;
    @Value("${kafka.topic}")
    String topic;

    @GetMapping("/sendFlink")
    public R sendFlink(String date){

        ActivityBase activityBase = activityService.getActivityBaseByActivityId("db32c6fa4ef94767a5a7175df4d0bc5e");

        JSONObject jsonObject = new JSONObject();
        Date date1 = null;
        try {
            date1 = new SimpleDateFormat("yyyy-MM-dd").parse(date);
        } catch (ParseException p){

        }

        jsonObject.put("url","/testFlink/sendFlink");
        jsonObject.put("userId","0003a50f450e478f9df0517cc089b37c");
        jsonObject.put("nickName","testFlink");
        jsonObject.put("lineId",activityBase.getLineId());
        jsonObject.put("lineName",activityBase.getLineName());
        jsonObject.put("activityId",activityBase.getActivityId());
        jsonObject.put("activityName",activityBase.getActivityName());
        jsonObject.put("ipaddress","192.168.0.111");
        jsonObject.put("outsetTime",activityBase.getOutsetTime());
        jsonObject.put("timestamp", new Date().getTime());
        jsonObject.put("visitTime", date1);
        jsonObject.put("status", 0);

        kafkaTemplate.send("pvuv_topic", "pvuv_topic",jsonObject.toJSONString());

        return R.ok("操作成功").put("date",new Date());

    }

}