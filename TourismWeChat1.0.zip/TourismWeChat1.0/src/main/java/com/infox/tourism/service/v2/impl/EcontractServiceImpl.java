package com.infox.tourism.service.v2.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infox.common.base.impl.BaseServiceImpl;
import com.infox.tourism.entity.v2.econtract.Econtract;
import com.infox.tourism.service.v2.EcontractService;

import tk.mybatis.mapper.common.BaseMapper;

@Service
public class EcontractServiceImpl extends BaseServiceImpl<Econtract> implements EcontractService {

	@Autowired
	@Override
	public void setBaseMapper(BaseMapper<Econtract> baseMapper) {
		this.baseMapper = baseMapper;
	}

}
