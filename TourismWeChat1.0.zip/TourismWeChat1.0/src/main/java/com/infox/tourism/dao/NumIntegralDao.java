package com.infox.tourism.dao;

import com.infox.tourism.entity.vo.UserVO.UserVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.infox.tourism.entity.NumIntegralEntity;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * @author Tan Ling
 * @date 2019年1月22日 下午9:26:40
 */
@Mapper
public interface NumIntegralDao extends BaseMapper<NumIntegralEntity> {
	
	/**
	 * 查询用户积分记录
	 * @author Tan Ling
	 * @date 2019年1月22日 下午9:26:31
	 * @param userId
	 * @return
	 */
	NumIntegralEntity queryByUserId(@Param("userId") String userId);
	/**
	 * 更新用户积分
	 * @author Tan Ling
	 * @date 2019年1月22日 下午9:24:43
	 * @param numIntegralId
	 * @param usableRecord
	 * @param numIntegral
	 * @return
	 */
	void updateUserPoint(@Param("numIntegralId") String numIntegralId, @Param("usableRecord") Integer usableRecord, @Param("numIntegral") Integer numIntegral);

	/**
	 * 根据用户id更新积分
	 * @param userVO
	 */
    void updateNumIntegralByUserId(UserVO userVO);
}
