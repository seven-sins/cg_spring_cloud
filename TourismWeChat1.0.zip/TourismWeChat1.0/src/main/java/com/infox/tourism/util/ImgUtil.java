package com.infox.tourism.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

/**
 * 获取缩略图
 * @author Tan Ling
 * @date 2019年1月25日 上午9:23:05
 */
public class ImgUtil {
	/**
	 * 缩略图
	 */
	private static final String REGEX = "\\w+\\.\\w+$";
	private static final Pattern THUMBNAIL = Pattern.compile(REGEX);

	public static String small(String img) {
		if(StringUtils.isBlank(img)) {
			return "";
		}
		return refactorImg("s_", img);
	}
	
	public static String middle(String img) {
		if(StringUtils.isBlank(img)) {
			return "";
		}
		return refactorImg("m_", img);
	}
	
	public static String hight(String img) {
		if(StringUtils.isBlank(img)) {
			return "";
		}
		return refactorImg("h_", img);
	}
	
	private static String refactorImg(String prefix, String img) {
		Matcher m = THUMBNAIL.matcher(img);
		if(m.find()) {
			String imgName = prefix + m.group(0);
			if(StringUtils.isBlank(imgName)) {
				return img;
			}
			return img.replaceAll(REGEX, "") + imgName;
		}
		
		return img;
	}
}
