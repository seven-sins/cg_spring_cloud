package com.infox.tourism.controller.messageController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infox.common.utils.Assert;
import com.infox.tourism.entity.MessagePushEntity;
import com.infox.tourism.service.MessageService;
import com.infox.tourism.util.R;

/**
 * @Author Hale
 * @Date 2018/12/14
 */
@RestController
@RequestMapping("/message")
public class messageController {

    @Autowired
    private MessageService messageService;
    @GetMapping("/getByMessageId")
    public R getByMessageId(String messageId){
    	Assert.notEmpty(messageId, "messageId不能为空");
        MessagePushEntity message = messageService.get(messageId);
        return R.ok().put("data",message);
    }

}
