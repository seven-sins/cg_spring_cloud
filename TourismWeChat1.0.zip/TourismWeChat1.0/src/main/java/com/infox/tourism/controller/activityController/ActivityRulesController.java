package com.infox.tourism.controller.activityController;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageInfo;
import com.infox.tourism.entity.ActivityRulesEntity;
import com.infox.tourism.service.ActivityRulesService;
import com.infox.tourism.util.R;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * 活动规则表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-15 10:36:29
 */
@Api(description = "活动规则表")
@RestController
@RequestMapping("/activityRules")
public class ActivityRulesController {
	
    @Autowired
    private ActivityRulesService activityRulesService;

    @ApiOperation(value = "列表", response = ActivityRulesEntity.class)
    @GetMapping("/list")
    public R list(
    		@RequestParam(value = "pageNum") int pageNum, 
    		@RequestParam(value = "pageSize") int pageSize, 
    		@ApiParam ActivityRulesEntity activityRulesEntity ){
        List<ActivityRulesEntity> list = activityRulesService.find(pageNum, pageSize, "create_time desc", activityRulesEntity);

        return R.ok().put("data", list).put("total", new PageInfo<ActivityRulesEntity>(list).getTotal());
    }

    @ApiOperation(value = "单记录查询", response = ActivityRulesEntity.class)
    @GetMapping("/info/{activityRulesId}")
    public R info(@PathVariable("activityRulesId") String activityRulesId){
		ActivityRulesEntity activityRules = activityRulesService.get(activityRulesId);

        return R.ok().put("activityRules", activityRules);
    }

    @ApiOperation("保存")
    @PostMapping("/save")
    public R save(@Valid @RequestBody ActivityRulesEntity activityRules){
		activityRulesService.insert(activityRules);

        return R.ok();
    }

    @ApiOperation("修改")
    @PostMapping("/update")
    public R update(@RequestBody ActivityRulesEntity activityRules){
    	if(activityRules.getId() == null) {
    		return R.error(400, "ID不能为空");
    	}
    	
		activityRulesService.update(activityRules);

        return R.ok();
    }
    
    @ApiOperation("删除")
    @PostMapping("/delete/{id}")
    public R delete(@PathVariable("id") String id){
		activityRulesService.deleteById(id);

        return R.ok();
    }

}
