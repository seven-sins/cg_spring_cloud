package com.infox.tourism.config.filter;

import java.io.IOException;
import java.util.Date;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.springframework.kafka.core.KafkaTemplate;

import com.alibaba.fastjson.JSONObject;
import com.infox.common.utils.DateUtils;
import com.infox.tourism.config.filter.request.wrapper.WebHttpServletRequestWrapper;

/**
 * 记录请求参数
 * @author rex.tan
 * @date 2019年9月12日 上午9:37:17
 */
public class HttpServletRequestReplacedFilter implements Filter {
	private KafkaTemplate<String, String> kafkaTemplate;
	
	public HttpServletRequestReplacedFilter(KafkaTemplate<String, String> kafkaTemplate) {
		this.kafkaTemplate = kafkaTemplate;
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		ServletRequest requestWrapper = null;
		if (request instanceof HttpServletRequest) {
			WebHttpServletRequestWrapper webHttpServletRequestWrapper = new WebHttpServletRequestWrapper((HttpServletRequest) request);
			requestWrapper = webHttpServletRequestWrapper;
			//
			HttpServletRequest httpServletRequest = (HttpServletRequest) request;
			String url = httpServletRequest.getRequestURI();
			/**
			 * 记录请求参数
			 */
			JSONObject json = new JSONObject();
			json.put("visitTime", DateUtils.format(new Date(), "yyyy-MM-dd HH:mm:ss"));
			json.put("url", url);
			json.put("channel", httpServletRequest.getHeader("channel"));
			json.put("parameters", webHttpServletRequestWrapper.getRequestParams());
			json.put("timestamp", System.currentTimeMillis());
			kafkaTemplate.send("paramater_topic", "paramater_topic", json.toJSONString());
		}
		// 获取请求中的流如何，将取出来的字符串，再次转换成流，然后把它放入到新request对象中。
		// 在chain.doFiler方法中传递新的request对象
		if (requestWrapper == null) {
			chain.doFilter(request, response);
		} else {
			chain.doFilter(requestWrapper, response);
		}
	}
}
