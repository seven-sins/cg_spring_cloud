package com.infox.tourism.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.infox.tourism.entity.ActivityInfoEntity;
import com.infox.tourism.entity.vo.CalenderVO.CalenderCountVO;
import com.infox.tourism.entity.vo.CalenderVO.CalenderVO;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 日历模块
 *
 * @author yiwei
 * @email
 * @date 2018-12-06 11:31:27
 */
@Mapper
public interface CalenderDao extends BaseMapper<ActivityInfoEntity> {
		
		/**
	    * 查询月每天的活动总数
	    * @return
	    */
	    List<CalenderCountVO> selectCalenderCount(@Param("startTime") String startTime,@Param("endTime") String endTime, String companyId);
	    
		/**
	    * 查询一天的活动列表
	    * @return
	    */
	    List<CalenderVO> selectCalenderListByDay(@Param("dayTime") String dayTime, String companyId);
}
