package com.infox.tourism.service.v2.impl.cost;

import com.infox.tourism.service.v2.cost.CostManagementService;
import org.springframework.stereotype.Service;


/**
 * 
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2019-04-02 14:07:18
 */
@Service("costManagementService")
public class CostManagementServiceImpl implements CostManagementService {

}
