package com.infox.tourism.dao;

import com.infox.tourism.entity.InsureOrderEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import tk.mybatis.mapper.common.BaseMapper;

import java.util.List;

/**
 * 保险和订单关系表
 * 
 * @author Tan Ling 
 * 2018年12月17日 下午5:30:49
 */
@Mapper
public interface InsureOrderDao extends BaseMapper<InsureOrderEntity> {

	/**
	 * 查询分页
	 * 
	 * @return
	 */
	List<InsureOrderEntity> queryPage();
	
	/**
	 * 根据订单ID查询保险单
	 * @param orderId
	 * @return
	 */
	InsureOrderEntity getByOrderId(@Param("orderId") String orderId);


}
