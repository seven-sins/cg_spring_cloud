package com.infox.tourism.base;

import tk.mybatis.mapper.common.Mapper;
import tk.mybatis.mapper.common.MySqlMapper;

/**
 * 继承通用mapper的方法
 *
 * @Author: cenjinxing
 * @Date: Created in 2018/9/26 14:04
 **/
public interface IBaseMapper<T> extends Mapper<T>, MySqlMapper<T> {
}
