package com.infox.tourism.controller.userInfoController;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageInfo;
import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.entity.vo.UserVO.ExceptionalVO;
import com.infox.tourism.service.ExceptionalRecordService;
import com.infox.tourism.util.R;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

/**
 * 我的打赏
 * @Author: cenjinxing
 * @Date: Created in 2018/12/12 15:47
 **/
@RestController
@RequestMapping("/myReward")
@Api(description = "我的打赏",tags = {"MyRewardController"})
public class MyRewardController {

    @Autowired
    private ExceptionalRecordService exceptionalRecordService;


    @ApiOperation(value = "我的打赏", response = ExceptionalVO.class)
    @GetMapping("/reward")
    public R reward(@ApiIgnore AuthUser authUser,int pageNum ,int pageSize) {

        List<ExceptionalVO> list = exceptionalRecordService.selectByExceptionalPeople(pageNum, pageSize, authUser.getUserId());

        PageInfo<ExceptionalVO> pageInfo = new PageInfo<>(list);

        /**
         * 我的总金额
         */
        Integer totalAmount = exceptionalRecordService.getTotalAmount(authUser.getUserId());

        HashMap<Object, Object> map = new HashMap<>();
        map.put("list",list);
        map.put("total",pageInfo.getTotal());
        map.put("totalAmount",totalAmount);


        return R.ok().put("data", map);
    }

}
