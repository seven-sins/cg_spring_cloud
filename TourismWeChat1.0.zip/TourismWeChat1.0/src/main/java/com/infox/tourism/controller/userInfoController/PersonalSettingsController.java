package com.infox.tourism.controller.userInfoController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.entity.PersonalSettingsEntity;
import com.infox.tourism.service.PersonalSettingsService;
import com.infox.tourism.util.R;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

/**
 * 提醒设置
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-12-11 18:52:59
 */
@RestController
@RequestMapping("/personalsettings")
@Api(description = "提醒设置",tags = {"PersonalSettingsController"})
public class PersonalSettingsController {

    @Autowired
    private PersonalSettingsService personalSettingsService;

    /**
     * 提醒设置
     */
    @ApiOperation(value = "提醒设置",response = PersonalSettingsEntity.class)
    @GetMapping("/selectByOpenId")
    public R selectByOpenId(@ApiIgnore AuthUser authUser){
        PersonalSettingsEntity personalSettingsEntity = personalSettingsService.queryPage(authUser.getUserId());

        return R.ok().put("data",personalSettingsEntity);
    }

    /**
     * 领队动态提醒      1 开启   2  关闭
     */
    @ApiOperation(value = "领队动态提醒      1 开启   2  关闭",response = PersonalSettingsEntity.class)
    @PostMapping("/updateLeaderMovingTips")
    public R updatePersonalSettings(@RequestBody PersonalSettingsEntity personalSettingsEntity){
        boolean b = personalSettingsService.updatePersonalSettings(personalSettingsEntity);

        return R.ok().put("data",b);
    }

}
