package com.infox.tourism.dao.activity;

import org.apache.ibatis.annotations.Mapper;

import com.infox.tourism.entity.v2.activityInfo.ViewRecord;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 活动访问记录
 * @author Tan Ling
 * @date 2019年6月20日 下午5:37:41
 */
@Mapper
public interface ViewRecordMapper extends BaseMapper<ViewRecord> {
	
	/**
	 * 统计线路访问次数
	 * @author Tan Ling
	 * @date 2019年7月23日 下午4:21:34
	 * @param lineId
	 * @return
	 */
	Integer queryCountByLineId(String lineId);
}
