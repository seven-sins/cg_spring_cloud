package com.infox.tourism.util;

import com.infox.tourism.config.InsuranceConfig;

public class InsurerApi {

    public static String getProductListAPI(String insurerSign){

        String repUrl = InsuranceConfig.devUrl + InsuranceConfig.ProductListAPI + "?sign=" + insurerSign;

        return repUrl;

    }

    public static String getSimpleInsureAPI(String insurerSign){

        String repUrl = InsuranceConfig.devUrl + InsuranceConfig.SimpleInsureAPI + "?sign=" + insurerSign;

        return repUrl;

    }

    public static String getSimpleTrialAPI(String insurerSign){

        String repUrl = InsuranceConfig.devUrl + InsuranceConfig.SimpleTrialAPI + "?sign=" + insurerSign;

        return repUrl;

    }

    public static String getLocalPayAPI(String insurerSign){

        String repUrl = InsuranceConfig.devUrl + InsuranceConfig.LocalPayAPI + "?sign=" + insurerSign;

        return repUrl;

    }

    public static String getProductDestinationAPI(String insurerSign){

        String repUrl = InsuranceConfig.devUrl + InsuranceConfig.ProductDestinationAPI + "?sign=" + insurerSign;

        return repUrl;

    }

    public static String getSurrenderPolicyAPI(String insurerSign){

        String repUrl = InsuranceConfig.devUrl + InsuranceConfig.SurrenderPolicyAPI + "?sign=" + insurerSign;

        return repUrl;
    }

}