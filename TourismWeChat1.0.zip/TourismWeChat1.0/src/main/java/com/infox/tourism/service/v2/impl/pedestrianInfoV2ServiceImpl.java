package com.infox.tourism.service.v2.impl;

import java.math.BigDecimal;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.infox.tourism.dao.v2.PedestrianInfoV2Mapper;
import com.infox.tourism.service.v2.PedestrianInfoV2Service;

/**
 * @author yuanfang
 * 2019年4月25日 下午1:45:47
 */
@Service
public class pedestrianInfoV2ServiceImpl implements PedestrianInfoV2Service {
	
	@Autowired
	PedestrianInfoV2Mapper pedestrianInfoV2Mapper;

	@Override
	public BigDecimal queryByDistributionUserId(String distributionUserId) {
		return pedestrianInfoV2Mapper.queryByDistributionUserId(distributionUserId);
	}

	@Override
	public BigDecimal withdrawByDistributionUserId(String distributionUserId) {
		return pedestrianInfoV2Mapper.withdrawByDistributionUserId(distributionUserId);
	}

}
