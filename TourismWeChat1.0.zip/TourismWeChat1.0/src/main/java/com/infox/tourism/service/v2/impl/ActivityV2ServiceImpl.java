package com.infox.tourism.service.v2.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infox.tourism.dao.v2.ActivityV2Mapper;
import com.infox.tourism.entity.ActivityInfoEntity;
import com.infox.tourism.service.v2.ActivityV2Service;
/**
 * 
 * @author yuanfang
 * 2019年5月14日 上午10:51:28
 */
@Service
public class ActivityV2ServiceImpl implements ActivityV2Service {

	@Autowired
	ActivityV2Mapper activityV2Mapper;
	
	@Override
	public List<ActivityInfoEntity> queryByLeaderId(String leaderId) {
		return activityV2Mapper.queryByLeaderId(leaderId);
	}

	@Override
	public int queryCountByUserId(String userId) {
		return activityV2Mapper.queryCountByUserId(userId);
	}

}
