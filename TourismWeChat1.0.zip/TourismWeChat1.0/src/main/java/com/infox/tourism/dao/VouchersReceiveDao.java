package com.infox.tourism.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.infox.tourism.entity.VouchersReceiveEntity;
import com.infox.tourism.entity.vo.voucher.VoucherInfoVO;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 代金券领取表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-21 15:17:44
 */
@Mapper
public interface VouchersReceiveDao extends BaseMapper<VouchersReceiveEntity> {

    /**
    * 查询分页
    * @return
    */
    List<VouchersReceiveEntity> queryPage();

    /**
     * 根据主键更新
     * @param vouchersReceiveEntity
     */
    void updateByvouchersReceiveId(VouchersReceiveEntity vouchersReceiveEntity);
    /**
     * 查询单个优惠券
     * @author Tan Ling
     * @date 2019年1月26日 下午7:54:32
     * @param vouchersReceiveId
     * @return
     */
    VoucherInfoVO queryVoucherById(@Param("vouchersReceiveId") String vouchersReceiveId);
}
