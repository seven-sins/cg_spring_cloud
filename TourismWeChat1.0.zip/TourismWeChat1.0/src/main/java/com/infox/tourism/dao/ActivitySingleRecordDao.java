package com.infox.tourism.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.infox.tourism.entity.ActivitySingleRecordEntity;
import com.infox.tourism.entity.vo.activity.ActivitySingleRecordVo;
import com.infox.tourism.entity.vo.share.ToShareVO;
import com.infox.tourism.entity.vo.single.ActivitySingleRecordInitiator;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 拼单活动记录
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-15 10:36:29
 */
@Mapper
public interface ActivitySingleRecordDao extends BaseMapper<ActivitySingleRecordEntity> {

	/**
	 * 查询分页
	 * 
	 * @return
	 */
	List<ActivitySingleRecordEntity> queryPage();
	
	/**
	 * 查询正常状态下的拼单记录
	 * @author Tan Ling
	 * @date 2019年4月27日 上午12:32:00
	 * @param groupId
	 * @return
	 */
	List<ActivitySingleRecordEntity> querySingleListByGroupId(@Param("groupId") String groupId);

	/**
	 * 使用组ID查询
	 * 
	 * @param groupId
	 * @return
	 */
	ActivitySingleRecordEntity getByGroupId(@Param("groupId") String groupId);

	/**
	 * 查询活动发起人的拼单记录
	 * @param groupUserId
	 * @param groupId
	 * @return
	 */
	ActivitySingleRecordEntity getActivityInitiatorByGroupId(@Param("groupId") String groupId);

	/**
	 * 查询当前活动拼单发起人列表
	 * 
	 * @param activityId
	 * @return
	 */
	List<ActivitySingleRecordVo> findSingleRecordListByActivityId(@Param("activityId") String activityId);
	
	/**
	 * 查询当前组已有的拼单人数
	 * @param groupId
	 * @return
	 */
	Integer getSingleCountByGroupId(@Param("groupId") String groupId);
	
	/**
	 * 更新拼单数量
	 * @param singleId
	 * @param singleNumber
	 */
	void updateSingleNumber(@Param("singleId") String singleId, @Param("singleNumber") Integer singleNumber);
	
	/**
	 * 查询某个活动下的所有拼单
	 * @param activityId
	 * @return
	 */
	List<ActivitySingleRecordInitiator> findSingleRecordListMoreByActivityId(@Param("activityId") String activityId);

	/**
	 * 查询待分享拼单数据
	 * @author Tan Ling
	 * @date 2019年2月21日 上午11:48:05
	 * @param userId
	 * @return
	 */
	List<ToShareVO> selectShareList(@Param("userId") String userId, @Param("orderId") String orderId);
	
	/**
	 * 查询当前订单拼单数量
	 * @author Tan Ling
	 * @date 2019年3月1日 下午3:54:39
	 * @param orderId
	 * @return
	 */
	ActivitySingleRecordEntity selectByOrderId(@Param("orderId") String orderId);
	/**
	 * 修改发起人状态
	 * @author Tan Ling
	 * @date 2019年4月27日 上午12:36:14
	 * @param singleId
	 * @param isInitiator
	 */
	void updateInitiatorStatus(@Param("singleId") String singleId, @Param("isInitiator") Integer isInitiator);
}
