package com.infox.tourism.service;

import java.util.List;

import com.infox.tourism.entity.vo.UserVO.AttentionVO;

/**
 * 关注记录表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-21 15:17:45
 */
public interface AttentionService {

    /**
     *我的关注领队
     * @param userId
     * @return
     */
    List<AttentionVO> selectByAttentionPeople(String userId, int pageNum, int pageSize);
}

