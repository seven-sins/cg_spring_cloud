package com.infox.tourism.controller.activityController;

import java.util.List;

import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageInfo;
import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.entity.ActivitySingleRecordEntity;
import com.infox.tourism.entity.vo.activity.ActivitySingleRecordVo;
import com.infox.tourism.entity.vo.single.ActivitySingleRecordInitiator;
import com.infox.tourism.service.ActivitySingleRecordService;
import com.infox.tourism.util.R;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import springfox.documentation.annotations.ApiIgnore;

/**
 * 拼单活动记录
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-15 10:36:29
 */
@Api(description = "拼单活动记录")
@RestController
@RequestMapping("/activitysinglerecord")
public class ActivitySingleRecordController {
	
    @Autowired
    private ActivitySingleRecordService activitySingleRecordService;

    @ApiOperation(value = "列表", response = ActivitySingleRecordEntity.class)
    @GetMapping("/list")
    public R list(
    		@RequestParam(value = "pageNum") int pageNum, 
    		@RequestParam(value = "pageSize") int pageSize,
    		@ApiParam ActivitySingleRecordEntity activitySingleRecordEntity){
        List<ActivitySingleRecordEntity> list = activitySingleRecordService.find(pageNum, pageSize, null, activitySingleRecordEntity);

        return R.ok().put("data", list).put("total", new PageInfo<ActivitySingleRecordEntity>(list).getTotal());
    }
    
    @ApiOperation(value = "列表", response = ActivitySingleRecordInitiator.class)
    @GetMapping("/list/more")
    public R more(
    		@RequestParam(value = "pageNum") int pageNum, 
    		@RequestParam(value = "pageSize") int pageSize,
    		@ApiParam ActivitySingleRecordEntity activitySingleRecordEntity){
        List<ActivitySingleRecordInitiator> list = activitySingleRecordService.findSingleRecordListMoreByActivityId(pageNum, pageSize, activitySingleRecordEntity.getActivityId());

        return R.ok().put("data", list).put("total", new PageInfo<ActivitySingleRecordInitiator>(list).getTotal());
    }
	
	@ApiOperation(value = "查询活动发起拼单用户列表", response = ActivitySingleRecordVo.class)
	@GetMapping("/{activityId}")
	public R activitySingleRecord(
			@RequestParam(value = "pageNum") int pageNum, 
    		@RequestParam(value = "pageSize") int pageSize,
			@PathVariable("activityId") String activityId) {
		List<ActivitySingleRecordVo> list = activitySingleRecordService.findSingleRecordListByActivityId(pageNum, pageSize, activityId);
		
		return R.ok().put("data", list).put("total", new PageInfo<ActivitySingleRecordVo>(list).getTotal());
	}

    @ApiOperation(value = "单记录查询", response = ActivitySingleRecordEntity.class)
    @GetMapping("/info/{singleId}")
    public R info(@PathVariable("singleId") String singleId){
        return R.ok().put("activitySingleRecord", activitySingleRecordService.get(singleId));
    }

    @ApiOperation("保存")
    @PostMapping("/save")
    public R save(@ApiIgnore AuthUser user, @Valid @RequestBody ActivitySingleRecordEntity activitySingleRecord){
		activitySingleRecordService.insert(user, activitySingleRecord);

        return R.ok();
    }

    @ApiOperation("修改")
    @PostMapping("/update")
    public R update(@RequestBody ActivitySingleRecordEntity activitySingleRecord){
    	if(StringUtils.isBlank(activitySingleRecord.getSingleId())) {
    		R.error(400, "拼单记录ID不能为空");
    	}
		activitySingleRecordService.update(activitySingleRecord);

        return R.ok();
    }

    @ApiOperation("删除")
    @PostMapping("/delete/{id}")
    public R delete(@PathVariable("id") String id){
		activitySingleRecordService.deleteById(id);

        return R.ok();
    }

}
