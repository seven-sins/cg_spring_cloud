package com.infox.tourism.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infox.tourism.dao.VoucherBaseInformationDao;
import com.infox.tourism.dao.VoucherDao;
import com.infox.tourism.dao.VoucherPushMapper;
import com.infox.tourism.dao.VouchersReceiveDao;
import com.infox.tourism.entity.UserInfoEntity;
import com.infox.tourism.entity.VoucherBaseInformationEntity;
import com.infox.tourism.entity.VoucherPush;
import com.infox.tourism.entity.VouchersReceiveEntity;
import com.infox.tourism.entity.vo.couponVo.VoucherVo;
import com.infox.tourism.entity.vo.indexVO.VoucherIndexVO;
import com.infox.tourism.service.VoucherService;
import com.infox.tourism.util.UUIDUtil;

/**
 * @author Tan Ling
 * @date 2019年6月12日 下午5:33:20
 */
@Service
public class VoucherServiceImpl implements VoucherService {

    @Autowired
    private VoucherDao voucherDao;
    @Autowired
    private VoucherPushMapper voucherPushMapper;
    @Autowired
    private VouchersReceiveDao vouchersReceiveDao;
    @Autowired
    private VoucherBaseInformationDao voucherBaseInformationDao;

    @Override
    public List<VoucherIndexVO> selectPushVoucher(String userId, String locationId) {
    	List<VoucherIndexVO> result = new ArrayList<>();
    	// 查询按城市推送的优惠券列表
    	List<VoucherIndexVO> cityPushList = voucherDao.selectCityPushVoucher(userId, locationId);
    	if(cityPushList != null && !cityPushList.isEmpty()) {
    		result.addAll(cityPushList);
    	}
    	// 查询按用户推送的优惠券列表
        List<VoucherIndexVO> userPushList = voucherDao.selectUserPushVoucher(userId);
        if(userPushList != null && !userPushList.isEmpty()) {
    		result.addAll(userPushList);
    	}
        
        return result;
    }

    @Override
    public void insertReceiveVoucher(UserInfoEntity user, List<String> voucherIds) {
        for(String item: voucherIds) {
        	if(StringUtils.isBlank(item)) {
        		continue;
        	}
        	VoucherPush voucherPush = voucherPushMapper.selectByPrimaryKey(item);
        	if(voucherPush == null) {
        		continue;
        	}
        	
        	VoucherBaseInformationEntity voucherBase = voucherBaseInformationDao.selectByPrimaryKey(voucherPush.getVoucherBaseId());
        	if(voucherBase == null) {
        		continue;
        	}
        	VouchersReceiveEntity voucher = new VouchersReceiveEntity();
        	voucher.setVouchersReceiveId(UUIDUtil.create());
        	voucher.setCreateTime(new Date());
        	voucher.setCreateBy(user.getUserId());
        	voucher.setUserId(user.getUserId());
        	voucher.setVoucherBaseId(voucherBase.getVoucherBaseId());
        	voucher.setGetTime(new Date());
        	voucher.setOverdueTime(voucherBase.getEndTime());
        	voucher.setVrType(voucherBase.getVbiType());
        	voucher.setVbiFull(voucherBase.getVbiFull());
        	voucher.setVrStatus(0);
        	voucher.setStartTime(voucherBase.getStartTime());
        	voucher.setEndTime(voucherBase.getEndTime());
        	voucher.setVbiName(voucherBase.getVbiName());
        	// 1:推送, 2:兑换
        	voucher.setVrSource(1);
        	// 1，满减   2，抵押金钱
        	if(voucherBase.getVbiType() == 1) {
        		voucher.setAmount(voucherBase.getVbiSubtract());
        	} else {
        		voucher.setAmount(voucherBase.getVbiMoney());
        	}
        	vouchersReceiveDao.insert(voucher);
        	// 更新优惠券领取状态
        	voucherPushMapper.receiveVoucherPush(item);
        }
    }

    @Override
    public List<VoucherVo> selectVoucherReceiveByUserId(String userId) {
        return voucherDao.selectVoucherReceiveByUserId(userId);
    }

}
