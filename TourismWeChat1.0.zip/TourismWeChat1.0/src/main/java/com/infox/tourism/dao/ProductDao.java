package com.infox.tourism.dao;

import com.infox.tourism.entity.vo.productVO.ProductVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface ProductDao {

    List<ProductVO> selectProductByActivityId(@Param("activityId") String activityId);
}
