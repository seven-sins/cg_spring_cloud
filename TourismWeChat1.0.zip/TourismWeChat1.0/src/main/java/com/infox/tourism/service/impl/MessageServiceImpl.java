package com.infox.tourism.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.infox.common.base.impl.BaseServiceImpl;
import com.infox.tourism.dao.MessageDao;
import com.infox.tourism.entity.MessagePushEntity;
import com.infox.tourism.entity.vo.MessageVO.MessageVO;
import com.infox.tourism.entity.vo.indexVO.MessagePushIndexVO;
import com.infox.tourism.service.MessageService;

import tk.mybatis.mapper.common.BaseMapper;


/**
 * 消息推送表
 *
 * @author yiwei
 * @email yiwei@163.com
 * @date 2018-11-21 21:21:45
 */
@Service("messagePushService")
public class MessageServiceImpl extends BaseServiceImpl<MessagePushEntity> implements MessageService {
    @Resource
    public void setBaseMapper(BaseMapper<MessagePushEntity> messagePushDao) {
        this.baseMapper = messagePushDao;
    }
    /**
    * messagePushDao层
    * @param params
    * @return
    */
    @Autowired
    private MessageDao messagePushDao;

    /**
     * 首页查找已发布的暴走快讯
     * @return
     */
    @Override
    public List<MessagePushIndexVO>selectListForWeChat(){
    	return messagePushDao.selectListForWeChat();
    }

    /**
     * 我的系统消息
     * @return
     */
    @Override
    public List<MessageVO> selectByUserId(String userId, int pageNum , int pageSize, String search, String time) {
        PageHelper.startPage(pageNum,pageSize);
        return messagePushDao.selectByUserId(userId, search, time);
    }

}
