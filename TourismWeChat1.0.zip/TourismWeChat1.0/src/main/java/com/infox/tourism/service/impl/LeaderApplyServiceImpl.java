package com.infox.tourism.service.impl;

import java.util.Date;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infox.common.base.impl.BaseServiceImpl;
import com.infox.tourism.dao.LeaderApplyDao;
import com.infox.tourism.entity.LeaderApplyEntity;
import com.infox.tourism.entity.v2.leaderinfo.vo.LeaderVo;
import com.infox.tourism.service.LeaderApplyService;
import com.infox.tourism.util.UUIDUtil;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 领队申请表Service
 * @author Tan Ling
 * 2018年12月10日 下午2:45:25
 */
@Service
public class LeaderApplyServiceImpl extends BaseServiceImpl<LeaderApplyEntity> implements LeaderApplyService {

	@Autowired
	LeaderApplyDao leaderAppDao;
	
	@Resource
	public void setBaseMapper(BaseMapper<LeaderApplyEntity> leaderAppDao) {
		this.baseMapper = leaderAppDao;
	}

	@Override
	public void insert(LeaderApplyEntity entity) {
		entity.setLeaderApplyId(UUIDUtil.create());
		entity.setCreateTime(new Date());
		
		baseMapper.insert(entity);
	}

	public LeaderVo selectLeaderApplyByUserId(String userId) {
		return leaderAppDao.selectLeaderApplyByUserId(userId);
	}


}
