package com.infox.tourism.dao;

import com.infox.tourism.entity.PhotoEntity;
import org.apache.ibatis.annotations.Mapper;
import tk.mybatis.mapper.common.BaseMapper;

import java.util.List;

/**
 * 照片表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-14 14:49:56
 */
@Mapper
public interface PhotoDao extends BaseMapper<PhotoEntity> {

    /**
     * 查询分页
     *
     * @return
     */
    List<PhotoEntity> queryPage();

    /**
     * 根据相册id查询照片
     * @param albumId
     * @return
     */
    List<PhotoEntity> queryByAlbumId(String albumId);

    /**
     * 删除相片
     * @param photoEntity
     * @return
     */
    boolean updateByPhotoId(PhotoEntity photoEntity);

    /**
     * 更新相片
     * @param photoEntity
     * @return
     */
    boolean updatePhoto(PhotoEntity photoEntity);

    /**
     * 图片的总数
     * @return
     */
    Integer total(String albumId);


}
