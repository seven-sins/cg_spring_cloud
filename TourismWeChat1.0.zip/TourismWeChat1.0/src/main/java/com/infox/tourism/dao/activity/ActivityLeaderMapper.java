package com.infox.tourism.dao.activity;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.infox.tourism.entity.ActivityLeaderRelation;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 活动领队查询
 * @author Tan Ling
 * @date 2019年1月15日 下午2:49:41
 */
@Mapper
public interface ActivityLeaderMapper extends BaseMapper<ActivityLeaderRelation> {
	
	/**
	 * 查询活动领队信息
	 * @author Tan Ling
	 * @date 2019年1月16日 下午1:50:16
	 * @param activityId
	 * @return
	 */
	List<ActivityLeaderRelation> findActivityLeaderByActivityId(@Param("activityId") String activityId);
}
