package com.infox.tourism.service;

import com.infox.tourism.entity.JoinCity;

public interface JoinCityService {
	
	/**
	 * 使用locationId查询接入城市信息
	 * @author Tan Ling
	 * @date 2019年5月24日 下午4:46:02
	 * @param sbLocationId
	 * @return
	 */
	JoinCity getBySbLocationId(String sbLocationId);
	
}
