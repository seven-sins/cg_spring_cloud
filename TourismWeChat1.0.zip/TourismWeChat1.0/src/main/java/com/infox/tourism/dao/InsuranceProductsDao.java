package com.infox.tourism.dao;

import org.apache.ibatis.annotations.Mapper;

import com.infox.tourism.entity.InsuranceProductsEntity;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 保险
 * @author Tan Ling
 * @date 2019年1月29日 下午4:42:37
 */
@Mapper
public interface InsuranceProductsDao extends BaseMapper<InsuranceProductsEntity> {


}
