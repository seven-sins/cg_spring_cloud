package com.infox.tourism.controller.v2;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.entity.ActivityInfoEntity;
import com.infox.tourism.service.v2.ActivityV2Service;
import com.infox.tourism.util.R;

import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

/**
 * @author yuanfang 2019年5月14日 上午10:57:28
 */
@RestController
@RequestMapping("/activity/v2")
public class ActivityV2Controller {

	@Autowired
	ActivityV2Service activityV2Service;

	@ApiOperation(value = "领队带领的活动")
	@GetMapping("/queryByLeaderId")
	public R queryByLeaderId(int pageNum, int pageSize, @ApiIgnore AuthUser user) {
		PageHelper.startPage(pageNum, pageSize);
		List<ActivityInfoEntity> list = activityV2Service.queryByLeaderId(user.getUserId());
		return R.ok().put("data", list).put("total", new PageInfo<ActivityInfoEntity>(list).getTotal());
	}

	@ApiOperation(value = "领队活动总数")
	@GetMapping("/queryCountByOpenId")
	public R queryCountByOpenId(@ApiIgnore AuthUser user) {
		int queryCountByOpenId = activityV2Service.queryCountByUserId(user.getUserId());
		return R.ok().put("data", queryCountByOpenId);
	}
}
