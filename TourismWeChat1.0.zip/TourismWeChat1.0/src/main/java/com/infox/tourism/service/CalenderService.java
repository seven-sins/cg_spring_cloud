package com.infox.tourism.service;

import java.util.List;

import com.infox.tourism.entity.vo.CalenderVO.CalenderCountVO;
import com.infox.tourism.entity.vo.CalenderVO.CalenderVO;

/**
 * 日历模块
 *
 * @author yiwei
 * @email
 * @date 2018-12-06 11:31:27
 */
public interface CalenderService {
	/**
	 * 查询月每天的活动总数
	 * 
	 * @return
	 */
	List<CalenderCountVO> selectCalenderCount(String startTime, String endTime, String companyId);

	/**
	 * 查询一天的活动列表
	 * 
	 * @return
	 */
	List<CalenderVO> selectCalenderListByDay(int pageNum, int pageSize, String dayTime, String companyId);
}
