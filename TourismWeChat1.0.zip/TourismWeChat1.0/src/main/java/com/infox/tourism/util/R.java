package com.infox.tourism.util;

import io.swagger.annotations.ApiModel;

import java.util.HashMap;
import java.util.Map;

/**
 * 返回数据
 *
 * @Author: cenjinxing
 * @Date: Created in 2018/9/26 14:52
 **/
@ApiModel(value = "返回的响应属性",description = "无论成功或失败，一定会返回此响应信息." )
public class R extends HashMap<String, Object> {

    private static final long serialVersionUID = 1L;
    private static final String SUCCESS = "操作成功";

    public R() {
        put("code", 0);
    }

    public static R error() {
        return error(500, "未知异常，请联系管理员");
    }

    public static R error(String msg) {
        return error(500, msg);
    }

    public static R error(int code, String msg) {
        R r = new R();
        r.put("code", code);
        r.put("statusText", msg);
        return r;
    }

    public static R ok(String msg) {
        R r = new R();
        r.put("msg", msg);
        return r;
    }

    public static R ok(Map<String, Object> map) {
        R r = new R();
        r.putAll(map);
        return r;
    }

    public static R ok() {
        return new R();
    }

    public R put(String key, Object value) {
        super.put(key, value);
        return this;
    }
    
    public static R success() {
        return new R().put("data", SUCCESS);
    }
}
