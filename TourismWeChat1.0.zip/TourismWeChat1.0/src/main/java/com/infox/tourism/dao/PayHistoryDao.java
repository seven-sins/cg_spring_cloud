package com.infox.tourism.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.infox.tourism.entity.PayHistoryEntity;

import tk.mybatis.mapper.common.BaseMapper;

/**
  * 支付历史记录
 * @author Tan Ling
 * 2018年12月11日 下午8:51:09
 */
@Mapper
public interface PayHistoryDao extends BaseMapper<PayHistoryEntity> {

	/**
	 * 根据交易流水号获取记录
	 * @param trxid
	 * @return
	 */
	PayHistoryEntity getByTrxid(@Param("trxid") String trxid);
}
