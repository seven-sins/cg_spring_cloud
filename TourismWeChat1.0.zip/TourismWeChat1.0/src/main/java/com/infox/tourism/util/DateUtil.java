package com.infox.tourism.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;

/**
 * @Author: cenjinxing
 * @Date: Created in 2018/9/25 13:57
 **/
public class DateUtil {

    @SuppressWarnings("deprecation")
	public static Date getYYMMDD(){
        java.util.Date  date=new java.util.Date("");
        Date  data1=new Date(date.getTime());
        return data1;
    }

    /**
     * 获取当前时间
     * @return
     */
    public static String getYYYYMMDDHHMMSS(){
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//        simpleDateFormat.parse();
        String s = simpleDateFormat.format(new java.util.Date());
        System.out.println(s);
        return s;
    }


    /**
     * 生成随机文件名：当前年月日时分+五位随机数
     * @return
     */
    public static String getRandomFileName() {

        SimpleDateFormat simpleDateFormat;

        simpleDateFormat = new SimpleDateFormat("yyyyMMddmm");

        java.util.Date date = new java.util.Date();

        String str = simpleDateFormat.format(date);
        System.out.println("当前时间"+str);

        Random random = new Random();

        int rannum = (int) (random.nextDouble() * (99999 - 10000 + 1)) + 10000;// 获取5位随机数

        return str + rannum;// 当前时间  }
    }

    /**
     * 判断时间大小
     */
    public static boolean timeComparison(String beginTime) throws ParseException {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMddmm");

        java.util.Date d= simpleDateFormat.parse(beginTime);
        java.util.Date now = simpleDateFormat.parse(DateUtil.getYYMMDD().toString());

        if(now.getTime()<d.getTime()){

            // System.out.println("开始");
            return false;
        }else {
            // System.out.println("还没开始");
            return true;
        }
    }

    /**
     * 时间
     * @param hour
     * @param minure
     * @param second
     * @return
     */
    public static java.util.Date getTime(int hour, int minure, int second){
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, hour);  //小时
        calendar.set(Calendar.MINUTE, minure);  //分
        calendar.set(Calendar.SECOND, second);  //ss
        java.util.Date time = calendar.getTime();
        return time;
    }

    /**
     * Date转String
     * @param date
     * @return
     */
    public static String getStringByDate(java.util.Date date){
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String s = simpleDateFormat.format(date);
        return s;
    }

    /**
     * 改变时间，单位（小时）
     * @param time
     * @param amount
     * @return
     */
    public static String getDemandTime(String time,int amount) {
        // 创建 Calendar 对象
        Calendar calendar = Calendar.getInstance();
        try {
            // 对 calendar 设置时间的方法
            // 设置传入的时间格式
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            // 指定一个日期
            java.util.Date date = dateFormat.parse(time);
            // 对 calendar 设置为 date 所定的日期
            calendar.setTime(date);

            calendar.add(Calendar.HOUR_OF_DAY, amount);

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

            String dateStr = sdf.format(calendar.getTimeInMillis());

            return dateStr;
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     *
     * @doc 日期转换周几
     * 日期 date格式时间
     * @return String 例:周二
     */
    public static String dateToWeek(Date date) {
    	if(date == null) {
    		return "";
    	}
        String[] weekDays = { "周日", "周一", "周二", "周三", "周四", "周五", "周六" };
        Calendar cal = Calendar.getInstance(); // 获得一个日历
        cal.setTime(date);
        int w = cal.get(Calendar.DAY_OF_WEEK) - 1; // 指示一个星期中的某天。
        if (w < 0)
            w = 0;
        return weekDays[w];
    }

    /**
     * date2比date1多的天数
     * @param date1
     * @param date2
     * @return
     */
    public static int differentDays(Date date1,Date date2)
    {
        Calendar cal1 = Calendar.getInstance();
        cal1.setTime(date1);

        Calendar cal2 = Calendar.getInstance();
        cal2.setTime(date2);
        int day1= cal1.get(Calendar.DAY_OF_YEAR);
        int day2 = cal2.get(Calendar.DAY_OF_YEAR);

        int year1 = cal1.get(Calendar.YEAR);
        int year2 = cal2.get(Calendar.YEAR);
        if(year1 != year2)   //同一年
        {
            int timeDistance = 0 ;
            for(int i = year1 ; i < year2 ; i ++)
            {
                if(i%4==0 && i%100!=0 || i%400==0)    //闰年
                {
                    timeDistance += 366;
                }
                else    //不是闰年
                {
                    timeDistance += 365;
                }
            }

            return timeDistance + (day2-day1) ;
        }
        else    //不同年
        {
            return day2-day1;
        }
    }

    /*
     * 将时间转换为时间戳
     */
    public static String dateToStamp(String s) throws ParseException{
        String res;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = simpleDateFormat.parse(s);
        long ts = date.getTime();
        res = String.valueOf(ts);
        return res;
    }


    /*
     * 将时间戳转换为时间
     */
    public static String stampToDate(String s){
        String res;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        long lt = new Long(s);
        Date date = new Date(lt);
        res = simpleDateFormat.format(date);
        return res;
    }

}
