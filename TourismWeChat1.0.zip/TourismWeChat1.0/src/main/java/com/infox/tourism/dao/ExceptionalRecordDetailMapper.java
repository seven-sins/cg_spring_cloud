package com.infox.tourism.dao;

import org.apache.ibatis.annotations.Mapper;

import com.infox.tourism.entity.v2.leader.ExceptionalRecordDetail;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 打赏明细
 * @author Tan Ling
 * @date 2019年7月4日 上午10:38:19
 */
@Mapper
public interface ExceptionalRecordDetailMapper extends BaseMapper<ExceptionalRecordDetail> {

}
