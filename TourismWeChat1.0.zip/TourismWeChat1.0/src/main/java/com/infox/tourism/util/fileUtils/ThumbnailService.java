package com.infox.tourism.util.fileUtils;


import net.coobird.thumbnailator.Thumbnails;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.infox.common.qiniu.QiniuYunUtil;

/**
 * 缩略图服务类
 * @author ZhangCheng on 2017-07-19
 *
 */
@Service
public class ThumbnailService {

    public static final int WIDTH = 200;
    public static final int HEIGHT = 200;

    public static final int WIDTH1 = 400;
    public static final int HEIGHT1 = 400;

    public static final int WIDTH2 = 600;
    public static final int HEIGHT2 = 600;

    public String thumbnail(MultipartFile file,String uploadPath,String realUploadPath, String newFileName, String fileSuffixName){
        String smallFileName =newFileName;

        try{
            String twoHundred = realUploadPath + "s_" + smallFileName;
            Thumbnails.of(file.getInputStream()).size(WIDTH, HEIGHT).toFile(twoHundred);
            String fourHundred = realUploadPath + "m_" + smallFileName;
            Thumbnails.of(file.getInputStream()).size(WIDTH1, HEIGHT1).toFile(fourHundred);
            String sixHundred = realUploadPath + "h_" + smallFileName;
            Thumbnails.of(file.getInputStream()).size(WIDTH2, HEIGHT2).toFile(sixHundred);
            
            /**
             * 同步到七牛云
             */
            QiniuYunUtil.uploadToQiniu(realUploadPath + "s_" + smallFileName, "s_" + smallFileName);
            QiniuYunUtil.uploadToQiniu(realUploadPath + "m_" + smallFileName, "m_" + smallFileName);
            QiniuYunUtil.uploadToQiniu(realUploadPath + "h_" + smallFileName, "h_" + smallFileName);
        }catch (Exception e) {
            e.printStackTrace();
        }
        return realUploadPath + "s_" + smallFileName + ", " + realUploadPath + "m_" + smallFileName;
    }
}
