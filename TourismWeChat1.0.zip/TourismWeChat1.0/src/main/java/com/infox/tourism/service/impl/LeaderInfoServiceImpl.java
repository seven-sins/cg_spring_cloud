package com.infox.tourism.service.impl;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageHelper;
import com.infox.common.base.impl.BaseServiceImpl;
import com.infox.common.exception.CustomException;
import com.infox.common.utils.redis.RedisConstant;
import com.infox.common.utils.redis.RedisService;
import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.config.resolver.Guest;
import com.infox.tourism.dao.AttentionDao;
import com.infox.tourism.dao.ExceptionalRecordDao;
import com.infox.tourism.dao.ExceptionalRecordDetailMapper;
import com.infox.tourism.dao.ExceptionalSumInfoDao;
import com.infox.tourism.dao.LeaderApplyDao;
import com.infox.tourism.dao.LeaderInfoDao;
import com.infox.tourism.entity.AttentionEntity;
import com.infox.tourism.entity.ExceptionalRecordEntity;
import com.infox.tourism.entity.LeaderApplyEntity;
import com.infox.tourism.entity.LeaderInfoEntity;
import com.infox.tourism.entity.LeaderLevelEntity;
import com.infox.tourism.entity.PhotoEntity;
import com.infox.tourism.entity.UserInfoEntity;
import com.infox.tourism.entity.v2.leader.ExceptionalRecordDetail;
import com.infox.tourism.entity.v2.leader.LeaderScoreVo;
import com.infox.tourism.entity.v2.leaderinfo.vo.LeaderVo;
import com.infox.tourism.entity.vo.leaderInfoVO.ActivityUnderLeaderVO;
import com.infox.tourism.entity.vo.leaderInfoVO.LeaderAndActivityVO;
import com.infox.tourism.entity.vo.leaderInfoVO.LeaderPhotoAlbumVO;
import com.infox.tourism.entity.vo.leaderInfoVO.LeaderRecordVO;
import com.infox.tourism.entity.vo.leaderInfoVO.leaderEvaVO;
import com.infox.tourism.service.LeaderInfoService;
import com.infox.tourism.util.DateUtil;
import com.infox.tourism.util.UUIDUtil;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 领队个人信息表
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class LeaderInfoServiceImpl extends BaseServiceImpl<LeaderInfoEntity> implements LeaderInfoService {
    @Autowired
    RedisService redisService;
	@Autowired
	LeaderInfoDao leaderInfoDao;
	@Autowired
	LeaderApplyDao leaderApplyDao;
	@Autowired
	ExceptionalRecordDao exceptionalRecordDao;
	@Autowired
	ExceptionalSumInfoDao exceptionalSumInfoDao;
	@Autowired
	AttentionDao attentionDao;
	@Autowired
	ExceptionalRecordDetailMapper exceptionalRecordDetailMapper;
	
	@Resource
	public void setBaseMapper(BaseMapper<LeaderInfoEntity> leaderInfoDao) {
		this.baseMapper = leaderInfoDao;
	}

	@Override
	public LeaderInfoEntity insert(UserInfoEntity user, LeaderInfoEntity entity) {
		LeaderInfoEntity dbLeader = leaderInfoDao.getByUserId(entity.getUserId());
		if(dbLeader != null) {
			throw new CustomException("不能重复提交申请");
		}
		/**
		 * 领队个人信息表
		 */
		entity.setLeaderId(UUIDUtil.create());
		entity.setCreateTime(new Date());
		// 1不删除
		entity.setIsDelete(1);
		// 0不冻结
		entity.setlEnable(1);
		entity.setHeadImg(user.getHeadImg());
		leaderInfoDao.insert(entity);
		/**
		 * 领队申请表
		 */
		LeaderApplyEntity leaderApply = new LeaderApplyEntity();
		leaderApply.setLeaderApplyId(UUIDUtil.create());
		leaderApply.setUserId(entity.getUserId());
		leaderApply.setLeaderId(entity.getLeaderId());
		leaderApply.setLProposer(entity.getNickName());
		leaderApply.setlReason(entity.getReason());
		// -1不同意   0未处理    1 同意
		leaderApply.setlStatus(0);
		leaderApply.setCreateBy(user.getUserId());
		leaderApply.setCreateTime(new Date());
		// 1不删除
		leaderApply.setIsDelete(1);
		leaderApply.setApproveTime(new Date());
		leaderApplyDao.insert(leaderApply);

		return entity;
	}

	/**
    * 查询领队等级列表
    * @return
    */
	@Override
	public List<LeaderLevelEntity> queryLeaderLevelList() {
		 List<LeaderLevelEntity> list = leaderInfoDao.queryLeaderLevelList();
	     return list;
	}
	
    /**
     * 查询领队分页
     *
     * @param pageNum
     * @param pageSize
     * @param search
     * @return
     */
    @Override
    public List<LeaderAndActivityVO> queryLeaderList(int pageNum, int pageSize, String leaderLevel, String companyId) {
        // 使用分页插件实现分页
        PageHelper.startPage(pageNum, pageSize);
        // 调用dao的方法
        List<LeaderAndActivityVO> list = leaderInfoDao.queryLeaderList(leaderLevel, companyId);
        return list;
    }

    /**
     * 查询领队活动分页
     *
     * @param pageNum
     * @param pageSize
     * @param search
     * @return
     */
    @Override
    public List<ActivityUnderLeaderVO> queryLeaderActivityList(int pageNum, int pageSize,int state, String leaderId) {
        // 使用分页插件实现分页
        PageHelper.startPage(pageNum, pageSize);
        // 调用dao的方法
        List<ActivityUnderLeaderVO> list = leaderInfoDao.queryLeaderActivityList(state,leaderId);
        return list;
    }

	@Override
	public LeaderAndActivityVO queryLeaderById(String leaderId, Guest user) {
		LeaderAndActivityVO leaderAndActivityVO = null;
		leaderAndActivityVO = leaderInfoDao.queryLeaderById(leaderId);
		if(leaderAndActivityVO == null) {
			return null;
		}
		/**
		 * 查询当前用户是否关注过领队
		 */
		if(StringUtils.isNotBlank(user.getUserId())) {
			List<AttentionEntity> AttentionEntityList = attentionDao.queryAttByUserId(leaderId, user.getUserId());
			if (AttentionEntityList.size() > 0) {
				AttentionEntity attention = AttentionEntityList.get(0);
				leaderAndActivityVO.setAttentionOrNot(attention.getIsEnable());
			}
		}
		/**
		 * 查询领队评分
		 */
		LeaderScoreVo leaderScoreVo = leaderInfoDao.queryLeaderScoreByLeaderId(leaderId);
		// 查询领队带队次数
		leaderAndActivityVO.setLeadNum(leaderInfoDao.queryLeaderNumByLeaderId(leaderId));
		// 查询领队被关注数
		leaderAndActivityVO.setFollowNum(leaderInfoDao.queryFollowNumByLeaderId(leaderId));
		
		BigDecimal overallScore = leaderScoreVo.getTrafficSatisfaction().add(leaderScoreVo.getLeaderSatisfaction()).add(leaderScoreVo.getLineSatisfaction());
		// 领队综合评分
		leaderAndActivityVO.setOverallScore(overallScore.divide(new BigDecimal("3"), 2, BigDecimal.ROUND_HALF_UP));
		leaderAndActivityVO.setEvaluationNum(leaderScoreVo.getEvaluationNum());
		leaderAndActivityVO.setTrafficSatisfaction(leaderScoreVo.getTrafficSatisfaction());
		leaderAndActivityVO.setLeaderSatisfaction(leaderScoreVo.getLeaderSatisfaction());
		leaderAndActivityVO.setLineSatisfaction(leaderScoreVo.getLineSatisfaction());
		
		return leaderAndActivityVO;
	}

	@Override
	public List<LeaderPhotoAlbumVO> queryLeaderPhotoList(int pageNum, int pageSize, String leaderId) {
		   // 使用分页插件实现分页
        PageHelper.startPage(pageNum, pageSize);
        // 调用dao的方法
        List<LeaderPhotoAlbumVO> list = leaderInfoDao.queryLeaderPhotoList(leaderId);
        return list;
	}

	@Override
	public List<PhotoEntity> queryLeaderPhotoDetailList(int pageNum, int pageSize,String albumId) {
		// 使用分页插件实现分页
        PageHelper.startPage(pageNum, pageSize);
        // 调用dao的方法
        List<PhotoEntity> list = leaderInfoDao.queryLeaderPhotoDetailList(albumId);
        return list;
	}

	@Override
	public List<leaderEvaVO> queryLeaderEvaluationList(int pageNum, int pageSize, String leaderId) {
		// 使用分页插件实现分页
        PageHelper.startPage(pageNum, pageSize);
        // 调用dao的方法
        List<leaderEvaVO> list = leaderInfoDao.queryLeaderEvaluationList(leaderId);
        return list;
	}

	@Override
	public List<LeaderRecordVO> queryLeaderExReList(int pageNum, int pageSize, String leaderId) {
		// 使用分页插件实现分页
        PageHelper.startPage(pageNum, pageSize);
        // 调用dao的方法
        List<LeaderRecordVO> list = leaderInfoDao.queryLeaderExReList(leaderId);
        return list;
	}

	@Override
	public ExceptionalRecordEntity insert(ExceptionalRecordEntity exceptionalRecordEntity, AuthUser user) {
		/**
		 * 1. 添加主体信息
		 */
		String leaderIdStr = exceptionalRecordEntity.getLeaderId();
		exceptionalRecordEntity.setExceptionalRecordId(UUIDUtil.create());
		exceptionalRecordEntity.setCreateTime(DateUtil.getYYYYMMDDHHMMSS());
		exceptionalRecordEntity.setCreateBy(user.getUserId());
		exceptionalRecordEntity.setExceptionalPeople(user.getUserId());
		exceptionalRecordEntity.setErUrl(user.getHeadImg());
		exceptionalRecordEntity.setExceptionalTime(DateUtil.getYYYYMMDDHHMMSS());
		exceptionalRecordEntity.setState(0);
		// 移除主体信息中的leaderId, 改用子表存储
		exceptionalRecordEntity.setLeaderId("");
		exceptionalRecordDao.insert(exceptionalRecordEntity);
		/**
		 * 2. 添加明细
		 */
		String[] leaderIds = leaderIdStr.split(",");
		// 打赏金额均分
		BigDecimal amount = exceptionalRecordEntity.getErMoney().divide(new BigDecimal(leaderIds.length), BigDecimal.ROUND_DOWN);
		for(String leaderId: leaderIds) {
			ExceptionalRecordDetail detail = new ExceptionalRecordDetail();
			detail.setExceptionalRecordDetailId(UUIDUtil.create());
			detail.setExceptionalRecordId(exceptionalRecordEntity.getExceptionalRecordId());
			detail.setLeaderId(leaderId);
			detail.setAmount(amount);
			exceptionalRecordDetailMapper.insert(detail);
		}
		
		return exceptionalRecordEntity;
	}

	@Override
	public ExceptionalRecordEntity selectExceptionalRecordById(String exceptionalRecordId) {
		ExceptionalRecordEntity exceptionalRecordEntity = exceptionalRecordDao.selectByPrimaryKey(exceptionalRecordId);
		exceptionalRecordEntity.setOmoney(exceptionalRecordEntity.getErMoney());
		return exceptionalRecordEntity;
	}

	@Override
	public boolean insertAttention(AttentionEntity attentionEntity, AuthUser user) {
		List<AttentionEntity> attentionEntityList = attentionDao.queryAttByUserId(attentionEntity.getLeaderId(), user.getUserId());
		AttentionEntity attention = new AttentionEntity();
		if (attentionEntityList.size() > 0) {
			attention = attentionEntityList.get(0);
			attentionEntity.setAttentionPeople(user.getUserId());
			attention.setIsEnable(attentionEntity.getIsEnable());
			attention.setUpdateBy(attentionEntity.getUpdateBy());
			attention.setUpdateTime(DateUtil.getYYYYMMDDHHMMSS());
			attention.setAttentionTime(DateUtil.getYYYYMMDDHHMMSS());
			attentionDao.updateById(attention);
		} else {
			attentionEntity.setAttentionPeople(user.getUserId());
			attentionEntity.setaUrl(user.getHeadImg());
			attentionEntity.setAttentionId(UUIDUtil.create());
			attentionEntity.setCreateBy(user.getUserId());
			attentionEntity.setCreateTime(DateUtil.getYYYYMMDDHHMMSS());
			attentionEntity.setAttentionTime(DateUtil.getYYYYMMDDHHMMSS());
			attentionEntity.setIsEnable(1);
			attentionDao.insert(attentionEntity);
		}

		return true;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<LeaderInfoEntity> findLeader() {
		List<LeaderInfoEntity> leaderList = (List<LeaderInfoEntity>) redisService.get(RedisConstant.LEADER_INFO_PREFIX);
		if(leaderList == null) {
			leaderList = leaderInfoDao.findLeader();
			redisService.add(RedisConstant.LEADER_INFO_PREFIX, leaderList, 3);
		}
		
		return leaderList;
	}

	/**
	 * 根据userId查询
	 * @param userId
	 * @return
	 */
	@Override
	public List<LeaderVo> queryLeaderByUserId(String userId, int pageNum, int pageSize) {
		PageHelper.startPage(pageNum,pageSize);
		return leaderInfoDao.queryLeaderByUserId(userId);
	}

	@Override
	public Integer selectCanWithdrawalsMoneyByUserId(String userId) {
		int money = 0;
		Integer id1 = leaderInfoDao.selectExceptionalMoneyByUserId(userId);
		Integer id = leaderInfoDao.selectDistributionAmountByUserId(userId);
		if(id1 == null){
			id1 = 0;
		}
		if(id == null){
			id = 0;
		}
		money = id1 + id;
		return money;
	}

	@Override
	public LeaderScoreVo queryLeaderScoreByLeaderId(String leaderId) {
		return leaderInfoDao.queryLeaderScoreByLeaderId(leaderId);
	}

}
