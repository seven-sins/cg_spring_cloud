package com.infox.tourism.service.v2.impl;

import java.util.Date;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.infox.common.base.impl.BaseServiceImpl;
import com.infox.tourism.entity.UserInfoEntity;
import com.infox.tourism.entity.v2.activityInfo.ViewRecord;
import com.infox.tourism.service.v2.ViewRecordService;
import com.infox.tourism.util.UUIDUtil;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 活动访问记录
 * @author Tan Ling
 * @date 2019年6月20日 下午5:39:14
 */
@Service
public class ViewRecordServiceImpl extends BaseServiceImpl<ViewRecord> implements ViewRecordService {

	@Resource
	public void setBaseMapper(BaseMapper<ViewRecord> baseMapper) {
		this.baseMapper = baseMapper;
	}

	@Override
	public void addViewRecord(UserInfoEntity user, String lineId, String activityId) {
		ViewRecord viewRecord = new ViewRecord();
		viewRecord.setViewRecordId(UUIDUtil.create());
		viewRecord.setUserId(user.getUserId() == null ? "" : user.getUserId());
		/**
		 * viewType: 1线路, 2:活动
		 */
		if(StringUtils.isNotBlank(lineId)) {
			viewRecord.setLineId(lineId);
			viewRecord.setViewType(1);
		}
		if(StringUtils.isNotBlank(activityId)) {
			viewRecord.setActivityId(activityId);
			viewRecord.setViewType(2);
		}
		viewRecord.setViewTime(new Date());
		
		this.baseMapper.insert(viewRecord);
	}

}
