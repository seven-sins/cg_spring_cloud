package com.infox.tourism.service.v2.travel.note;

import java.util.List;

import com.infox.common.base.BaseService;
import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.config.resolver.Guest;
import com.infox.tourism.entity.UserInfoEntity;
import com.infox.tourism.entity.travel.note.TravelNote;

/**
 * 游记
 * @author Tan Ling
 * @date 2019年7月5日 下午3:31:05
 */
public interface TravelNoteService extends BaseService<TravelNote> {

	/**
	 * 列表查询
	 * @author Tan Ling
	 * @date 2019年7月5日 下午3:18:22
	 * @param travelNote
	 * @return
	 */
	List<TravelNote> find(TravelNote travelNote, Guest guest);
	
	/**
	 * 浏览次数+1
	 * @author Tan Ling
	 * @date 2019年7月5日 下午3:13:06
	 * @param travelNoteId
	 */
	void addViewNum(String travelNoteId);
	/**
	 * 点赞数+1
	 * @author Tan Ling
	 * @date 2019年7月5日 下午3:13:33
	 * @param travelNoteId
	 */
	int addLikeNum(String travelNoteId, UserInfoEntity user);
	/**
	 * 分享转发数+1
	 * @author Tan Ling
	 * @date 2019年7月5日 下午3:13:54
	 * @param travelNoteId
	 */
	void addShareNum(String travelNoteId);
	/**
	 * 评论数+1
	 * @author Tan Ling
	 * @date 2019年7月5日 下午3:14:18
	 * @param travelNoteId
	 */
	void addCommentNum(String travelNoteId);
	/**
	 * 收藏数+1
	 * @author Tan Ling
	 * @date 2019年7月5日 下午4:19:36
	 * @param travelNoteId
	 */
	int addCollectNum(String travelNoteId, UserInfoEntity user);
	/**
	 * 单记录查询
	 * @author Tan Ling
	 * @date 2019年7月5日 下午5:32:28
	 * @param travelNoteId
	 * @return
	 */
	TravelNote getByTravelNoteId(String travelNoteId, Guest guest);
	
	/**
	 * 删除游记
	 * @author Tan Ling
	 * @date 2019年7月9日 上午11:01:06
	 * @param travelNoteId
	 */
	void deleteByTravelNoteId(String travelNoteId);
	
	/**
	 * 查询用户收藏的游记
	 * @author Tan Ling
	 * @date 2019年7月9日 下午3:52:28
	 * @param travelNote
	 * @param user
	 * @return
	 */
	List<TravelNote> collectList(TravelNote travelNote, AuthUser user);
}
