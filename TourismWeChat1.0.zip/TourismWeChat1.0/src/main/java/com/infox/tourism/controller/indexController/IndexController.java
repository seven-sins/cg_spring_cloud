package com.infox.tourism.controller.indexController;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSONObject;
import com.infox.common.utils.Assert;
import com.infox.common.utils.RestUtil;
import com.infox.tourism.async.UserCity;
import com.infox.tourism.config.resolver.AuthUser;
import com.infox.tourism.config.resolver.Guest;
import com.infox.tourism.constants.ResultCode;
import com.infox.tourism.entity.SbLocationEntity;
import com.infox.tourism.entity.vo.indexVO.CarouselMapIndexVO;
import com.infox.tourism.entity.vo.indexVO.MessagePushIndexVO;
import com.infox.tourism.entity.vo.indexVO.VoucherIndexVO;
import com.infox.tourism.entity.vo.lineVO.LineThemeVO;
import com.infox.tourism.entity.vo.lineVO.LineTypeVO;
import com.infox.tourism.entity.vo.locationVO.SBLocationVO;
import com.infox.tourism.service.BannerService;
import com.infox.tourism.service.JoinCityService;
import com.infox.tourism.service.LineThemeService;
import com.infox.tourism.service.LineTypeService;
import com.infox.tourism.service.LocationService;
import com.infox.tourism.service.MessageService;
import com.infox.tourism.service.VoucherService;
import com.infox.tourism.util.ImgUtil;
import com.infox.tourism.util.R;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * @Description 微信公众号首页Controller
 * @Author Lizhihui
 * @Date 2018/11/27
 */
@RestController
@RequestMapping("/index")
@Api(description = "首页公众号接口",tags = {"indexController"})
public class IndexController {
	private static final Logger LOG = LoggerFactory.getLogger(IndexController.class);
    @Value("${baiduMap.url}")
    private String mapUrl;
    @Value("${baiduMap.ak}")
    private String ak;
    @Value("${baiduMap.ipAddrUrl}")
    private String ipAddrUrl;
    @Autowired
    private BannerService bannerService;
    @Autowired
    private LocationService locationService;
    @Autowired
    private MessageService messageService;
    @Autowired
    private VoucherService voucherService;
    @Autowired
    private LineTypeService lineTypeService;
    @Autowired
    private LineThemeService lineThemeService;
    @Autowired
    private JoinCityService joinCityService;
    /**
     * 用户定位信息
     */
    @Autowired
    private UserCity userCity;

    @GetMapping("/slideShow")
    public R slideShow(String sbLocationId) {
    	List<CarouselMapIndexVO> banners = bannerService.selectListOfWeChat(sbLocationId);
    	return R.ok().put("data", banners);
    }
    
    @ApiOperation("获取首页数据")
    @GetMapping("/getWeChatIndexData")
    public R getWeChatIndexData(){
        List<MessagePushIndexVO> messages = messageService.selectListForWeChat();
        if(messages != null && !messages.isEmpty()) {
        	for(MessagePushIndexVO item: messages) {
        		item.setMpUrl(ImgUtil.hight(item.getMpUrl()));
        	}
        }
        List<LineTypeVO> lineTypes = lineTypeService.selectTop3LineType();
        if(lineTypes != null && !lineTypes.isEmpty()) {
        	for(LineTypeVO item: lineTypes) {
        		item.setTypeIcon(ImgUtil.small(item.getTypeIcon()));
        	}
        }
        List<LineThemeVO> lineThemes = lineThemeService.selectIndexTheme();
        if(lineThemes != null && !lineThemes.isEmpty()) {
        	for(LineThemeVO item: lineThemes) {
        		item.setLineThemeIcon(ImgUtil.small(item.getLineThemeIcon()));
        	}
        }
        List<LineThemeVO> lineThemesV2 = lineThemeService.selectIndexThemeV2();
        if(lineThemesV2 != null && !lineThemesV2.isEmpty()) {
        	for(LineThemeVO item: lineThemesV2) {
        		item.setLineThemeIcon(ImgUtil.small(item.getLineThemeIcon()));
        	}
        }
        HashMap<String,Object> data = new HashMap<>();
        data.put("messages",messages);
        data.put("lineTypes",lineTypes);
        data.put("lineThemes",lineThemes);
        data.put("lineThemesV2",lineThemesV2);
        
        return R.ok().put("data",data);
    }

    @ApiOperation("获取覆盖城市")
    @GetMapping("/getCoverCity")
    public R getCoverCity(String locationId){
        List<SBLocationVO> list = locationService.selectCoverCity(locationId);
        return R.ok().put("data",list);
    }

    @ApiOperation("根据经纬度获取城市")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "lat", value = "纬度", required = true),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "lng", value = "经度", required = true)
    })
    @GetMapping("/getCityByGPS")
    public R getCityByGPS(String lat, String lng, HttpServletRequest request) {
    	// 改为使用ip获取
    	String ip = getLocalIp(request);
    	String ipUrl = String.format(ipAddrUrl, ak, ip);
    	JSONObject json = RestUtil.get(ipUrl);
    	/**
    	 * 获取token(缓存定位信息使用)
    	 */
    	String token = request.getHeader("token");
    	
    	// 调用成功返回信息
    	if(json != null && json.containsKey("status") && "0".equals(json.getString("status"))) {
    		if(json.containsKey("content")) {
    			JSONObject content = json.getJSONObject("content");
    			if(content.containsKey("point")) {
    				JSONObject point = content.getJSONObject("point");
    				lng = point.getString("x");
        			lat = point.getString("y");
        			LOG.info("=============使用ip获取经纬度: lat-" + lat + ", lng-" + lng);
    			}
    		}
    	}
    	
    	// 如参数为空, 取广州市的经纬度
    	if(StringUtils.isBlank(lat) || StringUtils.isBlank(lng)) {
    		lat = "23.137365341186523";
    		lng = "113.35107421875";
    	}
    	String requestUrl = mapUrl + "?output=json&pois=0&ak={ak}&location={location}";
    	
        RestTemplate restTemplate = new RestTemplate();
        HashMap<String, Object> args = new HashMap<>();
        args.put("ak", ak);
        args.put("location", lat + "," + lng);
        JSONObject respon = JSONObject.parseObject(restTemplate.getForObject(requestUrl, String.class, args));
        /**
         * 缓存用户定位信息
         */
        userCity.cacheUserPosition(token, respon);
        
        if (respon.getInteger("status") == 0) {
            String adcode = respon.getJSONObject("result").getJSONObject("addressComponent").getString("adcode");
            if ("0".equals(adcode)) {
                SbLocationEntity location = locationService.selectByValueForWeChat("440100");
                HashMap<String,Object> result = new HashMap<>();
                result.put("code",ResultCode.WECHAT_INDEX_GPS_ERROR.getCode());
                result.put("msg",ResultCode.WECHAT_INDEX_GPS_ERROR.getMsg());
                result.put("data",location);
                return R.ok().put("data",result).put("ip", ip);
            }else if (!"4401".equals(adcode.substring(0,4)) && !"4406".equals(adcode.substring(0,4))){
                SbLocationEntity location = locationService.selectByValueForWeChat("440100");
                HashMap<String,Object> result = new HashMap<>();
                result.put("code",ResultCode.WECHAT_INDEX_GPS_UNSUPPORT.getCode());
                result.put("msg",ResultCode.WECHAT_INDEX_GPS_UNSUPPORT.getMsg());
                result.put("data",location);
                return R.ok().put("data",result).put("ip", ip);
            }
            else {
            	/**
            	 * 如果获取到的不是覆盖城市, 默认返回广州市
            	 */
            	SbLocationEntity location = locationService.selectByValueForWeChat(adcode);
            	Assert.notNull(location, "调用百度API定位失败");
            	if(joinCityService.getBySbLocationId(location.getSbLocationId()) == null) {
            		location = locationService.selectByValueForWeChat("440100");
            	}
            	
            	return R.ok().put("data", location).put("ip", ip);
            }
        } else {
            return R.error(ResultCode.UN_KNOW_EXCEPTION.getCode(), "调用百度Api出错:" + respon.getString("message"));
        }
    }

    @ApiOperation("获取优惠券列表")
    @GetMapping("/getVoucherList")
    public R getVoucherList(Guest authUser, String locationId){
    	if(authUser == null || StringUtils.isBlank(authUser.getUserId())) {
    		return R.ok().put("data", new ArrayList<>());
    	}
    	if(StringUtils.isBlank(locationId)) {
    		return R.ok().put("data", new ArrayList<>());
    	}
        List<VoucherIndexVO> list = voucherService.selectPushVoucher(authUser.getUserId(), locationId);
        return R.ok().put("data", list);
    }

    @ApiOperation("一键领取优惠券")
    @PostMapping("/receiveVouchers")
    public R receiveVouchers(@RequestBody Map<String, String> json,AuthUser authUser){
        String voucherIds = json.get("voucherIds");
        if(StringUtils.isBlank(voucherIds)){
            return R.error(ResultCode.PARAM_ERROR.getCode(),ResultCode.PARAM_ERROR.getMsg());
        }
        voucherService.insertReceiveVoucher(authUser,Arrays.asList(voucherIds.split(",")));
        return R.ok().put("statusText","领取成功");
    }
    
    public static String getLocalIp(HttpServletRequest request) {
    	String ip = request.getHeader("x-forwarded-for"); 
        System.out.println("x-forwarded-for ip: " + ip);
        if (ip != null && ip.length() != 0 && !"unknown".equalsIgnoreCase(ip)) {  
            // 多次反向代理后会有多个ip值，第一个ip才是真实ip
            if( ip.indexOf(",")!=-1 ){
                ip = ip.split(",")[0];
            }
        }  
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {  
            ip = request.getHeader("Proxy-Client-IP");  
            System.out.println("Proxy-Client-IP ip: " + ip);
        }  
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {  
            ip = request.getHeader("WL-Proxy-Client-IP");  
            System.out.println("WL-Proxy-Client-IP ip: " + ip);
        }  
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {  
            ip = request.getHeader("HTTP_CLIENT_IP");  
            System.out.println("HTTP_CLIENT_IP ip: " + ip);
        }  
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {  
            ip = request.getHeader("HTTP_X_FORWARDED_FOR");  
            System.out.println("HTTP_X_FORWARDED_FOR ip: " + ip);
        }  
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {  
            ip = request.getHeader("X-Real-IP");  
            System.out.println("X-Real-IP ip: " + ip);
        }  
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {  
            ip = request.getRemoteAddr();  
            System.out.println("getRemoteAddr ip: " + ip);
        } 
        LOG.info("=============客户端ip: " + ip);
        
        return ip; 
    }
}
