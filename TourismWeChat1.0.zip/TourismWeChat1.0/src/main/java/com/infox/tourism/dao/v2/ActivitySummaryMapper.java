package com.infox.tourism.dao.v2;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.infox.tourism.entity.v2.activitysummary.ActivitySummary;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 领队总结
 * @author yuanfang
 * 2019年5月14日 上午10:55:23
 */
@Mapper
public interface ActivitySummaryMapper extends BaseMapper<ActivitySummary> {
	/*
	 * 根据主键查询
	 */
	public ActivitySummary selectByActivitySummaryId(String activitySummaryId);
	/*
	 * 查询所有
	 */
	public List<ActivitySummary> selectAllActivitySummary(ActivitySummary activitySummary);
	/*
	 * 根据活动ID查询
	 */
	public  ActivitySummary findByActivityId(String activityId);
	/*
	 * 根据领队ID删除
	 */
	public void deleteByActivitySummaryId(String activitySummaryId);

}
