package com.infox.tourism.dao;

import com.infox.tourism.entity.CarouselMapEntity;
import com.infox.tourism.entity.vo.indexVO.CarouselMapIndexVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import tk.mybatis.mapper.common.BaseMapper;

import java.util.List;

/**
 * 轮播图表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-06 17:10:28
 */
@Mapper
public interface BannerDao extends BaseMapper<CarouselMapEntity> {

    /**
     * 微信查询轮播图
     * @return
     */
    List<CarouselMapIndexVO> selectListOfWeChat(@Param("companyId") String companyId);
}
