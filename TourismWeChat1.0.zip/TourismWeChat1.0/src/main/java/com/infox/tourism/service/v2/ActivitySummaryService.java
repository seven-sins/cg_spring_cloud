package com.infox.tourism.service.v2;

import java.util.List;

import com.infox.tourism.entity.v2.activitysummary.ActivitySummary;

/**
 * 
 * @author yuanfang
 * 2019年5月14日 上午10:50:29
 */
/*
 * 领队总结
 */
public interface ActivitySummaryService {
	/*
	 * 添加总结
	 */
	void insert(ActivitySummary activitySummary);
	/*
	 * 修改总结
	 */
	void update(ActivitySummary activitySummary);
	/*
	 * 删除总结
	 */
	void deleteByActivitySummaryId(String activitySummaryId);
	/*
	 * 查询总结
	 */
	ActivitySummary selectByActivitySummaryId(String activitySummaryId);
	/*
	 * 查询所有总结
	 */
	List<ActivitySummary> selectAllActivitySummary(ActivitySummary activitySummary);
	/*
	 * 查询领队Id
	 * 
	 */
	ActivitySummary  findByActivityId (String activityId);
}
