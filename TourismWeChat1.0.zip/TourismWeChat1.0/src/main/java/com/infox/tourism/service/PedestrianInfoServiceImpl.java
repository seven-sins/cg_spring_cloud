package com.infox.tourism.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infox.common.base.impl.BaseServiceImpl;
import com.infox.tourism.dao.PedestrianInfoDao;
import com.infox.tourism.entity.PedestrianInfoEntity;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 出行人
 * @author Tan Ling
 * @date 2019年1月16日 下午3:01:57
 */
@Service
public class PedestrianInfoServiceImpl extends BaseServiceImpl<PedestrianInfoEntity> implements PedestrianInfoService {

	@Autowired
	private PedestrianInfoDao pedestrianInfoDao;
	
	@Resource
	public void setBaseMapper(BaseMapper<PedestrianInfoEntity> pedestrianInfoDao) {
		this.baseMapper = pedestrianInfoDao;
	}

	@Override
	public List<PedestrianInfoEntity> findByOrderId(String orderId) {
		return pedestrianInfoDao.findByOrderId(orderId);
	}

	/**
	 * 查询某个订单下的出行人列表           新接口
	 * @param activityId
	 * @return
	 */
	@Override
	public List<PedestrianInfoEntity> findByOrderIdList(String orderId) {
		return pedestrianInfoDao.findByOrderIdList(orderId);
	}

	/**
	 * 更新出行人状态
	 * (1:正常,2:已改期,3:退款,4:申请退款)
	 * @author Tan Ling
	 * @date 2019年1月16日 下午3:17:21
	 * @param pedestrianId
	 * @param pedestrianStatus
	 */
	@Override
	public void updatePedestrianStatus(String pedestrianId, Integer pedestrianStatus) {
		pedestrianInfoDao.updatePedestrianStatus(pedestrianId, pedestrianStatus);		
	}

	/**
	 * 修改签到
	 * (1：签到,0：未签到)
	 */
	@Override
	public void updateIsSignin(String pedestrianId) {
		pedestrianInfoDao.updateIsSignin(pedestrianId);
	}
	
	/*
	 * 查询信息
	 */
	@Override
	public List<PedestrianInfoEntity> findByActivityId(String activityId) {
		return pedestrianInfoDao.findByActivityId(activityId);
	}
}
