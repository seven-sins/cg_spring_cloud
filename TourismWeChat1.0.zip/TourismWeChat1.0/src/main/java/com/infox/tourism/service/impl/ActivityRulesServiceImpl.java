package com.infox.tourism.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.infox.common.base.impl.BaseServiceImpl;
import com.infox.tourism.dao.ActivityRulesDao;
import com.infox.tourism.entity.ActivityRulesEntity;
import com.infox.tourism.service.ActivityRulesService;

import tk.mybatis.mapper.common.BaseMapper;


/**
 * 活动规则表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-15 10:36:29
 */
@Service("activityRulesService")
public class ActivityRulesServiceImpl extends BaseServiceImpl<ActivityRulesEntity> implements ActivityRulesService {
	
    /**
    * activityRulesDao层
    * @param params
    * @return
    */
    @Autowired
    private ActivityRulesDao activityRulesDao;
    
    @Resource
    public void setBaseMapper(BaseMapper<ActivityRulesEntity> activityRulesDao) {
		this.baseMapper = activityRulesDao;
	}

    /**
    * 查询分页
    * @param pageNum
    * @param pageSize
    * @param search
    * @return
    */
    @Override
    public List<ActivityRulesEntity> queryPage(int pageNum, int pageSize, String search){
        // 使用分页插件实现分页
        PageHelper.startPage(pageNum,pageSize);
        // 调用dao的方法
        return activityRulesDao.queryPage(search);
    }

	@Override
	public ActivityRulesEntity selectByActivityId(String activityId) {
		return activityRulesDao.selectByActivityId(activityId);
	};

}
