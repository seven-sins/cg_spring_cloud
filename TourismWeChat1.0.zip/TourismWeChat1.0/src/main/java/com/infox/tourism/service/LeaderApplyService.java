package com.infox.tourism.service;

import com.infox.common.base.BaseService;
import com.infox.tourism.entity.LeaderApplyEntity;
import com.infox.tourism.entity.v2.leaderinfo.vo.LeaderVo;

/**
 * 领队申请表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-12 20:59:36
 */
public interface LeaderApplyService extends BaseService<LeaderApplyEntity> {

    /**
     * 根据openid查询领队申请信息
     * @param openId
     * @return
     */
    LeaderVo selectLeaderApplyByUserId(String userId);


}

