package com.infox.tourism.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infox.common.base.impl.BaseServiceImpl;
import com.infox.common.sms.SmsService;
import com.infox.tourism.dao.OrderInfoDao;
import com.infox.tourism.dao.PayAndRefundRecordDao;
import com.infox.tourism.dao.PayHistoryDao;
import com.infox.tourism.dao.PedestrianInfoDao;
import com.infox.tourism.dao.activity.ActivityMapper;
import com.infox.tourism.entity.ActivityInfoEntity;
import com.infox.tourism.entity.OrderInfoEntity;
import com.infox.tourism.entity.PayAndRefundRecordEntity;
import com.infox.tourism.entity.PayHistoryEntity;
import com.infox.tourism.entity.PedestrianInfoEntity;
import com.infox.tourism.service.PayHistoryService;
import com.infox.tourism.service.payment.PaymentService;
import com.infox.tourism.util.UUIDUtil;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 支付历史记录
 * @author Tan Ling
 * 2018年12月11日 下午8:53:21
 */
@Service
public class PayHistoryServiceImpl extends BaseServiceImpl<PayHistoryEntity> implements PayHistoryService {
	@Autowired
	private PayHistoryDao payHistoryDao;
	@Autowired
	private OrderInfoDao orderInfoDao;
	@Autowired
	private PaymentService paymentService;
	@Autowired
	private SmsService smsService;
	@Autowired
	private PedestrianInfoDao pedestrianInfoDao;
	@Autowired
	private ActivityMapper activityMapper;
	@Autowired
	private PayAndRefundRecordDao payAndRefundRecordDao;
	
	@Resource
	public void setBaseMapper(BaseMapper<PayHistoryEntity> payHistoryDao) {
		this.baseMapper = payHistoryDao;
	}
	
	@Override
	public void insert(Map<String, ?> map) {
		// TODO: pay_history中的记录后续弃用
		PayHistoryEntity dbData = payHistoryDao.getByTrxid((String) map.get("trxid"));
		if(dbData != null) {
			dbData.setNotifyNum(dbData.getNotifyNum() != null ? dbData.getNotifyNum() + 1 : 1);
			payHistoryDao.updateByPrimaryKeySelective(dbData);
			return;
		}
		
		PayHistoryEntity payHistory = new PayHistoryEntity();
		payHistory.setPayHisId(UUIDUtil.create());
		payHistory.setUserId((String) map.get("acct"));
		payHistory.setPayTime(new Date());
		payHistory.setOrderType((String) map.get("trxreserved"));
		payHistory.setTrxid((String) map.get("trxid"));
		payHistory.setCreateTime(new Date());
		payHistory.setNotifyNum(1);
		
		payHistoryDao.insert(payHistory);
		
		/**
		 * 推送微信消息
		 */
		OrderInfoEntity order = orderInfoDao.getByTrxid((String) map.get("trxid"));
		if(order != null) {
			// 插入对账表
			PayAndRefundRecordEntity record = new PayAndRefundRecordEntity();
			record.setRecordId(UUIDUtil.create());
			record.setAmount(order.getoMoney());
			record.setUserId(order.getUserId());
			record.setCreateTime(new Date());
			record.setTrxid((String) map.get("trxid"));
			record.setOrderId(order.getOrderId());
			record.setCompanyId(order.getCompanyId());
			record.setOrderType(payHistory.getOrderType());
			// 1:支付,2:退款
			record.setType(1);
			payAndRefundRecordDao.insert(record);
			
			// 推送微信消息
			paymentService.pushWechatMessage(order);
			/**
			 * 推送手机短信
			 */
			ActivityInfoEntity activity = activityMapper.getActivityByActivityId(order.getActivityId());
			List<PedestrianInfoEntity> pedestrianList = pedestrianInfoDao.findByOrderId(order.getOrderId());
			List<String> phoneList = new ArrayList<>();
			for(PedestrianInfoEntity item: pedestrianList) {
				if(StringUtils.isNotBlank(item.getContactPhone()) && !phoneList.contains(item.getContactPhone()) ) {
					phoneList.add(item.getContactPhone());
					smsService.buyActivity(item.getContactPhone(), item.getContactPeople(), activity.getActivityName());
				}
			}
		}
	}

}
