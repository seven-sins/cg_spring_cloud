package com.infox.tourism.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.infox.tourism.entity.DurationScope;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 时长范围
 * @author Tan Ling
 * @date 2019年1月24日 上午9:28:53
 */
@Mapper
public interface DurationScopeMapper extends BaseMapper<DurationScope> {
    
	/**
	 * 根据时长范围查询
	 * @author Tan Ling
	 * @date 2019年1月24日 上午9:37:15
	 * @param durationScope
	 * @return
	 */
	DurationScope getByDurationScope(@Param("durationScope") String durationScope);
	/**
	 * 检查数据是否被占用
	 * @author Tan Ling
	 * @date 2019年1月24日 上午9:47:06
	 * @param durationScopeId
	 * @return
	 */
	Integer checkUsed(@Param("durationScopeId") String durationScopeId);
	/**
	 * 删除
	 * @author Tan Ling
	 * @date 2019年1月24日 上午10:10:30
	 * @param durationScopeId
	 */
	void deleteByDurationScopeId(@Param("durationScopeId") String durationScopeId);
}