package com.infox.tourism.controller.calenderController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.infox.common.utils.Assert;
import com.infox.tourism.entity.JoinCity;
import com.infox.tourism.entity.vo.CalenderVO.CalenderCountVO;
import com.infox.tourism.entity.vo.CalenderVO.CalenderVO;
import com.infox.tourism.service.CalenderService;
import com.infox.tourism.service.JoinCityService;
import com.infox.tourism.util.R;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 日历查询
 *
 * @author yiwei
 * @email
 * @date 2018-12-06 15:16:27
 */
@Api(description = "日历", tags = {"CalenderController"})
@RestController
@RequestMapping("/calender")
public class CalenderController {
    @Autowired
    private CalenderService calenderService;
    @Autowired
    private JoinCityService joinCityService;

    /**
     * 查询一天的活动列表
     */
    @ApiOperation(value = "查询一天的活动列表", notes = "查询一天的活动列表 ", response = CalenderVO.class)
    @GetMapping("/calenderlist")
    public R calenderlist(Integer pageNum, Integer pageSize, 
    		String dayTime,
    		@RequestParam(value = "locationId", defaultValue = "1b03e554006211e9922700163e0ec1a2") String locationId) {
    	Assert.notEmpty(locationId, "locationId不能为空");
		JoinCity joinCity = joinCityService.getBySbLocationId(locationId);
		Assert.notNull(joinCity, "数据异常, 城市信息不存在");
		
        // 使用分页插件实现分页
        PageHelper.startPage(pageNum, pageSize);
        List<CalenderVO> calenderlist = calenderService.selectCalenderListByDay(pageNum, pageSize, dayTime, joinCity.getCompanyId());

        PageInfo<CalenderVO> pageInfo = new PageInfo<>(calenderlist);
        return R.ok().put("data", calenderlist).put("total", pageInfo.getTotal());
    }

    /**
     * 查询月每天的活动总数
     */
    @ApiOperation(value = "查询月每天的活动总数", notes = "查询月每天的活动总数 ", response = CalenderVO.class)
    @GetMapping("/calenderCountlist")
    public R calenderCountlist(String startTime, String endTime,
    		@RequestParam(value = "locationId", defaultValue = "1b03e554006211e9922700163e0ec1a2") String locationId) {
    	Assert.notEmpty(locationId, "locationId不能为空");
		JoinCity joinCity = joinCityService.getBySbLocationId(locationId);
		Assert.notNull(joinCity, "数据异常, 城市信息不存在");
		
        List<CalenderCountVO> calenderCountlist = calenderService.selectCalenderCount(startTime, endTime, joinCity.getCompanyId());

        return R.ok().put("data", calenderCountlist);
    }

}
