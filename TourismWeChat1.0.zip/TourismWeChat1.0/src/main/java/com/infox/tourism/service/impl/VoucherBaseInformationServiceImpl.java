package com.infox.tourism.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageHelper;
import com.infox.common.exception.CustomException;
import com.infox.tourism.dao.NumIntegralDao;
import com.infox.tourism.dao.UserInfoDao;
import com.infox.tourism.dao.VoucherBaseInformationDao;
import com.infox.tourism.dao.VouchersReceiveDao;
import com.infox.tourism.entity.VoucherBaseInformationEntity;
import com.infox.tourism.entity.VouchersReceiveEntity;
import com.infox.tourism.entity.vo.UserVO.UserVO;
import com.infox.tourism.entity.vo.couponVo.VoucherVo;
import com.infox.tourism.service.VoucherBaseInformationService;
import com.infox.tourism.util.UUIDUtil;

/**
 * @Author: cenjinxing
 * @Date: Created in 2018/12/8 12:18
 **/
@Service
public class VoucherBaseInformationServiceImpl implements VoucherBaseInformationService {
    @Autowired
    private VoucherBaseInformationDao voucherBaseInformationDao;
    @Autowired
    private VouchersReceiveDao vouchersReceiveDao;
    @Autowired
    private NumIntegralDao numIntegralDao;
    @Autowired
    private UserInfoDao userInfoDao;

    /**
     * 根据userId查询未使用的优惠券
     * @return
     */
    @Override
    public List<VoucherVo> selectByUserId(String userId,Integer type,Integer pageNum, Integer pageSize) {
        List<VoucherVo> list = new ArrayList<>();
        PageHelper.startPage(pageNum,pageSize);
        // 0:未使用, 1:已使用 , 2:已过期
        if (type.equals(0)){
            list = voucherBaseInformationDao.selectByUserId(userId, type);
        } else if (type.equals(1)){
            list = voucherBaseInformationDao.selectByUserId(userId, type);
        } else {
            list = voucherBaseInformationDao.selectByUserId(userId, 2);
        }

        return list;
    }

    /**
     * 立即使用  0  否   1  是  2,过期
     * @param
     * @return
     */
    @Override
    public boolean updateUse(String vouchersReceiveId) {
        VouchersReceiveEntity key = vouchersReceiveDao.selectByPrimaryKey(vouchersReceiveId);
        boolean b = voucherBaseInformationDao.updateVouchersReceiveByStatus(1,key.getVouchersReceiveId());
        return b;
    }

    /**
     * 积分商城
     * @param pageNum
     * @param pageSize
     * @return
     */
    @Override
    public List<VoucherVo> convertProductList(Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum,pageSize);
        return voucherBaseInformationDao.couponList();
    }

    /**
     * 立即兑换  1，  未兑换 2，已兑换
     * @param
     * @return
     */
    @Override
    @Transactional
    public void updateIsNeedScord(VoucherBaseInformationEntity voucherBaseInformationEntity,String userId) {
        // 立即兑换规则：1, 一定是用户积分大于等于优惠券兑换积分，2, 用户积分少于优惠劵兑换积分  提示：您的积分不足以兑换此优惠券
        // 获取用户的总积分
        UserVO userVO = userInfoDao.selectUserInfoByUserId(userId);

        //  查询所有未兑换优惠券  1，  未兑换 2，已兑换
        VoucherBaseInformationEntity selectByPrimaryKey = voucherBaseInformationDao.selectByPrimaryKey(voucherBaseInformationEntity.getVoucherBaseId());

        if (userVO.getNumIntegral() < selectByPrimaryKey.getScordNum()){
            throw new CustomException("您的积分不足以兑换此优惠券");
        }
        userVO.setNumIntegral(userVO.getNumIntegral() - selectByPrimaryKey.getScordNum());
        numIntegralDao.updateNumIntegralByUserId(userVO);
        //
        VouchersReceiveEntity voucher = new VouchersReceiveEntity();
    	voucher.setVouchersReceiveId(UUIDUtil.create());
    	voucher.setCreateTime(new Date());
    	voucher.setCreateBy(userId);
    	voucher.setUserId(userId);
    	voucher.setVoucherBaseId(selectByPrimaryKey.getVoucherBaseId());
    	voucher.setGetTime(new Date());
    	voucher.setOverdueTime(selectByPrimaryKey.getEndTime());
    	voucher.setVrType(selectByPrimaryKey.getVbiType());
    	voucher.setVbiFull(selectByPrimaryKey.getVbiFull());
    	voucher.setVrStatus(0);
    	voucher.setStartTime(selectByPrimaryKey.getStartTime());
    	voucher.setEndTime(selectByPrimaryKey.getEndTime());
    	voucher.setVbiName(selectByPrimaryKey.getVbiName());
    	// 1:推送, 2:兑换
    	voucher.setVrSource(2);
    	// 1，满减   2，抵押金钱
    	if(selectByPrimaryKey.getVbiType() == 1) {
    		voucher.setAmount(selectByPrimaryKey.getVbiSubtract());
    	} else {
    		voucher.setAmount(selectByPrimaryKey.getVbiMoney());
    	}
    	vouchersReceiveDao.insert(voucher);
    }
}
