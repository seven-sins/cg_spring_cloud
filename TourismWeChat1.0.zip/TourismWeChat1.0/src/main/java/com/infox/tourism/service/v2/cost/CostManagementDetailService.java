package com.infox.tourism.service.v2.cost;


/**
 * 
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2019-04-02 14:07:17
 */
public interface CostManagementDetailService {
}

