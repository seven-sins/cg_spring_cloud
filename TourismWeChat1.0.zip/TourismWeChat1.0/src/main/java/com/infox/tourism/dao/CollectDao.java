package com.infox.tourism.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.infox.tourism.entity.CollectEntity;
import com.infox.tourism.entity.vo.UserVO.CollectVO;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 收藏表
 *
 * @author yiwei
 * @email @163.com
 * @date 2018-12-10 8:46:05
 */
@Mapper
public interface CollectDao extends BaseMapper<CollectEntity> {
		
	 /**
     * 根据id查询
     * @param lineThemeId
     * @return
     */
	CollectEntity selectById(@Param("travelsActivityId") String travelsActivityId, @Param("userId") String userId,@Param("collectType") String collectType);
	
	  /**
     * 根据id修改
     */
    int updateById(CollectEntity collectEntity);

	/**
	 * 我的收藏  活动
	 * @param userId
	 * @param collectType
	 * @return
	 */
    List<CollectVO> selectByActivity(@Param("userId") String userId,@Param("collectType")Integer collectType);

	/**
	 * 我的收藏   游记
	 * @param userId
	 * @param collectType
	 * @return
	 */
	List<CollectVO> selectTravels(@Param("userId") String userId,@Param("collectType")Integer collectType);

	/**
	 * 取消收藏
	 * @return
	 */
	boolean updateEnable(CollectEntity collectEntity);


}
