package com.infox.tourism.service;

import java.util.List;

import com.infox.common.base.BaseService;
import com.infox.tourism.entity.MessagePushEntity;
import com.infox.tourism.entity.vo.MessageVO.MessageVO;
import com.infox.tourism.entity.vo.indexVO.MessagePushIndexVO;

/**
 * 消息推送表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-21 15:17:45
 */
public interface MessageService extends BaseService<MessagePushEntity> {

    /**
     * 首页查找已发布的暴走快讯
     * @return
     */
    List<MessagePushIndexVO>selectListForWeChat();

    /**
     * 我的系统消息
     * @return
     */
    List<MessageVO> selectByUserId(String userId, int pageNum , int pageSize, String search, String time);
}

