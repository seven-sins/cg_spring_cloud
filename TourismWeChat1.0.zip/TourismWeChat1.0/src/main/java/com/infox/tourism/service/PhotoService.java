package com.infox.tourism.service;

import com.infox.tourism.entity.PhotoEntity;

import java.util.List;

/**
 * 照片表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-14 14:49:56
 */
public interface PhotoService {

    /**
     * 根据相册id查询照片
     * @param albumId
     * @return
     */
    List<PhotoEntity> queryByAlbumId(String albumId, int pageNum, int pageSize);

    /**
     * 添加
     * @param photoEntity
     * @return
     */
    boolean insert(PhotoEntity photoEntity);

    /**
     * 删除照片
     * @param photoId
     * @return
     */
    boolean deleteByPhotoId( String path ,String photoId);

    /**
     * 图片的总数
     * @return
     */
    Integer total(String albumId);



}

