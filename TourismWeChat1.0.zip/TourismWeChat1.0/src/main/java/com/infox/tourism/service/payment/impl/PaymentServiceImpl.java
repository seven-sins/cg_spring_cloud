package com.infox.tourism.service.payment.impl;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONObject;
import com.infox.common.exception.CustomException;
import com.infox.common.utils.Assert;
import com.infox.common.utils.payment.SybConstants;
import com.infox.common.utils.payment.SybPayService;
import com.infox.common.wechat.message.MessageUtil;
import com.infox.tourism.dao.ActivityInfoDao;
import com.infox.tourism.dao.ExceptionalRecordDao;
import com.infox.tourism.dao.ExceptionalSumInfoDao;
import com.infox.tourism.dao.IntegralIncomeDao;
import com.infox.tourism.dao.MessagePushDao;
import com.infox.tourism.dao.OrderInfoDao;
import com.infox.tourism.dao.PedestrianInfoDao;
import com.infox.tourism.dao.UserInfoDao;
import com.infox.tourism.dao.VipOpenRecordDao;
import com.infox.tourism.dao.VipRecordDao;
import com.infox.tourism.dao.VouchersReceiveDao;
import com.infox.tourism.dao.activity.ActivityMapper;
import com.infox.tourism.entity.ActivityInfoEntity;
import com.infox.tourism.entity.ExceptionalRecordEntity;
import com.infox.tourism.entity.ExceptionalSumInfoEntity;
import com.infox.tourism.entity.IntegralIncomeEntity;
import com.infox.tourism.entity.MessagePushEntity;
import com.infox.tourism.entity.OrderInfoEntity;
import com.infox.tourism.entity.PedestrianInfoEntity;
import com.infox.tourism.entity.UserInfoEntity;
import com.infox.tourism.entity.VipOpenRecordEntity;
import com.infox.tourism.entity.VipRecordEntity;
import com.infox.tourism.entity.VouchersReceiveEntity;
import com.infox.tourism.service.ActivityService;
import com.infox.tourism.service.payment.PaymentService;
import com.infox.tourism.util.DateUtil;
import com.infox.tourism.util.R;
import com.infox.tourism.util.UUIDUtil;

/**
  * 支付Service
 * @author Tan Ling
 * 2018年12月11日 下午4:29:57
 */
@Transactional(rollbackFor = Exception.class)
@Service
public class PaymentServiceImpl implements PaymentService {
	private static final Logger LOG = Logger.getLogger(PaymentServiceImpl.class);
	private static final String ACTIVITY = "activity";
	private static final String USER_VIP = "user";
	private static final String LEADER= "leader";
	private static final String CUSTOMER_SERVICE1 = "o4uepwuXH5sMLMMGLqocmFZM6wDc";
	private static final String CUSTOMER_SERVICE2 = "o4uepwkknElCwRoGPT8N_oHAETyg";
	private static final String CUSTOMER_SERVICE3 = "o4uepwsUR5Y2_9raXCviN5xZ3eo8";
	private static final String CUSTOMER_SERVICE4 = "o4uepwqnxfmekF-nmyszRLDUTC-0";
	private static final String CUSTOMER_SERVICE5 = "o4uepwtVLbqV9Omh7Bj7ivaSRJOk";
	/**
	  * 收付通接口调用成功返回trxstatus == 0000
	 */
	private static final String SUCCESS_CODE = "0000";
	/**
	 * 活动分享报名获得积分
	 */
	private static final Integer SHARE_POINT = 10;
	@Autowired
	private SybPayService sybPayService;
	@Autowired
	private OrderInfoDao orderInfoDao;
	@Autowired
	private UserInfoDao userInfoDao;
	@Autowired
	private VipRecordDao vipRecordDao;
	@Autowired
	private VipOpenRecordDao vipOpenRecordDao;
	@Autowired
	private ActivityInfoDao activityInfoDao;
	@Autowired
    private ActivityService activityService;
	@Autowired
	private MessageUtil messageUtil;
	@Autowired
	private PedestrianInfoDao pedestrianInfoDao;
	@Autowired
    private VouchersReceiveDao vouchersReceiveDao;
	@Autowired
    private ExceptionalRecordDao exceptionalRecordDao;
	@Autowired
    private ExceptionalSumInfoDao exceptionalSumInfoDao;
	@Autowired
	private MessagePushDao messagePushDao;
	@Autowired
	private ActivityMapper activityMapper;
	@Autowired
    private IntegralIncomeDao integralIncomeDao;
	//	@Autowired
	//	private NumIntegralDao numIntegralDao;
	@Autowired
	private SybConstants sybConstants;
	@Value("${share.activityPoint}")
	private Integer shareActivityPoint;
	
	@Override
	public Map<String, ?> pay(UserInfoEntity user, String orderId, String orderType) {
		if(ACTIVITY.equals(orderType)) {
			return activityPay(user, orderId, orderType);
		} else if(USER_VIP.equals(orderType)) {
			return userVip(user, orderId, orderType);
		}else if(LEADER.equals(orderType)){
			return leaderPay(user, orderId, orderType);
		}


		
		return null;
	}
	
	@Override
	public Map<String, ?> appletPay(UserInfoEntity user, String orderId, String orderType) {
		if(ACTIVITY.equals(orderType)) {
			return activityAppletPay(user, orderId, orderType);
		} else if(USER_VIP.equals(orderType)) {
			return userVip(user, orderId, orderType);
		}else if(LEADER.equals(orderType)){
			return leaderPay(user, orderId, orderType);
		}


		
		return null;
	}
	
	/**
	  * 用户开通VIP
	 * @param user
	 * @param vipId
	 * @param orderType
	 * @return
	 */
	private Map<String, ?> userVip(UserInfoEntity user, String vipId, String orderType) {
		if (vipId == null || "".equals(vipId)){
			return R.error(400,"vipid不能为空");
		}

		UserInfoEntity userInfo = userInfoDao.selectByPrimaryKey(user.getUserId());
		Assert.notNull(userInfo, "用户未找到");
//		Assert.isTrue(!(userInfo.getUVip() != null && userInfo.getUVip() == 1), "用户已经开通会员");
		long amount = 10;
		/**
		 * 1. vip开通记录表取出数据
		 */
		VipOpenRecordEntity vipOpenRecordEntity = vipOpenRecordDao.selectByVipId(vipId);

		if(vipOpenRecordEntity == null) {
			throw new CustomException("未找到填写数据");
		}
		if(vipOpenRecordEntity.getPayStatus() != null && vipOpenRecordEntity.getPayStatus() == 1) {
			throw new CustomException("订单已支付");
		}

		/**
		 * 2. 生成支付订单
		 */
		Map<String, ?> map = createPayOrder(amount, vipOpenRecordEntity.getVipId(), USER_VIP, user);
		/**
		 * 3. 生成支付订单成功, 将交易流水号trxid插入订单表
		 */
		VipOpenRecordEntity openRecordEntity = new VipOpenRecordEntity();
		openRecordEntity.setVipId(vipOpenRecordEntity.getVipId());
		String trxid = "trxid";
		if(map.get(trxid) == null) {
			throw new CustomException("数据异常, 生成的支付订单中没有交易流水号");
		}
		openRecordEntity.setTrxid(String.valueOf(map.get(trxid)));
		vipOpenRecordDao.updateVipOpenRecordTrxid(openRecordEntity);

		return map;
	}

	/**
	  * 打赏领队
	 * @param user
	 * @param orderId
	 * @param orderType
	 * @return
	 */
	private Map<String, ?> leaderPay(UserInfoEntity user, String orderId, String orderType){
		/**
		 * 1. 根据orderId获取打赏数据
		 */	
		ExceptionalRecordEntity order = exceptionalRecordDao.queryById(orderId);
		Assert.notNull(order, "订单未找到");
		Assert.notNull(order.getErMoney(), "数据异常, 打赏为空");
		
		long amount = order.getErMoney().multiply(new BigDecimal(100)).longValue();
		/**
		 * 2. 生成支付订单
		 */
		Map<String, ?> map = createPayOrder(amount, order.getExceptionalRecordId(), LEADER, user);
		/**
		 * 3. 生成支付订单成功, 将交易流水号trxid插入订单表
		 */
		ExceptionalRecordEntity orderInfo = new ExceptionalRecordEntity();
		orderInfo.setExceptionalRecordId(order.getExceptionalRecordId());
		String trxid = "trxid";
		Assert.notNull(map.get(trxid), "数据异常, 生成的支付订单中没有交易流水号");

		//orderInfo.setTrxid(String.valueOf(map.get(trxid)));
		//orderInfo.setState(0);
		
		exceptionalRecordDao.updateStatusById(orderInfo.getExceptionalRecordId(), String.valueOf(map.get(trxid)), 0);
		
		return map;
	}
	
	/**
	 * 活动订单支付
	 * @param user
	 * @param orderId
	 * @param orderType
	 * @return
	 */
	private Map<String, ?> activityPay(UserInfoEntity user, String orderId, String orderType){
		/**
		 * 1. 根据orderId获取订单数据
		 */
		OrderInfoEntity order = orderInfoDao.getByOrderId(orderId);
		Assert.notNull(order, "订单未找到");
		Assert.notNull(order.getOMoney(), "数据异常, 价格为空");
		Assert.isTrue(order.getPayStatus() != null && order.getPayStatus() != 1, "订单已支付");
		Assert.isTrue(order.getPayStatus() != null && order.getPayStatus() != -1, "订单已退款, 不能支付");
		
		ActivityInfoEntity activityInfo = activityMapper.getActivityByActivityId(order.getActivityId());
		Assert.notNull(activityInfo, "数据异常, 订单关联活动未找到");
		
		// 1已报满 2已成行 3报名中 4已截止 5即将成行 6已下架
		Integer joinNum = activityMapper.queryActivityPeopleNum(activityInfo.getActivityId());
		Assert.isTrue(activityInfo.getMostPeopleSum() != null && activityInfo.getMostPeopleSum() >= joinNum, "活动已报满");

		long amount = order.getOMoney().multiply(new BigDecimal(100)).longValue();
		/**
		 * 2. 生成支付订单
		 */
		// Map<String, ?> map = createPayOrder(amount, order.getOrderId(), ACTIVITY, user);
		Map<String, ?> map = createPayOrder(amount, activityInfo.getActivityName(), ACTIVITY, user);
		/**
		 * 3. 生成支付订单成功, 将交易流水号trxid插入订单表
		 */
		OrderInfoEntity orderInfo = new OrderInfoEntity();
		orderInfo.setOrderId(order.getOrderId());
		String trxid = "trxid";
		Assert.notNull(map.get(trxid), "数据异常, 生成的支付订单中没有交易流水号");

		orderInfo.setTrxid(String.valueOf(map.get(trxid)));
		orderInfoDao.updateOrderTrxid(orderInfo);
		
		return map;
	}
	
	/**
	 * 活动订单支付
	 * @param user
	 * @param orderId
	 * @param orderType
	 * @return
	 */
	private Map<String, ?> activityAppletPay(UserInfoEntity user, String orderId, String orderType){
		/**
		 * 1. 根据orderId获取订单数据
		 */
		OrderInfoEntity order = orderInfoDao.getByOrderId(orderId);
		Assert.notNull(order, "订单未找到");
		Assert.notNull(order.getOMoney(), "数据异常, 价格为空");
		Assert.isTrue(order.getPayStatus() != null && order.getPayStatus() != 1, "订单已支付");
		Assert.isTrue(order.getPayStatus() != null && order.getPayStatus() != -1, "订单已退款, 不能支付");
		
		ActivityInfoEntity activityInfo = activityMapper.getActivityByActivityId(order.getActivityId());
		Assert.notNull(activityInfo, "数据异常, 订单关联活动未找到");
		
		// 1已报满 2已成行 3报名中 4已截止 5即将成行 6已下架
		Integer joinNum = activityMapper.queryActivityPeopleNum(activityInfo.getActivityId());
		Assert.isTrue(activityInfo.getMostPeopleSum() != null && activityInfo.getMostPeopleSum() >= joinNum, "活动已报满");

		long amount = order.getOMoney().multiply(new BigDecimal(100)).longValue();
		/**
		 * 2. 生成支付订单
		 */
		// Map<String, ?> map = createPayOrder(amount, order.getOrderId(), ACTIVITY, user);
		Map<String, ?> map = createAppletPayOrder(amount, activityInfo.getActivityName(), ACTIVITY, user);
		/**
		 * 3. 生成支付订单成功, 将交易流水号trxid插入订单表
		 */
		OrderInfoEntity orderInfo = new OrderInfoEntity();
		orderInfo.setOrderId(order.getOrderId());
		String trxid = "trxid";
		Assert.notNull(map.get(trxid), "数据异常, 生成的支付订单中没有交易流水号");

		orderInfo.setTrxid(String.valueOf(map.get(trxid)));
		orderInfoDao.updateOrderTrxid(orderInfo);
		
		return map;
	}

	/**
	 * 创建支付订单
	 * @param amount
	 * @param goodsName
	 * @param goodsType
	 * @param user
	 * @return
	 */
	private Map<String, ?> createPayOrder(long amount, String goodsName, String goodsType, UserInfoEntity user){
		String reqsn = String.valueOf(System.currentTimeMillis());
		Map<String, String> map;
		try {
			// TODO: amount    测试阶段固定金额 1分
			map = sybPayService.pay(
					amount,  
					reqsn, 
					"W02", 
					goodsName, 
					goodsType, 
					user.getOpenId(), 
					"134541202599004381", 
					sybConstants.getNotify(), 
					"", "", "", "");
		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomException("生成支付订单出错, " + e.getMessage());
		}
		
		return map;
	}
	
	/**
	 * 创建支付订单
	 * @param amount
	 * @param goodsName
	 * @param goodsType
	 * @param user
	 * @return
	 */
	private Map<String, ?> createAppletPayOrder(long amount, String goodsName, String goodsType, UserInfoEntity user){
		String reqsn = String.valueOf(System.currentTimeMillis());
		Map<String, String> map;
		try {
			// TODO: amount    测试阶段固定金额 1分
			map = sybPayService.appletPay(
					amount,  
					reqsn, 
					"W02", 
					goodsName, 
					goodsType, 
					user.getOpenId(), 
					"134541202599004381", 
					sybConstants.getNotify(), 
					"", "", "", "");
		} catch (Exception e) {
			LOG.error("生成支付订单出错: ", e);
			if(e instanceof CustomException) {
				CustomException cusEx = (CustomException) e;
				throw new CustomException("生成支付订单出错, " + cusEx.getMsg());
			}
			throw new CustomException("生成支付订单出错, " + e.getMessage());
		}
		
		return map;
	}

	@Override
	public void updatePayStatus(String trxid, String orderType, int payStatus) {
		if(ACTIVITY.equals(orderType)) {
//			/**
//			 * 1. 取出活动订单, 查询是否购买保险, 如果购买保险调用第三方接口
//			 */
			OrderInfoEntity order = orderInfoDao.getByTrxid(trxid);
			if(order == null) {
				LOG.error("=============数据异常, 订单未找到, trxid: " + trxid);
				return;
			}
			if(order.getPayStatus() != null && order.getPayStatus() == 1) {
				return;
			}
			orderInfoDao.updatePayStatus(trxid, payStatus);
			/**
	    	 * 2. 如果是用户分享出去的链接, 需要给对应用户添加积分
	    	 */
	    	this.addActivityPoints(order);
	    	/**
	    	 * 3. 用户报名获得相应积分
	    	 */
	    	this.addUserPoints(order);
	    	/**
	    	 * 4. 修改活动状态
	    	 */
	    	activityService.resetActivityStatus(order.getActivityId());
	    	/**
	    	 * 5. 删除当前活动未支付的订单
	    	 */
	    	orderInfoDao.deleteNonpaymentOrderByActivityIdAndOrderId(order.getActivityId(), order.getUserId(), order.getOrderId());
	    	
		} else if(USER_VIP.equals(orderType)){
			vipOpenRecordDao.updatePayStatus(trxid, payStatus);
			VipOpenRecordEntity openRecordEntity1 = vipOpenRecordDao.selectByTrxid(trxid);
			VipRecordEntity vipRecordEntity = vipRecordDao.selectByPrimaryKey(openRecordEntity1.getVipId());
			UserInfoEntity userInfoEntity = userInfoDao.selectByPrimaryKey(vipRecordEntity.getUserId());
			userInfoEntity.setUVip(1);
			//TODO
			//  判断是否是超级会员 ， 是超级会员就是续费  ， 获取开通会员的截至时间+12个月
			//  1  开通vip 0 未开通vip
			if (userInfoEntity.getUVip() != null && userInfoEntity.getUVip() == 1){
				// 获取当前时间
				Calendar calendarEndDate = Calendar.getInstance();
//				calendarEndDate.setTime(userInfoEntity.getEndTime());
				// 获取12个月的时间，开通会员截至时间
				calendarEndDate.add(Calendar.MONTH, 12);
				userInfoEntity.setEndTime(calendarEndDate.getTime());
				userInfoDao.updateUserInfoEndTime(userInfoEntity);
			}

			userInfoDao.updateUserInfoVip(userInfoEntity);
		}else if(LEADER.equals(orderType)){	
			/**
			 * 取出打赏订单
			 */
			ExceptionalRecordEntity order = exceptionalRecordDao.queryByTrxid(trxid);
			if(order == null) {
				LOG.error("=============数据异常, 订单未找到, trxid: " + trxid);
				return;
			}
			// TODO:
			/**
			 * 更新打赏订单信息
			 */
			order.setState(1);
			order.setUpdateTime(DateUtil.getYYYYMMDDHHMMSS());
			//exceptionalRecordDao.updateById(order);
			
			exceptionalRecordDao.updateStatusById(order.getExceptionalRecordId(), trxid, 1);
			/**
			 * 更新领队总金额信息
			 */
			List<ExceptionalSumInfoEntity> exceptionList= exceptionalSumInfoDao.queryExSumInfoByleaderId(order.getLeaderId());
			ExceptionalSumInfoEntity esumEntity = new ExceptionalSumInfoEntity();
			BigDecimal totalAmount = new BigDecimal(0);
			if(exceptionList.size()>0)	{        		
        		esumEntity= exceptionList.get(0);
        		totalAmount = totalAmount.add(new BigDecimal(esumEntity.getEsSum().toString()));
        		totalAmount = totalAmount.add(new BigDecimal(order.getErMoney().toString()));
        		esumEntity.setEsSum( totalAmount);
        		esumEntity.setUpdateBy(order.getCreateBy());
        		esumEntity.setUpdateTime(DateUtil.getYYYYMMDDHHMMSS());
        		exceptionalSumInfoDao.updateById(esumEntity);
        	}else{
        		esumEntity.setExceptionalSumId(UUIDUtil.create());
        		esumEntity.setLeaderId(order.getLeaderId());
        		esumEntity.setCreateBy(order.getCreateBy());
        		esumEntity.setCreateTime(DateUtil.getYYYYMMDDHHMMSS());
        		esumEntity.setEsSum(order.getErMoney());
        		exceptionalSumInfoDao.insert(esumEntity);
        	}
		}

	}

	@Override
	public Map<String, ?> refund(String userId, String orderId, String orderType) {
		/**
		 * 活动订单退款
		 */
		if(ACTIVITY.equals(orderType)) {
			OrderInfoEntity order = orderInfoDao.getByOrderId(orderId);
			Assert.notNull(order, "数据异常, 订单不存在");
			Assert.isTrue(userId.equals(order.getUserId()), "登录用户与订单所属用户不一致");
			UserInfoEntity userInfo = userInfoDao.selectByPrimaryKey(userId);
			Assert.notNull(userInfo, "数据异常, 订单用户不存在");
			ActivityInfoEntity activityInfo = activityMapper.getActivityByActivityId(order.getActivityId());
			Assert.notNull(activityInfo, "数据异常, 订单活动不存在");
			
			return refund(order, activityInfo, userInfo);
		}
		
		return null;
	}
	
    /**
     * 如果是用户分享出去的链接, 需要给对应用户添加积分
     * @author Tan Ling
     * @date 2019年1月16日 下午4:29:26
     * @param order
     */
	private void addActivityPoints(OrderInfoEntity order) {
		if(StringUtils.isBlank(order.getShareUserId())) {
			return;
		}
		UserInfoEntity user = userInfoDao.selectByPrimaryKey(order.getShareUserId());
		Assert.notNull(user, "数据异常, 分享用户不存在");
		IntegralIncomeEntity integralIncome = new IntegralIncomeEntity();
		integralIncome.setIntegralIncomeId(UUIDUtil.create());
		// 积分来源(1.分享 2.订单 3,优惠券)
		integralIncome.setIntegralType(2);
		integralIncome.setUserId(user.getUserId());
		// 0:已删除,1:未删除
		integralIncome.setIsDel(1);
		integralIncome.setAssociatedId(order.getOrderId());
		integralIncome.setCreateTime(new Date());
		integralIncome.setCreateBy(user.getUserId());
		integralIncome.setIntegralInNum(SHARE_POINT);
		// 1:已结算,0:未结算
		integralIncome.setIsSettlement(0);
		
		integralIncomeDao.insert(integralIncome);
	}
	
	/**
	 * 用户报名, 给用户加积分
	 * @author Tan Ling
	 * @date 2019年1月22日 下午8:48:51
	 * @param order
	 */
	private void addUserPoints(OrderInfoEntity order) {
		ActivityInfoEntity activityInfo = activityInfoDao.selectByPrimaryKey(order.getActivityId());
		if(activityInfo == null) {
			LOG.error("=============支付成功给用户添加积分时出错, 活动未找到");
			return;
		}
		if(activityInfo.getEarnPoint() == null) {
			return;
		}
		UserInfoEntity user = userInfoDao.selectByPrimaryKey(order.getUserId());
		if(user == null) {
			LOG.error("=============支付成功给用户添加积分时出错, 订单所属用户未找到");
			return;
		}
		
		IntegralIncomeEntity integralIncome = new IntegralIncomeEntity();
		integralIncome.setIntegralIncomeId(UUIDUtil.create());
		// 积分来源(1.分享 2.订单 3,优惠券)
		integralIncome.setIntegralType(2);
		integralIncome.setUserId(user.getUserId());
		// 0:已删除,1:未删除
		integralIncome.setIsDel(1);
		integralIncome.setAssociatedId(order.getOrderId());
		integralIncome.setCreateTime(new Date());
		integralIncome.setCreateBy(user.getUserId());
		integralIncome.setIntegralInNum(activityInfo.getEarnPoint());
		// 是否已结算(0:未结算,1:已结算)
		integralIncome.setIsSettlement(0);
		
		integralIncomeDao.insert(integralIncome);
		/**
		 * 更新用户积分
		 */
		// 2019-05-17修改: 改为定时结算积分
		// addUserPoint(user.getUserId(), activityInfo.getEarnPoint());
	}
	
	//	private void addUserPoint(String userId, Integer point) {
	//		NumIntegralEntity entity = numIntegralDao.queryByUserId(userId);
	//		if(entity == null) {
	//			return;
	//		}
	//		numIntegralDao.updateUserPoint(entity.getNumIntegralId(), entity.getUsableRecord(), entity.getNumIntegral() + point);
	//	}
	
	private Map<String, ?> refund(OrderInfoEntity order, ActivityInfoEntity activityInfo, UserInfoEntity userInfo) {
		/**
		 * 1. 查询第三方支付订单
		 */
		Map<String, ?> map;
		try {
			map = sybPayService.query("", order.getTrxid());
		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomException("查询退款支付信息异常, " + e.getMessage());
		}
		String trxstatus = "trxstatus";
		if(!SUCCESS_CODE.equals(map.get(trxstatus))) {
			print(map);
			throw new CustomException("执行退款操作失败");
		}
		/**
		 * 2. 回滚订单数据
		 */
		// 2.1 删除出行人
		PedestrianInfoEntity pedestrianInfo = new PedestrianInfoEntity();
		pedestrianInfo.setOrderId(order.getOrderId());
		// 0:删除
		pedestrianInfo.setIsDelete(0);
		pedestrianInfoDao.deleteByOrderId(pedestrianInfo);
		// 2.2 删除商品
		// productByOrderDao.deleteProductByOrderId(order.getOrderId());
		// 2.3 如果使用了优惠券, 将优惠券标记为未使用
		if(StringUtils.isNotBlank(order.getVouchersId())) {
			VouchersReceiveEntity vouchers = vouchersReceiveDao.selectByPrimaryKey(order.getVouchersId());
			Assert.notNull(vouchers, "数据异常, 用户没有订单中的优惠券");
			vouchers.setVrStatus(2);
			vouchersReceiveDao.updateByvouchersReceiveId(vouchers);
		}
		/**
		 * 3. 将订单状态改为退款(4:退款)
		 */
		order.setOrderStatus(4);
		orderInfoDao.updateByOrderIdAndOrderStatus(order);
		/**
		 * 4. 调用第三方支付接口退款
		 */
		long amount = Long.parseLong(String.valueOf(map.get("trxamt")));
		try {
			map = sybPayService.refund(amount, String.valueOf(System.currentTimeMillis()), order.getTrxid(), "");
		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomException("执行退款操作异常, " + e.getMessage());
		}
		/**
		 * 5. 推送微信消息
		 */
		JSONObject params = new JSONObject();
		params.put("amount", order.getoMoney());
		params.put("activityName", activityInfo.getActivityName());
		params.put("outsetTime", getDateString(activityInfo.getOutsetTime()));
		params.put("orderNumber", order.getoNumber());
		params.put("orderId", order.getOrderId());
		params.put("activityType", activityInfo.getTypeDicId());
		
		messageUtil.pushCancelOrderWechatMessage(userInfo.getOpenId(), params, "");
		
		return map;
	}
	
	private static void print(Map<String, ?> map){
		LOG.info("=============返回数据如下:");
		if(map!=null){
			for(String key:map.keySet()){
				LOG.info(key+": "+map.get(key));
			}
		}
	}
	
	/**
	 * 推送消息
	 * @param order
	 */
	@Override
	public void pushWechatMessage(OrderInfoEntity order) {
		ActivityInfoEntity activityInfo = activityMapper.getActivityByActivityId(order.getActivityId());
		if(activityInfo == null) {
			LOG.error("=============数据异常, 活动信息未找到, activityId: " + order.getActivityId());
			return;
		}
		UserInfoEntity userInfo = userInfoDao.selectByPrimaryKey(order.getUserId());
		if(userInfo == null || StringUtils.isBlank(userInfo.getOpenId())) {
			LOG.error("=============数据异常, 用户信息不存在或用户openId为空");
			return;
		}
		/**
		 * 1. 推送系统消息
		 */
		this.pushSystemMessage(order, activityInfo, userInfo);
		/**
		 * 2. 推送微信消息
		 */
		try {
			String destination = activityMapper.queryByDestination(activityInfo.getActivityId());
			if(StringUtils.isNotBlank(activityInfo.getDestination())) {
				destination = activityInfo.getDestination();
			}
			
			JSONObject params = new JSONObject();
			BigDecimal amount = order.getoMoney();
			amount = amount.setScale(2, RoundingMode.HALF_DOWN);
			params.put("amount", amount);
			params.put("destination", destination);
			params.put("activityName", activityInfo.getActivityName());
			params.put("outsetTime", getDateString(activityInfo.getOutsetTime()));
			params.put("meetingPlace", activityInfo.getMeetingPlace());
			params.put("orderId", order.getOrderId());
			params.put("activityType", activityInfo.getTypeDicId());
			messageUtil.pushOrderWechatMessage(userInfo.getOpenId(), params, "");
			// 同步推送消息给管理员
			// o4uepwuXH5sMLMMGLqocmFZM6wDc, o4uepwkknElCwRoGPT8N_oHAETyg, o4uepwsUR5Y2_9raXCviN5xZ3eo8
			messageUtil.pushOrderWechatMessage(CUSTOMER_SERVICE1, params, "");
			messageUtil.pushOrderWechatMessage(CUSTOMER_SERVICE2, params, "");
			messageUtil.pushOrderWechatMessage(CUSTOMER_SERVICE3, params, "");
			messageUtil.pushOrderWechatMessage(CUSTOMER_SERVICE4, params, "");
			messageUtil.pushOrderWechatMessage(CUSTOMER_SERVICE5, params, "");
		}catch(Exception e) {
			LOG.error("=============推送微信消息时出错:", e);
			e.printStackTrace();
		}
	}
	
	/**
	 * 推送系统消息
	 * @param order
	 */
	private void pushSystemMessage(OrderInfoEntity order, ActivityInfoEntity activityInfo, UserInfoEntity userInfo) {
		MessagePushEntity message = new MessagePushEntity();
		message.setMessagePushId(UUIDUtil.create());
		message.setActivityId(activityInfo.getActivityId());
		message.setMpTitle(userInfo.getNickName() + "参加了报名活动 " + activityInfo.getActivityName());
		message.setMpContent(activityInfo.getActivityName());
		message.setMpAuthor(userInfo.getNickName());
		// [1,暴走快讯，2,微信推送 3,系统消息 ]
		message.setMpStatus("1");
		message.setOpenId(userInfo.getOpenId());
		// 0  发布失败   1发布成功
		message.setPostStatus(1);
		message.setIsDelete(0);
		message.setLineId(activityInfo.getLineId());
		message.setLeaderInformationId(activityInfo.getLeaderId());
		message.setCreateBy(userInfo.getUserId());
		message.setCreateTime(new Date());
		
		messagePushDao.insert(message);
	}
	
	private static String getDateString(Date date) {
		if(date == null) {
			return "";
		}
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH);
		int day = calendar.get(Calendar.DATE);
		
		return year + "年" + (month + 1) + "月" + day + "日";
	}
}

















