package com.infox.tourism.dao;


import org.apache.ibatis.annotations.Mapper;

import com.infox.tourism.entity.PayAndRefundRecordEntity;

import tk.mybatis.mapper.common.BaseMapper;


/**
 * @author Tan Ling
 * @date 2019年4月25日 下午4:40:20
 */
@Mapper
public interface PayAndRefundRecordDao extends BaseMapper<PayAndRefundRecordEntity> {

}
