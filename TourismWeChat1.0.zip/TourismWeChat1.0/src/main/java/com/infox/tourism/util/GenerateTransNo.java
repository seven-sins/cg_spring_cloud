package com.infox.tourism.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

public class GenerateTransNo {

    public static String getTransNo(){

        Date date = new Date();

        Random rad=new Random();

        String result  = rad.nextInt(10000) + "";

        if(result.length()<4){

            int leng = 4 - result.length();

            for(int j = 0; j < leng; j++){
                result = "0" + result;
            }

        }

        String Day = new SimpleDateFormat("yyyyMMdd").format(date);
        String Time = new SimpleDateFormat("HHmmss").format(date);

        //生成保险订单号
        String flowNum = "tourism" + Day + Time + result;

        return flowNum;
    }

}