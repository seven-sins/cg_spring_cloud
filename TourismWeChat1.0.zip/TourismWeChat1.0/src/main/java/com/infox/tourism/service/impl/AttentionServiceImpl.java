package com.infox.tourism.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.infox.tourism.dao.AttentionDao;
import com.infox.tourism.entity.vo.UserVO.AttentionVO;
import com.infox.tourism.service.AttentionService;

/**
 * 关注记录表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-21 15:17:45
 */
@Service("attentionService")
public class AttentionServiceImpl implements AttentionService {
	/**
	 * attentionDao层
	 * 
	 * @param params
	 * @return
	 */
	@Autowired
	private AttentionDao attentionDao;

	/**
	 * 我的关注领队
	 *
	 * @param userId
	 * @return
	 */
	@Override
	public List<AttentionVO> selectByAttentionPeople(String userId, int pageNum, int pageSize) {
		PageHelper.startPage(pageNum, pageSize);

		List<AttentionVO> list = attentionDao.selectByAttentionPeople(userId);

		return list;
	}

}
