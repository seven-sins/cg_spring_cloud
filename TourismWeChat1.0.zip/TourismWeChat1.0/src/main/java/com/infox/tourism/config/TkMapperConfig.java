package com.infox.tourism.config;

import com.infox.tourism.base.IBaseMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import tk.mybatis.spring.mapper.MapperScannerConfigurer;

import java.util.Properties;

/**
 * @Author: cenjinxing
 * @Date: Created in 2018/9/26 11:57
 **/
@Configuration
public class TkMapperConfig {

    @Bean
    public MapperScannerConfigurer mapperScannerConfigurer(){
        MapperScannerConfigurer mapperScannerConfigurer = new MapperScannerConfigurer();
        // 添加dao层
        mapperScannerConfigurer.setBasePackage("com.infox.tourism.dao");
        Properties propertiesMapper = new Properties();
        // 设置属性
        propertiesMapper.setProperty("mappers", IBaseMapper.class.getName());
        propertiesMapper.setProperty("notEmpty", "false");
        //主键UUID回写方法执行顺序,默认AFTER,可选值为(BEFORE|AFTER)
        propertiesMapper.setProperty("ORDER","BEFORE");
        mapperScannerConfigurer.setProperties(propertiesMapper);
        return mapperScannerConfigurer;
    }
}
