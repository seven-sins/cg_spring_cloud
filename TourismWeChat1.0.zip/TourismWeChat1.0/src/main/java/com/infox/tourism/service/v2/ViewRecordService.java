package com.infox.tourism.service.v2;

import com.infox.common.base.BaseService;
import com.infox.tourism.entity.UserInfoEntity;
import com.infox.tourism.entity.v2.activityInfo.ViewRecord;

/**
 * 活动访问记录
 * @author Tan Ling
 * @date 2019年6月20日 下午5:38:29
 */
public interface ViewRecordService extends BaseService<ViewRecord> {
	
	/**
	 * 添加访问记录
	 * @author Tan Ling
	 * @date 2019年6月20日 下午5:42:34
	 * @param user
	 * @param lineId
	 * @param activityId
	 */
	void addViewRecord(UserInfoEntity user, String lineId, String activityId);
}
