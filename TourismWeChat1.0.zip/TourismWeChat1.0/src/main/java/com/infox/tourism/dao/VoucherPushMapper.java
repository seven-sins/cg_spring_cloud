package com.infox.tourism.dao;

import org.apache.ibatis.annotations.Mapper;

import com.infox.tourism.entity.VoucherPush;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 优惠券推送
 * @author Tan Ling
 * @date 2019年6月11日 上午11:11:13
 */
@Mapper
public interface VoucherPushMapper extends BaseMapper<VoucherPush> {
	/**
	 * 领取优惠券
	 * @author Tan Ling
	 * @date 2019年6月13日 下午4:08:03
	 * @param voucherPushId
	 */
	void receiveVoucherPush(String voucherPushId);
}
