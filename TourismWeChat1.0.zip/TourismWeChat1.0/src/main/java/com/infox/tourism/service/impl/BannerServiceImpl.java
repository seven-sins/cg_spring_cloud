package com.infox.tourism.service.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infox.common.exception.CustomException;
import com.infox.common.utils.redis.RedisConstant;
import com.infox.common.utils.redis.RedisService;
import com.infox.tourism.dao.BannerDao;
import com.infox.tourism.dao.JoinCityMapper;
import com.infox.tourism.dao.activity.ActivityMapper;
import com.infox.tourism.entity.JoinCity;
import com.infox.tourism.entity.vo.indexVO.CarouselMapIndexVO;
import com.infox.tourism.service.BannerService;

/**
 * 轮播图
 * 
 * @author Tan Ling
 * @date 2019年1月21日 上午9:42:52
 */
@Service
public class BannerServiceImpl implements BannerService {
	static final Logger LOG = LoggerFactory.getLogger(BannerServiceImpl.class);
	@Autowired
	private BannerDao carouselMapDao;
	@Autowired
	private JoinCityMapper joinCityMapper;
	@Autowired
	private RedisService redisService;
	@Autowired
	private ActivityMapper activityMapper;

	@Override
	public List<CarouselMapIndexVO> selectListOfWeChat(String sbLocationId) {
		List<CarouselMapIndexVO> list;
		if(StringUtils.isBlank(sbLocationId)) {
			list = carouselMapDao.selectListOfWeChat(null);
		} else {
			//
			JoinCity joinCity = (JoinCity) redisService.get(RedisConstant.CITY_PREFIX + sbLocationId);
			if(joinCity == null) {
				joinCity = joinCityMapper.getBySbLocationId(sbLocationId);
				if(joinCity == null) {
					LOG.error("=============接入城市不存在, locationId: " + sbLocationId);
					throw new CustomException("接入城市不存在");
				}
				redisService.add(RedisConstant.CITY_PREFIX + sbLocationId, joinCity, 1440);
			}
			list = carouselMapDao.selectListOfWeChat(joinCity.getCompanyId());
		}
		for(CarouselMapIndexVO item: list) {
			// 当前线路最新一期的活动ID
			item.setActivityId(activityMapper.getRecentlyActivityId(item.getLineId(), item.getCompanyId()));
		}
		
		return list;
	}
}
