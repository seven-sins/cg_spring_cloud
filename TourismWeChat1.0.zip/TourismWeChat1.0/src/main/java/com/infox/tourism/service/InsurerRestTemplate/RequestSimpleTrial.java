package com.infox.tourism.service.InsurerRestTemplate;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.infox.tourism.util.InsurerApi;
import com.infox.tourism.util.InsurerSign;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class RequestSimpleTrial {

    public static JSONObject sendRequestSimpleTrial(JSONObject simpleTrialJSON){

        RestTemplate restTemplate = new RestTemplate();

        HttpEntity<JSONObject> httpEntity = new HttpEntity<>(simpleTrialJSON);

        String STSign = InsurerSign.getInsurerSign(simpleTrialJSON.toJSONString());

        String STUrl = InsurerApi.getSimpleTrialAPI(STSign);

        ResponseEntity<String> responseEntity = restTemplate.postForEntity(STUrl, httpEntity, String.class);

        JSONObject SimpleTrialJson = JSON.parseObject(responseEntity.getBody());

        System.out.println("SimpleTrialJson--------------请求回来的参数：" + responseEntity.getBody());

        return SimpleTrialJson;

    }

}