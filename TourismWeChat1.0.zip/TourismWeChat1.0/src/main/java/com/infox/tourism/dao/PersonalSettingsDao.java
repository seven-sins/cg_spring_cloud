package com.infox.tourism.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.infox.tourism.entity.PersonalSettingsEntity;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-12-11 18:52:59
 */
@Mapper
public interface PersonalSettingsDao extends BaseMapper<PersonalSettingsEntity> {

    /**
    * 查询分页
    * @return
    */
    PersonalSettingsEntity queryPage();

    /**
     * 领队动态提醒      1 开启   2  关闭
     */
    boolean updateLeaderMovingTips(@Param("leaderMovingTips") Integer leaderMovingTips, @Param("settingId")String settingId);

    /**
     * 全新线路时提醒   1 开启   2  关闭
     */
    boolean updateLineTips(@Param("lineTips")Integer lineTips, @Param("settingId")String settingId);

    /**
     * 报名名额提醒  1 开启   2  关闭
     */
    boolean updateEnrollName(@Param("enrollName")Integer enrollName,@Param("settingId")String settingId);

    /**
     * 隐藏游记   1 开启   2  关闭
     */
    boolean updateHideTravels(@Param("hideTravels")Integer hideTravels,@Param("settingId") String settingId);

    /**
     * 根据userId查询
     * @param userId
     * @return
     */
    PersonalSettingsEntity selectByUserId(String userId);

}
