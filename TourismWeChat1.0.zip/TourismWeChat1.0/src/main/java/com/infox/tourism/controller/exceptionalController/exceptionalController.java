package com.infox.tourism.controller.exceptionalController;

import com.github.pagehelper.PageInfo;
import com.infox.common.utils.Assert;
import com.infox.tourism.entity.ExceptionalRecordEntity;
import com.infox.tourism.entity.LeaderInfoEntity;
import com.infox.tourism.service.ExceptionalRecordService;
import com.infox.tourism.util.R;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;

@RestController
@RequestMapping("/exceptional")
public class exceptionalController {

    /**
     * 兑换记录
     */
    @Autowired
    private ExceptionalRecordService exceptionalRecordService;

    /**
     * 打赏领队
     * @param
     * @return
     */
    @ApiOperation(value = "打赏领队")
    @GetMapping("/rewardLeader")
    public R rewardLeader(String activityId){

        List<LeaderInfoEntity> list = exceptionalRecordService.rewardLeader(activityId);

        PageInfo<LeaderInfoEntity> pageInfo = new PageInfo<>(list);

        HashMap<String, Object> map = new HashMap<>();
        map.put("total",pageInfo.getTotal());
        map.put("list",list);

        return R.ok().put("data",map);

    }

    /**
     * 打赏记录
     * @param
     * @return
     */
    @ApiOperation(value = "打赏记录")
    @GetMapping("/rewardRecord")
    public R rewardRecord(int pageNum, int pageSize,String activityId,String leaderId){
    	Assert.notEmpty(leaderId, "参数错误, 领队ID不能为空");
    	Assert.notEmpty(leaderId, "参数错误, 活动ID不能为空");
        List<ExceptionalRecordEntity> list = exceptionalRecordService.rewardRecord(pageNum, pageSize,activityId,leaderId);

        PageInfo<ExceptionalRecordEntity> pageInfo = new PageInfo<>(list);

        HashMap<String, Object> map = new HashMap<>();
        map.put("total",pageInfo.getTotal());
        map.put("list",list);

        return R.ok().put("data",map);
    }
}
