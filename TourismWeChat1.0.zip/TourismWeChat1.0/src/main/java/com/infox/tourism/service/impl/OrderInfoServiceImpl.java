package com.infox.tourism.service.impl;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.util.StringUtil;
import com.infox.common.base.impl.BaseServiceImpl;
import com.infox.common.exception.CustomException;
import com.infox.common.utils.Assert;
import com.infox.common.utils.DateUtils;
import com.infox.common.utils.IdMaker;
import com.infox.common.utils.IdcardUtil;
import com.infox.common.utils.redis.RedisConstant;
import com.infox.common.utils.redis.RedisService;
import com.infox.tourism.dao.ActivityBargainRecordDao;
import com.infox.tourism.dao.ActivityCoverDao;
import com.infox.tourism.dao.ActivityRulesDao;
import com.infox.tourism.dao.ActivitySingleRecordDao;
import com.infox.tourism.dao.CommonContactsDao;
import com.infox.tourism.dao.EvaluationDao;
import com.infox.tourism.dao.LineDao;
import com.infox.tourism.dao.OrderInfoDao;
import com.infox.tourism.dao.PedestrianInfoDao;
import com.infox.tourism.dao.ProductByOrderDao;
import com.infox.tourism.dao.ProductInfoDao;
import com.infox.tourism.dao.RefundRulesDao;
import com.infox.tourism.dao.SpikeActivityRuleDao;
import com.infox.tourism.dao.VouchersReceiveDao;
import com.infox.tourism.dao.activity.ActivityMapper;
import com.infox.tourism.dao.shammember.RemoveShamMemberMapper;
import com.infox.tourism.entity.ActivityBargainRecordEntity;
import com.infox.tourism.entity.ActivityCoverEntity;
import com.infox.tourism.entity.ActivityInfoEntity;
import com.infox.tourism.entity.ActivityLeaderRelation;
import com.infox.tourism.entity.ActivityRulesEntity;
import com.infox.tourism.entity.ActivitySingleRecordEntity;
import com.infox.tourism.entity.CommonContacts;
import com.infox.tourism.entity.EvaluationEntity;
import com.infox.tourism.entity.InsuranceProductsEntity;
import com.infox.tourism.entity.OrderInfoEntity;
import com.infox.tourism.entity.PedestrianInfoEntity;
import com.infox.tourism.entity.ProductByOrder;
import com.infox.tourism.entity.ProductInfoEntity;
import com.infox.tourism.entity.SpikeActivityRuleEntity;
import com.infox.tourism.entity.UserInfoEntity;
import com.infox.tourism.entity.VouchersReceiveEntity;
import com.infox.tourism.entity.order.OrderArgs;
import com.infox.tourism.entity.shammember.RemoveShamMember;
import com.infox.tourism.entity.traffic.TrafficMode;
import com.infox.tourism.entity.vo.OrderVO.OrderDetailVO;
import com.infox.tourism.entity.vo.OrderVO.OrderRefund;
import com.infox.tourism.entity.vo.OrderVO.OrderVO;
import com.infox.tourism.entity.vo.OrderVO.ProductByOrderVO;
import com.infox.tourism.entity.vo.activity.RefundRulesVO;
import com.infox.tourism.entity.vo.productVO.ProductInfoVO;
import com.infox.tourism.entity.vo.share.ToShareVO;
import com.infox.tourism.mapper.order.OrderArgsMapper;
import com.infox.tourism.mapper.traffic.TrafficModeMapper;
import com.infox.tourism.service.ActivityService;
import com.infox.tourism.service.InsuranceProductService;
import com.infox.tourism.service.OrderInfoService;
import com.infox.tourism.util.UUIDUtil;

import tk.mybatis.mapper.common.BaseMapper;

/**
 * 订单表
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class OrderInfoServiceImpl extends BaseServiceImpl<OrderInfoEntity> implements OrderInfoService {
	private static final Logger LOG = LoggerFactory.getLogger(OrderInfoServiceImpl.class);
	// 
	private static final String SYMBOL_REGEX = "\\-";
	private static final String NAN = "\\D+";
	// (0:新订单 1:取消订单 2:退款申请 3:退款失败 4:退款成功 5:已改期)
	private static final List<Integer> ORDER_STATUS = Arrays.asList(1, 3, 4, 5);
	// 下单类型(0:普通活动,1:秒杀活动,2:拼单活动,3:砍价活动)
	/******************************************************************************START
	 * 如虚假会员数量=10, 当前订单出行人数量=3, 活动最大参加人数=20, 预留名额=5 
	 * 	a. 10+3>20-5, 条件不成立, 不立即删除虚假会员
	 * 	b. 10+3>20/2, 条件成立, 添加当前报名人数的虚假会员到任务表, 让定时任务做无规律删除
	 */
	/**
	 * 1. 活动预留名额, 活动剩余名额为x时, 出行人+1, 虚假会员-1
	 */
	private static final int RESERVED_PLACE = 5;
	/**
	 * 2. 当活动报名人数达到最大值/2时, 开始删除虚假会员
	 */
	private static final int REMOVE_SHAM_MEMBER = 2;
	/**
	 * 3. 每次删除虚假会员数量
	 */
	private static final int BATCH_REMOVE_NUMBER = 3;
	/******************************************************************************END/
	/**
	 * 拼单
	 */
	private static final Integer SINGLE = 2;
	/**
	 * 砍价
	 */
	private static final Integer BARGAIN = 3;
	/**
	 * 秒杀
	 */
	private static final Integer SECKILL = 1;
	/**
	 * 成人年龄
	 */
	private static final Integer ADULT_AGE = 18;
	@Autowired
	private CommonContactsDao commonContactsDao;
    @Autowired
    private OrderInfoDao orderInfoDao;
    @Autowired
    private PedestrianInfoDao pedestrianInfoDao;
    @Autowired
    private ProductByOrderDao productByOrderDao;
    @Autowired
    private ProductInfoDao productInfoDao;
    @Autowired
    private VouchersReceiveDao vouchersReceiveDao;
    @Autowired
    private ActivitySingleRecordDao activitySingleRecordDao;
    @Autowired
    private ActivityRulesDao activityRulesDao;
    @Autowired
    private SpikeActivityRuleDao spikeActivityRuleDao;
    @Autowired
	private ActivityBargainRecordDao activityBargainRecordDao;
    @Autowired
    private ActivityCoverDao activityCoverDao;
    @Autowired
    private ActivityMapper activityMapper;
    @Autowired
    private ActivityService activityService;
    @Autowired
    private InsuranceProductService insuranceProductService;
    @Autowired
    private LineDao lineDao;
    @Autowired
    private RefundRulesDao refundRulesDao;
	@Autowired
	private EvaluationDao evaluationDao;
	@Autowired
	private RemoveShamMemberMapper removeShamMemberMapper;
	@Autowired
	private RedisService redisService;
	@Autowired
	private OrderArgsMapper orderArgsMapper;
	@Autowired
    private TrafficModeMapper trafficModeMapper;
    
    @Resource
    @Override
    public void setBaseMapper(BaseMapper<OrderInfoEntity> orderInfoDao) {
		this.baseMapper = orderInfoDao;
	}
    
    @Override
    public OrderInfoEntity createGroup(UserInfoEntity user, OrderInfoEntity order) {
    	order = insert(user, order, SINGLE);
    	
    	createSingleRecord(user, order);
    	
    	return order;
    }
    
    @Override
    public OrderInfoEntity joinGroup(UserInfoEntity user, OrderInfoEntity order,  String groupId) {
    	order = insert(user, order, SINGLE);
    	
    	createSingleRecord(user, order, groupId);
    	
    	return order;
    }
    
    /**
     * @author Tan Ling
     * @date 2019年1月25日 下午6:52:43
     * @param user
     * @param order
     * @param type  1: 拼单, 2: 砍价
     * @return
     */
    @Override
    public OrderInfoEntity insert(UserInfoEntity user, OrderInfoEntity order, Integer type) {
    	/**
    	 * 先将参数序列化, 订单创建成功时存储
    	 */
    	String orderArgsString = JSONObject.toJSONString(order);
    	/**
    	 * 删除当前活动未支付的订单
    	 */
    	orderInfoDao.deleteNonpaymentOrderByActivityId(order.getActivityId(), user.getUserId());
    	/**
    	 * 1. 获取活动信息
    	 */
    	ActivityInfoEntity activity = activityMapper.getActivityByActivityId(order.getActivityId());
    	Assert.notNull(activity, "活动不存在");
    	Assert.isTrue(activity.getaStatus() != null && activity.getaStatus() == 3, "活动非发布状态不能报名");
    	// 1已报满 2已成行 3报名中 4已截止  5 即将成行 6已下架
		Assert.notNull(activity.getActivityStatus(), "数据异常, 活动状态为空");
		Assert.isTrue(activity.getActivityStatus() != null && activity.getActivityStatus() != 1, "活动已报满");
		Assert.isTrue(activity.getActivityStatus() != null && activity.getActivityStatus() != 4, "活动已截止报名");
		Assert.isTrue(activity.getActivityStatus() != null && activity.getActivityStatus() != 6, "活动已下架");
		Assert.isTrue(activity.getActivityStatus() != null && activity.getActivityStatus() != 7, "活动未成行(已取消)");
    	/**
    	 * 2. 判断是否超出活动最大参与人数
    	 */
    	int count = this.removeShamOrder(activity, order);
    	/**
    	 * 3. 创建订单
    	 */
    	order.setOrderId(IdMaker.getStringKey());
    	// 下单类型(0:普通活动,1:秒杀活动,2:拼单活动,3:砍价活动)
    	order.setOrderType(type);
    	// 生成订单号
    	order.setoNumber(this.createOrderNumber());
    	order.setUserId(user.getUserId());
    	// 0: 新订单
    	order.setOrderStatus(0);
    	// 0: 未支付
    	order.setPayStatus(0);
    	order.setPlaceOrderTime(new Date());
    	order.setRefundAmount(new BigDecimal(0));
    	order.setCreateTime(new Date());
    	order.setCreateBy(user.getUserId());
    	order.setIsDelete(1);
    	order.setCompanyId(activity.getCompanyId());
    	order.setDiscountAmount(new BigDecimal(0));
    	// 真实订单(0:假,1:真)
    	order.setoType(1);
    	BigDecimal bargainAmount = new BigDecimal(0);
    	if(BARGAIN.equals(type)) {
    		Assert.notEmpty(order.getGroupId(), "砍价订单groupId不能为空");
    		// 已砍掉的金额
    		bargainAmount = activityBargainRecordDao.getActivityTotalBargainPrice(order.getGroupId(), order.getActivityId());
    		LOG.info("=============砍掉的金额: " + bargainAmount);
    		// 优惠金额
    		order.setDiscountAmount(bargainAmount);
    	}
    	/**
    	 * 4. 添加出行人
    	 */
    	BigDecimal totalPrice = this.createPedestrian(activity, order, user, type, bargainAmount);
    	/**
    	  * 5. 添加商品
    	 */
    	totalPrice = totalPrice.add(this.addOrderProduct(order, user));
    	/**
    	 * 6. 如果使用了优惠券, 扣减相应金额
    	 */
    	totalPrice = this.useVouchers(user, activity, order, totalPrice);
    	/**
    	 * 7.  修改活动状态为即将成行(活动状态，1已报满  2已成行  3报名中   4已截止  5  即将成行)
    	 */
    	Assert.notNull(activity.getFormPeople(), "数据异常, 活动成行人数为空");
    	
    	
    	
    	// activity.setActivityStatus(3);
    	// 达到成行人数一半, 即将成行
    	/**
    	 * 改为支付时修改状态
    	 */
//    	if(count + order.getPedestrianList().size() >= activity.getFormPeople()/2) {
//    		activity.setActivityStatus(5);
//    	}
//    	if( (count + order.getPedestrianList().size()) >= activity.getFormPeople()) {
//    		activity.setActivityStatus(2);
//    	}
    	Assert.notNull(activity.getMostPeopleSum(), "数据异常, 活动最大人数为空");
    	Assert.isTrue((count + order.getPedestrianList().size()) <= activity.getMostPeopleSum(), "活动报名人数超出限制");
    	// 已报名人数 == 活动最大报名人数, 修改状态为已报满
    	//if( (count + order.getPedestrianList().size()) == activity.getMostPeopleSum()) {
    	//	activity.setActivityStatus(1);
    	//}
    	
    	
    	
    	// 7.1 设置订单金额
    	// 如果是砍价活动, - 砍掉的金额
    	if(BARGAIN.equals(type)) {
    		Assert.notEmpty(order.getGroupId(), "砍价订单groupId不能为空");
    		// 已砍掉的金额
    		BigDecimal amount = activityBargainRecordDao.getActivityTotalBargainPrice(order.getGroupId(), order.getActivityId());
    		LOG.info("=============砍掉的金额: " + amount);
    		// 赋值优惠金额
    		order.setDiscountAmount(amount);
    		
    		amount = amount == null ? new BigDecimal(0) : amount;
    		totalPrice = totalPrice.subtract(amount);
    		LOG.info("=============付款金额: " + totalPrice);
    		// 修改砍价状态
    		ActivityBargainRecordEntity bargainInfo = activityBargainRecordDao.getBargainInfoByGroupId(order.getActivityId(), order.getGroupId());
    		Assert.notNull(bargainInfo, "数据异常, 砍价信息不存在");
    		Assert.isTrue(bargainInfo.getIsEnd() != 1, "数据异常, 砍价已结束");
    		// 将砍价状态标记为结束
    		bargainInfo.setIsEnd(1);
    		activityBargainRecordDao.updateByBargainId(bargainInfo);
    	}
    	order.setOMoney(totalPrice);
    	orderInfoDao.insert(order);
    	// 7.2 更新活动总金额
    	//BigDecimal activityTotalAmount = activity.getPaymentMoney() == null ? new BigDecimal(0) : activity.getPaymentMoney();
    	//activity.setPaymentMoney(activityTotalAmount.add(totalPrice));
    	// 7.3 更新活动总人数
    	//int activityTotalNumber = activity.getPaymentNumber() == null ? 0 : activity.getPaymentNumber();
    	//activity.setPaymentNumber(activityTotalNumber + order.getPedestrianList().size());
    	//activityInfoDao.updateByActivityId(activity);
    	
    	/**
    	 * 删除报名人数缓存
    	 */
    	redisService.delete(RedisConstant.PEOPLE_NUM_PREFIX + order.getActivityId());
    	
    	/**
    	 * 订单创建成功, 存储参数信息
    	 */
    	OrderArgs orderArgs = new OrderArgs();
    	orderArgs.setOrderArgsId(UUIDUtil.create());
    	orderArgs.setActivityId(order.getActivityId());
    	orderArgs.setOrderId(order.getOrderId());
    	orderArgs.setUserId(order.getUserId());
    	orderArgs.setOrderArgs(orderArgsString);
    	orderArgs.setCreateTime(new Date());
    	orderArgsMapper.insert(orderArgs);
    	
    	return order;
    }
    
	/**
	 * 删除虚假会员 
	 * 如当前报名人数 > 1/3, 
	 * 新增一个出行人对应删除一个虚假订单中的出行人, 删完为止
	 * @param activity
	 * @param order
	 */
    private int removeShamOrder(ActivityInfoEntity activity, OrderInfoEntity order) {
    	Assert.notNull(activity.getMostPeopleSum(), "数据异常, 活动最大参与人数不能为空");
    	// 获取当前活动虚假订单出行人数
    	Integer shamCount = pedestrianInfoDao.getShamCountByActivityId(activity.getActivityId());
    	// 虚假会员数量 需要减去领队数量
    	shamCount = shamCount == null ? 0 : shamCount;
    	
    	// int total = shamCount;
    	// 当前已报名用户数量
    	Integer joinNum = activityMapper.queryActivityPeopleNum(activity.getActivityId());
    	joinNum = joinNum == null ? 0 : joinNum;
    	// 总数量， 虚假会员数量 + 报名数量
    	// total = total + joinNum;
    	
    	LOG.info("=============joinNum: " + joinNum);
    	LOG.info("=============shamCount: " + shamCount);
    	
		if (shamCount > 0) {
			// 活动最大参与人数
			int mostPeapleSum = activity.getMostPeopleSum();
			/**
			 * (虚假出行人数量 + 当前出行人数量) > (活动最大出行人数量 - 预留名额)
			 * 如虚假会员数量=10, 当前订单出行人数量=3, 活动最大参加人数=20, 预留名额=5
			 * 		a. 10+3>20-5, 条件不成立, 不立即删除虚假会员
			 * 		b. 10+3>20/2, 条件成立, 添加当前报名人数的虚假会员到任务表, 让定时任务做无规律删除
			 */
			if ((joinNum + order.getPedestrianList().size()) > (mostPeapleSum - RESERVED_PLACE)) {
				// 当前订单有多少出行人， 删除对应数量虚假数据
				List<PedestrianInfoEntity> list = pedestrianInfoDao.findShamList(activity.getActivityId(), order.getPedestrianList().size());
				if (list != null && !list.isEmpty()) {
					for (PedestrianInfoEntity item : list) {
						// 删除虚假出行人(0:删除)
						pedestrianInfoDao.updatePedestrianInfoStatus(item.getPedestrianId(), 0);
						// 获取虚假出行人关联订单下的出行人数量, 如数量 == 0, 删除订单
						Integer shamPedestrianCountByOrder = pedestrianInfoDao.getCountByOrderId(item.getOrderId());
						shamPedestrianCountByOrder = shamPedestrianCountByOrder == null ? 0 : shamPedestrianCountByOrder;
						if (shamPedestrianCountByOrder == 0) {
							// 0:删除
							orderInfoDao.updateOrderStatusByOrderId(item.getOrderId(), 0);
						}
						// 同时修改活动设置的虚假会员数量
						ActivityInfoEntity dbData = activityMapper.getActivityByActivityId(order.getActivityId());
						if(dbData == null || dbData.getFalseMemberNum() == null) {
							continue;
						}
						if(dbData.getFalseMemberNum() > 0) {
							activityMapper.updateFalseMemberNum(order.getActivityId(), dbData.getFalseMemberNum() - 1);
						}
					}
				}
			}
			/**
			 * 出报名人数达到活动最大人数的一半, 将对应当前订单出行人数量的虚假会员添加到删除任务表
			 */
			else if ((joinNum + order.getPedestrianList().size()) > (mostPeapleSum / REMOVE_SHAM_MEMBER)) {
				// 查询跟出行人相同数量的虚假会员添加到删除表
				// 当前订单有多少出行人， 删除对应数量虚假数据
				List<PedestrianInfoEntity> list = pedestrianInfoDao.findShamList(activity.getActivityId(), order.getPedestrianList().size());
				if(list != null && !list.isEmpty()) {
					for(PedestrianInfoEntity item: list) {
						RemoveShamMember shamMember = new RemoveShamMember();
						shamMember.setRemoveShamId(UUIDUtil.create());
						shamMember.setOrderId(item.getOrderId());
						shamMember.setPedestrianId(item.getPedestrianId());
						removeShamMemberMapper.insert(shamMember);
					}
				}
			}
		}
    	
    	// Integer count = pedestrianInfoDao.getCountByActivityId(activity.getActivityId());
    	if(joinNum != null && activity.getMostPeopleSum() < (joinNum + order.getPedestrianList().size())) {
    		throw new CustomException("超出活动报名人数限制");
    	}
    	
    	return joinNum;
    }
    
    @Override
    public void removeShamMember() {
    	List<RemoveShamMember> list = removeShamMemberMapper.findByRandom(BATCH_REMOVE_NUMBER);
    	if(list == null || list.isEmpty()) {
    		return;
    	}
    	for (RemoveShamMember item : list) {
			// 删除虚假出行人(0:删除)
			pedestrianInfoDao.updatePedestrianInfoStatus(item.getPedestrianId(), 0);
			// 获取虚假出行人关联订单下的出行人数量, 如数量 == 0, 删除订单
			Integer shamPedestrianCountByOrder = pedestrianInfoDao.getCountByOrderId(item.getOrderId());
			shamPedestrianCountByOrder = shamPedestrianCountByOrder == null ? 0 : shamPedestrianCountByOrder;
			if (shamPedestrianCountByOrder == 0) {
				// 0:删除
				orderInfoDao.updateOrderStatusByOrderId(item.getOrderId(), 0);
			}
			// 从任务表删除
			removeShamMemberMapper.deleteById(item.getRemoveShamId());
			/**
			 * 减去活动中设置的虚假会员数量
			 */
			OrderInfoEntity order = orderInfoDao.selectByPrimaryKey(item.getOrderId());
			if(order == null) {
				continue;
			}
			ActivityInfoEntity activity = activityMapper.getActivityByActivityId(order.getActivityId());
			if(activity == null || activity.getFalseMemberNum() == null) {
				continue;
			}
			if(activity.getFalseMemberNum() > 0) {
				activityMapper.updateFalseMemberNum(order.getActivityId(), activity.getFalseMemberNum() - 1);
			}
		}
    }
    
	/**
	 * 使用优惠券
	 * @param user
	 * @param activity
	 * @param order
	 * @param totalPrice
	 * @return
	 */
    private BigDecimal useVouchers(UserInfoEntity user, ActivityInfoEntity activity, OrderInfoEntity order, BigDecimal totalPrice) {
    	BigDecimal amount = totalPrice;
    	if(StringUtils.isNotBlank(order.getVouchersId())) {
    		VouchersReceiveEntity vouchers = vouchersReceiveDao.selectByPrimaryKey(order.getVouchersId());
    		Assert.notNull(vouchers, "数据异常, 用户没有这张代金券");
    		Assert.isTrue(user.getUserId().equals(vouchers.getUserId()), "数据异常, 代金券不属于当前用户");
    		// Assert.isTrue((new Date().getTime() - vouchers.getOverdueTime().getTime()) < 0, "代金券已过期");
    		Assert.isTrue(!(vouchers.getVrStatus() != null && vouchers.getVrStatus() == 1), "数据异常, 代金券已经使用");
    		Assert.notEmpty(vouchers.getVoucherBaseId(), "数据异常, 代金券关联ID为空");
    		// VoucherBaseInformationEntity  voucherBaseInfo = voucherBaseInformationDao.selectByPrimaryKey(vouchers.getVoucherBaseId());
    		// Assert.notNull(voucherBaseInfo, "数据异常, 代金券不存在");
    		Date today = DateUtils.removeHms(new Date());
    		Date startTime = DateUtils.removeHms(vouchers.getStartTime());
    		Date endTime = DateUtils.removeHms(vouchers.getEndTime());
    		Assert.isTrue(today.getTime() <= endTime.getTime(), "代金券已过有效期");
    		Assert.isTrue(today.getTime() >= startTime.getTime(), "代金券不在有效期");
    		if(vouchers.getVrType() != null && vouchers.getVrType() == 1) {
    			Assert.notNull(vouchers.getVbiFull(), "数据异常, 满减金额为空");
    			Assert.notNull(vouchers.getAmount(), "数据异常, 满减金额为空");
    			Assert.isTrue(amount.compareTo(vouchers.getVbiFull()) != -1, "数据异常, 订单金额小于代金券满减金额");
    			amount = amount.subtract(vouchers.getAmount());
    			// 赋值优惠金额
    			order.setDiscountAmount(vouchers.getAmount());
    		} else {
    			Assert.notNull(vouchers.getAmount(), "数据异常, 金额为空");
    			amount = amount.subtract(vouchers.getAmount());
    			// 赋值优惠金额
    			order.setDiscountAmount(vouchers.getAmount());
    		}
    		vouchers.setOrderId(order.getOrderId());
    		vouchers.setUseSource(activity.getActivityName());
    		vouchers.setUseTime(new Date());
    		vouchers.setVrStatus(1);
    		vouchersReceiveDao.updateByvouchersReceiveId(vouchers);
    	}
    	
    	return amount;
    }
    
	/**
	 * 添加活动商品
	 * @param order
	 * @return
	 */
    private BigDecimal addOrderProduct(OrderInfoEntity order, UserInfoEntity user) {
    	BigDecimal totalPrice = new BigDecimal(0);
    	if(order.getProductList() != null && !order.getProductList().isEmpty()) {
    		for(ProductByOrder item: order.getProductList()) {
    			ProductInfoEntity productInfo = productInfoDao.selectByPrimaryKey(item.getProductId());
    			Assert.notNull(productInfo, "数据异常, 商品不存在");
    			//  && productInfo.getVipPrice() != null
    			Assert.isTrue(productInfo.getProductPrice() != null, "数据异常, 商品价格为空");
    			item.setProductByOrderId(UUIDUtil.create());
    			item.setCreateTime(new Date());
    			item.setOrderId(order.getOrderId());
    			item.setActivityId(order.getActivityId());
    			// 订单价格 += 商品单价 * 数量
    			// 如果用户是VIP, 使用会员价
    			if(user.getUVip() != null && productInfo.getVipPrice() != null && user.getUVip() == 1) {
    				BigDecimal vipPrice = productInfo.getVipPrice();
    				item.setPrice(vipPrice);
//    				if(vipPrice == null) {
//    					vipPrice = productInfo.getProductPrice();
//    				}
//    				Assert.notNull(vipPrice, "数据异常, 商品价格为空");
    				totalPrice = totalPrice.add(vipPrice.multiply(new BigDecimal(item.getProductNum())));
    				item.setOrderAmount(vipPrice.multiply(new BigDecimal(item.getProductNum())));
    				// item.setOrderAmount(vipPrice);
    			} else {
    				item.setPrice(productInfo.getProductPrice());
    				totalPrice = totalPrice.add(productInfo.getProductPrice().multiply(new BigDecimal(item.getProductNum())));
    				item.setOrderAmount(productInfo.getProductPrice().multiply(new BigDecimal(item.getProductNum())));
    				// item.setOrderAmount(productInfo.getProductPrice());
    			}
    			Assert.isTrue(item.getPrice() != null, "数据异常, 商品单价获取失败");
    			// 订单产品状态(1:正常,2:已改期,3:已退款,4:申请退款)
    			item.setProductByOrderStatus(1);
    			item.setRefundAmount(new BigDecimal(0));
    			
    			productByOrderDao.insert(item);
    		}
    	}
    	
    	return totalPrice;
    }
    
    private boolean getSecKillPrice(String activityId) {
		Date date = new Date();
		List<SpikeActivityRuleEntity> spikeActivityRuleEntities = spikeActivityRuleDao.selectSpikeByActivityId(activityId);
		if(spikeActivityRuleEntities == null || spikeActivityRuleEntities.isEmpty()) {
			return false;
		}
		for (SpikeActivityRuleEntity item : spikeActivityRuleEntities) {
			if (item.getStartTime().getTime() < date.getTime() && date.getTime() < item.getEndTime().getTime()) {
				return true;
			}
		}
		return false;
    }
	/**
	 * 添加出行人
	 * @param activity
	 * @param order
	 * @return
	 */
    private BigDecimal createPedestrian(ActivityInfoEntity activity, OrderInfoEntity order, UserInfoEntity user, Integer type, BigDecimal bargainAmount) {
    	// 角色(1.普通 2.会员 )
    	int role = (user.getuVip() != null && user.getuVip() == 1) ? 2 : 1;
    	// 订单总金额
    	BigDecimal totalPrice = new BigDecimal(0);
    	/**
    	 * 如果vip价或儿童价为空, 默认使用成人价
    	 */
    	Assert.notNull(activity.getAdultPrice(), "数据异常, 活动成人价为空");
    	// 出行人中没有成人
    	// boolean hasAdult = false;
    	// 活动分销金额
    	BigDecimal zero = new BigDecimal("0");
    	BigDecimal distribution = activity.getRebate();
    	distribution = distribution == null ? zero : distribution;
    	/**
    	 * 如果shareUserId不为空, 当前活动是通过分享出去的链接下单, 记录分销金额
    	 * 如果shareUserId为空, 分销金额记为0
    	 * 如果是分销人自己下单, 不记录分销金额
    	 */
    	if(StringUtil.isEmpty(order.getShareUserId())) {
    		distribution = zero;
    	} else {
//    		// 2019-05-16修改, 自己点自己生成的链接需要计算分销
//    		if(user.getUserId().equals(order.getShareUserId())) {
//    			distribution = zero;
//    			order.setShareUserId(null);
//    		}
    		// 客户环境错误信息排查
    		if(order.getShareUserId().length() > 32) {
    			LOG.error("=============分享用户ID超出最大长度, shareUserId: " + order.getShareUserId());
    			throw new CustomException("参数错误, 分销用户ID超出最大长度");
    		}
    	}
    	
    	/**
    	 * 查询年龄限制
    	 */
    	String ageLimit = lineDao.queryAgeLimitByLineId(activity.getLineId());
    	Integer minAge = 0, maxAge = 0;
    	if(StringUtils.isNotBlank(ageLimit)) {
    		String[] arr = ageLimit.split(SYMBOL_REGEX);
    		if(arr.length == 2) {
    			try {
    				minAge = Integer.parseInt(arr[0].replaceAll(NAN, ""));
        			maxAge = Integer.parseInt(arr[1].replaceAll(NAN, ""));
        			Assert.isTrue(minAge <= maxAge, "年龄段配置错误, " + ageLimit + ", " + maxAge + " 必须>= " + minAge);
    			}catch(Exception e) {
    				if(e instanceof CustomException) {
    					throw e;
    				}
    				LOG.error("=============解析年龄段限制出错");
    				e.printStackTrace();
    			}
    		}
    	}
    	
    	for(PedestrianInfoEntity item: order.getPedestrianList()) {
    		/**
    		 * 如果常用联系人中没有当前添加的出行人, 需要添加到常用联系人
    		 */
    		this.addCommonContact(item, user);
    		/**
    		 * 数据验证
    		 * 出行人类型(1:成人, 2:儿童)
    		 */
    		if(item.getPeopleType() == 1) {
    			// hasAdult = true;
    		}
    		String errorMsg = item.getCertificateType() != null && item.getCertificateType() == 1? " 身份证号不能为空":" 身护照不能为空";
    		Assert.notEmpty(item.getpIdentity(), item.getContactPeople() + errorMsg);
			Assert.notEmpty(item.getContactPhone(), item.getContactPeople() + " 联系电话不能为空");
			/**
        	 * 查询出行人是否已报名
        	 * 出行人不能重复报名
        	 */
	      	if(pedestrianInfoDao.selectPedestrianCountByActivityIdAndIdCard(activity.getActivityId(), item.getPIdentity()) > 0) {
        		throw new CustomException(item.getContactPeople() + "已经报名该活动");
        	}
    		
    		item.setActivityId(order.getActivityId());
    		item.setOrderId(order.getOrderId());
    		item.setPedestrianId(UUIDUtil.create());
    		item.setCreateTime(new Date());
    		item.setRefundAmount(new BigDecimal(0));
    		item.setIsInsure(0);
    		item.setpRole(role);
    		item.setCompanyId(activity.getCompanyId());
    		// 分销用户
    		item.setDistributionUserId(order.getShareUserId());
    		// 分销金额
    		item.setDistributionAmount(distribution);
    		// 未分销
    		item.setIsDistribution(0);
    		
    		// 如果证件类型是身份证, 从身份证中解析年龄
    		if(item.getCertificateType() == PedestrianInfoEntity.IDCATD) {
    			item.setpAge(IdcardUtil.getAgeFromIdCard(item.getpIdentity()));
    			item.setpSex(IdcardUtil.getSexFromIdCard(item.getpIdentity()));
    			item.setBirthday(IdcardUtil.getBirthdayFromIdCard(item.getpIdentity()));
    		} else {
    			Assert.notNull(item.getpSex(), item.getContactPeople() + "性别不能为空");
    			Assert.notNull(item.getBirthday(), item.getContactPeople() + "出生年月不能为空");
    			item.setpAge(IdcardUtil.getAgeFromBirthday(item.getBirthday()));
    		}
    		item.setAgeCheck(0);
    		// 年龄不为空, 验证年龄段限制
    		if(item.getpAge() != null && item.getpAge() > 0) {
    			if(minAge > 0 && maxAge > 0) {
    				// 年龄段不匹配也可以报名, 移除验证
    				// Assert.isTrue(item.getpAge() >= minAge && item.getpAge() <= maxAge, "当前活动限制出行人年龄为 " + ageLimit);
    				// 记录不匹配的年龄
    				item.setAgeCheck(1);
    			}
    		}
    		/**
    		 * 1:正常,2:已改期,3:已退款,4:申请退款
    		 */
    		item.setPedestrianStatus(1);
    		// 1正常状态, 0删除
    		item.setIsDelete(1);
    		/**
    		 * 如果是拼单使用拼单价格
    		 * *** 20190415修改: 拼单使用原价支付, 活动出行时, 退款  原价-拼单价
    		 */
    		if(SINGLE.equals(type)) {
    			ActivityRulesEntity rules = activityRulesDao.selectByActivityId(activity.getActivityId());
    			Assert.notNull(rules, "数据异常, 获取活动规则返回null");
    			Assert.notNull(rules.getUnitPrice(), "数据异常, 组队价格为空");
    			// totalPrice = totalPrice.add(rules.getUnitPrice());
    			// item.setOrderAmount(rules.getUnitPrice());
    			// 拼单使用原价支付, 活动出行时, 退款  原价-拼单价
    			totalPrice = totalPrice.add(activity.getAdultPrice());
    			item.setOrderAmount(activity.getAdultPrice());
    		}
    		/**
    		 * 如果是砍价使用砍价价格
    		 */
    		else if(BARGAIN.equals(type)) {
    			ActivityRulesEntity rules = activityRulesDao.selectByActivityId(activity.getActivityId());
    			Assert.notNull(rules, "数据异常, 获取活动规则返回null");
    			Assert.notNull(rules.getBargainPrice(), "数据异常, 组队价格为空");
    			totalPrice = totalPrice.add(activity.getAdultPrice());
    			// 如果是砍价, 出行人价格 = 单价-砍掉的金额
    			bargainAmount = bargainAmount == null? new BigDecimal(0): bargainAmount;
    			item.setOrderAmount(activity.getAdultPrice().subtract(bargainAmount));
    		} 
    		/**
    		 * 如果是秒杀使用秒杀价格
    		 */
    		else if(SECKILL.equals(type)) {
    			ActivityRulesEntity rules = activityRulesDao.selectByActivityId(activity.getActivityId());
				// ActivityRulesEntity rules = activityRulesDao.selectByActivityId(activity.getActivityId());
				Assert.notNull(rules, "数据异常, 获取活动规则返回null");
				Assert.notNull(rules.getSeckillPrice(), "数据异常, 秒杀价格为空");
    			boolean isKill = this.getSecKillPrice(activity.getActivityId());
    			BigDecimal price = null;
    			if(isKill) {
    				price = rules.getSeckillPrice();
    			} else {
    				price = activity.getAdultPrice();
    			}
    			price = price == null ? activity.getAdultPrice() : price;
    			totalPrice = totalPrice.add(price);
    			item.setOrderAmount(price);
    		}
    		/**
    		 * 普通活动
    		 */
    		else if(item.getpAge() >= ADULT_AGE) {
    			Assert.isTrue(PedestrianInfoEntity.ADULT.equals(item.getPeopleType()), item.getContactPeople() + " 是成人, 出行人类型错误");
    			// 当前用户如果是VIP, 使用vip_price
    			if(user.getUVip() != null && user.getUVip() == 1) {
    				// Assert.notNull(activity.getVipPrice(), "数据异常, 活动VIP价为空");
    				if(activity.getVipPrice() != null) {
    					totalPrice = totalPrice.add(activity.getVipPrice());
    					item.setOrderAmount(activity.getVipPrice());
    				} else {
    					LOG.info("=============活动VIP价为空, 使用成人价");
    					totalPrice = totalPrice.add(activity.getAdultPrice());
    					item.setOrderAmount(activity.getAdultPrice());
    				}
    			} else {
    				totalPrice = totalPrice.add(activity.getAdultPrice());
    				item.setOrderAmount(activity.getAdultPrice());
    			}
    		} else {
    			// 儿童价
    			// Assert.notNull(activity.getChildPrice(), "数据异常, 活动儿童价为空");
    			// Assert.isTrue(PedestrianInfoEntity.CHILD.equals(item.getPeopleType()), item.getContactPeople() + " 是儿童, 出行人类型错误");
    			/**
    			 * 如果是vip, 使用vip价, 如没有vip价使用儿童价, 如儿童价也没有, 使用成人价
    			 */
    			if(user.getUVip() != null && user.getUVip() == 1) {
    				if(activity.getVipPrice() != null) {
    					totalPrice = totalPrice.add(activity.getVipPrice());
    					item.setOrderAmount(activity.getVipPrice());
    				} else {
    					if(activity.getChildPrice() != null) {
    	    				totalPrice = totalPrice.add(activity.getChildPrice());
    	    				item.setOrderAmount(activity.getChildPrice());
    	    			} else {
    	    				LOG.info("=============活动儿童价为空, 使用成人价");
    	    				totalPrice = totalPrice.add(activity.getAdultPrice());
    	    				item.setOrderAmount(activity.getAdultPrice());
    	    			}
    				}
    			} else {
    				if(activity.getChildPrice() != null) {
        				totalPrice = totalPrice.add(activity.getChildPrice());
        				item.setOrderAmount(activity.getChildPrice());
        			} else {
        				LOG.info("=============活动儿童价为空, 使用成人价");
        				totalPrice = totalPrice.add(activity.getAdultPrice());
        				item.setOrderAmount(activity.getAdultPrice());
        			}
    			}
    		}
    		/**
    		 * 如果设置了交通方式, 计算金额
    		 */
    		if(StringUtils.isNotBlank(item.getTrafficId())) {
    			TrafficMode trafficMode = trafficModeMapper.selectByPrimaryKey(item.getTrafficId());
    			Assert.notNull(trafficMode, "数据异常, 选择的交通方式不存在");
    			Assert.notNull(trafficMode.getTrafflicModeAmount(), "数据异常, 选择的交通方式金额不存在");
    			//
    			totalPrice = totalPrice.add(trafficMode.getTrafflicModeAmount());
				item.setOrderAmount(item.getOrderAmount().add(trafficMode.getTrafflicModeAmount()));
    		}
    		
    		pedestrianInfoDao.insert(item);
    	}
    	
    	// Assert.isTrue(hasAdult, "出行人中没有成人, 不能报名");
    	
    	return totalPrice;
    }

    /**
     * 检查出行人是否在常用联系人中， 如果不存在添加到常用联系人
     * @author Tan Ling
     * @date 2019年2月21日 下午2:24:38
     * @param item
     */
	private void addCommonContact(PedestrianInfoEntity item, UserInfoEntity user) {
		/**
		 * 检查身份证是否已存在
		 */
		CommonContacts commonContacts = commonContactsDao.getByIdCard(user.getUserId(), item.getpIdentity());
		if(commonContacts != null) {
			return;
		}
		commonContacts = new CommonContacts();
		commonContacts.setUserId(user.getUserId());
		commonContacts.setCommonContactsId(UUIDUtil.create());
		commonContacts.setCreateTime(new Date());
		commonContacts.setContactsName(item.getContactPeople());
		commonContacts.setPeopleType(item.getPeopleType());
		commonContacts.setIdCard(item.getpIdentity());
		commonContacts.setMobile(item.getContactPhone());
		commonContacts.setCertificateType(item.getCertificateType());
		commonContacts.setAge(item.getpAge());
		commonContacts.setSex(item.getpSex());
		commonContacts.setBirthday(item.getBirthday());
		// 如果证件类型是身份证, 从身份证中解析年龄
		if(item.getCertificateType() == PedestrianInfoEntity.IDCATD) {
			commonContacts.setAge(IdcardUtil.getAgeFromIdCard(item.getpIdentity()));
			commonContacts.setSex(IdcardUtil.getSexFromIdCard(item.getpIdentity()));
			commonContacts.setBirthday(IdcardUtil.getBirthdayFromIdCard(item.getpIdentity()));
		} else {
			Assert.notNull(item.getpSex(), item.getContactPeople() + "性别不能为空");
			commonContacts.setAge(IdcardUtil.getAgeFromBirthday(item.getBirthday()));
		}
		commonContactsDao.insert(commonContacts);
	}

	/**
	 * 根据userId 
	 * 根据支付状态查询
	 * @param pageNum
	 * @param pageSize
	 * @param userId
	 * @param payStatus
	 * @return
	 */
    @Override
    public List<OrderVO> selectByUserIdAndPayStatus(int pageNum, int pageSize, String userId, Integer payStatus){
        // 使用分页插件实现分页
        PageHelper.startPage(pageNum,pageSize);

        // 调用dao的方法
        List<OrderVO> list = new ArrayList<>();

        // 支付状态[0，未付款, 1，已付款   -1,已退出]
        if (payStatus.equals(0)){
            list = orderInfoDao.selectByUserIdAndPayStatus(userId,payStatus);
            list.forEach(item ->{
				List<ActivityLeaderRelation> activityLeaderRelations = orderInfoDao.selectByActivityId(item.getActivityId());
				item.setNickNames(activityLeaderRelations);
				// 计算金额    金额 = 支付金额 - 退款金额
				BigDecimal orderAmount = item.getoMoney() == null ? new BigDecimal(0) : item.getoMoney();
				BigDecimal refundAmount = item.getRefundAmount() == null ? new BigDecimal(0) : item.getRefundAmount();
				item.setoMoney(orderAmount.subtract(refundAmount));
			});
        } else if (payStatus.equals(1)){
            list = orderInfoDao.selectByUserIdAndPayStatus(userId,payStatus);
			list.forEach(item ->{
				// 计算金额    金额 = 支付金额 - 退款金额
				BigDecimal orderAmount = item.getoMoney() == null ? new BigDecimal(0) : item.getoMoney();
				BigDecimal refundAmount = item.getRefundAmount() == null ? new BigDecimal(0) : item.getRefundAmount();
				item.setoMoney(orderAmount.subtract(refundAmount));
				//
				List<PedestrianInfoEntity> orderIdList = pedestrianInfoDao.findByOrderIdList(item.getOrderId());
				// 如果有出行人存在，显示在页面中
				if (orderIdList.size() > 0){
					List<ActivityLeaderRelation> activityLeaderRelations = orderInfoDao.selectByActivityId(item.getActivityId());
					item.setNickNames(activityLeaderRelations);
				}else {
					// 如果没有出行人就更改状态
					OrderInfoEntity orderInfoEntity = new OrderInfoEntity();
					orderInfoEntity.setOrderId(item.getOrderId());
					orderInfoEntity.setOrderStatus(4);
					orderInfoDao.updateByOrderIdAndOrderStatus(orderInfoEntity);
				}
			});
        } else {
            list = orderInfoDao.selectByUserIdOrPayStatus(userId);
			list.forEach(item ->{
				List<ActivityLeaderRelation> activityLeaderRelations = orderInfoDao.selectByActivityId(item.getActivityId());
				item.setNickNames(activityLeaderRelations);
				// 计算金额    金额 = 支付金额 - 退款金额
				BigDecimal orderAmount = item.getoMoney() == null ? new BigDecimal(0) : item.getoMoney();
				BigDecimal refundAmount = item.getRefundAmount() == null ? new BigDecimal(0) : item.getRefundAmount();
				item.setoMoney(orderAmount.subtract(refundAmount));
				// 如果是退款的订单, 显示退款金额
				if(item.getOrderStatus() != null && item.getOrderStatus() == 4) {
					item.setoMoney(refundAmount);
				}
			});
        }

        return list;
    }

	@Override
	public List<OrderVO> getByOrder(int pageNum, int pageSize, String userId) {
		// 使用分页插件实现分页
		PageHelper.startPage(pageNum,pageSize);
		List<OrderVO> order = orderInfoDao.getByOrder(userId);
		order.forEach(item ->{
			List<ActivityLeaderRelation> activityLeaderRelations = orderInfoDao.selectByActivityId(item.getActivityId());
			item.setNickNames(activityLeaderRelations);
		});
		return order;
	}

	/**
	  * 根据userId
	  * 根据活动状态查询
	 * @param pageNum
	 * @param pageSize
	 * @param userId
	 * @return
	 */
    @Override
    public List<OrderVO> selectByUserIdAndActivityStatus(int pageNum, int pageSize, String userId) {
        PageHelper.startPage(pageNum,pageSize);

        List<OrderVO> list = orderInfoDao.selectByUserIdAndActivityStatus(userId);
		list.forEach(item ->{
			List<ActivityLeaderRelation> activityLeaderRelations = orderInfoDao.selectByActivityId(item.getActivityId());
			item.setNickNames(activityLeaderRelations);

			// 计算金额    金额 = 支付金额 - 退款金额
			BigDecimal orderAmount = item.getoMoney() == null ? new BigDecimal(0) : item.getoMoney();
			BigDecimal refundAmount = item.getRefundAmount() == null ? new BigDecimal(0) : item.getRefundAmount();
			item.setoMoney(orderAmount.subtract(refundAmount));
			// 如果是退款的订单, 显示退款金额
			if(item.getOrderStatus() != null && item.getOrderStatus() == 4) {
				item.setoMoney(refundAmount);
			}
			EvaluationEntity evaluationEntity = evaluationDao.selectEvaluationByActivityId(userId, item.getActivityId());
			if (evaluationEntity != null){
				item.setEvaluateState(1);
			} else {
				item.setEvaluateState(0);
			}
			/**
			 * 判定回程日期是否 >= 当前日期
			 */
			if(item.getOutsetTime() != null && item.getDurationTime() != null) {
				Calendar ca = Calendar.getInstance();
				ca.setTime(item.getOutsetTime());
				ca.add(Calendar.DATE, item.getDurationTime());
				if(ca.getTime().getTime() <= DateUtils.removeHms(new Date()).getTime()) {
					item.setIsCompleted(1);
				} else {
					item.setIsCompleted(0);
				}
			}
		});
        return list;
    }

	/**
	  * 取消订单  0，新订单  1  取消订单  2  订单审核
	 * @return
	 */
    @Override
    public boolean updateByOrderIdAndOrderStatus(OrderInfoEntity orderInfoEntity) {
		// boolean b = false;

		orderInfoEntity.setOrderStatus(1);

		// 取消订单
		// boolean a =
		orderInfoDao.updateByOrderIdAndOrderStatus(orderInfoEntity);
		// 取消订单成功
		// if (a == true){

		// 根据订单id查询出行人
		// List<PedestrianInfoEntity> list =
		// pedestrianInfoDao.findByOrderId(orderInfoEntity.getOrderId());

//			for (PedestrianInfoEntity p : list) {
//				p.setIsDelete(0);
//				b = pedestrianInfoDao.deleteByOrderId(p);
//			}
		// }
		/**
		 * 重置活动状态
		 */
		Assert.notEmpty(orderInfoEntity.getOrderId(), "参数错误, orderId为空");
		OrderInfoEntity order = orderInfoDao.selectByPrimaryKey(orderInfoEntity.getOrderId());
		Assert.notNull(order, "数据异常, 查询订单返回null");
		Assert.notEmpty(order.getActivityId(), "数据异常, 订单activityId为空");
		activityService.resetActivityStatus(order.getActivityId());

        return true;
    }

	/**
	  * 根据id查询订单
	 * @param orderId
	 * @return
	 */
	@Override
    public OrderVO selectByOrderId(String orderId){
		OrderVO orderVO = orderInfoDao.selectByOrderId(orderId);
		List<ActivityLeaderRelation> activityLeaderRelations = orderInfoDao.selectByActivityId(orderVO.getActivityId());
		orderVO.setNickNames(activityLeaderRelations);
        return orderVO;
    }

	/**
	  * 申请退团
	 */
	@Override
    public boolean applyRetreat(String orderId){

        boolean b = false;

        OrderVO orderVO = orderInfoDao.applyRetreat(orderId);

        // 如果没有大于现在时间的数据 说明是申请退团失败，提示
        if (orderVO == null){
            return false;
        }

		// 查询活动是否有出行人
		List<PedestrianInfoEntity> pedestrian = pedestrianInfoDao.findByOrderId(orderId);

		// 有大于现在时间的数据   说明是可以提交订单审核  0，新订单  1  取消订单  2  订单审核
        if (orderVO != null){
        	// 如果没有出行人，那么订单就为退款成功
			if (pedestrian.size() > 0){
				OrderInfoEntity orderInfoEntity = new OrderInfoEntity();
				BeanUtils.copyProperties(orderVO,orderInfoEntity);
				orderInfoEntity.setOrderStatus(2);
				b = orderInfoDao.updateByOrderIdAndOrderStatus(orderInfoEntity);
			}
        }

        return  b;
    }

	@Override
	public Map<String, Object> getOrderInfo(String orderId,  Integer type) {
		OrderInfoEntity order = orderInfoDao.selectByPrimaryKey(orderId);
		Assert.notNull(order, "数据异常, 获取订单信息返回空");

		Map<String, Object> map = new HashMap<>();

		//
		// 下单类型(1:普通活动,1:秒杀活动,2:拼单活动,3:砍价活动)
		if (order.getOrderType() != null && order.getOrderType() == 2){
			ActivitySingleRecordEntity singleRecord = activitySingleRecordDao.selectByOrderId(order.getOrderId());
			if(singleRecord != null) {
				Integer singleCount = activitySingleRecordDao.getSingleCountByGroupId(singleRecord.getGroupId());
				singleCount = singleCount == null ? 0: singleCount;
				ActivityRulesEntity activityRules = activityRulesDao.selectByActivityId(order.getActivityId());
				Assert.notNull(activityRules, "数据异常, 活动规则不存在");
				Assert.notNull(activityRules.getUnitNum(), "数据异常, 组队成行人数为空");
				if(singleCount >= activityRules.getUnitNum()) {
					// 
					order.setOrderType(1);
				}
				//查询获取组队队长UserId
				ActivitySingleRecordEntity initiatorRecord = activitySingleRecordDao.getActivityInitiatorByGroupId(singleRecord.getGroupId());
				if(initiatorRecord != null){
					map.put("initiatorUserId", initiatorRecord.getUserId());
				}
			}
		}

		/**
		 * 兼容前端提交参数处理
		 */
		// (0:新订单 1:取消订单 2:退款申请 3:退款失败 4:退款成功 5:已改期)
		if(ORDER_STATUS.contains(order.getOrderStatus())) {
			// type == 4, 已退出的订单
			type = 4;
		}
		// 查询活动
		ActivityInfoEntity activity = activityMapper.getActivityByActivityId(order.getActivityId());
		Assert.notNull(activity, "数据异常, 获取活动信息返回空");
		/**
		 * 保险名称
		 */
		if(StringUtils.isNotBlank(activity.getInsurancesId())) {
			InsuranceProductsEntity insuranceProduct = insuranceProductService.getInsuranceProductById(activity.getInsurancesId());
			if(insuranceProduct != null) {
				activity.setInsurancesName(insuranceProduct.getCompanyName() + "  " + insuranceProduct.getProdName());
			}
		}
		
		/**
		 * 订单金额 = 订单金额 - 退款金额
		 */
		BigDecimal orderAmount = order.getoMoney() == null ? new BigDecimal(0): order.getoMoney();
		BigDecimal refundAmount = order.getRefundAmount() == null ? new BigDecimal(0): order.getRefundAmount();
		
		order.setoMoney(orderAmount.subtract(refundAmount));

		map.put("order", order);
		map.put("activity", activity);
		// 查询订单出行人
		List<PedestrianInfoEntity> pedestrianList = null;
		List<ProductInfoVO> productList = null;
		// type == 4, 查退出的出行人
		if(type != null && type == 4) {
			pedestrianList = pedestrianInfoDao.queryExitPedestrianOfOrderByOrderId(orderId);
			productList = productInfoDao.findExitProductByOrderId(orderId);
		} else {
			// 第2个参数 == 1, 查询有效状态下的出行人
			pedestrianList = pedestrianInfoDao.queryPedestrianOfOrderByOrderId(orderId, 1);
			productList = productInfoDao.findProductByOrderId(orderId);
		}
		map.put("pedestrianList", pedestrianList);
		// 查询订单商品
		if(productList != null && !productList.isEmpty()) {
			for(ProductInfoVO item: productList) {
				item.setOrderAmount(item.getPrice());
			}
		}
		
		map.put("productList", productList);
		// 如果是砍价活动, 查询砍掉的金额
		if(activity.getTypeDicId() != null && activity.getTypeDicId() == 3 && StringUtils.isNotBlank(order.getGroupId())) {
			BigDecimal bargainAmount = activityBargainRecordDao.getActivityTotalBargainPrice(order.getGroupId(), order.getActivityId());
			map.put("bargainAmount", bargainAmount != null ? bargainAmount : new BigDecimal(0));
		}
		// 活动封面图
		List<ActivityCoverEntity> coverList = activityCoverDao.queryByCoverList(activity.getActivityId());
		map.put("coverList", coverList);
		// 查询订单使用的优惠券
		if(StringUtils.isNotBlank(order.getVouchersId())) {
			map.put("vouchers", vouchersReceiveDao.queryVoucherById(order.getVouchersId()));
		}
		
		return map;
	}
	
	/**
	  * 创建拼单
	 * @param user
	 * @param order
	 */
	private void createSingleRecord(UserInfoEntity user, OrderInfoEntity order) {
		createSingleRecord(user, order, null);
	}
	
	private void createSingleRecord(UserInfoEntity user, OrderInfoEntity order, String groupId) {
		/**
    	 * 1. 获取活动规则
    	 */
    	ActivityRulesEntity activityRules = activityRulesDao.selectByActivityId(order.getActivityId());
    	Assert.notNull(activityRules, "数据异常,  获取活动规则失败, 结果为空");
    	Assert.notNull(activityRules.getUnitNum(), "数据异常, 组队所需人数为空");
    	Assert.notEmpty(activityRules.getUnitTime(), "数据异常, 组队时间为空");
    	
    	ActivitySingleRecordEntity singleRecord = new ActivitySingleRecordEntity();
    	/**
    	 * 拼单ID
    	 */
    	String newGroupId = IdMaker.getStringKey();
    	// 是否拼单发起人
    	singleRecord.setIsInitiator(1);
    	// 拼单人数
    	singleRecord.setSingleNumber(1);
    	/**
    	 * groupId不为空时, 是加入别人发起的拼单
    	 */
    	if(StringUtils.isNotBlank(groupId)) {
    		newGroupId = groupId;
    		ActivitySingleRecordEntity initiatorSingleRecord = activitySingleRecordDao.getActivityInitiatorByGroupId(groupId);
    		Assert.notNull(initiatorSingleRecord, "数据异常, 发起组队记录不存在");
    		Assert.isTrue(!user.getUserId().equals(initiatorSingleRecord.getUserId()), "不能加入自己发起的组队");
    		// 只能通过队长分享的链接组队
    		Assert.isTrue(initiatorSingleRecord.getUserId().equals(order.getSingleShareUserId()), "只能通过队长分享的链接组队");
    		// 检查组队发起人的订单状态
    		Assert.notEmpty(initiatorSingleRecord.getOrderId(), "数据异常, 队长订单ID为空");
    		OrderInfoEntity singleOrder = orderInfoDao.selectByPrimaryKey(initiatorSingleRecord.getOrderId());
    		Assert.notNull(singleOrder, "数据异常, 队长订单不存在");
    		String errorMsg = "链接失效, 队长已退款";
    		Assert.isTrue(singleOrder.getPayStatus() != null && singleOrder.getPayStatus() == 1, errorMsg);
    		// 拼单只有一个出行人, 验证出行人状态
    		List<PedestrianInfoEntity> pedestrianList = pedestrianInfoDao.queryPedestrianOfOrderByOrderId(singleOrder.getOrderId(), 1);
    		Assert.isTrue(pedestrianList != null && !pedestrianList.isEmpty(), errorMsg);
    		for(PedestrianInfoEntity item: pedestrianList) {
    			Assert.isTrue(item.getPedestrianStatus() != null && item.getPedestrianStatus() == 1, errorMsg);
    		}
    		
    		//
    		Integer count = activitySingleRecordDao.getSingleCountByGroupId(groupId);
    		count = count == null ? 0 : count;
    		
    		if(activityRules.getMaxUnitNum() != null) {
    			Assert.isTrue(activityRules.getMaxUnitNum() >= count + 1, "组队人数超出活动限制");
    		} else {
    			Assert.isTrue(activityRules.getUnitNum() >= count + 1, "组队人数超出活动限制");
    		}
    		
    		if(activityRules.getUnitNum() == count + 1) {
    			// 拼单成功
    			// 1:拼单中,2:拼单成功,3:拼单失败
    			orderInfoDao.updateSingleStatus(initiatorSingleRecord.getOrderId(), 2);
    		} 
    		// 不是拼单发起人
    		singleRecord.setIsInitiator(0);
    		// 拼单数量+1
    		initiatorSingleRecord.setSingleNumber(initiatorSingleRecord.getSingleNumber() + 1);
    		// 更新拼单数量
    		activitySingleRecordDao.updateSingleNumber(initiatorSingleRecord.getSingleId(), initiatorSingleRecord.getSingleNumber());
    	} else {
    		// 拼单成功
			// 1:拼单中,2:拼单成功,3:拼单失败
			orderInfoDao.updateSingleStatus(order.getOrderId(), 1);
    	}

    	singleRecord.setOrderId(order.getOrderId());
    	singleRecord.setActivityId(order.getActivityId());
    	singleRecord.setUserId(user.getUserId());
    	// 主键
    	singleRecord.setSingleId(IdMaker.getStringKey());
    	// 生成组ID
    	singleRecord.setGroupId(newGroupId);
    	// 原价
    	singleRecord.setOriginalPrice(activityRules.getOriginalCost());
    	// 拼单价
    	singleRecord.setSinglePrice(activityRules.getUnitPrice());
    	singleRecord.setActivityRulesId(activityRules.getActivityRulesId());
    	singleRecord.setCreateTime(new Date());
    	singleRecord.setCreateBy(user.getUserId());
    	// 是否返还原价-拼单价的金额(1:已返,0:未返)
    	singleRecord.setIsRebate(0);
    	singleRecord.setCompanyId(order.getCompanyId());
    	
    	activitySingleRecordDao.insert(singleRecord);
	}

	/**
	 * 	请求参数
	 * {
		  "pedestrianId": "776bab5c4dc04b629915aa91b91f2a2d,98b976cada3243479eddea3da43ed7a0",
		  "productList":[{"productByOrderId":"88185cd31f08457c967aab8f125f1177","productNum":3},
		  	{"productByOrderId":"b27e90efe95743b6abcf661e6f059bae","productNum":2}
		  ]
		}
	 * 申请退款
	 * @author Tan Ling
	 * @date 2019年2月18日 上午9:39:58
	 * @param orderRefund
	 * @param authUser
	 */
	@Override
	public BigDecimal applyRefund(OrderRefund orderRefund, UserInfoEntity authUser, boolean isRefund) {
		String[] ids = orderRefund.getPedestrianId().split(",");
		List<PedestrianInfoEntity> list = pedestrianInfoDao.selectInPedestrianId(ids);
		Assert.isTrue(list != null && !list.isEmpty(), "参数错误, 出行人不存在");
		
		BigDecimal refundAmount = new BigDecimal("0");
		/**
		 * 1. 参数验证
		 * 		验证出行人状态
		 * 		验证是否属同一个订单
		 * 		验证订单是否属当前用户
		 */
		String orderId = list.get(0).getOrderId();
		Assert.notEmpty(orderId, "数据异常, 订单ID不存在");
		OrderInfoEntity order = orderInfoDao.selectByPrimaryKey(orderId);
		Assert.notNull(order, "数据异常, 订单不存在");
		
		Integer count = pedestrianInfoDao.getCountByOrderId(orderId);
		if(count != null && count > 0) {
			if(count == list.size()) {
				List<ProductByOrderVO> productList = productByOrderDao.queryByOrderId(orderId, 1);
				if(productList != null && !productList.isEmpty()) {
					Assert.isTrue(orderRefund.getProductList() != null && !orderRefund.getProductList().isEmpty(), "出行人全部退款必须所有增值商品同时退款");
				}
			}
		}
		
		// 验证活动状态
		ActivityInfoEntity activity = activityMapper.getActivityByActivityId(order.getActivityId());
		Assert.notNull(activity, "数据异常, 订单不存在");
		// 活动状态，1已报满  2已成行  3报名中   4已截止  5  即将成行 6 已下架
		Assert.isTrue(activity.getActivityStatus() != null && activity.getActivityStatus() != 4, "活动已截止不能申请退款");
		
		// 验证是否属当前用户
		Assert.isTrue(authUser.getUserId().equals(order.getUserId()), "操作失败, 订单不属于当前用户");
		// 验证订单状态(0:新订单  1:取消订单 2:退款申请 3:退款失败 4:退款成功 5:已改期)
		Assert.isTrue(order.getOrderStatus() != null && order.getOrderStatus() != 5, "操作失败, 订单已改期");
		Assert.isTrue(order.getOrderStatus() != null && order.getOrderStatus() != 4, "操作失败, 订单已退款");
		Assert.isTrue(order.getOrderStatus() != null && order.getOrderStatus() != 1, "操作失败, 订单已取消");
		// 支付状态[0，未付款, 1，已付款  -1,退款]
		Assert.isTrue(order.getPayStatus() != null && order.getPayStatus() != 0, "操作失败, 订单未支付");
		Assert.isTrue(order.getPayStatus() != null && order.getPayStatus() != -1, "操作失败, 订单已退款");
		
		for(PedestrianInfoEntity item: list) {
			// 验证出行人是否属同一个订单
			Assert.isTrue(order.getOrderId().equals(item.getOrderId()), "操作失败, 出行人订单ID不一致");
			// 验证出行人状态(1:正常,2:已改期,3:已退款,4:申请退款)
			Assert.isTrue(item.getPedestrianStatus() != null && item.getPedestrianStatus() != 4, "出行人 " + item.getContactPeople() + " 已经申请退款");
			Assert.isTrue(item.getPedestrianStatus() != null && item.getPedestrianStatus() != 3, "出行人 " + item.getContactPeople() + " 已经退款");
			Assert.isTrue(item.getPedestrianStatus() != null && item.getPedestrianStatus() != 2, "出行人 " + item.getContactPeople() + " 已经改期");
			refundAmount = refundAmount.add(this.sub(item.getOrderAmount(), item.getRefundAmount()));
		}
		if(isRefund) {
			// 修改出行人状态((1:正常,2:已改期,3:已退款,4:申请退款)
			pedestrianInfoDao.updateStatusInPedestrianIds(ids, 4);
			// 修改订单更新时间
			orderInfoDao.setUpdateTime(order.getOrderId());
		}
		/**
		 * 2. 商品验证
		 */
		if(orderRefund.getProductList() != null && !orderRefund.getProductList().isEmpty()) {
			List<String> idList = new ArrayList<>();
			orderRefund.getProductList().forEach(item -> {
				Assert.notEmpty(item.getProductByOrderId(), "退款商品ID不能为空");
				Assert.isTrue(item.getProductNum() != null && item.getProductNum() > 0, "退款商品数量必须大于0");
				idList.add(item.getProductByOrderId());
			});
			String[] idArray = idList.toArray(new String[idList.size()]);
			List<ProductByOrder> productList = productByOrderDao.selectInProductByOrderId(idArray);
			Assert.isTrue(productList != null && !productList.isEmpty(), "操作失败, 未找到订单关联商品");
			// 验证商品是否属当前订单
			for(ProductByOrder item: productList) {
				Assert.isTrue(order.getOrderId().equals(item.getOrderId()), "操作失败, 商品订单ID不一致");
				Assert.isTrue(item.getProductNum() != null && item.getProductNum() > 0, "申请退款商品数量不能为空");
				item.setApplyRefundNum(this.getApplyProductNum(orderRefund, item.getProductByOrderId(), item.getProductNum()));
				refundAmount = refundAmount.add(this.mul(item.getApplyRefundNum(), item.getPrice()));
				if(isRefund) {
					// 1:正常,2:已改期,3:已退款,4:申请退款
					productByOrderDao.updateStatusAndApplyRefundNum(item.getProductByOrderId(), this.getApplyRefundNum(orderRefund.getProductList(), item.getProductByOrderId()), 4);
				}
			}
		}
		/**
		 * 如果当前订单是组队发起人, 将发起人身份给其他人
		 * 
		 * 下单类型(1:普通活动,1:秒杀活动,2:拼单活动,3:砍价活动)
		 */
		if(isRefund && order.getOrderType() != null && order.getOrderType() == 2) {
			updateInitiatorStatus(order.getOrderId());
		}
		
		/**
		 * 刷新活动状态
		 */
		if(isRefund) {
			activityService.resetActivityStatus(activity.getActivityId());
		}
		
		/********************************金额计算***************************
		 *****************************************************************
		 */
		if(!isRefund) {
			/**
			 * a. 如果使用了满减优惠券, 需要判断退款后是否还能达到满减
			 */
			if(StringUtils.isNotBlank(order.getVouchersId())) {
				VouchersReceiveEntity vouchers = vouchersReceiveDao.selectByPrimaryKey(order.getVouchersId());
	    		Assert.notNull(vouchers, "数据异常, 关联代金券不存在");
	    		// 1:满减, 2:抵扣
	    		if(vouchers.getVrType() != null && vouchers.getVrType() == 1) {
	    			/**
	    			 * 订单中3个出行人, 每人150, 支付合计450
	    			 * 使用一张满400减100的优惠券, 抵扣后支付350元
	    			 * 一个出行人申请退款, 扣除150后, 剩余金额不够满减金额. 所以需要扣除优惠券的金额 100
	    			 * 所以, 一个出行人退款的金额为 150-100=50
	    			 */
	    			Assert.notNull(vouchers.getVbiFull(), "数据异常, 优惠券满减金额为空");
	    			Assert.notNull(vouchers.getAmount(), "数据异常, 优惠券优惠金额为空");
	    			if(order.getoMoney().subtract(refundAmount).compareTo(vouchers.getVbiFull()) == -1) {
	    				refundAmount = refundAmount.subtract(vouchers.getAmount());
	    			}
	    		}
			}
			/**
			 * b. 当前请求是获取退款金额，不是申请退款，金额根据活动退款规则重新计算
			 */
			List<RefundRulesVO> refundRules = this.getRefundRule(activity);
			if(refundRules != null && !refundRules.isEmpty()) {
				// 匹配当前日期的退款规则, isCurrentRule = true
				for(RefundRulesVO item: refundRules) {
					if(item.getIsCurrentRule()) {
						if(item.getRefundPercent() != null && item.getRefundPercent() == 0) {
							refundAmount = new BigDecimal("0");
						} else {
							// 比例使用百分比, 需要先除以100
							BigDecimal percent = new BigDecimal(item.getRefundPercent()).divide(new BigDecimal(100));
							refundAmount = refundAmount.multiply(percent);
						}
					}
				}
			}
		}
		
		return refundAmount;
	}
	
	/**
	 * 申请退款的商品金额
	 * 单价 * 数量
	 * @author Tan Ling
	 * @date 2019年5月23日 下午6:03:09
	 * @param applyRefundNum
	 * @param price
	 * @return
	 */
	private BigDecimal mul(Integer applyRefundNum, BigDecimal price) {
		if(applyRefundNum == null || applyRefundNum == 0) {
			return new BigDecimal("0");
		}
		if(price == null) {
			return new BigDecimal("0");
		}
		
		return price.multiply(new BigDecimal(applyRefundNum));
	}

	/**
	 * 订单金额-退款金额
	 * @author Tan Ling
	 * @date 2019年5月23日 下午4:54:56
	 * @param orderAmount
	 * @param refundAmount
	 * @return
	 */
	private BigDecimal sub(BigDecimal orderAmount, BigDecimal refundAmount) {
		Assert.notNull(orderAmount, "数据异常, 出行人下单金额为空");
		refundAmount = refundAmount == null ? new BigDecimal("0") : refundAmount;
		return orderAmount.subtract(refundAmount);
	}
	
	/**
	 * 如果当前订单是组队发起人, 将发起人身份给其他人
	 * @author Tan Ling
	 * @date 2019年5月23日 下午4:55:14
	 * @param orderId
	 */
	private void updateInitiatorStatus(String orderId) {
		ActivitySingleRecordEntity singleRecord = activitySingleRecordDao.selectByOrderId(orderId);
		if(singleRecord != null && singleRecord.getIsInitiator() != null && singleRecord.getIsInitiator() == 1) {
			List<ActivitySingleRecordEntity> singleList = activitySingleRecordDao.querySingleListByGroupId(singleRecord.getGroupId());
			if(singleList != null && !singleList.isEmpty()) {
				for(ActivitySingleRecordEntity item: singleList) {
					// 如果是自己, 将发起人身份设为否
					if(orderId.equals(item.getOrderId())) {
						activitySingleRecordDao.updateInitiatorStatus(item.getSingleId(), 0);
						break;
					} 
				}
				for(ActivitySingleRecordEntity item: singleList) {
					// 如果不是自己, 将发起人身份设为是
					if(!orderId.equals(item.getOrderId())) {
						activitySingleRecordDao.updateInitiatorStatus(item.getSingleId(), 1);
						break;
					} 
				}
			}
		}
	}
	
	private Integer getApplyRefundNum(List<ProductByOrder> productList, String productByOrderId) {
		if(productList == null || productList.isEmpty()) {
			throw new CustomException("数据异常, 退款商品未找到");
		}
		for(ProductByOrder item: productList) {
			if(productByOrderId.equals(item.getProductByOrderId())) {
				return item.getProductNum();
			}
		};
		throw new CustomException("数据异常, 退款商品未找到");
	}

	/**
	 * status == 1, 查询正常状态下的订单(非改期, 非退款)
	 * status == 4, 查询申请退款的订单数据
	 * @author Tan Ling
	 * @date 2019年2月19日 上午9:27:26
	 * @param orderId
	 * @param status
	 * @return
	 */
	@Override
	public OrderDetailVO queryOrderDetail(String orderId, Integer status) {
		// List<RefundRulesVO> list = new ArrayList<>();
		OrderInfoEntity order = orderInfoDao.selectByPrimaryKey(orderId);
		Assert.notNull(order, "订单不存在");
		ActivityInfoEntity activity = activityMapper.getActivityByActivityId(order.getActivityId());
		Assert.notNull(activity, "活动不存在");
		
		if(status != null && status == 1) {
			// (0:新订单  1:取消订单 2:退款申请 3:退款失败 4:退款成功 5:已改期)
			Assert.isTrue(order.getOrderStatus() != null && order.getOrderStatus() != 5, "订单已改期");
			Assert.isTrue(order.getOrderStatus() != null && order.getOrderStatus() != 4, "订单已退款");
			Assert.isTrue(order.getOrderStatus() != null && order.getOrderStatus() != 1, "订单已取消");
		}
		// 查询商品
		List<ProductByOrderVO> productList = productByOrderDao.queryByOrderId(orderId, status);
		// 查询出行人
		List<PedestrianInfoEntity> pedestrianList = pedestrianInfoDao.queryPedestrianOfOrderByOrderId(orderId, status);
		
		if(status != null && status == 4) {
			order.setoMoney(this.getApplyRefundAmount(pedestrianList, productList));
		}
		
		OrderDetailVO orderDetail = new OrderDetailVO();
		orderDetail.setOrder(order);
		orderDetail.setActivity(activity);
		orderDetail.setProductList(productList);
		orderDetail.setPedestrianList(pedestrianList);

		orderDetail.setRefundRules(this.getRefundRule(activity));
		// 优惠券
		if(StringUtils.isNotBlank(order.getVouchersId())) {
			VouchersReceiveEntity voucher = vouchersReceiveDao.selectByPrimaryKey(order.getVouchersId());
			orderDetail.setVoucherText(this.getVoucherText(voucher));
		}
		
		return orderDetail;
	}
	
	/**
     * 根据优惠券信息拼接显示文本
     * @author Tan Ling
     * @date 2019年5月22日 上午10:57:12
     * @param voucherBase
     * @return
     */
    private String getVoucherText(VouchersReceiveEntity voucher) {
    	if(voucher == null) {
    		return "";
    	}
    	if(voucher.getVrType() != null && voucher.getVrType() == 1) {
			return "满" + voucher.getVbiFull() + "减" + voucher.getAmount() + "元";
		} else {
			return "抵扣" + voucher.getAmount() + "元";
		}
    }
    
	/**
	 * 重构活动退款规则(将距离活动出行xx小时转换为日期)
	 * @author Tan Ling
	 * @date 2019年5月24日 上午10:20:36
	 * @param activity
	 * @return
	 */
	private List<RefundRulesVO> getRefundRule(ActivityInfoEntity activity){
		List<RefundRulesVO> list = refundRulesDao.selectByActivityId(activity.getActivityId());
		if(list == null || list.isEmpty()) {
			return list;
		}
		Date date = new Date();
		RefundRulesVO currentRule = null;
		for (RefundRulesVO item : list) {
			Assert.notNull(item.getDistanceCancelTime(), "数据异常, 距离取消时间为空");
			Assert.notNull(item.getRefundPercent(), "数据异常, 退款比例为空");
			Calendar rightNow = Calendar.getInstance();
			// 活动出行时间 - 减去距离取消时间
			rightNow.setTime(activity.getOutsetTime());
			BigDecimal minute = new BigDecimal(60);
			BigDecimal multiply = item.getDistanceCancelTime().multiply(minute);
			int i1 = multiply.intValue();
			rightNow.add(Calendar.MINUTE, i1 - (i1 + i1));
			item.setRefundRulesTime(DateUtils.format(rightNow.getTime(), "yyyy年MM月dd日 HH时mm分"));
			if(date.getTime() > rightNow.getTime().getTime()) {
				currentRule = item;
			}
		}
		if(currentRule != null) {
			currentRule.setIsCurrentRule(true);
		}
		
		return list;
	}
	
	/**
	 * 计算申请退款金额
	 * @author Tan Ling
	 * @date 2019年2月21日 上午9:01:21
	 * @param pedestrianList
	 * @param productList
	 * @return
	 */
	private BigDecimal getApplyRefundAmount(List<PedestrianInfoEntity> pedestrianList, List<ProductByOrderVO> productList) {
		BigDecimal amount = new BigDecimal(0);
		if(pedestrianList != null && !pedestrianList.isEmpty()) {
			for(PedestrianInfoEntity item: pedestrianList) {
				if(item.getOrderAmount() != null) {
					amount = amount.add(item.getOrderAmount());
				}
			}
		}
		if(productList != null && !productList.isEmpty()) {
			for(ProductByOrderVO item: productList) {
				if(item.getApplyRefundNum() != null && item.getPrice() != null) {
					amount = amount.add(item.getPrice().multiply(new BigDecimal(item.getApplyRefundNum())));
				}
			}
		}
		return amount;
	}
	
	/**
	 * 查询订单金额    status == 1时，查询正常状态数据(非改期非退款等)
	 * @author Tan Ling
	 * @date 2019年2月19日 上午9:58:06
	 * @param orderId
	 * @param status
	 * @return
	 */
	@Override
	public Map<String, ?> queryOrderAmount(String orderId, Integer status){
		OrderInfoEntity order = orderInfoDao.selectByPrimaryKey(orderId);
		Assert.notNull(order, "订单不存在");
		if(status != null && status == 1) {
			// (0:新订单  1:取消订单 2:退款申请 3:退款失败 4:退款成功 5:已改期)
			Assert.isTrue(order.getOrderStatus() != null && order.getOrderStatus() != 5, "订单已改期");
			Assert.isTrue(order.getOrderStatus() != null && order.getOrderStatus() != 4, "订单已退款");
			Assert.isTrue(order.getOrderStatus() != null && order.getOrderStatus() != 1, "订单已取消");
		}
		// 查询商品
		List<ProductByOrderVO> productList = productByOrderDao.queryByOrderId(orderId, status);
		// 查询出行人
		List<PedestrianInfoEntity> pedestrianList = pedestrianInfoDao.queryPedestrianOfOrderByOrderId(orderId, status);
		
		BigDecimal amount = new BigDecimal(0);
		if(productList != null && !productList.isEmpty()) {
			for(ProductByOrderVO item: productList) {
				Assert.notNull(item.getOrderAmount(), "数据异常, 订单商品金额为空");
				amount = amount.add(item.getOrderAmount());
			}
		}
		if(pedestrianList != null && !pedestrianList.isEmpty()) {
			for(PedestrianInfoEntity item: pedestrianList) {
				Assert.notNull(item.getOrderAmount(), "数据异常, 订单出行人金额为空");
				amount = amount.add(item.getOrderAmount());
			}
		}
		
		Map<String, Object> map = new HashMap<>();
		map.put("amount", amount);
		
		return map;
	}
	
	/**
	 * 验证申请退款的商品数量是否超出限制
	 * @author Tan Ling
	 * @date 2019年2月18日 上午11:13:54
	 * @param orderRefund
	 * @param dbProductByOrderId
	 * @param dbProductNum
	 */
	private int getApplyProductNum(OrderRefund orderRefund, String dbProductByOrderId, int dbProductNum) {
		for(ProductByOrder item: orderRefund.getProductList()) {
			if(dbProductByOrderId.equals(item.getProductByOrderId())) {
				Assert.isTrue(dbProductNum >= item.getProductNum(), "申请退款商品数量不能大于购买数量");
				return item.getProductNum();
			}
		}
		return 0;
	}
	
	private String createOrderNumber() {
		Random random = new Random();
		SimpleDateFormat allTime = new SimpleDateFormat("yyyyMMddHHmmSS");
		String subjectno = allTime.format(new Date()) + random.nextInt(100000);
		return subjectno + random.nextInt(10);
	}

	@Override
	public List<ToShareVO> selectShareList(String userId) {
		List<ToShareVO> result = new ArrayList<>();
		/**
		 * 查询拼单分享列表
		 */
		List<ToShareVO> singleRecordList = activitySingleRecordDao.selectShareList(userId, null);
		if(singleRecordList != null && !singleRecordList.isEmpty()) {
			for(ToShareVO item: singleRecordList) {
				// 类型(2:拼单,3砍价)
				item.setType(2);
				// 查询当前拼单人数
				item.setCurrentUnitNum(activitySingleRecordDao.getSingleCountByGroupId(item.getGroupId()));
				// 
				OrderInfoEntity order = orderInfoDao.selectByPrimaryKey(item.getOrderId());
				Assert.notNull(order, "数据异常, 订单未找到");
				item.setNickNames(orderInfoDao.selectByActivityId(item.getActivityId()));
				item.setAmount(order.getoMoney());
			}
			result.addAll(singleRecordList);
		}
		/**
		 * 查询砍价分享列表
		 */
		List<ToShareVO> bargainRecordList = activityBargainRecordDao.selectShareList(userId);
		if(bargainRecordList != null && !bargainRecordList.isEmpty()) {
			for(ToShareVO item: bargainRecordList) {
				// 类型(2:拼单,3砍价)
				item.setType(3);
				// 查询已砍金额
				item.setBargainAmount(activityBargainRecordDao.getActivityTotalBargainPrice(item.getGroupId(), item.getActivityId()));
				item.setNickNames(orderInfoDao.selectByActivityId(item.getActivityId()));
				//
				BigDecimal amount = item.getAmount() == null ? new BigDecimal(0) : item.getAmount();
				BigDecimal bargainAmount = item.getBargainAmount() == null ? new BigDecimal(0) : item.getBargainAmount();
				item.setAmount(amount.subtract(bargainAmount));
			}
			result.addAll(bargainRecordList);
		}
		/**
		 * 排序, 出行日期升序
		 */
		Collections.sort(result, new Comparator<ToShareVO>() {  
            @Override  
            public int compare(ToShareVO o1, ToShareVO o2) {  
                if (o1.getOutsetTime().getTime() > o2.getOutsetTime().getTime()) {  
                    return 1;  
                } 
                if (o1.getOutsetTime().getTime() == o2.getOutsetTime().getTime()) {  
                    return 0;  
                }  
                return -1;  
            }  
        });
		
		return result;
	}

	@Override
	public ToShareVO selectShare(String orderId, String userId) {
		OrderInfoEntity order = orderInfoDao.selectByPrimaryKey(orderId);
		Assert.notNull(order, "数据异常, 订单不存在");
		/**
		 * 下单类型(1:普通活动,1:秒杀活动,2:拼单活动,3:砍价活动)
		 */
		if(order.getOrderType() != null && order.getOrderType() == 0) {
			
			return null;
		}
		else if(order.getOrderType() != null && order.getOrderType() == 2) {
			List<ToShareVO> singleRecordList = activitySingleRecordDao.selectShareList(userId, orderId);
			if(singleRecordList != null && !singleRecordList.isEmpty()) {
				ToShareVO item = singleRecordList.get(0);
				// 类型(2:拼单,3砍价)
				item.setType(2);
				// 查询当前拼单人数
				item.setCurrentUnitNum(activitySingleRecordDao.getSingleCountByGroupId(item.getGroupId()));
				item.setNickNames(orderInfoDao.selectByActivityId(item.getActivityId()));
				
				return item;
			}
		} 
		
		return null;
	}

	@Override
	public void cancel(String orderId, String userId) {
		OrderInfoEntity order = orderInfoDao.selectByPrimaryKey(orderId);
		Assert.notNull(order, "订单不存在");
		Assert.isTrue(userId.equals(order.getUserId()), "操作失败,订单不属于当前用户");
		order.setOrderStatus(1);
		orderInfoDao.updateByOrderIdAndOrderStatus(order);
		/**
		 * 刷新活动状态
		 */
		activityService.resetActivityStatus(order.getActivityId());
	}

	@Override
	public Integer querySurplus(String orderId) {
		OrderInfoEntity order = orderInfoDao.selectByPrimaryKey(orderId);
		Assert.notNull(order, "订单不存在");
		ActivityInfoEntity activity = activityMapper.getActivityByActivityId(order.getActivityId());
		Assert.notNull(activity, "活动不存在");
		Assert.notNull(activity.getMostPeopleSum(), "活动最大成行人数不存在");
		Integer joinPeopleNum = activityMapper.queryPeopleNum(activity.getActivityId());
    	joinPeopleNum = joinPeopleNum == null ? 0 : joinPeopleNum;
		int pedestrianNum = pedestrianInfoDao.getTotalCountByOrderId(orderId);
		// 判定活动已报名人数 + 当前订单出行人数 是否大于 活动最大报名人数
		Assert.isTrue((joinPeopleNum + pedestrianNum) <= activity.getMostPeopleSum(), "支付失败, 活动已报满");
    	
		return activity.getMostPeopleSum() - (joinPeopleNum + pedestrianNum);
	}

	@Override
	public OrderArgs getNonpaymentOrderByActivityId(String activityId, String userId) {
		OrderInfoEntity order = orderInfoDao.getNonpaymentOrderByActivityId(activityId, userId);
		if(order != null) {
			return orderArgsMapper.getByOrderId(order.getOrderId());
		}
		
		return null;
	}



}
