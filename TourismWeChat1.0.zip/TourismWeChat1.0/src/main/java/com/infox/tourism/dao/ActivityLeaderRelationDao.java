package com.infox.tourism.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.infox.tourism.entity.LeaderInfoEntity;

/**
 * @Author: cenjinxing
 * @Date: Created in 2019/2/22 15:23
 **/
public interface ActivityLeaderRelationDao {

    /**
     * 根据活动id查询领队跟活动的关系表
     * @param activityId
     * @return
     */
    List<LeaderInfoEntity> selectByActivityLeaderRelationByActivityId(@Param("activityId") String activityId);
}
