package com.infox.tourism.service;

import com.infox.tourism.entity.SbLocationEntity;
import com.infox.tourism.entity.vo.locationVO.SBLocationVO;

import java.util.List;

/**
 * 全球地区表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-06 17:14:57
 */
public interface LocationService {

    /**
     * 根据区域代码查询
     * @param adcode 区域代码
     * @return
     */
    SbLocationEntity selectByValueForWeChat(String adcode);


    /**
     * 查询覆盖活动的城市
     * @param locationId 默认选择的城市，设置isSelect=1
     * @return
     */
    List<SBLocationVO> selectCoverCity(String locationId);
}

