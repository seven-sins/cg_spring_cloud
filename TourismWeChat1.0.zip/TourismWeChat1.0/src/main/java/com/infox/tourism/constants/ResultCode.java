package com.infox.tourism.constants;

/**
 * 状态码
 * Created by cenjinxing on 2018/10/22.
 */
public enum ResultCode {

    // ------------------------固定状态码------------------------------------
    SUCCESS(0, "成功") ,
    SUCCESS_CODE(200, "服务器正常"),UN_KNOW_EXCEPTION(500, "未知异常") ,
    CLIENT_ERROR(400, "数据格式错误") , PARAM_ERROR(401, "参数错误") ,
    NO_PERMISSIONS(403, "无权限进行此操作!") , OP_ERROR(501, "操作失败，请重试") ,
    JSON_ERROR(502, "Json操作错误,请检查数据格式") , JDBC_ERROR(503, "数据库操作错误") ,
    DATA_ASSOCIATION(504, "操作失败,数据存在关联关系") ,DATA_NOT_EXIST(505, "记录不存在") ,
    ILLEGAL_OPERATING(506, "操作失败,用户非法操作") ,WECHAT_ERROR(507, "操作失败，对接微信配置发生错误") ,
    UNKNOWN_ERROR(508, "未知错误") ,SIGN_ERROR(509, "校验签名失败，请检查参数是否正常.") ,
    LIST_NULL_ERROR(510, "操作失败，列表数据为空."),NEWWORK_ERROR(511,"网络错误.") ,REPEAT_ERROR(512,"操作失败，重复操作.") ,
    DELETE_PUBLISH_ERROR(512,"操作失败，不能删除已发布的数据") ,
    WECHAT_OPENID_ERROR(513,"操作失败,用户尚未通过微信授权.") ,
    WECHAT_MINI_PROGRAM_TOKEN_ERROR(514,"操作失败,小程序token无效") ,
    WECHAT_MINI_PROGRAM_SESSION_ERROR(515,"操作失败,小程序登录状态过期") ,
    IMG_PARREM_ERROR(516,"操作失败,图片格式出错") ,
    //-----------------------用户相关，状态码1000~1200 -----------------------------------

    ACCOUNT_CREATE_FAIL(1000, "用户创建失败") , ACCOUNT_LONG_ERROR(1001, "用户名或密码错误") ,
    ACCOUNT_PWD_ERROR(1002, "密码与确认密码不一致") ,ACCOUNT_NAME_EMPTY(1003, "用户名不能为空") ,
    ACCOUNT_TYPE_ERROR(1004, "用户类型错误") ,ACCOUNT_UPDATE_FAIL(1005, "用户修改失败") ,
    ACCOUNT_TRY_TOO_MORE(1006, "登录尝试次数过多，请10分钟后重试") ,ACCOUNT_LOCKED(1007, "账号被锁定") ,
    ACCOUNT_NOT_OPEN(1008, "未开放登录的用户") ,CAPTCHA_ERROR(1009, "验证码错误."),
    MOBILECODE_NUM_ERROR(1010, "获取手机验证码失败,超过获取次数上限."),
    MOBILECODE_ERROR(1011, "手机验证码错误，请输入正确的手机验证码."),
    MOBILECODE_GET_ERROR(1012, "获取验证码失败"),
    MOBILECODE_TIME_ERROR(1013,"获取验证码失败,距离上一次获取不足5分钟.") ,
    USER_NOTLOGIN_ERROR(1014, "用户尚未登录"),USER_CONTACT_ADMIN(1015,"请联系管理员"),

    //-----------------------邮箱相关，状态码2000~2200 -----------------------------------
    EMAIL_ERROR(2000,"您填写的邮箱与后台绑定的邮箱不一致，请重新输入"),

    //-----------------------城市维护相关，状态码3000~3200 -----------------------------------
    COUNTRIES_ERROR(3000,"请您选择国家在操作下一步，谢谢"),PROVINCES_ERROR(3001,"请您选择省份在操作下一步，谢谢"),
    COUNTRIES_PROVINCES_ERROR(3002,"请您确定国家下没有省份才可以删除，谢谢"),COUNTRIES_CITY_ERROR(3003,"请您确定国家下没有城市才可以删除，谢谢"),
    DESTINATION_ERROR(3004,"目的地已存在"),

    //---------------------------角色相关，状态码3500~3800------------------------------------------
    ROLE_ERROR(3500,"角色已存在"),

    //----------------------API接口异常，状态码4000~4500 -invalid----------------------------------
    INVALID_TOKEN(4014, "无效Access Token!"),
    // 用于报名小程序token失效
    INVALID_COOKIE(10001, "token无效"),
    INVALID_CODE(4015, "无效User Code!"),

    //----------------------公众号首页，状态码10000~11000 -----------------------------------
    WECHAT_INDEX_GPS_ERROR(10000,"暂时无法定位您所在的城市。"),
    WECHAT_INDEX_GPS_UNSUPPORT(10001,"您所在的城市暂未开通此功能");
    private Integer code;
    private String msg;


    ResultCode(Integer code, String msg){
        this.code = code;
        this.msg = msg;
    }


    public int getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }

    public static String  getMessage(int code){
        for (ResultCode temp : ResultCode.values()) {
            if ( temp.code == code) {
                return temp.getMsg();
            }
        }
        return null;
    }


}
