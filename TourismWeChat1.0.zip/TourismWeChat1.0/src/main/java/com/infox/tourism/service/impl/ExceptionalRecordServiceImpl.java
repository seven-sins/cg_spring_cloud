package com.infox.tourism.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.infox.tourism.dao.ActivityLeaderRelationDao;
import com.infox.tourism.dao.ExceptionalRecordDao;
import com.infox.tourism.entity.ExceptionalRecordEntity;
import com.infox.tourism.entity.LeaderInfoEntity;
import com.infox.tourism.entity.vo.UserVO.ExceptionalVO;
import com.infox.tourism.service.ExceptionalRecordService;

/**
 * 打赏记录表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-21 15:17:45
 */
@Service("exceptionalRecordService")
public class ExceptionalRecordServiceImpl implements ExceptionalRecordService {
	/**
	 * exceptionalRecordDao层
	 * 
	 * @param params
	 * @return
	 */
	@Autowired
	private ExceptionalRecordDao exceptionalRecordDao;

	/**
	 * 活动与领队的关系
	 */
	@Autowired
	private ActivityLeaderRelationDao activityLeaderRelationDao;

	/**
	 * 查询分页
	 */
	@Override
	public List<ExceptionalVO> selectByExceptionalPeople(int pageNum, int pageSize, String userId) {
		// 使用分页插件实现分页
		PageHelper.startPage(pageNum, pageSize);
		// 调用dao的方法
		List<ExceptionalVO> list = exceptionalRecordDao.selectByExceptionalPeople(userId);

		return list;
	}

	/**
	 * 我的总金额
	 * 
	 * @param userId
	 * @return
	 */
	@Override
	public Integer getTotalAmount(String userId) {
		Integer totalAmount = exceptionalRecordDao.getTotalAmount(userId);
		return totalAmount;
	}

	/**
	 * 打赏领队
	 * 
	 * @param activityId
	 * @return
	 */
	@Override
	public List<LeaderInfoEntity> rewardLeader(String activityId) {
		return activityLeaderRelationDao.selectByActivityLeaderRelationByActivityId(activityId);
	}

	/**
	 * 打赏明细
	 * 
	 * @param pageNum
	 * @param pageSize
	 * @param activityId
	 * @return
	 */
	@Override
	public List<ExceptionalRecordEntity> rewardRecord(int pageNum, int pageSize, String activityId, String leaderId) {
		PageHelper.startPage(pageNum, pageSize);
		return exceptionalRecordDao.selectExceptionalRecordByActivityIdAndLeaderId(activityId, leaderId.split(","));
	}

}
