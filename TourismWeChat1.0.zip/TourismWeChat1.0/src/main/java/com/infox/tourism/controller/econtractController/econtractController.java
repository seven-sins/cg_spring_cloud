package com.infox.tourism.controller.econtractController;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.infox.tourism.entity.v2.econtract.ReqEcontract;
import com.infox.tourism.entity.v2.econtract.UserEcontract;
import com.infox.tourism.service.v2.EcontractService;
import com.infox.tourism.service.v2.UserEcontractService;
import com.infox.tourism.util.EncodeUtil;
import com.infox.tourism.util.R;
import com.infox.tourism.util.UUIDUtil;

import io.swagger.annotations.Api;

@Api(description = "申报合同")
@RequestMapping("/econtract")
@RestController
public class econtractController {
	@Autowired
	EcontractService econtractService;
	@Autowired
	UserEcontractService usercontractService;
	@Autowired
	RestTemplate restTemplate;
	
	static String appId = "80fbb1925abd525e1488a849ad3663cb";
	static String signKey = "205ed81b027f5983c8371c45f461400e";
		
	@PostMapping("/post/{eContactsId}")
	public R post(@PathVariable("eContactsId") String commonContactsId, @RequestBody ReqEcontract eContracts) {
		
//        String getnum = eContracts.getEcontrctnum();	
		
		//添加HttpHeader
		HttpHeaders requestHeaders = new HttpHeaders();
        requestHeaders.add("Content-Type", "application/json;charset=utf-8");   
        requestHeaders.add("x-12301-source", appId);
        requestHeaders.add("x-12301-key", appId);        
        requestHeaders.add("x-12301-version", "1.1.1");
        String timestamp = String.valueOf(new Date().getTime()/1000);
        requestHeaders.add("x-12301-timestamp",timestamp);
        //生成签名
        String signature = signKey + timestamp;
        String getSignature = EncodeUtil.md5EncryptBase64(signature);
        requestHeaders.add("x-12301-signature",getSignature);       
        
        //调用 - 申报合同
        //创建合同body
        JSONObject json = new JSONObject();
        json.put("ERPContractId", "BZHT-00001");     //旅行社自定合同号
        json.put("templateID", "E00001");           //模板ID  A00001 – 境内游， C00001 – 出境游， D00001 – 一日游，F00001 – 赴台游，E00001 – 代订代办

        //json.put("supplementaryClause", "r6757567567567");  //其他约定内容
        json.put("callbackURL", "http://bzt.fmcgnet.com/wechat/econtract/callback");    //回调地址
//        json.put("isMultiSignatory", true);         //是否多人签署
		
		//travelAgency 分段 旅行社信息
		JSONObject travelAgency = new JSONObject();		
		JSONObject agencyAddress = new JSONObject();
		agencyAddress.put("description", "广州暴走团国际旅行社有限公司");
		agencyAddress.put("country", "中国");
		agencyAddress.put("state", "广东省");
		agencyAddress.put("state", "广州市");
		agencyAddress.put("district", "天河区");
		agencyAddress.put("zip", "512000");
		
		travelAgency.put("agencyAddress",agencyAddress);		
		travelAgency.put("agencyName", "广州暴走团国际旅行社有限公司");
		travelAgency.put("businessLicenseNumber", "782718738173");  //工商注册号
		travelAgency.put("businessScope", "测试经营范围");
		travelAgency.put("transactorName", "于小辉");
		travelAgency.put("transactorPhone", "13581511618");
		travelAgency.put("travelAgencyLicenseNumber", "L-GD-100179");		
		
		travelAgency.put("contactName", "签约社联系人");
		travelAgency.put("contactPhone", "13527728211");              //签约社电话
		travelAgency.put("fax", "020-38668088");                             //传真
		travelAgency.put("email", "ocean@infox.com.cn");               //签约社联络人邮箱
		
		json.put("travelAgency", travelAgency);
		//
		
		
		//touristsInfo 分段  旅客列表信息
		JSONObject touristsInfo = new JSONObject();
		touristsInfo.put("adultNumber",1);     //成人数量
		touristsInfo.put("childNumber",1);     //小孩数量
		touristsInfo.put("totalNumber",2);     //总共数量
		JSONArray tourists = new JSONArray();     
		
		JSONObject tourist = new JSONObject();		
		JSONObject ID = new JSONObject();
		ID.put("IDNumber","009009001");         //证件编号
		ID.put("IDType","8");		            //证件类型 1：身份证，2：士官证，3：港澳通行证，4：护照，5：赴台证，6：回乡证，7：台胞证，8：其他
		tourist.put("gender","女");             //性别
		tourist.put("age",28);                  //年龄
		tourist.put("health","良好");            //健康状况
		tourist.put("isChild",false);           //是否小孩
		tourist.put("name","陈女士");            //姓名
		tourist.put("number",1);                //排序
		tourist.put("phone","13527728222");     //电话
		tourist.put("signer",true);             //是否签署人
		tourist.put("address","广州天河");        ///地址，当游客为签署人时，必填	
		tourists.add(tourist);		
		
		touristsInfo.put("tourists",tourists);
		json.put("touristsInfo", touristsInfo);
		//
		
		//签署人/游客代表 部分
		JSONObject signatory = new JSONObject();
		JSONObject sID = new JSONObject();
		sID.put("IDNumber","009009001");          //证件编号
		sID.put("IDType","8");	                  //证件类型		
		signatory.put("ID",sID);                  
		
		JSONObject address = new JSONObject();
		address.put("description","在水一方A区16栋3单元701");   //地址
		address.put("zip","066000");	                       //邮编
		signatory.put("address",address);                      //联系地址
		
		signatory.put("mode",1);                               //签约方式，1:短信签约，2:现场签约，3.线下签约
		
		signatory.put("name","Ocean");                         //代签者 ，企业经办人
		signatory.put("officePhone","0335-3113116");           //办公电话
		signatory.put("phone","13527728211");                  //联系电话
		signatory.put("signingPlace","广东");                  //签署地址
		signatory.put("phone","13527728211");                     //联系电话
		signatory.put("officePhone","020-380668088");               //固定电话
		signatory.put("companyName","*单位名称");               //单位名称
		signatory.put("email","ocean@infox.com.cn");                     //联系邮箱
		signatory.put("fax","020-38668088");                           //联系邮箱
		json.put("signatory", signatory);	
		//
		
		//导游部分
		JSONObject tourGuides = new JSONObject();
		tourGuides.put("name", "*导游姓名");                       //*导游姓名
		tourGuides.put("phone", "13527728211");                              //*导游电话
		tourGuides.put("tourGuideID", "*导游证号");                //*导游证号
		json.put("tourGuides", tourGuides);		
		
		
		//费用部分
		JSONObject cost = new JSONObject();
		cost.put("adultCost", 5500);                           //成人费用
		cost.put("childCost", 3000); 				            //儿童费用
		cost.put("guideServiceCost", 800); 				        //导游服务费用
		cost.put("singleSupplementCost", 800); 				    //单间差费用
		cost.put("totalCost", 6000); 		        		    //总费用
		cost.put("totalMealCost", 500); 		        		//餐饮费用
		cost.put("paymentDeadline", "2019-09-01"); 		        //费用缴纳期限
		cost.put("paymentTime", "2019-08-01"); 		        	//支付时间
		cost.put("paymentMethod", 3); 		                	//支付方式 1：现金 2：转账 3：线上支付
		cost.put("excludeNote", "团费不包含内容"); 	           	//团费不包含内容的备注
		cost.put("paymentDescription", "费用支付说明"); 	        //费用支付说明
		
//		JSONObject fullPayment = new JSONObject();
//		fullPayment.put("deadline", "2019-09-01");     //
//		cost.put("fullPayment", fullPayment);
		
		json.put("cost", cost);
		//	
		
		//保险部分
		JSONObject insurance = new JSONObject();
		insurance.put("purchaseMethod", 1);          //保险购买方式 1：委托旅行社购买，2：自行购买，3：放弃购买，4：同意旅行社赠送人身意外保险
		insurance.put("productName", "保险产品名称");  //保险产品名称
		insurance.put("company", "保险公司名称");      //保险公司名称		
		json.put("insurance", insurance);
		
		//争议解决部分
		JSONObject dispute = new JSONObject();
		dispute.put("resolution", 1);                 //解决办法 1：提交仲裁委员会仲裁 2：向人民法院提起诉讼
		dispute.put("tribunalName", "*仲裁委员会名称");  //仲裁委员会名称
		dispute.put("courtName", "*法院名称");  
		json.put("dispute", dispute);
		
		//自费项目
		JSONObject activities = new JSONObject();
		activities.put("date", "2019-10-01");         //日期 ， YYYY-MM-DD
		activities.put("place", "*地点");             //地点
		activities.put("item", "*项目");              //地点
		activities.put("fee", 100);                   //费用
		activities.put("stayDuration", "1小时");       //最长停留时间 
		activities.put("memo", "*其他说明");           //其他说明
		json.put("activities", activities);
		
		//购物部分
	    json.put("hasShopping", false);               //是否含购
	    json.put("shoppingViewSpot", "*购物景点名称"); //购物景点名称
	    JSONObject shoppings = new JSONObject();
	    shoppings.put("date", "2019-10-01");           //日期，YYYY-MM-DD
	    shoppings.put("place", "*购物地点");           //购物地点
	    shoppings.put("shoppingPlace", "*购物场所名称");           //购物场所名称
	    shoppings.put("goods", "*主要商品信息");         //主要商品信息
	    shoppings.put("stayDuration", "*最长停留时间");  //最长停留时间
	    shoppings.put("memo", "*其他说明");              //其他说明
	    json.put("shoppings", shoppings);
	    
	    //成团约定
	    JSONObject groupAgreement = new JSONObject();
	    groupAgreement.put("resolution", 3);    //如不能成团的其他解决办法，1: 委托其他社，2: 延期出团，3: 改签其他路线，4: 解除合同
	    groupAgreement.put("leastCustomerNumber", 3);      //最低成团人数
	    groupAgreement.put("agreeToTransfer", true);      //是否同意委托其它社组团
	    groupAgreement.put("transferToCompanyName", "");   //受委托社信息，如果有必填	    
	    groupAgreement.put("agreeToDelay", true);         //是否同意延期
	    groupAgreement.put("agreeToChangeLine", true);         //是否同意改为其它线路
	    groupAgreement.put("agreeToTerminate", true);         //是否同意解除合同
	    groupAgreement.put("agreeToMerge", true);              //是否同意拼团
	    groupAgreement.put("mergeToCompanyName", "*拼团旅行社名称");         //拼团旅行社名称，如果有必填    
	    json.put("groupAgreement", groupAgreement);
	    
	    //委托事项
	    JSONObject entrustment = new JSONObject();	    
	    JSONObject order = new JSONObject();
	    JSONArray airTickets = new JSONArray();
	    JSONObject airTicket = new JSONObject();	    
	    airTicket.put("totalCostTax", 100);                   //总税费（单位：元）
	    airTicket.put("totalCount", 30);                      //机票总张数
	    airTicket.put("totalCost", 3000);                     //机票总价
	    airTicket.put("memo", "");                            //其他说明
	    JSONArray flights = new JSONArray();                  //航班
	    JSONObject flight = new JSONObject();                 
	    flight.put("departureTime", "2019-10-01");             //出发日期，YYYY-MM-DD
	    flight.put("arrivalTime", "2019-10-21");               //返回日期，YYYY-MM-DD
	    flight.put("tripType", 2);                             //1单程 2往返 允许值1，2
	    flight.put("totalNumber", 2);                          //单条预定张数
	    JSONObject source = new  JSONObject();
	    source.put("description", "*出发城市");                 //出发城市
	    flight.put("source", source);         
	    JSONObject destination = new  JSONObject();
	    destination.put("description", "*到达城市");            //到达城市
	    flight.put("destination", destination);          
	    flights.add(flight);
	    airTicket.put("flights", flights);
	    airTickets.add(airTicket);
	    order.put("airTickets", airTickets);
	    
	    JSONObject accommodation = new JSONObject();			//酒店预订代办
	    accommodation.put("totalPrice", 300);					//酒店费用合计
	    accommodation.put("memo", "*酒店预订其他说明");          //酒店预订其他说明
	    
	    JSONObject accommodations = new JSONObject();           //酒店信息
	    accommodations.put("name", "*酒店名称");                 //酒店名称
	    JSONObject a_address = new JSONObject();
	    address.put("description", "*地址");		                //酒店地址
	    address.put("country", "国家/城市"); 					//酒店城市
	    accommodations.put("address", a_address);               //地址信息
	    accommodations.put("checkInDate", "2019-10-01");        //入住日期
	    accommodations.put("checkOutDate", "2019-10-11");       //离开日期
	    accommodations.put("roomType", 101);               //房型  ？？？？？
	    accommodations.put("rooms", 3);                         //数量
	    accommodations.put("roomPrice", 500);	                //单价
	    accommodation.put("accommodations", accommodations);
	    order.put("accommodation", accommodation);
	    
	    
	    JSONObject transportService = new JSONObject();          //用车代办
	    transportService.put("totalNumber", 5);                  //用车总数量
	    transportService.put("totalCost", 50);                  //用车总费用
	    transportService.put("memo", "*用车服务其他说明");       //用车服务其他说明
	    
	    JSONObject transportServices = new JSONObject();        //用车
	    transportServices.put("time", "2019-10-01");            //服务日期
	    transportServices.put("model", "*车型");                //*车型
	    transportServices.put("passengerNumber", 10);           //*乘客人数
	    transportServices.put("serviceType", 1);           //服务类型 1接送机单程 2接送机往返 99其他
	    transportServices.put("cost", 100);                //单价
	    
	    JSONObject ts_source = new JSONObject();
	    ts_source.put("description", "出发地");             //出发地
	    transportServices.put("source", ts_source); 
	    JSONObject ts_destination = new JSONObject();
	    ts_destination.put("description", "目的地");        //目的地
	    transportServices.put("destination", ts_destination); 	    
	    transportService.put("transportServices", transportServices);	    
	    order.put("transportService", transportService);
	    
	    
	    
	    JSONObject tourGuideService = new JSONObject();     //导游服务代办
	    tourGuideService.put("totalNumber", 10);            //导游总人数
	    tourGuideService.put("totalCost", 1000);            //导游费用合计
	    tourGuideService.put("memo", "*导游服务其他说明");   //导游服务其他说明
	    
	    JSONObject tourGuideServices = new JSONObject();    //导游服务
	    tourGuideServices.put("time", "2019-08-22");        //服务日期
	    tourGuideServices.put("languages", "中文");         //语种
	    tourGuideServices.put("gender", 1);                 //性别0男 1女
	    tourGuideServices.put("totalNumber", 1);            //数量	    
	    tourGuideService.put("tourGuideServices", tourGuideServices);
	    order.put("tourGuideService", tourGuideService);
	    
	    
	    JSONObject visaService = new JSONObject();          //签证代办
	    visaService.put("totalNumber", 3);                  //办理人数
	    visaService.put("totalCost", 300);                  //办理总费用
	    visaService.put("memo", "*代办签证其他说明");         //代办签证其他说明
	    visaService.put("visaDeadline","2019-10-10" );         //签证资料提交最终期限
	    
	    JSONObject visaServices = new JSONObject();
	    visaServices.put("type", 1);                           //服务类型 1签证 2签注 3入台证
	    visaServices.put("reason","*前往事由");                 //前往事由
	    visaServices.put("time","2019-10-18");                  //*签注日期
	    visaServices.put("entryTime",1);                        //入境次数
	    visaServices.put("weekdayNumber",10);                   //签注工作日
	    visaServices.put("departureTime","2019-10-12");         //预计出行日期
	    visaServices.put("cost",300);                           //费用
	    JSONObject v_address = new JSONObject();                //地址	    
	    v_address.put("country", "美国");                       //国家/地区
	    visaServices.put("address", v_address);	    
	    visaService.put("visaServices", visaServices);
	    order.put("visaService", visaService);
	    
	    JSONObject otherService = new JSONObject();              //其他服务
	    otherService.put("item", "*服务内容");                   //服务内容
	    otherService.put("totalNumber", 11);                     //办理人数	    
	    order.put("otherService", otherService);     
	    order.put("totalCost", 1100);                           //办理费用合计
	    
	    JSONObject clauses = new JSONObject();
	    clauses.put("item", "*条款名称");                        //条款名称
	    clauses.put("hint", "*条款具体提示");                    //条款具体提示
	    
	    
	    entrustment.put("order", order);
	    entrustment.put("clauses", clauses);
	    
	    json.put("entrustment", entrustment);
	    
	    
	    
	    
	    
	    
	    
	    
		System.out.println(json);		
		
		JSONArray array = new JSONArray();
		array.add(json);		        
//      HttpEntity<JSONArray> requestEntity = new HttpEntity<JSONArray>(array, requestHeaders);
		
		HttpEntity<JSONObject> requestEntity = new HttpEntity<JSONObject>(json, requestHeaders);
		ResponseEntity<String> result = restTemplate.postForEntity("http://api.12301e.com/v1/econtract/apply/EBR2US14V18G", requestEntity, String.class);		

	    System.out.println(result.getBody());
		
		JSONObject rspobject =	JSONObject.parseObject(result.getBody());
		
		JSONObject data = rspobject.getJSONObject("data");	
		if(data!=null) {
			String QRCodeURL = data.getString("QRCodeURL");
			String viewURL = data.getString("viewURL");
			String contractNumber = data.getString("contractNumber");
			String fileURL = data.getString("fileURL");
			String signingURL = data.getString("signingURL");
			
			
			UserEcontract uEcontract = new UserEcontract();
			uEcontract.setUserEcontractid(UUIDUtil.create());
			uEcontract.setQrcodeUrl(QRCodeURL);
			uEcontract.setViewUrl(viewURL);
			uEcontract.setContractNumber(contractNumber);
			uEcontract.setFileUrl(fileURL);
			uEcontract.setSigningUrl(signingURL);
			uEcontract.setCreateTime(new Date());
			uEcontract.setState(1);
			
			usercontractService.insert(uEcontract);
			
			
		}
//		String message = data.getString("message");
		
		
		
//		return new Result<>();
		return R.ok().put("impdata", json).put("data", rspobject);
		
		
	}
}

