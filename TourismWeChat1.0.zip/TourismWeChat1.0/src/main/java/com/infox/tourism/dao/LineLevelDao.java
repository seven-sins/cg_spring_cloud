package com.infox.tourism.dao;

import com.infox.tourism.entity.LineLevelEntity;
import com.infox.tourism.entity.vo.lineVO.LineLevelVO;
import org.apache.ibatis.annotations.Mapper;
import tk.mybatis.mapper.common.BaseMapper;

import java.util.List;

/**
 * 路线等级表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-06 17:10:28
 */
@Mapper
public interface LineLevelDao extends BaseMapper<LineLevelEntity> {

    List<LineLevelVO> selectTop5LineLevel();

}
