package com.infox.tourism.service;

import java.util.Map;

import com.infox.common.base.BaseService;
import com.infox.tourism.entity.PayHistoryEntity;

/**
  * 支付历史记录
 * @author Tan Ling
 * 2018年12月11日 下午8:52:21
 */
public interface PayHistoryService extends BaseService<PayHistoryEntity> {

	/**
	 * 插入交易记录
	 * @param map
	 */
	public void insert(Map<String, ?> map);
}
