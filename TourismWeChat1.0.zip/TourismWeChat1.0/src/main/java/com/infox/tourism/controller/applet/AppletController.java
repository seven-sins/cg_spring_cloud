package com.infox.tourism.controller.applet;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSONObject;
import com.infox.common.utils.Assert;
import com.infox.common.utils.redis.RedisConstant;
import com.infox.common.utils.redis.RedisDistributedLock;
import com.infox.common.utils.redis.RedisService;
import com.infox.common.utils.response.Result;
import com.infox.common.wechat.utils.AppletProperties;
import com.infox.tourism.entity.UserInfoEntity;
import com.infox.tourism.entity.applet.AppletUser;
import com.infox.tourism.service.UserInfoService;
import com.infox.tourism.util.R;
import com.infox.tourism.util.UUIDUtil;

/**
 * 小程序
 * @author Tan Ling
 * @date 2019年6月18日 下午1:54:38
 */
@RestController
public class AppletController {
	static final String LOCK_KEY_PREFIX = "lock_";
	private static final Logger LOG = Logger.getLogger(AppletController.class);
	@Autowired
	private AppletProperties appletProperties;
	@Autowired
	private RestTemplate restTemplate;
	@Autowired
	private RedisService redisService;
	@Autowired
	private UserInfoService userInfoService;
	@Autowired
	private RedisDistributedLock redisDistributedLock;
	/**
	 * 创建小程序用户
	 * @author Tan Ling
	 * @date 2019年6月18日 下午1:45:11
	 * @param appletUser
	 * @return
	 */
	@PostMapping("/applet/user/create")
	public Result<?> appletUserCreate(@Valid @RequestBody AppletUser appletUser, HttpServletRequest request){
		String token = request.getHeader("token");
		Assert.notEmpty(token, "token不能为空");
		/**
		 * 使用分布式事务控制
		 */
		redisDistributedLock.get(LOCK_KEY_PREFIX + token, null);
		UserInfoEntity user = userInfoService.insertAppletUser(appletUser);
		redisService.add(RedisConstant.WECHAT_OPENID_PREFIX + token, appletUser.getUnionid());
		/**
		 * 释放锁
		 */
		redisDistributedLock.release(LOCK_KEY_PREFIX + token);
		
		return new Result<>(user);
	}
	
	@GetMapping("/loginIn")
	public R getOpenId(String code) throws IOException {
		LOG.info("=============(applet)code: " + code);
		String openIdUrl = String.format(appletProperties.getAppletUserUrl(), appletProperties.getAppId(), appletProperties.getAppSecret(), code);
		ResponseEntity<String> result = restTemplate.postForEntity(openIdUrl, null, String.class);
		Assert.notNull(result, "=============(applet)获取access_token失败...");
		
		JSONObject json = JSONObject.parseObject(result.getBody());
		LOG.info("==========获取unionid: " + json);
		// Assert.isTrue(json.containsKey("unionid"), "=============(applet)获取unionid失败, unionid为空...");
		/**
		 * 生成缓存token(缓存有效时间6小时)  6小时 = 240分
		 */
		String token = UUIDUtil.create();
		// 缓存unionid    RedisConstant.WECHAT_OPENID_PREFIX + token
		redisService.add(RedisConstant.WECHAT_OPENID_PREFIX + token, json.getString("unionid"));
		
		return R.ok().put("data", json).put("token", token);
	}
}
