package com.infox.tourism.dao;

import com.infox.tourism.entity.vo.activityDetailVO.LineEvaluationVO;
import com.infox.tourism.entity.vo.baseVo.CommentVO;
import org.apache.ibatis.annotations.Mapper;

import com.infox.tourism.entity.EvaluationEntity;
import com.infox.tourism.entity.vo.evaluation.EvaluationVO;

import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.BaseMapper;

import java.util.List;

/**
 * 评价表
 *
 * @author cenjinxing
 * @email Venus@163.com
 * @date 2018-11-15 11:31:27
 */
@Mapper
public interface EvaluationDao extends BaseMapper<EvaluationEntity> {

    /**
     * 根据openid查询评价
     * @param userId
     * @return
     */
    List<EvaluationVO> selectByUserId(String userId);

    /**
     * 线路的评价汇总
     * @param lineId
     * @return
     */
    LineEvaluationVO selectEvaluationByLineId (String lineId);

    /**
     *查 出线路的所有评价
     * @param lineId
     * @return
     */
    List<CommentVO> selectCommonListByLineId(String lineId);

    /**
     * 根据活动id查询评价详情
     * @param activityId
     * @return
     */
    EvaluationEntity selectEvaluationByActivityId(@Param("userId") String userId, @Param("activityId") String activityId);

    /**
     * 根据活动id查询评价详情
     * @param activityId
     * @return
     */
    Integer selectEvaluationStatusByActivityId(@Param("activityId") String activityId);
}
